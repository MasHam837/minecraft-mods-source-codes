package mh837.gile.client;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModItems;
import mh837.gile.GileModTags;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagsProvider;
import net.minecraft.core.HolderLookup;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Items;

import java.util.concurrent.CompletableFuture;

public class GileModItemTagsProvider extends FabricTagsProvider.ItemTagsProvider {

    public GileModItemTagsProvider(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void addTags(HolderLookup.Provider wrapperLookup) {
        // === Custom Item Tags ===
        // Wish Table
        valueLookupBuilder(GileModTags.Items.WISH_INPUT).add(GileModBlocks.WISH.asItem());
        valueLookupBuilder(GileModTags.Items.SIGIL_INPUT).add(GileModItems.ANEMO_SIGIL, GileModItems.GEO_SIGIL, GileModItems.ELECTRO_SIGIL,
                GileModItems.DENDRO_SIGIL, GileModItems.HYDRO_SIGIL, GileModItems.PYRO_SIGIL, GileModItems.CRYO_SIGIL, GileModItems.LUNA_SIGIL);
        // Tools
        valueLookupBuilder(GileModTags.Items.ENDERITE_TOOL_MATERIALS).add(GileModItems.ENDERITE_INGOT);
        valueLookupBuilder(GileModTags.Items.ENDERITE_MINING_TOOLS).add(Items.NETHERITE_PICKAXE, GileModItems.ENDERITE_PICKAXE);
        // Weapons
        valueLookupBuilder(GileModTags.Items.ELEMENTAL_WEAPON)
                .add(GileModItems.DAYBREAK_CHRONICLES).add(GileModItems.VORTEX_VANQUISHER)
                .add(GileModItems.ENGULFING_LIGHTNING).add(GileModItems.THOUSAND_FLOATING_DREAMS)
                .add(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS).add(GileModItems.THOUSAND_BLAZING_SUNS)
                .add(GileModItems.HIEMAL_MANDATE).add(GileModItems.NOCTURNES_CURTAIN_CALL);
        valueLookupBuilder(GileModTags.Items.LEGENDARY_WEAPON)
                .add(GileModItems.TOME_OF_NABERIUS).add(GileModItems.PALM_OF_ASMODAY)
                .add(GileModItems.HOURGLASS_OF_ISTAROTH).add(GileModItems.SCYTHE_OF_RONOVA);
        valueLookupBuilder(GileModTags.Items.PRIMORDIAL_WEAPON)
                .add(GileModItems.PHANES_BLADE);

        // === Block Items ===
        // Wood
        valueLookupBuilder(ItemTags.LOGS_THAT_BURN)
                .add(GileModBlocks.GHOSTLY_LOG.asItem()).add(GileModBlocks.STRIPPED_GHOSTLY_LOG.asItem())
                .add(GileModBlocks.GHOSTLY_WOOD.asItem()).add(GileModBlocks.STRIPPED_GHOSTLY_WOOD.asItem())
                        .add(GileModBlocks.INVERTED_OAK_LOG.asItem()).add(GileModBlocks.STRIPPED_INVERTED_OAK_LOG.asItem())
                        .add(GileModBlocks.INVERTED_OAK_WOOD.asItem()).add(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD.asItem());
        // Planks
        valueLookupBuilder(ItemTags.PLANKS).add(GileModBlocks.GHOSTLY_PLANKS.asItem()).add(GileModBlocks.INVERTED_OAK_PLANKS.asItem());
        valueLookupBuilder(ItemTags.WOODEN_SLABS).add(GileModBlocks.GHOSTLY_SLAB.asItem()).add(GileModBlocks.INVERTED_OAK_SLAB.asItem());
        valueLookupBuilder(ItemTags.WOODEN_STAIRS).add(GileModBlocks.GHOSTLY_STAIRS.asItem()).add(GileModBlocks.INVERTED_OAK_STAIRS.asItem());
        valueLookupBuilder(ItemTags.WOODEN_FENCES).add(GileModBlocks.GHOSTLY_FENCE.asItem()).add(GileModBlocks.INVERTED_OAK_FENCE.asItem());
        valueLookupBuilder(ItemTags.WOODEN_DOORS).add(GileModBlocks.GHOSTLY_DOOR.asItem()).add(GileModBlocks.INVERTED_OAK_DOOR.asItem());
        valueLookupBuilder(ItemTags.WOODEN_TRAPDOORS).add(GileModBlocks.GHOSTLY_TRAPDOOR.asItem()).add(GileModBlocks.INVERTED_OAK_TRAPDOOR.asItem());
        valueLookupBuilder(ItemTags.WOODEN_BUTTONS).add(GileModBlocks.GHOSTLY_BUTTON.asItem()).add(GileModBlocks.INVERTED_OAK_BUTTON.asItem());
        valueLookupBuilder(ItemTags.WOODEN_PRESSURE_PLATES).add(GileModBlocks.GHOSTLY_PRESSURE_PLATE.asItem()).add(GileModBlocks.INVERTED_OAK_PRESSURE_PLATE.asItem());
        // Signs
        valueLookupBuilder(ItemTags.SIGNS).add(GileModItems.GHOSTLY_SIGN_ITEM).add(GileModItems.INVERTED_OAK_SIGN_ITEM);
        valueLookupBuilder(ItemTags.HANGING_SIGNS).add(GileModItems.GHOSTLY_HANGING_SIGN_ITEM).add(GileModItems.INVERTED_OAK_HANGING_SIGN_ITEM);
        // Plants
        valueLookupBuilder(ItemTags.SMALL_FLOWERS).add(GileModBlocks.MOON_FLOWER.asItem()).add(GileModBlocks.GLOOMY_FLOWER.asItem()).add(GileModBlocks.DRY_FLOWER.asItem());

        // === Combat / Equipment ===
        // Fate Sword
        valueLookupBuilder(ItemTags.SWORDS).add(GileModItems.FATE_SWORD);
        valueLookupBuilder(ItemTags.DURABILITY_ENCHANTABLE).add(GileModItems.FATE_SWORD);
        valueLookupBuilder(ItemTags.VANISHING_ENCHANTABLE).add(GileModItems.FATE_SWORD);
        // Fate Bow
        valueLookupBuilder(ItemTags.BOW_ENCHANTABLE).add(GileModItems.FATE_BOW);
        valueLookupBuilder(ItemTags.DURABILITY_ENCHANTABLE).add(GileModItems.FATE_BOW);
        valueLookupBuilder(ItemTags.VANISHING_ENCHANTABLE).add(GileModItems.FATE_BOW);
        // Tools
        valueLookupBuilder(ItemTags.SWORDS).add(GileModItems.ENDERITE_SWORD); valueLookupBuilder(ItemTags.SPEARS).add(GileModItems.ENDERITE_SPEAR);
        valueLookupBuilder(ItemTags.DURABILITY_ENCHANTABLE)
                .add(GileModItems.SHRINKER).add(GileModItems.ENLARGER)
                .add(GileModItems.JELLY_ON_A_STICK).add(GileModItems.GRAPPLING_HOOK).add(GileModItems.FLUTTERER)
                .add(GileModItems.ENDERITE_AXE).add(GileModItems.ENDERITE_SWORD).add(GileModItems.ENDERITE_SPEAR)
                .add(GileModItems.ENDERITE_SHOVEL).add(GileModItems.ENDERITE_PICKAXE).add(GileModItems.ENDERITE_HOE);
        valueLookupBuilder(ItemTags.VANISHING_ENCHANTABLE)
                .add(GileModItems.SHRINKER).add(GileModItems.ENLARGER)
                .add(GileModItems.JELLY_ON_A_STICK).add(GileModItems.GRAPPLING_HOOK).add(GileModItems.FLUTTERER)
                .add(GileModItems.ENDERITE_AXE).add(GileModItems.ENDERITE_SWORD).add(GileModItems.ENDERITE_SPEAR)
                .add(GileModItems.ENDERITE_SHOVEL).add(GileModItems.ENDERITE_PICKAXE).add(GileModItems.ENDERITE_HOE);
        valueLookupBuilder(ItemTags.PICKAXES).add(GileModItems.ENDERITE_PICKAXE); valueLookupBuilder(ItemTags.AXES).add(GileModItems.ENDERITE_AXE);
        valueLookupBuilder(ItemTags.SHOVELS).add(GileModItems.ENDERITE_SHOVEL);  valueLookupBuilder(ItemTags.HOES).add(GileModItems.ENDERITE_HOE);

        // Armor
        valueLookupBuilder(ItemTags.TRIMMABLE_ARMOR).add(GileModItems.ENDERITE_HELMET).add(GileModItems.ENDERITE_CHESTPLATE).add(GileModItems.ENDERITE_LEGGINGS).add(GileModItems.ENDERITE_BOOTS);
        valueLookupBuilder(ItemTags.ARMOR_ENCHANTABLE).add(GileModItems.ENDERITE_HELMET).add(GileModItems.ENDERITE_CHESTPLATE).add(GileModItems.ENDERITE_LEGGINGS).add(GileModItems.ENDERITE_BOOTS);
        valueLookupBuilder(ItemTags.DURABILITY_ENCHANTABLE).add(GileModItems.ENDERITE_HELMET).add(GileModItems.ENDERITE_CHESTPLATE).add(GileModItems.ENDERITE_LEGGINGS).add(GileModItems.ENDERITE_BOOTS);
        valueLookupBuilder(ItemTags.VANISHING_ENCHANTABLE).add(GileModItems.ENDERITE_HELMET).add(GileModItems.ENDERITE_CHESTPLATE).add(GileModItems.ENDERITE_LEGGINGS).add(GileModItems.ENDERITE_BOOTS);
        valueLookupBuilder(ItemTags.CHEST_ARMOR_ENCHANTABLE).add(GileModItems.ENDERITE_CHESTPLATE);

        // === ELEMENTAL ===
        // Bows
        valueLookupBuilder(ItemTags.BOW_ENCHANTABLE)
                .add(GileModItems.DAYBREAK_CHRONICLES);
        // Spears
        valueLookupBuilder(ItemTags.SPEARS)
                .add(GileModItems.VORTEX_VANQUISHER)
                .add(GileModItems.ENGULFING_LIGHTNING)
                .add(GileModItems.SCYTHE_OF_RONOVA);
        // Catalysts
        valueLookupBuilder(ItemTags.WEAPON_ENCHANTABLE)
        .add(GileModItems.THOUSAND_FLOATING_DREAMS)
        .add(GileModItems.NOCTURNES_CURTAIN_CALL)
        .add(GileModItems.TOME_OF_NABERIUS)
        .add(GileModItems.PALM_OF_ASMODAY)
        .add(GileModItems.HOURGLASS_OF_ISTAROTH);
        // Swords
        valueLookupBuilder(ItemTags.SWORDS)
                .add(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS)
                .add(GileModItems.THOUSAND_BLAZING_SUNS)
                .add(GileModItems.HIEMAL_MANDATE)
                .add(GileModItems.PHANES_BLADE);

    }
}