package mh837.gile.client.renderer.blockentity.state;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;

public class WishTableRenderState extends BlockEntityRenderState {

    public ItemStackRenderState sigil = new ItemStackRenderState();
}