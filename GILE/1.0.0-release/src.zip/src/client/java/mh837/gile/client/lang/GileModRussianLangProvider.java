package mh837.gile.client.lang;

import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.core.HolderLookup;

import java.util.concurrent.CompletableFuture;

public final class GileModRussianLangProvider extends FabricLanguageProvider {

    public GileModRussianLangProvider(
            FabricPackOutput output,
            CompletableFuture<HolderLookup.Provider> lookup
    ) {
        super(output, "ru_ru", lookup);
    }

    @Override
    public void generateTranslations(
            HolderLookup.Provider lookup,
            TranslationBuilder t
    ) {
        GileModRussianTextProvider.advancements(t);
        GileModRussianTextProvider.tooltips(t);
        GileModRussianTextProvider.messages(t);
        GileModRussianTextProvider.keybinds(t);
        GileModRussianTextProvider.sounds(t);
        GileModRussianTextProvider.misc(t);

        GileModRussianNamesProvider.items(t);
        GileModRussianNamesProvider.blocks(t);
        GileModRussianNamesProvider.entities(t);
        GileModRussianNamesProvider.effects(t);
    }
}