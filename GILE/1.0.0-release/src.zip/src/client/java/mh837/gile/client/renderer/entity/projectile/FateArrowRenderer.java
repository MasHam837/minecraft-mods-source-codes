package mh837.gile.client.renderer.entity.projectile;

import mh837.gile.entity.projectile.FateArrowEntity;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.ArrowRenderState;
import net.minecraft.resources.Identifier;

public class FateArrowRenderer extends ArrowRenderer<FateArrowEntity, ArrowRenderState> {

    public static final Identifier TEXTURE = Identifier.fromNamespaceAndPath("gilemod", "textures/entity/projectiles/fate_arrow.png");

    public FateArrowRenderer(EntityRendererProvider.Context context) {super(context);}

    @Override
    public ArrowRenderState createRenderState() {return new ArrowRenderState();}

    @Override
    protected Identifier getTextureLocation(ArrowRenderState state) {
        return TEXTURE;
    }

}