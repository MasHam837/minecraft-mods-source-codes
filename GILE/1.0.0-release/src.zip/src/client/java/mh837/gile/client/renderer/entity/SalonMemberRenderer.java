package mh837.gile.client.renderer.entity;

import mh837.gile.GileMod;
import mh837.gile.client.model.CrabalettaModel;
import mh837.gile.client.model.ChevalmarinModel;
import mh837.gile.client.model.UsherModel;
import mh837.gile.client.renderer.state.SalonMembersRenderState;
import mh837.gile.entity.SalonMemberEntity;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;

public class SalonMemberRenderer extends MobRenderer<
        SalonMemberEntity,
        SalonMembersRenderState,
        EntityModel<SalonMembersRenderState>
        > {

    private static final Identifier USHER_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/salon_members/usher.png"
            );

    private static final Identifier CHEVALMARIN_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/salon_members/chevalmarin.png"
            );

    private static final Identifier CRABALETTA_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/salon_members/crabaletta.png"
            );

    private final UsherModel usherModel;
    private final ChevalmarinModel chevalmarinModel;
    private final CrabalettaModel crabalettaModel;

    public SalonMemberRenderer(
            EntityRendererProvider.Context context
    ) {
        super(
                context,
                new UsherModel(
                        context.bakeLayer(UsherModel.LAYER)
                ),
                0.5F
        );

        this.usherModel =
                new UsherModel(
                        context.bakeLayer(UsherModel.LAYER)
                );

        this.chevalmarinModel =
                new ChevalmarinModel(
                        context.bakeLayer(ChevalmarinModel.LAYER)
                );

        this.crabalettaModel =
                new CrabalettaModel(
                        context.bakeLayer(CrabalettaModel.LAYER)
                );
    }

    @Override
    public SalonMembersRenderState createRenderState() {
        return new SalonMembersRenderState();
    }

    @Override
    public void extractRenderState(
            SalonMemberEntity entity,
            SalonMembersRenderState state,
            float partialTick
    ) {
        super.extractRenderState(
                entity,
                state,
                partialTick
        );

        state.memberIndex =
                entity.getMemberIndex();

        state.scale =
                entity.getMemberScale();

        state.modelType =
                entity.getModelType();
    }

    @Override
    public void submit(
            SalonMembersRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState camera
    ) {
        EntityModel<SalonMembersRenderState> selectedModel =
                switch (state.memberIndex) {

                    case SalonMemberEntity.MODEL_CHEVALMARIN ->
                            this.chevalmarinModel;

                    case SalonMemberEntity.MODEL_CRABALETTA ->
                            this.crabalettaModel;

                    case SalonMemberEntity.MODEL_USHER ->
                            this.usherModel;

                    default ->
                            this.usherModel;
                };

        EntityModel<SalonMembersRenderState> oldModel =
                this.model;

        this.model = selectedModel;

        try {
            /*
             * Let MobRenderer/LivingEntityRenderer perform all
             * normal model transforms, animation, rotation, scale,
             * shadows, layers, etc.
             */
            super.submit(
                    state,
                    poseStack,
                    submitNodeCollector,
                    camera
            );
        } finally {
            this.model = oldModel;
        }
    }

    @Override
    public Identifier getTextureLocation(
            SalonMembersRenderState state
    ) {
        return switch (state.memberIndex) {

            case SalonMemberEntity.MODEL_CHEVALMARIN ->
                    CHEVALMARIN_TEXTURE;

            case SalonMemberEntity.MODEL_CRABALETTA ->
                    CRABALETTA_TEXTURE;

            case SalonMemberEntity.MODEL_USHER ->
                    USHER_TEXTURE;

            default ->
                    USHER_TEXTURE;
        };
    }
}