package mh837.gile.client.renderer.blockentity;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.GileMod;
import mh837.gile.block.GlitterJarBlock;
import mh837.gile.block.entity.GlitterJarBlockEntity;
import mh837.gile.client.model.GlitterModel;
import mh837.gile.client.model.layer.GlitterModelLayer;
import mh837.gile.client.renderer.blockentity.state.GlitterJarRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class GlitterJarRenderer
        implements BlockEntityRenderer<
        GlitterJarBlockEntity,
        GlitterJarRenderState> {

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/glitter.png"
            );

    private final GlitterModel model;

    public GlitterJarRenderer(
            BlockEntityRendererProvider.Context context
    ) {
        ModelPart root =
                context.bakeLayer(
                        GlitterModelLayer.GLITTER_LAYER
                );

        this.model = new GlitterModel(root);
    }

    @Override
    public GlitterJarRenderState createRenderState() {
        return new GlitterJarRenderState();
    }

    @Override
    public void extractRenderState(
            GlitterJarBlockEntity blockEntity,
            GlitterJarRenderState state,
            float tickProgress,
            Vec3 cameraPos,
            ModelFeatureRenderer.CrumblingOverlay crumblingOverlay
    ) {
        BlockEntityRenderer.super.extractRenderState(
                blockEntity,
                state,
                tickProgress,
                cameraPos,
                crumblingOverlay
        );

        state.glitterCount =
                blockEntity.getBlockState()
                        .getValue(GlitterJarBlock.GLITTERS);

        if (blockEntity.getLevel() != null) {
            state.age =
                    blockEntity.getLevel().getGameTime()
                            + tickProgress;
        }
    }

    @Override
    public void submit(
            GlitterJarRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState cameraState
    ) {
        for (int i = 0; i < state.glitterCount; i++) {

            poseStack.pushPose();

            /*
             * Move from block coordinates to the center
             * of the jar.
             */
            poseStack.translate(
                    0.5F,
                    0.25F,
                    0.5F
            );

            /*
             * Each Glitter gets its own position.
             */
            float angle =
                    (Mth.TWO_PI / state.glitterCount) * i;

            float radius = 0.22F;

            float x =
                    Mth.cos(angle) * radius;

            float z =
                    Mth.sin(angle) * radius;

            float verticalOffset =
                    (i - (state.glitterCount - 1) / 2.0F) * 0.18F;

            float y =
                    0.10F
                            + Mth.sin(
                            state.age * 0.05F + i
                    ) * 0.06F;

            poseStack.translate(
                    x,
                    y - 1.25F + verticalOffset,
                    z
            );

            /*
             * Jar-sized Glitter.
             */
            poseStack.scale(
                    1.0F,
                    1.0F,
                    1.0F
            );

            LivingEntityRenderState glitterState =
                    new LivingEntityRenderState();

            /*
             * Each Glitter gets a different phase in the rainbow.
             *
             * One complete rainbow cycle = 100 ticks because
             * GlitterRenderer uses ageInTicks * 0.01F.
             */
            float rainbowCycleTicks = 100.0F;

            float rainbowOffset =
                    (rainbowCycleTicks / state.glitterCount) * i;

            glitterState.ageInTicks =
                    state.age + rainbowOffset;

            model.setupAnim(glitterState);

            /*
             * Calculate this Glitter's individual rainbow color.
             */
            int tint =
                    getRainbowTint(
                            glitterState.ageInTicks
                    );

            /*
             * IMPORTANT:
             *
             * Use the FULL submitModel overload.
             *
             * This preserves GlitterModel's entityTranslucent
             * RenderType while allowing us to supply our tint.
             */
            collector.submitModel(
                    model,
                    glitterState,
                    poseStack,
                    model.renderType(TEXTURE),
                    state.lightCoords,
                    0,
                    tint,
                    null,
                    0,
                    state.breakProgress
            );
            poseStack.popPose();
        }
    }

    private static int getRainbowTint(float ageInTicks) {
        float hue = (ageInTicks * 0.01F) % 1.0F;

        float[] rgb = hsvToRgb(
                hue,
                1.0F,
                1.0F
        );

        return ARGB.colorFromFloat(
                1.0F,
                rgb[0],
                rgb[1],
                rgb[2]
        );
    }

    private static float[] hsvToRgb(
            float h,
            float s,
            float v
    ) {
        float r;
        float g;
        float b;

        float i = Mth.floor(h * 6.0F);
        float f = h * 6.0F - i;

        float p = v * (1.0F - s);
        float q = v * (1.0F - f * s);
        float t = v * (1.0F - (1.0F - f) * s);

        switch ((int) i % 6) {
            case 0 -> {
                r = v;
                g = t;
                b = p;
            }
            case 1 -> {
                r = q;
                g = v;
                b = p;
            }
            case 2 -> {
                r = p;
                g = v;
                b = t;
            }
            case 3 -> {
                r = p;
                g = q;
                b = v;
            }
            case 4 -> {
                r = t;
                g = p;
                b = v;
            }
            default -> {
                r = v;
                g = p;
                b = q;
            }
        }

        return new float[]{r, g, b};
    }

}