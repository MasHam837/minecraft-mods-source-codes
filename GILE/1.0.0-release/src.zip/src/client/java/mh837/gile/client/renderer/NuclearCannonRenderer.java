
package mh837.gile.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import mh837.gile.GileMod;
import mh837.gile.item.weapon.NuclearCannonItem;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public final class NuclearCannonRenderer {

    private static final Identifier BEAM_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/nuclear_beam.png"
            );

    private static final float BEAM_LENGTH = 40.0F;
    private static final float BEAM_RADIUS = 0.16F;

    private static final RenderType NUCLEAR_BEAM =
            RenderType.create(
                    "nuclear_beam_rendertype",
                    RenderSetup.builder(
                                    RenderPipelines.BEACON_BEAM_TRANSLUCENT
                            )
                            .withTexture("Sampler0", BEAM_TEXTURE)
                            .createRenderSetup()
            );

    private NuclearCannonRenderer() {
    }

    public static void initialize() {
        LevelRenderEvents.COLLECT_SUBMITS.register(context -> {
            Minecraft minecraft = Minecraft.getInstance();

            if (minecraft.level == null) {
                return;
            }

            SubmitNodeCollector collector =
                    context.submitNodeCollector();

            if (collector == null) {
                return;
            }

            Vec3 cameraPosition =
                    context.levelState().cameraRenderState.pos;

            /*
             * Render the beam for every player tracked by this client,
             * not just Minecraft.getInstance().player.
             */
            for (Player player : minecraft.level.players()) {
                if (!player.isUsingItem()
                        || !(player.getUseItem().getItem()
                        instanceof NuclearCannonItem)) {
                    continue;
                }

                Vec3 direction =
                        player.getViewVector(1.0F).normalize();

                /*
                 * Horizontal right vector based on the player's yaw.
                 * Unlike direction.cross(up), this remains defined
                 * even when the player looks nearly straight up/down.
                 */
                double yawRadians =
                        Math.toRadians(player.getYRot());

                Vec3 right = new Vec3(
                        -Math.cos(yawRadians),
                        0.0D,
                        -Math.sin(yawRadians)
                );

                /*
                 * Identify the arm holding the active item.
                 * The side offset changes for left-handed players
                 * and when the cannon is used in the offhand.
                 */
                boolean mainHand =
                        player.getUsedItemHand()
                                == InteractionHand.MAIN_HAND;

                boolean mainArmIsRight =
                        player.getMainArm() == HumanoidArm.RIGHT;

                boolean holdingInRightHand =
                        mainHand == mainArmIsRight;

                double handSide =
                        holdingInRightHand ? 1.0D : -1.0D;

                /*
                 * Approximate the held-item muzzle in world space.
                 * Keep the original offset and beam behavior, while
                 * applying the offset to the correct side.
                 */
                Vec3 start =
                        player.getEyePosition(1.0F)
                                .add(right.scale(0.28D * handSide))
                                .add(direction.scale(0.45D))
                                .add(0.0D, -0.35D, 0.0D);

                Vec3 end =
                        start.add(direction.scale(BEAM_LENGTH));

                Vec3 relativeStart =
                        start.subtract(cameraPosition);

                Vec3 relativeEnd =
                        end.subtract(cameraPosition);

                collector.order(1).submitCustomGeometry(
                        new PoseStack(),
                        NUCLEAR_BEAM,
                        (pose, consumer) ->
                                renderBeam(
                                        pose,
                                        consumer,
                                        relativeStart,
                                        relativeEnd
                                )
                );
            }
        });
    }

    private static void renderBeam(
            PoseStack.Pose pose,
            VertexConsumer consumer,
            Vec3 start,
            Vec3 end
    ) {
        Vec3 direction =
                end.subtract(start).normalize();

        Vec3 reference =
                Math.abs(direction.y) < 0.95D
                        ? new Vec3(0.0D, 1.0D, 0.0D)
                        : new Vec3(1.0D, 0.0D, 0.0D);

        Vec3 side =
                direction.cross(reference)
                        .normalize()
                        .scale(BEAM_RADIUS);

        Vec3 up =
                side.cross(direction)
                        .normalize()
                        .scale(BEAM_RADIUS);

        Vec3 s0 = start.subtract(side).subtract(up);
        Vec3 s1 = start.add(side).subtract(up);
        Vec3 s2 = start.add(side).add(up);
        Vec3 s3 = start.subtract(side).add(up);

        Vec3 e0 = end.subtract(side).subtract(up);
        Vec3 e1 = end.add(side).subtract(up);
        Vec3 e2 = end.add(side).add(up);
        Vec3 e3 = end.subtract(side).add(up);

        quad(pose, consumer, s0, s1, e1, e0);
        quad(pose, consumer, s1, s2, e2, e1);
        quad(pose, consumer, s2, s3, e3, e2);
        quad(pose, consumer, s3, s0, e0, e3);
    }

    private static void quad(
            PoseStack.Pose pose,
            VertexConsumer consumer,
            Vec3 p0,
            Vec3 p1,
            Vec3 p2,
            Vec3 p3
    ) {
        Matrix4f matrix = pose.pose();

        vertex(consumer, matrix, p0, 0.0F, 1.0F);
        vertex(consumer, matrix, p1, 0.0F, 0.0F);
        vertex(consumer, matrix, p2, 1.0F, 0.0F);
        vertex(consumer, matrix, p3, 1.0F, 1.0F);
    }

    private static void vertex(
            VertexConsumer consumer,
            Matrix4f matrix,
            Vec3 position,
            float u,
            float v
    ) {
        consumer
                .addVertex(
                        matrix,
                        (float) position.x,
                        (float) position.y,
                        (float) position.z
                )
                .setColor(255, 255, 255, 100)
                .setUv(u, v)
                .setUv2(240, 240)
                .setNormal(0.0F, 1.0F, 0.0F);
    }
}