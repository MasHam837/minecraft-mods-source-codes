package mh837.gile.client.renderer.entity.projectile;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import mh837.gile.entity.projectile.RocketEntity;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class RocketRenderer extends EntityRenderer<RocketEntity, RocketRenderer.RocketRenderState> {

    // 16 pixels = 1 block. Rocket is 2x2x3.
    private static final float WIDTH = 2.0F / 16.0F, HEIGHT = 2.0F / 16.0F, LENGTH = 3.0F / 16.0F;

    // entitySolid requires a texture-backed render type
    private static final RenderType RENDER_TYPE = RenderTypes.entitySolid(
            Identifier.fromNamespaceAndPath("minecraft", "textures/misc/white.png")
    );

    public RocketRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F; // Tiny rocket, no shadow
    }

    public static class RocketRenderState extends EntityRenderState {
        public float yaw, pitch;
    }

    @Override
    public RocketRenderState createRenderState() {
        return new RocketRenderState();
    }

    @Override
    public void extractRenderState(RocketEntity entity, RocketRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);

        // Interpolate rotation between ticks to prevent visual snapping
        state.yaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        state.pitch = Mth.lerp(partialTick, entity.xRotO, entity.getXRot());
    }

    @Override
    public void submit(RocketRenderState state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera) {
        // Let EntityRenderer handle its normal functionality first
        super.submit(state, poseStack, collector, camera);

        poseStack.pushPose();

        // Rotate the rocket according to its flight direction
        poseStack.mulPose(Axis.YP.rotationDegrees(state.yaw));
        poseStack.mulPose(Axis.XP.rotationDegrees(state.pitch));

        collector.submitCustomGeometry(poseStack, RENDER_TYPE, RocketRenderer::renderRocket);

        poseStack.popPose();
    }

    private static void renderRocket(PoseStack.Pose pose, VertexConsumer buffer) {
        float x1 = -WIDTH / 2.0F, x2 = WIDTH / 2.0F;
        float y1 = -HEIGHT / 2.0F, y2 = HEIGHT / 2.0F;
        float z1 = -LENGTH / 2.0F, z2 = LENGTH / 2.0F;

        // Front (+Z)
        quad(pose, buffer, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, 1.0F, 0.20F, 0.05F, 0.0F, 0.0F, 1.0F);
        // Back (-Z)
        quad(pose, buffer, x2, y1, z1, x1, y1, z1, x1, y2, z1, x2, y2, z1, 0.65F, 0.08F, 0.02F, 0.0F, 0.0F, -1.0F);
        // Left (-X)
        quad(pose, buffer, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, 0.75F, 0.10F, 0.025F, -1.0F, 0.0F, 0.0F);
        // Right (+X)
        quad(pose, buffer, x2, y1, z2, x2, y1, z1, x2, y2, z1, x2, y2, z2, 0.90F, 0.15F, 0.04F, 1.0F, 0.0F, 0.0F);
        // Top (+Y)
        quad(pose, buffer, x1, y2, z2, x2, y2, z2, x2, y2, z1, x1, y2, z1, 1.0F, 0.25F, 0.08F, 0.0F, 1.0F, 0.0F);
        // Bottom (-Y)
        quad(pose, buffer, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, 0.55F, 0.05F, 0.01F, 0.0F, -1.0F, 0.0F);
    }

    private static void quad(PoseStack.Pose pose, VertexConsumer buffer,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4,
                             float red, float green, float blue, float normalX, float normalY, float normalZ) {
        vertex(pose, buffer, x1, y1, z1, red, green, blue, normalX, normalY, normalZ);
        vertex(pose, buffer, x2, y2, z2, red, green, blue, normalX, normalY, normalZ);
        vertex(pose, buffer, x3, y3, z3, red, green, blue, normalX, normalY, normalZ);
        vertex(pose, buffer, x4, y4, z4, red, green, blue, normalX, normalY, normalZ);
    }

    // Minecraft 26.1 entitySolid vertex format requires Pos, Color, UV0, UV1, UV2, Normal
    private static void vertex(PoseStack.Pose pose, VertexConsumer buffer,
                               float x, float y, float z, float red, float green, float blue,
                               float normalX, float normalY, float normalZ) {
        buffer.addVertex(pose, x, y, z)
                .setColor(red, green, blue, 1.0F)
                .setUv(0.0F, 0.0F)
                .setUv1(0, 0)
                .setUv2(0xF000F0, 0xF000F0) // Fullbright
                .setNormal(pose, normalX, normalY, normalZ);
    }
}