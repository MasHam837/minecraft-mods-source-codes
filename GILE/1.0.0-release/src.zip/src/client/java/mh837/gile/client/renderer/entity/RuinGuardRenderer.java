package mh837.gile.client.renderer.entity;

import mh837.gile.GileMod;
import mh837.gile.client.model.RuinGuardModel;
import mh837.gile.client.renderer.entity.feature.RuinGuardEyeGlowFeatureRenderer;
import mh837.gile.client.renderer.state.RuinGuardRenderState;
import mh837.gile.entity.RuinGuardEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class RuinGuardRenderer extends MobRenderer<RuinGuardEntity, RuinGuardRenderState, RuinGuardModel> {

    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "textures/entity/ruin_guard/ruin_guard.png");

    public RuinGuardRenderer(EntityRendererProvider.Context context) {
        super(
                context,
                new RuinGuardModel(
                        context.bakeLayer(RuinGuardModel.GUARD_LAYER)
                ),
                1.25F
        );

        this.addLayer(new RuinGuardEyeGlowFeatureRenderer(this));
    }

    @Override
    public void extractRenderState(RuinGuardEntity entity, RuinGuardRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.walkAnimationState.copyFrom(entity.walkAnimationState);
        state.attackMeleeAnimationState.copyFrom(entity.attackMeleeAnimationState);
        state.attackRangeAnimationState.copyFrom(entity.attackRangeAnimationState);
        state.attackRotationAnimationState.copyFrom(entity.attackRotationAnimationState);
    }

    @Override
    public RuinGuardRenderState createRenderState() {return new RuinGuardRenderState();}

    @Override
    public Identifier getTextureLocation(RuinGuardRenderState state) {return TEXTURE;}

}