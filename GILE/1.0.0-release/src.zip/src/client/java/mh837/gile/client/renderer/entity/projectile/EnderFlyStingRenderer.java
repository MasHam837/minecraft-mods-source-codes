package mh837.gile.client.renderer.entity.projectile;

import mh837.gile.GileMod;

import mh837.gile.client.renderer.entity.projectile.state.EnderFlyStingRenderState;
import mh837.gile.entity.projectile.EnderFlyStingEntity;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.Identifier;

public class EnderFlyStingRenderer
        extends ArrowRenderer<
        EnderFlyStingEntity,
        EnderFlyStingRenderState
        > {

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/projectiles/ender_fly_sting.png"
            );

    public EnderFlyStingRenderer(
            EntityRendererProvider.Context context
    ) {
        super(context);
    }

    @Override
    public EnderFlyStingRenderState createRenderState() {
        return new EnderFlyStingRenderState();
    }

    @Override
    public Identifier getTextureLocation(EnderFlyStingRenderState state) {return TEXTURE;}

}