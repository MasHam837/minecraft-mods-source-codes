package mh837.gile.client.renderer.entity.feature;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.GileMod;
import mh837.gile.client.renderer.entity.MothRenderer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

public class MothRadianceGlowFeatureRenderer
        extends RenderLayer<
        MothRenderer.MothRenderState,
        EntityModel<MothRenderer.MothRenderState>
        > {

    private static final Identifier RADIANCE_GLOW_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/moth/radiance_glow.png"
            );

    public MothRadianceGlowFeatureRenderer(
            RenderLayerParent<
                    MothRenderer.MothRenderState,
                    EntityModel<MothRenderer.MothRenderState>
                    > parent
    ) {
        super(parent);
    }

    @Override
    public void submit(
            PoseStack poseStack,
            SubmitNodeCollector collector,
            int packedLight,
            MothRenderer.MothRenderState state,
            float limbSwing,
            float limbSwingAmount
    ) {
        // Only Radiance moths glow.
        if (!state.isRadiance) {
            return;
        }

        collector.submitModel(
                this.getParentModel(),
                state,
                poseStack,
                RenderTypes.eyes(
                        RADIANCE_GLOW_TEXTURE
                ),
                15728640,
                OverlayTexture.NO_OVERLAY,
                0xFFFFFFFF,
                null
        );
    }
}