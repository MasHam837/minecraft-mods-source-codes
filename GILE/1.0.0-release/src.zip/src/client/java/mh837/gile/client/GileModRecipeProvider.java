package mh837.gile.client;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModItems;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.recipes.*;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Items;
import net.minecraft.data.recipes.SingleItemRecipeBuilder;
import net.minecraft.world.item.crafting.CookingBookCategory;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Blocks;

import java.util.concurrent.CompletableFuture;

public class GileModRecipeProvider extends FabricRecipeProvider {

    public GileModRecipeProvider(
            FabricPackOutput output,
            CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected RecipeProvider createRecipeProvider(
            HolderLookup.Provider registries,
            RecipeOutput exporter) {

        return new RecipeProvider(registries, exporter) {

            @Override
            public void buildRecipes() {

                // === CRAFTING, STONECUTTING & SMITHING ===

                // Shaped
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.PEARLESCENT_MATERIAL)
                        .pattern("PPP")
                        .pattern("PPP")
                        .pattern("PPP")
                        .define('P', GileModItems.PRIMOGEM)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.WISH)
                        .pattern("PPP")
                        .pattern("PPP")
                        .pattern("PPP")
                        .define('P', GileModItems.PEARLESCENT_MATERIAL)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.ENDERITE_BLOCK)
                        .pattern("EEE")
                        .pattern("EEE")
                        .pattern("EEE")
                        .define('E', GileModItems.ENDERITE_INGOT)
                        .unlockedBy("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.WISH_INGOT)
                        .pattern("NNN")
                        .pattern("NNN")
                        .pattern("NNN")
                        .define('N', GileModItems.WISH_NUGGET)
                        .unlockedBy("has_wish_ingot", has(GileModItems.WISH_INGOT)).save(exporter, "gilemod:wish_ingot_from_nuggets");

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BLOCK)
                        .pattern("PP")
                        .pattern("PP")
                        .define('P', GileModItems.PEARLESCENT_MATERIAL)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_STAIRS, 4)
                        .pattern("P  ")
                        .pattern("PP ")
                        .pattern("PPP")
                        .define('P', GileModBlocks.PEARLESCENT_BLOCK)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_SLAB, 2)
                        .pattern("PPP")
                        .define('P', GileModBlocks.PEARLESCENT_BLOCK)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.PEARLESCENT_WALL, 6)
                        .pattern("PPP")
                        .pattern("PPP")
                        .define('P', GileModBlocks.PEARLESCENT_BLOCK)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS, 4)
                        .pattern("PP")
                        .pattern("PP")
                        .define('P', GileModBlocks.PEARLESCENT_BLOCK)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_STAIRS, 4)
                        .pattern("P  ")
                        .pattern("PP ")
                        .pattern("PPP")
                        .define('P', GileModBlocks.PEARLESCENT_BRICKS)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_SLAB, 2)
                        .pattern("PPP")
                        .define('P', GileModBlocks.PEARLESCENT_BRICKS)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.PEARLESCENT_BRICKS_WALL, 6)
                        .pattern("PPP")
                        .pattern("PPP")
                        .define('P', GileModBlocks.PEARLESCENT_BRICKS)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.PEARLESCENT_CHAIN)
                        .pattern("N  ")
                        .pattern("I  ")
                        .pattern("N  ")
                        .define('I', GileModItems.WISH_INGOT).define('N', GileModItems.WISH_NUGGET)
                        .unlockedBy("has_wish_ingot", has(GileModItems.WISH_INGOT)).save(exporter);
                // GHOSTLY
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.GHOSTLY_WOOD, 3)
                        .pattern("LL")
                        .pattern("LL")
                        .define('L', GileModBlocks.GHOSTLY_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.STRIPPED_GHOSTLY_WOOD, 3)
                        .pattern("SS")
                        .pattern("SS")
                        .define('S', GileModBlocks.STRIPPED_GHOSTLY_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.GHOSTLY_STAIRS, 4)
                        .pattern("G  ")
                        .pattern("GG ")
                        .pattern("GGG")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.GHOSTLY_SLAB, 6)
                        .pattern("GGG")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GHOSTLY_FENCE, 3)
                        .pattern("GSG")
                        .pattern("GSG")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS).define('S', Items.STICK)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.GHOSTLY_FENCE_GATE)
                        .pattern("SGS")
                        .pattern("SGS")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS).define('S', Items.STICK)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.GHOSTLY_DOOR, 3)
                        .pattern("GG ")
                        .pattern("GG ")
                        .pattern("GG ")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.GHOSTLY_TRAPDOOR, 2)
                        .pattern("GGG")
                        .pattern("GGG")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.GHOSTLY_PRESSURE_PLATE)
                        .pattern("GG ")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GHOSTLY_SIGN, 3)
                        .pattern("GGG")
                        .pattern("GGG")
                        .pattern(" S ")
                        .define('G', GileModBlocks.GHOSTLY_PLANKS).define('S', Items.STICK)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GHOSTLY_HANGING_SIGN, 6)
                        .pattern("P P")
                        .pattern("SSS")
                        .pattern("SSS")
                        .define('S', GileModBlocks.STRIPPED_GHOSTLY_LOG).define('P', GileModBlocks.PEARLESCENT_CHAIN)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GHOSTLY_SHELF, 6)
                        .pattern("SSS")
                        .pattern("   ")
                        .pattern("SSS")
                        .define('S', GileModBlocks.STRIPPED_GHOSTLY_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                // INVERTED_OAK
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.INVERTED_OAK_WOOD, 3)
                        .pattern("LL")
                        .pattern("LL")
                        .define('L', GileModBlocks.INVERTED_OAK_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.STRIPPED_INVERTED_OAK_WOOD, 3)
                        .pattern("SS")
                        .pattern("SS")
                        .define('S', GileModBlocks.STRIPPED_INVERTED_OAK_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.INVERTED_OAK_STAIRS, 4)
                        .pattern("G  ")
                        .pattern("GG ")
                        .pattern("GGG")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.INVERTED_OAK_SLAB, 6)
                        .pattern("GGG")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.INVERTED_OAK_FENCE, 3)
                        .pattern("GSG")
                        .pattern("GSG")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS).define('S', Items.STICK)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.INVERTED_OAK_FENCE_GATE)
                        .pattern("SGS")
                        .pattern("SGS")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS).define('S', Items.STICK)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.INVERTED_OAK_DOOR, 3)
                        .pattern("GG ")
                        .pattern("GG ")
                        .pattern("GG ")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.INVERTED_OAK_TRAPDOOR, 2)
                        .pattern("GGG")
                        .pattern("GGG")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.INVERTED_OAK_PRESSURE_PLATE)
                        .pattern("GG ")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.INVERTED_OAK_SIGN, 3)
                        .pattern("GGG")
                        .pattern("GGG")
                        .pattern(" S ")
                        .define('G', GileModBlocks.INVERTED_OAK_PLANKS).define('S', Items.STICK)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.INVERTED_OAK_HANGING_SIGN, 6)
                        .pattern("C C")
                        .pattern("SSS")
                        .pattern("SSS")
                        .define('S', GileModBlocks.STRIPPED_INVERTED_OAK_LOG).define('C', Blocks.IRON_CHAIN)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.INVERTED_OAK_SHELF, 6)
                        .pattern("SSS")
                        .pattern("   ")
                        .pattern("SSS")
                        .define('S', GileModBlocks.STRIPPED_INVERTED_OAK_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_CHISELED_SANDSTONE)
                        .pattern("M")
                        .pattern("M")
                        .define('M', GileModBlocks.MOON_SANDSTONE_SLAB)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE)
                        .pattern("MM")
                        .pattern("MM")
                        .define('M', GileModBlocks.MOON_SAND)
                        .unlockedBy("has_moon_sand", has(GileModBlocks.MOON_SAND)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE_STAIRS, 4)
                        .pattern("M  ")
                        .pattern("MM ")
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE_SLAB, 6)
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.MOON_SANDSTONE_WALL, 6)
                        .pattern("MMM")
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS, 4)
                        .pattern("M  ")
                        .pattern("MM ")
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_SMOOTH_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB, 6)
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_SMOOTH_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_CUT_SANDSTONE, 4)
                        .pattern("MM")
                        .pattern("MM")
                        .define('M', GileModBlocks.MOON_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_CUT_SANDSTONE_SLAB, 6)
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_CUT_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE_STAIRS, 4)
                        .pattern("M  ")
                        .pattern("MM ")
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_CHISELED_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_sandstone_stairs_from_chiseled");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE_SLAB, 6)
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_CHISELED_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter,"gilemod:moon_sandstone_slabs_from_chiseled");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.MOON_SANDSTONE_WALL, 6)
                        .pattern("MMM")
                        .pattern("MMM")
                        .define('M', GileModBlocks.MOON_CHISELED_SANDSTONE)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter,"gilemod:moon_sandstone_wall_from_chiseled");

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, Blocks.BREWING_STAND)
                        .pattern(" B ")
                        .pattern("EEE")
                        .define('E', Blocks.END_STONE).define('B', Items.BLAZE_ROD)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, Blocks.FURNACE)
                        .pattern("EEE")
                        .pattern("E E")
                        .pattern("EEE")
                        .define('E', Blocks.END_STONE)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.COMBAT, Items.STONE_SPEAR)
                        .pattern("  E")
                        .pattern(" S ")
                        .pattern("S  ")
                        .define('S', Items.STICK).define('E', Blocks.END_STONE)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.COMBAT, Items.STONE_SWORD)
                        .pattern("E")
                        .pattern("E")
                        .pattern("S")
                        .define('S', Items.STICK).define('E', Blocks.END_STONE)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, Items.STONE_PICKAXE)
                        .pattern("EEE")
                        .pattern(" S ")
                        .pattern(" S ")
                        .define('S', Items.STICK).define('E', Blocks.END_STONE)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, Items.STONE_SHOVEL)
                        .pattern("E")
                        .pattern("S")
                        .pattern("S")
                        .define('S', Items.STICK).define('E', Blocks.END_STONE)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, Items.STONE_AXE)
                        .pattern("EE")
                        .pattern("SE")
                        .pattern("S ")
                        .define('S', Items.STICK).define('E', Blocks.END_STONE)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, Items.STONE_HOE)
                        .pattern("EE")
                        .pattern("S ")
                        .pattern("S ")
                        .define('S', Items.STICK).define('E', Blocks.END_STONE)
                        .unlockedBy("has_end_stone", has(Blocks.END_STONE)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModItems.MOON_TORCH_ITEM)
                        .pattern("C  ")
                        .pattern("S  ")
                        .pattern("M  ")
                        .define('M', GileModBlocks.MOON_SAND).define('S', Items.STICK).define('C', Items.COAL)
                        .unlockedBy("has_moon_sand", has(GileModBlocks.MOON_SAND)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModItems.MOON_TORCH_ITEM)
                        .pattern("C  ")
                        .pattern("S  ")
                        .pattern("M  ")
                        .define('M', GileModBlocks.MOON_SAND).define('S', Items.STICK).define('C', Items.CHARCOAL)
                        .unlockedBy("has_moon_sand", has(GileModBlocks.MOON_SAND)).save(exporter, "gilemod:moon_torch_from_charcoal");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.MOON_LANTERN)
                        .pattern("NNN")
                        .pattern("NTN")
                        .pattern("NNN")
                        .define('T', GileModItems.MOON_TORCH_ITEM).define('N', GileModItems.WISH_NUGGET)
                        .unlockedBy("has_moon_sand", has(GileModBlocks.MOON_SAND)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.MOON_CAMPFIRE)
                        .pattern(" S ")
                        .pattern("SMS")
                        .pattern("LLL")
                        .define('M', GileModBlocks.MOON_SAND).define('S', Items.STICK).define('L', ItemTags.LOGS)
                        .unlockedBy("has_moon_sand", has(GileModBlocks.MOON_SAND)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.STAR)
                        .pattern("FF")
                        .pattern("FF")
                        .define('F', GileModItems.STAR_FRAGMENT)
                        .unlockedBy("has_star_fragment", has(GileModItems.STAR_FRAGMENT)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, GileModItems.SHRINKER)
                        .pattern(" J ")
                        .pattern("CJC")
                        .pattern(" S ")
                        .define('J', GileModItems.JERBOAS_TAIL).define('S', GileModBlocks.STAR).define('C', GileModItems.CRYSTAL)
                        .unlockedBy("has_crystal", has(GileModItems.CRYSTAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, GileModItems.ENLARGER)
                        .pattern(" S ")
                        .pattern("CJC")
                        .pattern(" J ")
                        .define('J', GileModItems.JERBOAS_TAIL).define('S', GileModBlocks.STAR).define('C', GileModItems.CRYSTAL)
                        .unlockedBy("has_crystal", has(GileModItems.CRYSTAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, GileModItems.JELLY_ON_A_STICK)
                        .pattern("F ")
                        .pattern(" J")
                        .define('F', Items.FISHING_ROD).define('J', GileModItems.JELLY)
                        .unlockedBy("has_jelly", has(GileModItems.JELLY)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, GileModItems.WARP_CLOCK)
                        .pattern("PMP")
                        .pattern("VCM")
                        .pattern("PEP")
                        .define('V', GileModItems.VOID_SLIMEBALL).define('C', GileModItems.CHRONO_GEAR).define('M', GileModItems.MOTH_WING)
                        .define('P', GileModItems.PHASMA).define('E', Items.ENDER_PEARL)
                        .unlockedBy("has_void_slimeball", has(GileModItems.CRYSTAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, GileModItems.GRAPPLING_HOOK)
                        .pattern(" FV")
                        .pattern(" WF")
                        .pattern("W  ")
                        .define('W', GileModItems.WISH_INGOT).define('V', GileModItems.VOID_SLIMEBALL).define('F', GileModItems.STAR_FRAGMENT)
                        .unlockedBy("has_star_fragment", has(GileModItems.STAR_FRAGMENT)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE)
                        .pattern("PWP")
                        .pattern("WNW")
                        .pattern("PWP")
                        .define('P', GileModItems.PEARLESCENT_MATERIAL).define('N', Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE).define('W', GileModItems.WISH_INGOT)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.COMBAT, GileModItems.FATE_ARROW, 4)
                        .pattern("C  ")
                        .pattern("S  ")
                        .pattern("M  ")
                        .define('M', GileModItems.MOTH_WING).define('S', Items.STICK).define('C', GileModItems.CRYSTAL)
                        .unlockedBy("has_crystal", has(GileModItems.CRYSTAL)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModBlocks.WISH)
                        .pattern("GGG")
                        .pattern("GGG")
                        .pattern("GGG")
                        .define('G', GileModItems.GENESIS_CRYSTAL)
                        .unlockedBy("has_genesis_crystal", has(GileModItems.GENESIS_CRYSTAL)).save(exporter, "wish_from_genesis_crystal");

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModBlocks.WISH_TABLE)
                        .pattern("PCP")
                        .pattern(" W ")
                        .pattern("WWW")
                        .define('P', GileModBlocks.PEARLESCENT_BLOCK).define('C', Blocks.CRAFTING_TABLE).define('W', GileModItems.WISH_INGOT)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GLITTER_BLOCK)
                        .pattern("DDD")
                        .pattern("DDD")
                        .pattern("DDD")
                        .define('D', GileModItems.DUST)
                        .unlockedBy("has_dust", has(GileModItems.DUST)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GLITTER_BLOCK)
                        .pattern("SSS")
                        .pattern("SSS")
                        .pattern("SSS")
                        .define('S', GileModItems.STAR_DUST)
                        .unlockedBy("has_star_dust", has(GileModItems.STAR_DUST)).save(exporter, "gilemod:glitter_block_from_star_dust");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GLITTER_CARPET)
                        .pattern("DDD")
                        .define('D', GileModItems.DUST)
                        .unlockedBy("has_dust", has(GileModItems.DUST)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GLITTER_CARPET)
                        .pattern("SSS")
                        .define('S', GileModItems.STAR_DUST)
                        .unlockedBy("has_star_dust", has(GileModItems.STAR_DUST)).save(exporter, "gilemod:glitter_carpet_from_star_dust");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GLITTER_BLOCK, 1)
                        .pattern("G  ")
                        .pattern("G  ")
                        .pattern("G  ")
                        .define('G', GileModBlocks.GLITTER_CARPET)
                        .unlockedBy("has_dust", has(GileModItems.DUST)).save(exporter, "gilemod:glitter_block_from_carpet");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.DECORATIONS, GileModBlocks.GLITTER_CARPET, 6)
                        .pattern("GG")
                        .define('G', GileModBlocks.GLITTER_BLOCK)
                        .unlockedBy("has_dust", has(GileModItems.DUST)).save(exporter, "gilemod:glitter_carpet_from_block");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModBlocks.JAR_OF_GLITTERS)
                        .pattern("GMG")
                        .pattern("GDG")
                        .pattern("GGG")
                        .define('D', GileModItems.DUST).define('G', Blocks.GLASS_PANE).define('M', GileModBlocks.MOON_LANTERN)
                        .unlockedBy("has_dust", has(GileModItems.DUST)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, GileModItems.FLUTTERER)
                        .pattern("MPM")
                        .pattern("D D")
                        .define('D', GileModItems.DUST).define('P', GileModBlocks.PEARLESCENT_CHAIN).define('M', GileModItems.MOTH_WING)
                        .unlockedBy("has_dust", has(GileModItems.DUST)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.COMBAT, GileModItems.NUCLEAR_CANNON)
                        .pattern("WEC")
                        .pattern(" W ")
                        .define('W', GileModItems.WISH_INGOT).define('E', GileModItems.ENDERITE_INGOT).define('C', GileModItems.COGWORK_CORE)
                        .unlockedBy("has_mechanisms_core", has(GileModItems.COGWORK_CORE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.COMBAT, GileModItems.PHANES_BLADE)
                        .pattern(" I ")
                        .pattern("RMA")
                        .pattern(" N ")
                        .define('M', GileModItems.COGWORK_CORE).define('A', GileModItems.PALM_OF_ASMODAY).define('R', GileModItems.SCYTHE_OF_RONOVA)
                        .define('I', GileModItems.HOURGLASS_OF_ISTAROTH).define('N', GileModItems.TOME_OF_NABERIUS)
                        .unlockedBy("has_mechanisms_core", has(GileModItems.COGWORK_CORE)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.TOOLS, GileModItems.END_COMPASS)
                        .pattern("PMP")
                        .pattern("PCP")
                        .pattern("PPP")
                        .define('M', GileModItems.MOTH_WING).define('P', GileModItems.PEARLESCENT_MATERIAL).define('C', GileModItems.COGWORK_CORE)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_BLOCK)
                        .pattern("PP")
                        .pattern("PP")
                        .define('P', GileModItems.GLOWING_POPPED_CHORUS_FRUIT)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_STAIRS, 4)
                        .pattern("F  ")
                        .pattern("FF ")
                        .pattern("FFF")
                        .define('F', GileModBlocks.FLUO_BLOCK)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_SLAB, 6)
                        .pattern("FFF")
                        .define('F', GileModBlocks.FLUO_BLOCK)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter);
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_PILLAR)
                        .pattern("F")
                        .pattern("F")
                        .define('F', GileModBlocks.FLUO_SLAB)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter);

                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_STAIRS, 4)
                        .pattern("F  ")
                        .pattern("FF ")
                        .pattern("FFF")
                        .define('F', GileModBlocks.FLUO_PILLAR)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter, "gilemod:fluo_stairs_from_pillar");
                ShapedRecipeBuilder.shaped(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_SLAB, 6)
                        .pattern("FFF")
                        .define('F', GileModBlocks.FLUO_PILLAR)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter,"gilemod:fluo_slabs_from_pillar");

                // Shapeless
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.GHOSTLY_PLANKS, 4)
                        .requires(GileModBlocks.GHOSTLY_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.GHOSTLY_PLANKS, 4)
                        .requires(GileModBlocks.STRIPPED_GHOSTLY_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter, "gilemod:ghostly_planks_from_stripped_log");
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.GHOSTLY_PLANKS, 4)
                        .requires(GileModBlocks.GHOSTLY_WOOD)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter, "gilemod:ghostly_planks_from_wood");
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.GHOSTLY_PLANKS, 4)
                        .requires(GileModBlocks.STRIPPED_GHOSTLY_WOOD)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter, "gilemod:ghostly_planks_from_stripped_wood");
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.GHOSTLY_BUTTON)
                        .requires(GileModBlocks.GHOSTLY_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);

                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.INVERTED_OAK_PLANKS, 4)
                        .requires(GileModBlocks.INVERTED_OAK_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.INVERTED_OAK_PLANKS, 4)
                        .requires(GileModBlocks.STRIPPED_INVERTED_OAK_LOG)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter, "gilemod:inverted_oak_planks_from_stripped_log");
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.INVERTED_OAK_PLANKS, 4)
                        .requires(GileModBlocks.INVERTED_OAK_WOOD)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter, "gilemod:inverted_oak_planks_from_wood");
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.INVERTED_OAK_PLANKS, 4)
                        .requires(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter, "gilemod:inverted_oak_planks_from_stripped_wood");
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.REDSTONE, GileModBlocks.INVERTED_OAK_BUTTON)
                        .requires(GileModBlocks.INVERTED_OAK_PLANKS)
                        .unlockedBy("has_logs", has(ItemTags.LOGS)).save(exporter);

                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.ANEMO_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(Items.WIND_CHARGE)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.GEO_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(Blocks.POINTED_DRIPSTONE)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.ELECTRO_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(Items.AMETHYST_SHARD)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.DENDRO_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(Items.BIG_DRIPLEAF)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.HYDRO_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(Items.PRISMARINE_SHARD)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.PYRO_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(Items.BLAZE_POWDER)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.CRYO_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(Items.SNOWBALL)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.LUNA_SIGIL, 2)
                        .requires(GileModItems.PRIMOGEM).requires(GileModBlocks.GLOOMY_FLOWER)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);

                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.PRIMOGEM, 9).requires(GileModItems.PEARLESCENT_MATERIAL)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.WISH_NUGGET, 9).requires(GileModItems.WISH_INGOT)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter);

                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, Items.LIGHT_BLUE_DYE).requires(GileModBlocks.MOON_FLOWER)
                        .unlockedBy("has_moon_flower", has(GileModBlocks.MOON_FLOWER)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, Items.CYAN_DYE).requires(GileModBlocks.GLOOMY_FLOWER)
                        .unlockedBy("has_gloomy_flower", has(GileModBlocks.GLOOMY_FLOWER)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, Items.BLACK_DYE).requires(GileModBlocks.DRY_FLOWER)
                        .unlockedBy("has_dry_flower", has(GileModBlocks.DRY_FLOWER)).save(exporter);

                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.FOOD, GileModItems.JAM).requires(GileModItems.JELLY, 3)
                        .requires(GileModItems.VOID_SLIMEBALL)
                        .unlockedBy("has_jelly", has(GileModItems.JELLY)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.FOOD, GileModItems.OFFERING)
                        .requires(Items.BOWL).requires(GileModItems.GLOWING_CHORUS_FRUIT).requires(GileModBlocks.MOON_FLOWER).requires(GileModItems.VOID_SLIMEBALL)
                        .unlockedBy("has_moon_flower", has(GileModBlocks.MOON_FLOWER)).save(exporter);

                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, Items.STRING, 3)
                        .requires(GileModItems.JERBOAS_TAIL, 2)
                        .unlockedBy("has_jerboas_tail", has(GileModItems.JERBOAS_TAIL)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.CHRONO_GEAR, 4)
                        .requires(GileModItems.VOID_SLIMEBALL).requires(GileModItems.PHASMA)
                        .unlockedBy("has_void_slimeball", has(GileModItems.VOID_SLIMEBALL)).save(exporter);

                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.ENDERITE_INGOT)
                        .requires(GileModItems.ENDERITE_SHARD, 4).requires(GileModItems.CRYSTAL, 4)
                        .unlockedBy("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter);
                ShapelessRecipeBuilder.shapeless(this.registries.lookupOrThrow(Registries.ITEM), RecipeCategory.MISC, GileModItems.ENDERITE_INGOT, 9)
                        .requires(GileModBlocks.ENDERITE_BLOCK)
                        .unlockedBy("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "gilemod:enderite_ingot_from_block");

                // Stonecutting
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_STAIRS, 1)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_stairs_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_SLAB, 2)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_slab_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_WALL, 1)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_wall_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS, 1)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_bricks_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_STAIRS, 1)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_bricks_stairs_from_stonecutting_normal");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_SLAB, 2)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_bricks_slab_from_stonecutting_normal");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_WALL, 1)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_bricks_wall_from_stonecutting_normal");

                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BRICKS), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_STAIRS, 1)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_bricks_stairs_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BRICKS), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_SLAB, 2)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_bricks_slab_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.PEARLESCENT_BRICKS), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.PEARLESCENT_BRICKS_WALL, 1)
                        .unlockedBy("has_pearlescent_material", has(GileModItems.PEARLESCENT_MATERIAL)).save(exporter, "gilemod:pearlescent_bricks_wall_from_stonecutting");

                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE_STAIRS, 1)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_sandstone_stairs_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE_SLAB, 2)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_sandstone_slab_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SANDSTONE_WALL, 1)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_sandstone_wall_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_CUT_SANDSTONE, 1)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_cut_sandstone_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_CUT_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_CUT_SANDSTONE_SLAB, 2)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_cut_sandstone_slab_from_cut_sandstone_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_CUT_SANDSTONE_SLAB, 2)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_cut_sandstone_slab_from_sandstone_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SMOOTH_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS, 1)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_smooth_sandstone_stairs_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SMOOTH_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB, 2)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_smooth_sandstone_slab_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.MOON_SANDSTONE), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.MOON_CHISELED_SANDSTONE, 1)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter, "gilemod:moon_chiseled_sandstone_from_stonecutting");

                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.FLUO_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_STAIRS, 1)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter, "gilemod:fluo_stairs_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.FLUO_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_SLAB, 2)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter, "gilemod:fluo_slab_from_stonecutting");
                SingleItemRecipeBuilder.stonecutting(Ingredient.of(GileModBlocks.FLUO_BLOCK), RecipeCategory.BUILDING_BLOCKS, GileModBlocks.FLUO_PILLAR, 1)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter, "gilemod:fluo_pillar_from_stonecutting");

                // Smithing transform
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_SPEAR), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.COMBAT, GileModItems.ENDERITE_SPEAR)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_spear");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_SWORD), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.COMBAT, GileModItems.ENDERITE_SWORD)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_sword");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_PICKAXE), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.TOOLS, GileModItems.ENDERITE_PICKAXE)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_pickaxe");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_AXE), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.TOOLS, GileModItems.ENDERITE_AXE)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_axe");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_SHOVEL), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.TOOLS, GileModItems.ENDERITE_SHOVEL)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_shovel");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_HOE), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.TOOLS, GileModItems.ENDERITE_HOE)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_hoe");

                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_HELMET), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.COMBAT, GileModItems.ENDERITE_HELMET)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_helmet");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_CHESTPLATE), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.COMBAT, GileModItems.ENDERITE_CHESTPLATE)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_chestplate");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_LEGGINGS), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.COMBAT, GileModItems.ENDERITE_LEGGINGS)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_leggings");
                SmithingTransformRecipeBuilder.smithing(Ingredient.of(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE),
                                Ingredient.of(Items.NETHERITE_BOOTS), Ingredient.of(GileModItems.ENDERITE_INGOT),RecipeCategory.COMBAT, GileModItems.ENDERITE_BOOTS)
                        .unlocks("has_enderite_shard", has(GileModItems.ENDERITE_SHARD)).save(exporter, "enderite_boots");

                // Smithing trim
               /*SmithingTrimRecipeBuilder.smithingTrim(
                        Ingredient.of(Items.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE), Ingredient.of(Items.DIAMOND_CHESTPLATE), Ingredient.of(GileModItems.WISH_INGOT),
                                this.registries.lookupOrThrow(Registries.TRIM_PATTERN).getOrThrow(TrimPatterns.DUNE), RecipeCategory.TOOLS)
                        .unlocks("has_wish_ingot", has(GileModItems.WISH_INGOT)).save(output, ResourceKey.create(Registries.RECIPE,
                                Identifier.fromNamespaceAndPath("gilemod", "diamond_chestplate_wish_trim")));*/

                // === SMELTING & COOKING ===

                // Furnace
                SimpleCookingRecipeBuilder.smelting(Ingredient.of(GileModBlocks.GHOSTLY_LEAVES),
                                RecipeCategory.DECORATIONS, CookingBookCategory.BLOCKS, Blocks.LEAF_LITTER, 0.1F, 200)
                        .unlockedBy("has_ghostly_leaves", has(GileModBlocks.GHOSTLY_LEAVES)).save(exporter, "gilemod:ghostly_leaf_litter");
                SimpleCookingRecipeBuilder.smelting(Ingredient.of(GileModBlocks.INVERTED_OAK_LEAVES),
                                RecipeCategory.DECORATIONS, CookingBookCategory.BLOCKS, Blocks.LEAF_LITTER, 0.1F, 200)
                        .unlockedBy("has_inverted_oak_leaves", has(GileModBlocks.INVERTED_OAK_LEAVES)).save(exporter, "gilemod:inverted_oak_leaf_litter");

                SimpleCookingRecipeBuilder.smelting(Ingredient.of(GileModBlocks.WISH),
                                RecipeCategory.MISC, CookingBookCategory.MISC, GileModItems.WISH_INGOT, 1.4F, 200)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter, "gilemod:wish_ingot_from_smelting");
                SimpleCookingRecipeBuilder.smelting(Ingredient.of(GileModBlocks.MOON_SAND),
                                RecipeCategory.BUILDING_BLOCKS, CookingBookCategory.BLOCKS, Blocks.TINTED_GLASS, 0.1F, 200)
                        .unlockedBy("has_moon_sand", has(GileModBlocks.MOON_SAND)).save(exporter);
                SimpleCookingRecipeBuilder.smelting(Ingredient.of(GileModBlocks.MOON_SANDSTONE),
                                RecipeCategory.BUILDING_BLOCKS, CookingBookCategory.BLOCKS, GileModBlocks.MOON_SMOOTH_SANDSTONE, 0.1F, 200)
                        .unlockedBy("has_moon_sandstone", has(GileModBlocks.MOON_SANDSTONE)).save(exporter);
                SimpleCookingRecipeBuilder.smelting(Ingredient.of(GileModItems.PHASMA),
                                RecipeCategory.FOOD,CookingBookCategory.FOOD,GileModItems.COOKED_PHASMA, 0.35F, 200)
                        .unlockedBy("has_phasma", has(GileModItems.PHASMA)).save(exporter);

                SimpleCookingRecipeBuilder.smelting(Ingredient.of(GileModItems.GLOWING_CHORUS_FRUIT),
                                RecipeCategory.BUILDING_BLOCKS,CookingBookCategory.BLOCKS,GileModItems.GLOWING_POPPED_CHORUS_FRUIT, 0.35F, 200)
                        .unlockedBy("has_glowing_chorus_fruit", has(GileModItems.GLOWING_CHORUS_FRUIT)).save(exporter);

                // Blasting
                SimpleCookingRecipeBuilder.blasting(Ingredient.of(GileModBlocks.WISH),
                                RecipeCategory.MISC, CookingBookCategory.BLOCKS, GileModItems.WISH_INGOT, 1.4F, 100)
                        .unlockedBy("has_primogem", has(GileModItems.PRIMOGEM)).save(exporter, "gilemod:wish_ingot_from_blasting");

                // Smoking
                SimpleCookingRecipeBuilder.smoking(Ingredient.of(GileModItems.PHASMA),
                                RecipeCategory.FOOD, GileModItems.COOKED_PHASMA, 0.35F, 100)
                        .unlockedBy("has_phasma", has(GileModItems.PHASMA)).save(exporter, "gilemod:cooked_phasma_from_smoking");

                // Campfire
                SimpleCookingRecipeBuilder.campfireCooking(Ingredient.of(GileModItems.PHASMA),
                                RecipeCategory.FOOD, GileModItems.COOKED_PHASMA, 0.35F, 600)
                        .unlockedBy("has_phasma", has(GileModItems.PHASMA)).save(exporter, "gilemod:cooked_phasma_from_campfire");

            }};}

    @Override
    public String getName() {
        return "Gile Recipes";
    }
}