package mh837.gile.client;

import java.util.concurrent.CompletableFuture;

import mh837.gile.GileModBlocks;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;

import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagsProvider;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import static mh837.gile.GileModTags.Blocks.GLOWING_CHORUS_SUPPORT;

public class GileModBlockTagsProvider extends FabricTagsProvider.BlockTagsProvider {

    private static final TagKey<Block> END_ORES_REPLACEABLES = TagKey.create(
            Registries.BLOCK, Identifier.fromNamespaceAndPath("gilemod", "end_ores_replaceables"));
    private static final TagKey<Block> MOON_SAND_REPLACEABLES = TagKey.create(
            Registries.BLOCK, Identifier.fromNamespaceAndPath("gilemod", "moon_sand_replaceables"));

    public GileModBlockTagsProvider(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void addTags(HolderLookup.Provider wrapperLookup) {

        valueLookupBuilder(END_ORES_REPLACEABLES).add(Blocks.END_STONE);
        valueLookupBuilder(MOON_SAND_REPLACEABLES).add(Blocks.END_STONE).add(GileModBlocks.END_GRASS_BLOCK);
        valueLookupBuilder(GLOWING_CHORUS_SUPPORT).add(Blocks.END_STONE).add(GileModBlocks.MOON_SAND)
                .add(GileModBlocks.GLOWING_CHORUS_PLANT).add(GileModBlocks.GLOWING_CHORUS_FLOWER);

        valueLookupBuilder(BlockTags.DIRT).add(GileModBlocks.END_GRASS_BLOCK).add(Blocks.END_STONE);

        valueLookupBuilder(BlockTags.WALLS).add(GileModBlocks.PEARLESCENT_WALL, GileModBlocks.PEARLESCENT_BRICKS_WALL, GileModBlocks.MOON_SANDSTONE_WALL);

        valueLookupBuilder(BlockTags.FENCES).add(GileModBlocks.GHOSTLY_FENCE).add(GileModBlocks.INVERTED_OAK_FENCE);
        valueLookupBuilder(BlockTags.FENCE_GATES).add(GileModBlocks.GHOSTLY_FENCE_GATE).add(GileModBlocks.INVERTED_OAK_FENCE_GATE);
        valueLookupBuilder(BlockTags.ALL_SIGNS).add(GileModBlocks.GHOSTLY_SIGN).add(GileModBlocks.GHOSTLY_WALL_SIGN)
                                                .add(GileModBlocks.INVERTED_OAK_SIGN).add(GileModBlocks.INVERTED_OAK_WALL_SIGN);
        valueLookupBuilder(BlockTags.STANDING_SIGNS).add(GileModBlocks.GHOSTLY_SIGN).add(GileModBlocks.INVERTED_OAK_SIGN);
        valueLookupBuilder(BlockTags.WALL_SIGNS).add(GileModBlocks.GHOSTLY_WALL_SIGN).add(GileModBlocks.INVERTED_OAK_WALL_SIGN);
        valueLookupBuilder(BlockTags.ALL_HANGING_SIGNS).add(GileModBlocks.GHOSTLY_HANGING_SIGN).add(GileModBlocks.GHOSTLY_WALL_HANGING_SIGN)
                                                .add(GileModBlocks.INVERTED_OAK_HANGING_SIGN).add(GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN);
        valueLookupBuilder(BlockTags.CEILING_HANGING_SIGNS).add(GileModBlocks.GHOSTLY_HANGING_SIGN).add(GileModBlocks.INVERTED_OAK_HANGING_SIGN);
        valueLookupBuilder(BlockTags.WALL_HANGING_SIGNS).add(GileModBlocks.GHOSTLY_WALL_HANGING_SIGN).add(GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN);

        valueLookupBuilder(BlockTags.MINEABLE_WITH_AXE)
                .add(GileModBlocks.GHOSTLY_LOG, GileModBlocks.STRIPPED_GHOSTLY_LOG, GileModBlocks.GHOSTLY_WOOD , GileModBlocks.STRIPPED_GHOSTLY_WOOD,
                        GileModBlocks.GHOSTLY_PLANKS , GileModBlocks.GHOSTLY_STAIRS , GileModBlocks.GHOSTLY_SLAB, GileModBlocks.GHOSTLY_FENCE , GileModBlocks.GHOSTLY_FENCE_GATE,
                        GileModBlocks.GHOSTLY_DOOR , GileModBlocks.GHOSTLY_TRAPDOOR , GileModBlocks.GHOSTLY_PRESSURE_PLATE , GileModBlocks.GHOSTLY_BUTTON,
                        GileModBlocks.GHOSTLY_SIGN , GileModBlocks.GHOSTLY_WALL_SIGN, GileModBlocks.GHOSTLY_HANGING_SIGN , GileModBlocks.GHOSTLY_WALL_HANGING_SIGN)
                .add(GileModBlocks.INVERTED_OAK_LOG, GileModBlocks.STRIPPED_INVERTED_OAK_LOG, GileModBlocks.INVERTED_OAK_WOOD , GileModBlocks.STRIPPED_INVERTED_OAK_WOOD,
                        GileModBlocks.INVERTED_OAK_PLANKS , GileModBlocks.INVERTED_OAK_STAIRS , GileModBlocks.INVERTED_OAK_SLAB, GileModBlocks.INVERTED_OAK_FENCE , GileModBlocks.INVERTED_OAK_FENCE_GATE,
                        GileModBlocks.INVERTED_OAK_DOOR , GileModBlocks.INVERTED_OAK_TRAPDOOR , GileModBlocks.INVERTED_OAK_PRESSURE_PLATE , GileModBlocks.INVERTED_OAK_BUTTON,
                        GileModBlocks.INVERTED_OAK_SIGN , GileModBlocks.INVERTED_OAK_WALL_SIGN, GileModBlocks.INVERTED_OAK_HANGING_SIGN , GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN ,
                        GileModBlocks.MOON_CAMPFIRE, GileModBlocks.GLOWING_CHORUS_FLOWER, GileModBlocks.GLOWING_CHORUS_PLANT);

        valueLookupBuilder(BlockTags.MINEABLE_WITH_SHOVEL)
                .add(GileModBlocks.MOON_SAND);

        valueLookupBuilder(BlockTags.MINEABLE_WITH_HOE)
                .add(GileModBlocks.GHOSTLY_LEAVES).add(GileModBlocks.INVERTED_OAK_LEAVES);

        valueLookupBuilder(BlockTags.MINEABLE_WITH_PICKAXE)
                    .add(GileModBlocks.PRIMOGEM_ORE, GileModBlocks.DEEPSLATE_PRIMOGEM_ORE,
                        GileModBlocks.END_PRIMOGEM_ORE, GileModBlocks.ENDERITE_ORE,
                        GileModBlocks.WISH, GileModBlocks.WISH_TABLE, GileModBlocks.ENDERITE_BLOCK,

                        GileModBlocks.END_GRASS_BLOCK,
                        GileModBlocks.FLUO_BLOCK, GileModBlocks.FLUO_STAIRS, GileModBlocks.FLUO_SLAB, GileModBlocks.FLUO_PILLAR,

                        GileModBlocks.PEARLESCENT_BLOCK, GileModBlocks.PEARLESCENT_STAIRS, GileModBlocks.PEARLESCENT_SLAB,
                        GileModBlocks.PEARLESCENT_WALL, GileModBlocks.PEARLESCENT_BRICKS, GileModBlocks.PEARLESCENT_BRICKS_STAIRS,
                        GileModBlocks.PEARLESCENT_BRICKS_SLAB, GileModBlocks.PEARLESCENT_BRICKS_WALL, GileModBlocks.PEARLESCENT_CHAIN,

                        GileModBlocks.MOON_SANDSTONE, GileModBlocks.MOON_SANDSTONE_STAIRS, GileModBlocks.MOON_SANDSTONE_SLAB,
                        GileModBlocks.MOON_SANDSTONE_WALL, GileModBlocks.MOON_SMOOTH_SANDSTONE, GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS,
                        GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB, GileModBlocks.MOON_CUT_SANDSTONE, GileModBlocks.MOON_CUT_SANDSTONE_SLAB,
                        GileModBlocks.MOON_CHISELED_SANDSTONE
                );

        valueLookupBuilder(BlockTags.NEEDS_STONE_TOOL)
                .add(GileModBlocks.MOON_SAND);

        valueLookupBuilder(BlockTags.NEEDS_IRON_TOOL)
                .add(GileModBlocks.PEARLESCENT_BLOCK,
                        GileModBlocks.PEARLESCENT_STAIRS,
                        GileModBlocks.PEARLESCENT_SLAB,
                        GileModBlocks.PEARLESCENT_WALL,
                        GileModBlocks.PEARLESCENT_BRICKS,
                        GileModBlocks.PEARLESCENT_BRICKS_STAIRS,
                        GileModBlocks.PEARLESCENT_BRICKS_SLAB,
                        GileModBlocks.PEARLESCENT_BRICKS_WALL,
                        GileModBlocks.PEARLESCENT_CHAIN,
                        GileModBlocks.MOON_LANTERN,
                        GileModBlocks.PRIMOGEM_ORE,
                        GileModBlocks.DEEPSLATE_PRIMOGEM_ORE,
                        GileModBlocks.END_PRIMOGEM_ORE
                );

        valueLookupBuilder(BlockTags.LOGS).add(GileModBlocks.GHOSTLY_LOG).add(GileModBlocks.STRIPPED_GHOSTLY_LOG)
                                            .add(GileModBlocks.GHOSTLY_WOOD).add(GileModBlocks.STRIPPED_GHOSTLY_WOOD)
                                            .add(GileModBlocks.INVERTED_OAK_LOG).add(GileModBlocks.STRIPPED_INVERTED_OAK_LOG)
                                            .add(GileModBlocks.INVERTED_OAK_WOOD).add(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD);
        valueLookupBuilder(BlockTags.LOGS_THAT_BURN).add(GileModBlocks.GHOSTLY_LOG).add(GileModBlocks.STRIPPED_GHOSTLY_LOG)
                                                     .add(GileModBlocks.GHOSTLY_WOOD).add(GileModBlocks.STRIPPED_GHOSTLY_WOOD)
                                                     .add(GileModBlocks.INVERTED_OAK_LOG).add(GileModBlocks.STRIPPED_INVERTED_OAK_LOG)
                                                     .add(GileModBlocks.INVERTED_OAK_WOOD).add(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD);
        valueLookupBuilder(BlockTags.PLANKS).add(GileModBlocks.GHOSTLY_PLANKS).add(GileModBlocks.INVERTED_OAK_PLANKS);

        valueLookupBuilder(BlockTags.STANDING_SIGNS).add(GileModBlocks.GHOSTLY_SIGN).add(GileModBlocks.INVERTED_OAK_SIGN);
        valueLookupBuilder(BlockTags.WALL_SIGNS).add(GileModBlocks.GHOSTLY_WALL_SIGN).add(GileModBlocks.INVERTED_OAK_WALL_SIGN);
        valueLookupBuilder(BlockTags.CEILING_HANGING_SIGNS).add(GileModBlocks.GHOSTLY_HANGING_SIGN).add(GileModBlocks.INVERTED_OAK_HANGING_SIGN);
        valueLookupBuilder(BlockTags.WALL_HANGING_SIGNS).add(GileModBlocks.GHOSTLY_WALL_HANGING_SIGN).add(GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN);
        valueLookupBuilder(BlockTags.SAPLINGS).add(GileModBlocks.GHOSTLY_SAPLING).add(GileModBlocks.INVERTED_OAK_SAPLING);

        valueLookupBuilder(BlockTags.WALL_POST_OVERRIDE).add(GileModBlocks.MOON_TORCH);
        valueLookupBuilder(BlockTags.LANTERNS).add(GileModBlocks.MOON_LANTERN);
        valueLookupBuilder(BlockTags.CAMPFIRES).add(GileModBlocks.MOON_CAMPFIRE);
        valueLookupBuilder(BlockTags.FIRE).add(GileModBlocks.MOON_FIRE);

    }
}