package mh837.gile.client.lang;

import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public final class GileModRussianTextProvider {

    private GileModRussianTextProvider() {}

    public static void advancements(FabricLanguageProvider.TranslationBuilder t) {
        // Root
        t.add("advancements.gilemod._root.title", "GILE");
        t.add("advancements.gilemod._root.description", "Узнай, что скрывается за пределами знакомого мира");

        // Abilities
        t.add("advancements.gilemod.ability_anemo.title", "Шёпот ветра");
        t.add("advancements.gilemod.ability_anemo.description", "Овладей силой Анемо");
        t.add("advancements.gilemod.ability_geo.title", "Скованный камнем");
        t.add("advancements.gilemod.ability_geo.description", "Овладей силой Гео");
        t.add("advancements.gilemod.ability_electro.title", "Гнев небес");
        t.add("advancements.gilemod.ability_electro.description", "Овладей силой Электро");
        t.add("advancements.gilemod.ability_dendro.title", "Там, где пускает корни жизнь");
        t.add("advancements.gilemod.ability_dendro.description", "Овладей силой Дендро");
        t.add("advancements.gilemod.ability_hydro.title", "Теки, словно вода");
        t.add("advancements.gilemod.ability_hydro.description", "Овладей силой Гидро");
        t.add("advancements.gilemod.ability_pyro.title", "Искра внутри");
        t.add("advancements.gilemod.ability_pyro.description", "Овладей силой Пиро");
        t.add("advancements.gilemod.ability_cryo.title", "Холоднее пустоты");
        t.add("advancements.gilemod.ability_cryo.description", "Овладей силой Крио");
        t.add("advancements.gilemod.ability_luna.title", "Под бледной луной");
        t.add("advancements.gilemod.ability_luna.description", "Овладей силой Луны");
        t.add("advancements.gilemod.ability_life.title", "Дыхание жизни");
        t.add("advancements.gilemod.ability_life.description", "Овладей силой Жизни");
        t.add("advancements.gilemod.ability_space.title", "За пределами звёзд");
        t.add("advancements.gilemod.ability_space.description", "Овладей силой Пространства");
        t.add("advancements.gilemod.ability_time.title", "Мгновение вне времени");
        t.add("advancements.gilemod.ability_time.description", "Овладей силой Времени");
        t.add("advancements.gilemod.ability_death.title", "Прикосновение смерти");
        t.add("advancements.gilemod.ability_death.description", "Овладей силой Смерти");
        t.add("advancements.gilemod.ability_divine.title", "Первый престол");
        t.add("advancements.gilemod.ability_divine.description", "Овладей силой Фанета");

        // Challenges
        t.add("advancements.gilemod.challenge_genshin.title", "Собери их всех");
        t.add("advancements.gilemod.challenge_genshin.description", "Получи всё оружие Genshin");

        // Defeat
        t.add("advancements.gilemod.defeat_ruin_guard.title", "Одним меньше");
        t.add("advancements.gilemod.defeat_ruin_guard.description", "Победи стража руин");

        // Discover
        t.add("advancements.gilemod.ancient_ruins.title", "Эхо ушедших эпох");
        t.add("advancements.gilemod.ancient_ruins.description", "Обнаружь древние руины");
        t.add("advancements.gilemod.discover_end_threshold.title", "Там, где сходятся миры");
        t.add("advancements.gilemod.discover_end_threshold.description", "Обнаружь границу между мирами");
        t.add("advancements.gilemod.ghostly_thickets.title", "Лес призраков");
        t.add("advancements.gilemod.ghostly_thickets.description", "Обнаружь призрачные заросли");
        t.add("advancements.gilemod.discover_moon.title", "Маленький шаг");
        t.add("advancements.gilemod.discover_moon.description", "Ступи на луну");
        t.add("advancements.gilemod.moon_desert.title", "Море безмолвия");
        t.add("advancements.gilemod.moon_desert.description", "Обнаружь лунную пустыню");

        // Encounter
        t.add("advancements.gilemod.encounter_gloomy_lynx.title", "Когтистые лапки");
        t.add("advancements.gilemod.encounter_gloomy_lynx.description", "Встреть мрачную рысь");
        t.add("advancements.gilemod.encounter_hovering_ghost.title", "Что-то парит");
        t.add("advancements.gilemod.encounter_hovering_ghost.description", "Встреть парящего призрака");
        t.add("advancements.gilemod.encounter_jerboa.title", "Карманный размер");
        t.add("advancements.gilemod.encounter_jerboa.description", "Встреть тушканчика");
        t.add("advancements.gilemod.encounter_weasel_thief.title", "Ловкие лапки");
        t.add("advancements.gilemod.encounter_weasel_thief.description", "Встреть хорька-барахольщика");
        t.add("advancements.gilemod.encounter_moon_mobs.title", "Не местный");
        t.add("advancements.gilemod.encounter_moon_mobs.description", "Встреть лунного моба");

        // Get
        t.add("advancements.gilemod.get_any_sigil.title", "Знак силы");
        t.add("advancements.gilemod.get_any_sigil.description", "Получи любую печать");
        t.add("advancements.gilemod.get_end_cloud.title", "Хождение по воздуху");
        t.add("advancements.gilemod.get_end_cloud.description", "Получи облако Края");
        t.add("advancements.gilemod.get_enderite.title", "Металл из-за грани");
        t.add("advancements.gilemod.get_enderite.description", "Получи эндеритовый слиток");
        t.add("advancements.gilemod.get_enderite_armor.title", "Доспехи для Края");
        t.add("advancements.gilemod.get_enderite_armor.description", "Получи полный комплект доспехов из эндерита");
        t.add("advancements.gilemod.get_enderite_tools.title", "За пределами незерита");
        t.add("advancements.gilemod.get_enderite_tools.description", "Создай все инструменты из эндерита");
        t.add("advancements.gilemod.get_fate_collection.title", "Написано среди звёзд");
        t.add("advancements.gilemod.get_fate_collection.description", "Собери меч, лук и стрелу судьбы");
        t.add("advancements.gilemod.get_ghostly_log.title", "Древесина из-за грани");
        t.add("advancements.gilemod.get_ghostly_log.description", "Получи призрачное бревно");
        t.add("advancements.gilemod.get_inverted_oak.title", "Перевернуть мир с ног на голову");
        t.add("advancements.gilemod.get_inverted_oak.description", "Получи перевёрнутое дубовое бревно");
        t.add("advancements.gilemod.get_jar_of_glitters.title", "Пригоршня пыли");
        t.add("advancements.gilemod.get_jar_of_glitters.description", "Получи банку блёсток");
        t.add("advancements.gilemod.get_moon_fire_collection.title", "Огонь в лунном свете");
        t.add("advancements.gilemod.get_moon_fire_collection.description", "Получи лунный факел, фонарь и костёр");
        t.add("advancements.gilemod.get_moon_sandstone.title", "Пыль другого мира");
        t.add("advancements.gilemod.get_moon_sandstone.description", "Получи лунный песчаник");
        t.add("advancements.gilemod.get_primogem.title", "Маленькое сияющее желание");
        t.add("advancements.gilemod.get_primogem.description", "Получи камень Истока");
        t.add("advancements.gilemod.get_sigils_collection.title", "Собиратель печатей");
        t.add("advancements.gilemod.get_sigils_collection.description", "Собери все виды печатей");
        t.add("advancements.gilemod.get_star_fragment.title", "Осколок небес");
        t.add("advancements.gilemod.get_star_fragment.description", "Получи осколок звезды");
        t.add("advancements.gilemod.get_void_slimeball.title", "С этой слизью что-то не так");
        t.add("advancements.gilemod.get_void_slimeball.description", "Получи сгусток пустотной слизи");
        t.add("advancements.gilemod.get_wish_table.title", "Загадай желание");
        t.add("advancements.gilemod.get_wish_table.description", "Получи алтарь желаний");
        t.add("advancements.gilemod.get_legendary_weapon.title", "Сила за пределами смертных");
        t.add("advancements.gilemod.get_legendary_weapon.description", "Получи любое легендарное оружие");
        t.add("advancements.gilemod.get_nuclear_cannon.title", "Соседям не понравится");
        t.add("advancements.gilemod.get_nuclear_cannon.description", "Получи ядерную пушку");
        t.add("advancements.gilemod.get_heart_of_emergency.title", "Разбить стекло в случае опасности");
        t.add("advancements.gilemod.get_heart_of_emergency.description", "Получи сердце спасения");

        // Hit By
        t.add("advancements.gilemod.ender_fly.title", "Смотри вверх!");
        t.add("advancements.gilemod.ender_fly.description", "Пропусти выстрел от эндерской мухи");

        // Make
        t.add("advancements.gilemod.make_a_wish.title", "Загадай желание");
        t.add("advancements.gilemod.make_a_wish.description", "Загадай желание у алтаря желаний");
        t.add("advancements.gilemod.make_jerboa_emerge.title", "Восстань, малыш");
        t.add("advancements.gilemod.make_jerboa_emerge.description", "Заставь тушканчика появиться");

        // Name
        t.add("advancements.gilemod.name_nyan.title", "Нян!");
        t.add("advancements.gilemod.name_nyan.description", "Дай существу имя Nyan Cat");
        t.add("advancements.gilemod.name_radiance.title", "Сияние");
        t.add("advancements.gilemod.name_radiance.description", "Дай существу имя Radiance");

        // Ride
        t.add("advancements.gilemod.ride_hovering_ghost.title", "Призрачный всадник");
        t.add("advancements.gilemod.ride_hovering_ghost.description", "Оседлай парящего призрака");

        // Trade
        t.add("advancements.gilemod.trade_weasel_thief.title", "Тёмная сделка");
        t.add("advancements.gilemod.trade_weasel_thief.description", "Поторгуй с хорьком-барахольщиком");
        t.add("advancements.gilemod.trade_with_wisher.title", "Торговля желаниями");
        t.add("advancements.gilemod.trade_with_wisher.description", "Поторгуй с желателем");

        // Use
        t.add("advancements.gilemod.use_flutterer.title", "Я верю, что могу летать");
        t.add("advancements.gilemod.use_flutterer.description", "Опробуй порхатель");
        t.add("advancements.gilemod.use_enlarger.title", "Или больше, или никак");
        t.add("advancements.gilemod.use_enlarger.description", "Опробуй увеличитель");
        t.add("advancements.gilemod.use_grappling_hook.title", "Зацепиться за мир");
        t.add("advancements.gilemod.use_grappling_hook.description", "Опробуй абордажный крюк");
        t.add("advancements.gilemod.use_shrinker.title", "Маленькие проблемы");
        t.add("advancements.gilemod.use_shrinker.description", "Опробуй уменьшитель");
        t.add("advancements.gilemod.use_warp_clock.title", "Шов времени");
        t.add("advancements.gilemod.use_warp_clock.description", "Опробуй часы пространственного скачка");
    }

    public static void tooltips(FabricLanguageProvider.TranslationBuilder t) {
        // Trim Materials
        t.add("trim_material.gilemod.wish_ingot","Слиток желания");
        t.add("trim_material.gilemod.enderite_ingot","Эндеритовый слиток");

        // Fate Upgrade Smithing Template
        t.add("trim_pattern.gilemod.fate_upgrade", "Кузнечный шаблон");
        t.add("item.minecraft.smithing_template.applies_to", "Применяется к:");
        t.add("smithing_template.gilemod.fate_upgrade.applies_to", " Незеритовому снаряжению");
        t.add("item.minecraft.smithing_template.ingredients", "Ингредиенты:");
        t.add("smithing_template.gilemod.fate_upgrade.ingredients", " Эндеритовый слиток");

        // Warp Clock
        t.add("tooltip.gilemod.warp_clock.unlinked", "Не привязаны");
        t.add("tooltip.gilemod.warp_clock.coordinates", "Координаты варпа: ");
        t.add("tooltip.gilemod.warp_clock.linked_warp", "Привязанный варп: ");
        t.add("tooltip.gilemod.warp_clock.consumes", "Расходует: ");

        // Weapons
        t.add("tooltip.gilemod.weapon_level", "Уровень %s");
        t.add("tooltip.gilemod.daybreak_chronicles.when_in_hand","При нахождении в любой руке:");
        t.add("tooltip.gilemod.daybreak_chronicles.arrow_damage"," %s Урон стрелы");
        t.add("tooltip.gilemod.daybreak_chronicles.arrow_speed"," %s Скорость стрелы");
    }

    public static void messages (FabricLanguageProvider.TranslationBuilder t) {
        // Abilities
        t.add("message.gilemod.stomp_cooldown", "Топот ещё не готов!");
        t.add("message.gilemod.shrink_visibility_off", "Твоя форма вновь становится видимой.");
        t.add("message.gilemod.shrink_visibility_on", "Твоя форма исчезает из виду.");
        t.add("message.gilemod.stomp", "Земля дрожит под твоим шагом.");

        // Elemental abilities
        t.add("message.gilemod.venti_vortex_activated", "§3Вихрь Венти обрушен!");
        t.add("message.gilemod.venti_vortex_cooldown", "§3Вихрь Венти будет готов через %s §3сек.");
        t.add("message.gilemod.zhong_li_barricade_activated", "§6Барьер Чжун Ли воздвигнут!");
        t.add("message.gilemod.zhong_li_barricade_cooldown", "§6Барьер Чжун Ли будет готов через %s §6сек.");
        t.add("message.gilemod.zhong_li_barricade_error", "§6Барьер Чжун Ли: недостаточно Гео на поверхности.");
        t.add("message.gilemod.raiden_thunder_activated", "§5Гром Райдэн обрушивается!");
        t.add("message.gilemod.raiden_thunder_cooldown", "§5Гром Райдэн будет готов через %s §5сек.");
        t.add("message.gilemod.raiden_thunder_end", "§5⚡ Гроза стихает...");
        t.add("message.gilemod.nahida_sowing_activated", "§aПосев Нахиды пускает корни!");
        t.add("message.gilemod.nahida_sowing_cooldown", "§aПосев Нахиды будет готов через %s §aсек.");
        t.add("message.gilemod.furina_salon_members_activated", "§1Участники салона Фурины выходят на сцену!");
        t.add("message.gilemod.furina_salon_members_cooldown", "§1Участники салона Фурины будут готовы через %s §1сек.");
        t.add("message.gilemod.mavuika_rage_activated", "§cЯрость Мавуики вспыхивает!");
        t.add("message.gilemod.mavuika_rage_cooldown", "§cЯрость Мавуики будет готова через %s §cсек.");
        t.add("message.gilemod.tsaritsas_blizzard_activated", "§bМетель Царицы обрушивается!");
        t.add("message.gilemod.tsaritsas_blizzard_cooldown", "§bМетель Царицы будет готова через %s §bсек.");
        t.add("message.gilemod.lunar_domain_activated", "§7Лунная сфера Колумбины раскрывается!");
        t.add("message.gilemod.lunar_domain_cooldown", "§7Лунная сфера Колумбины будет готов через %s §7сек.");

        // Legendary abilities
        t.add("message.gilemod.naberius_benediction_activated", "§eБлагословение Набериуса даровано!");
        t.add("message.gilemod.naberius_benediction_cooldown", "§eБлагословение Набериуса будет готово через %s §eсек.");
        t.add("message.gilemod.naberius_life_utility_cooldown", "§eИсцеление Набериуса будет готово через %s §eсек.");
        t.add("message.gilemod.asmoday_event_horizon_activated", "§dГоризонт событий Асмодей открывается!");
        t.add("message.gilemod.asmoday_event_horizon_cooldown", "§dГоризонт событий Асмодей будет готов через %s §dсек.");
        t.add("message.gilemod.asmoday_space_no_safe_position","§dБезопасное место не найдено.");
        t.add("message.gilemod.asmoday_space_utility_cooldown", "§dТелепортация Асмодей будет готова через %s §dсек.");
        t.add("message.gilemod.istaroth_time_manipulation_activated", "§9Астарот склоняет время!");
        t.add("message.gilemod.istaroth_time_manipulation_cooldown", "§9Манипуляция временем Астарот будет готова через %s §9сек.");
        t.add("message.gilemod.istaroth_time_utility_cooldown", "§6Остановка времени Астарот будет готова через %s §6сек.");
        t.add("message.gilemod.ronova_lifesteal_activated", "§4Похищение жизни Роновы забирает своё!");
        t.add("message.gilemod.ronova_lifesteal_cooldown", "§4Похищение жизни Роновы будет готово через %s §4сек.");
        t.add("message.gilemod.ronova_lifesteal_utility_cooldown", "§4Прикосновение смерти Роновы будет готово через %s §4сек.");

        // Primordial abilities
        t.add("message.gilemod.phanes_ability_activated", "Началось сотворение Фанета.");
        t.add("message.gilemod.phanes_ability_cooldown","Сотворение Фанета перезаряжается: %s сек.");
        t.add("message.gilemod.divine_ability_activated","Божественное присутствие Фанета снизошло.");
        t.add("message.gilemod.divine_ability_cooldown","Божественное присутствие Фанета перезаряжается: %s сек.");
        t.add("message.gilemod.phanes_utility_cooldown", "Ускорение времени Фанета перезаряжается: %s сек.");
        t.add("message.gilemod.phanes_utility_activated", "Ускорение времени Фанета активировано. Игровое правило random_tick_speed теперь установлено на 100.");
        t.add("message.gilemod.phanes_utility_deactivated", "Ускорение времени Фанета деактивировано. Игровое правило random_tick_speed снова установлено на 3.");

        // End compass
        t.add("message.gilemod.end_compass.invalid_dimension", "Компас Края работает только между Верхним миром и Краем.");
        t.add("message.gilemod.end_compass.destination_missing", "Некуда телепортироваться...");
        t.add("message.gilemod.end_compass.no_safe_position", "Безопасное место не найдено.");
        t.add("message.gilemod.end_compass.main_end_warning", "⚠ ВНИМАНИЕ: ты будешь телепортирован на главный остров Края. Нажми ещё раз, чтобы продолжить.");

        // Warp clock
        t.add("message.gilemod.warp_clock.linked", "Варп-часы привязаны!");
        t.add("message.gilemod.warp_clock.unlinked", "Варп-часы отвязаны.");
        t.add("message.gilemod.warp_clock.click_sign", "Нажми на табличку, чтобы установить точку варпа.");
        t.add("message.gilemod.warp_clock.wrong_dimension", "Этот варп находится в другом измерении.");
        t.add("message.gilemod.warp_clock.no_chrono_gear", "Для активации этого варпа нужна хроно-шестерёнка!");
        t.add("message.gilemod.warp_clock.missing_sign", "Ошибка: таблички этого варпа больше не существует!");

        // Nuclear Cannon
        t.add("message.gilemod.nuclear_cannon_broken", "§cУ твоей ядерной пушки закончились боеприпасы! Перезаряди её с помощью Shift + ПКМ, держа в руке самородки желания.");
        t.add("message.gilemod.nuclear_cannon_repaired", "§aЯдерная пушка перезаряжена!");
        t.add("message.gilemod.nuclear_cannon_ammo", "§cДля перезарядки нужны самородки желания во второй руке!");
        t.add("message.gilemod.nuclear_cannon_full","§aТвоя ядерная пушка уже полностью заряжена!");
    }

    public static void keybinds(FabricLanguageProvider.TranslationBuilder t) {
        t.add("key.category.gilemod.keys", "Genshin Impact: Лунное Расширение");
        t.add("key.gilemod.flutterer_jump", "Прыжок порхателя");
        t.add("key.gilemod.active_ability", "Стихийная/магическая способность");
        t.add("key.gilemod.divine_ability", "Божественная способность");
    }

    public static void sounds(FabricLanguageProvider.TranslationBuilder t) {
        t.add("subtitles.gilemod.entity.luminous.ambient", "Светяшка урчит");
        t.add("subtitles.gilemod.entity.luminous.hurt", "Светяшка получает урон");
        t.add("subtitles.gilemod.entity.weasel_thief.ambient", "Хорёк-барахольщик звенит");
        t.add("subtitles.gilemod.entity.hovering_ghost.nyan_ambient", "Звучит Nyan Cat");
        t.add("subtitles.gilemod.entity.ruin_guard.hit", "Страж руин наносит удар");
        t.add("subtitles.gilemod.entity.ruin_guard.rotation", "Страж руин вращается");
    }

    public static void misc(FabricLanguageProvider.TranslationBuilder t) {
        // Item Groups
        t.add("itemgroup.gilemod.gile", "GILE");

        // Villager Professions
        t.add("entity.gilemod.villager.wisher", "Желатель");

        // GUIs
        t.add("container.gilemod.wish_table", "Алтарь желаний");

        // Enchantments
        t.add("enchantment.gilemod.fluttering", "Порхание");
        t.add("enchantment.gilemod.range", "Дальность");

        // Item Tags
        t.add("tag.item.gilemod.enchantable.range", "Предметы для зачарования дальности");
        t.add("tag.item.gilemod.wish_input", "Предметы для желаний");
        t.add("tag.item.gilemod.sigil_input", "Предметы для печатей");
        t.add("tag.item.gilemod.elemental_weapon", "Стихийное оружие");
        t.add("tag.item.gilemod.legendary_weapon", "Легендарное оружие");
        t.add("tag.item.gilemod.primordial_weapon", "Первородное оружие");
        t.add("tag.item.gilemod.enderite_mining_tools", "Инструменты для добычи эндерита");
        t.add("tag.item.gilemod.enderite_tool_materials", "Материалы для инструментов эндерита");
    }

}