package mh837.gile.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.GileMod;
import mh837.gile.entity.JerboaEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class JerboaRenderer extends MobRenderer<
        JerboaEntity,
        JerboaRenderer.JerboaRenderState,
        EntityModel<JerboaRenderer.JerboaRenderState>> {

    public static final ModelLayerLocation JERBOA_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "jerboa"),
                    "main"
            );

    public static final ModelLayerLocation JERBOA_BABY_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "jerboa_baby"),
                    "main"
            );

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/jerboa.png"
            );

    private final JerboaModel adultModel;
    private final JerboaBabyModel babyModel;

    public JerboaRenderer(EntityRendererProvider.Context context) {
        super(
                context,
                new JerboaModel(context.bakeLayer(JERBOA_LAYER)),
                0.3F
        );

        this.adultModel = (JerboaModel) this.model;
        this.babyModel = new JerboaBabyModel(
                context.bakeLayer(JERBOA_BABY_LAYER)
        );
    }

    @Override
    public JerboaRenderState createRenderState() {
        return new JerboaRenderState();
    }

    @Override
    public void extractRenderState(
            JerboaEntity entity,
            JerboaRenderState state,
            float partialTick
    ) {
        super.extractRenderState(
                entity,
                state,
                partialTick
        );

        state.isDesert = entity.isDesertVariant();
        state.isHiding = entity.isHiding();
    }

    @Override
    public void submit(
            JerboaRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState camera
    ) {
        this.model = state.isBaby
                ? this.babyModel
                : this.adultModel;

        super.submit(
                state,
                poseStack,
                collector,
                camera
        );
    }

    @Override
    public Identifier getTextureLocation(JerboaRenderState state) {
        return TEXTURE;
    }

    @Override
    protected void scale(
            JerboaRenderState state,
            PoseStack poseStack
    ) {
        /*
         * Baby scaling deliberately removed.
         *
         * Hiding is a genuine pose/state and remains a renderer-scale
         * operation because it is unrelated to age.
         */
        if (state.isHiding) {
            poseStack.scale(1.0F, 0.15F, 1.0F);
        }
    }

    public static class JerboaRenderState extends LivingEntityRenderState {
        public boolean isDesert;
        public boolean isHiding;
    }

    public static class JerboaModel
            extends EntityModel<JerboaRenderState> {

        protected final ModelPart root;

        private final ModelPart bodyNormal;
        private final ModelPart headNormal;
        private final ModelPart leftEarNormal;
        private final ModelPart rightEarNormal;
        private final ModelPart tailNormal;

        private final ModelPart bodyDesert;
        private final ModelPart headDesert;
        private final ModelPart leftEarDesert;
        private final ModelPart rightEarDesert;
        private final ModelPart tailDesert;

        public JerboaModel(ModelPart root) {
            super(root);

            this.root = root;

            this.bodyNormal = root.getChild("body");
            this.headNormal = root.getChild("head");
            this.leftEarNormal = headNormal.getChild("left_ear");
            this.rightEarNormal = headNormal.getChild("right_ear");
            this.tailNormal = root.getChild("tail");

            this.bodyDesert = root.getChild("body_desert");
            this.headDesert = root.getChild("head_desert");
            this.leftEarDesert =
                    headDesert.getChild("left_ear_desert");
            this.rightEarDesert =
                    headDesert.getChild("right_ear_desert");
            this.tailDesert = root.getChild("tail_desert");
        }

        public static LayerDefinition getTexturedModelData() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();

            root.addOrReplaceChild(
                    "body",
                    CubeListBuilder.create()
                            .texOffs(0, 0)
                            .addBox(
                                    -2.5F, -3.0F, -3.5F,
                                    5.0F, 4.0F, 7.0F
                            ),
                    PartPose.offset(0.0F, 22.0F, 0.0F)
            );

            PartDefinition head = root.addOrReplaceChild(
                    "head",
                    CubeListBuilder.create()
                            .texOffs(0, 11)
                            .addBox(
                                    -2.0F, -2.0F, -3.0F,
                                    4.0F, 3.0F, 4.0F
                            ),
                    PartPose.offset(0.0F, 20.5F, -2.5F)
            );

            head.addOrReplaceChild(
                    "left_ear",
                    CubeListBuilder.create()
                            .texOffs(17, 0)
                            .addBox(0.0F, -4.0F, 0.0F,
                                    1.0F, 4.0F, 1.0F),
                    PartPose.offset(1.0F, -2.0F, -1.0F)
            );

            head.addOrReplaceChild(
                    "right_ear",
                    CubeListBuilder.create()
                            .texOffs(21, 0)
                            .addBox(-1.0F, -4.0F, 0.0F,
                                    1.0F, 4.0F, 1.0F),
                    PartPose.offset(-1.0F, -2.0F, -1.0F)
            );

            root.addOrReplaceChild(
                    "tail",
                    CubeListBuilder.create()
                            .texOffs(16, 12)
                            .addBox(-0.5F, 0.0F, 0.0F,
                                    1.0F, 5.0F, 1.0F),
                    PartPose.offsetAndRotation(
                            0.0F, 20.0F, 3.0F,
                            0.8F, 0.0F, 0.0F
                    )
            );

            root.addOrReplaceChild(
                    "body_desert",
                    CubeListBuilder.create()
                            .texOffs(0, 24)
                            .addBox(
                                    -2.5F, -3.0F, -3.5F,
                                    5.0F, 4.0F, 7.0F
                            ),
                    PartPose.offset(0.0F, 22.0F, 0.0F)
            );

            PartDefinition desertHead = root.addOrReplaceChild(
                    "head_desert",
                    CubeListBuilder.create()
                            .texOffs(0, 35)
                            .addBox(
                                    -2.0F, -2.0F, -3.0F,
                                    4.0F, 3.0F, 4.0F
                            ),
                    PartPose.offset(0.0F, 20.5F, -2.5F)
            );

            desertHead.addOrReplaceChild(
                    "left_ear_desert",
                    CubeListBuilder.create()
                            .texOffs(17, 24)
                            .addBox(0.0F, -4.0F, 0.0F,
                                    1.0F, 4.0F, 1.0F),
                    PartPose.offset(1.0F, -2.0F, -1.0F)
            );

            desertHead.addOrReplaceChild(
                    "right_ear_desert",
                    CubeListBuilder.create()
                            .texOffs(21, 24)
                            .addBox(-1.0F, -4.0F, 0.0F,
                                    1.0F, 4.0F, 1.0F),
                    PartPose.offset(-1.0F, -2.0F, -1.0F)
            );

            root.addOrReplaceChild(
                    "tail_desert",
                    CubeListBuilder.create()
                            .texOffs(16, 36)
                            .addBox(-0.5F, 0.0F, 0.0F,
                                    1.0F, 5.0F, 1.0F),
                    PartPose.offsetAndRotation(
                            0.0F, 20.0F, 3.0F,
                            0.8F, 0.0F, 0.0F
                    )
            );

            return LayerDefinition.create(mesh, 32, 64);
        }

        @Override
        public void setupAnim(JerboaRenderState state) {
            super.setupAnim(state);

            root.getAllParts().forEach(ModelPart::resetPose);

            boolean desert = state.isDesert;

            bodyNormal.visible = !desert;
            headNormal.visible = !desert;
            tailNormal.visible = !desert;

            bodyDesert.visible = desert;
            headDesert.visible = desert;
            tailDesert.visible = desert;

            ModelPart body = desert ? bodyDesert : bodyNormal;
            ModelPart head = desert ? headDesert : headNormal;
            ModelPart leftEar =
                    desert ? leftEarDesert : leftEarNormal;
            ModelPart rightEar =
                    desert ? rightEarDesert : rightEarNormal;
            ModelPart tail =
                    desert ? tailDesert : tailNormal;

            if (state.isHiding) {
                body.y += 4.0F;
                head.y += 4.0F;

                leftEar.xRot = -1.2F;
                rightEar.xRot = -1.2F;
                return;
            }

            float hop =
                    Mth.cos(
                            state.walkAnimationPos * 1.4F
                    ) * 1.2F * state.walkAnimationSpeed;

            body.xRot = hop * 0.15F;

            head.yRot =
                    state.yRot * ((float) Math.PI / 180F);
            head.xRot =
                    state.xRot * ((float) Math.PI / 180F);

            tail.yRot =
                    Mth.cos(state.ageInTicks * 0.2F) * 0.15F;

            leftEar.zRot =
                    Mth.cos(state.ageInTicks * 0.15F) * 0.05F;
            rightEar.zRot = -leftEar.zRot;
        }
    }

    /*
     * Juvenile model.
     *
     * Notice that the dimensions are changed directly instead of applying
     * PoseStack.scale(). This is the important part of the takeover.
     */
    public static class JerboaBabyModel
            extends EntityModel<JerboaRenderState> {

        private final ModelPart root;
        private final ModelPart bodyNormal, headNormal, leftEarNormal, rightEarNormal, tailNormal;
        private final ModelPart bodyDesert, headDesert, leftEarDesert, rightEarDesert, tailDesert;

        public JerboaBabyModel(ModelPart root) {
            super(root);
            this.root = root;
            bodyNormal = root.getChild("body");
            headNormal = root.getChild("head");
            leftEarNormal = headNormal.getChild("left_ear");
            rightEarNormal = headNormal.getChild("right_ear");
            tailNormal = root.getChild("tail");
            bodyDesert = root.getChild("body_desert");
            headDesert = root.getChild("head_desert");
            leftEarDesert = headDesert.getChild("left_ear_desert");
            rightEarDesert = headDesert.getChild("right_ear_desert");
            tailDesert = root.getChild("tail_desert");
        }

        public static LayerDefinition getTexturedModelData() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();
            addVariant(root, false, 0);
            addVariant(root, true, 24);
            return LayerDefinition.create(mesh, 32, 64);
        }

        private static void addVariant(PartDefinition root, boolean desert, int vOffset) {
            String suffix = desert ? "_desert" : "";
            PartDefinition body = root.addOrReplaceChild(
                    "body" + suffix,
                    CubeListBuilder.create()
                            .texOffs(17, 17 + vOffset)
                            .addBox(-1.75F, -2.0F, -1.0F, 3.0F, 2.0F, 4.0F),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );
            PartDefinition head = root.addOrReplaceChild(
                    "head" + suffix,
                    CubeListBuilder.create()
                            .texOffs(7, 19 + vOffset)
                            .addBox(-1.75F, -3.0F, -2.0F, 3.0F, 2.0F, 2.0F),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );
            head.addOrReplaceChild("left_ear" + suffix,
                    CubeListBuilder.create().texOffs(17, vOffset).addBox(-1.75F, -5.0F, -2.0F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
            head.addOrReplaceChild("right_ear" + suffix,
                    CubeListBuilder.create().texOffs(21, vOffset).mirror().addBox(0.25F, -5.0F, -2.0F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
            root.addOrReplaceChild("tail" + suffix,
                    CubeListBuilder.create().texOffs(16, 12 + vOffset).addBox(-1.0F, -2.0F, -1.0F, 1.0F, 2.0F, 1.0F),
                    PartPose.offsetAndRotation(0.25F, 23.0F, 2.5F, -2.0071F, 0.0F, 0.0F));
        }

        @Override
        public void setupAnim(JerboaRenderState state) {
            root.getAllParts().forEach(ModelPart::resetPose);
            boolean desert = state.isDesert;
            bodyNormal.visible = !desert;
            headNormal.visible = !desert;
            tailNormal.visible = !desert;
            bodyDesert.visible = desert;
            headDesert.visible = desert;
            tailDesert.visible = desert;
            ModelPart body = desert ? bodyDesert : bodyNormal;
            ModelPart head = desert ? headDesert : headNormal;
            ModelPart leftEar = desert ? leftEarDesert : leftEarNormal;
            ModelPart rightEar = desert ? rightEarDesert : rightEarNormal;
            ModelPart tail = desert ? tailDesert : tailNormal;
            if (state.isHiding) {
                body.y += 3.0F;
                head.y += 3.0F;
                leftEar.xRot = -1.2F;
                rightEar.xRot = -1.2F;
                return;
            }
            float hop = Mth.cos(state.walkAnimationPos * 1.4F) * state.walkAnimationSpeed;
            body.xRot = hop * 0.12F;
            head.yRot = state.yRot * ((float) Math.PI / 180F);
            head.xRot = state.xRot * ((float) Math.PI / 180F);
            tail.yRot = Mth.cos(state.ageInTicks * 0.2F) * 0.12F;
            leftEar.zRot = Mth.cos(state.ageInTicks * 0.15F) * 0.04F;
            rightEar.zRot = -leftEar.zRot;
        }
    }
}