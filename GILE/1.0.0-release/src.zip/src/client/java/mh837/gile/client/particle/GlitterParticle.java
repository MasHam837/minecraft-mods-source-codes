package mh837.gile.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.SingleQuadParticle;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.RandomSource;

import java.awt.Color;

public class GlitterParticle extends SingleQuadParticle {

    private final SpriteSet sprites;

    protected GlitterParticle(
            ClientLevel level,
            double x,
            double y,
            double z,
            double velocityX,
            double velocityY,
            double velocityZ,
            SpriteSet sprites
    ) {
        super(
                level,
                x,
                y,
                z,
                velocityX * 0.08D,
                velocityY * 0.08D,
                velocityZ * 0.08D,
                sprites.get(0, 1)
        );

        this.sprites = sprites;

        // Very small glitter.
        this.quadSize *= 0.25F;

        // Let the tiny particles linger.
        this.lifetime = 40;

        // No gravity.
        this.gravity = 0.0F;

        // Very gentle movement.
        this.xd *= 0.15D;
        this.yd *= 0.15D;
        this.zd *= 0.15D;

        this.setSpriteFromAge(this.sprites);
        this.updateRainbowColor();
    }

    @Override
    public void tick() {
        super.tick();

        this.setSpriteFromAge(this.sprites);
        this.updateRainbowColor();
    }

    /**
     * Creates a slowly cycling rainbow effect.
     */
    private void updateRainbowColor() {
        float hue = (this.age * 0.0125F) % 1.0F;

        int rgb = Color.HSBtoRGB(hue, 1.0F, 1.0F);

        float red = ((rgb >> 16) & 0xFF) / 255.0F;
        float green = ((rgb >> 8) & 0xFF) / 255.0F;
        float blue = (rgb & 0xFF) / 255.0F;

        this.setColor(red, green, blue);
    }

    @Override
    protected Layer getLayer() {
        return Layer.TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {

        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(
                SimpleParticleType type,
                ClientLevel level,
                double x,
                double y,
                double z,
                double velocityX,
                double velocityY,
                double velocityZ,
                RandomSource random
        ) {
            return new GlitterParticle(
                    level,
                    x,
                    y,
                    z,
                    velocityX,
                    velocityY,
                    velocityZ,
                    this.sprites
            );
        }
    }
}