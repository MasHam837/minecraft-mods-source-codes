package mh837.gile.client.lang;

import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.core.HolderLookup;

import java.util.concurrent.CompletableFuture;

public final class GileModFrenchLangProvider extends FabricLanguageProvider {

    public GileModFrenchLangProvider(
            FabricPackOutput output,
            CompletableFuture<HolderLookup.Provider> lookup
    ) {
        super(output, "fr_fr", lookup);
    }

    @Override
    public void generateTranslations(
            HolderLookup.Provider lookup,
            TranslationBuilder t
    ) {
        GileModFrenchTextProvider.advancements(t);
        GileModFrenchTextProvider.tooltips(t);
        GileModFrenchTextProvider.messages(t);
        GileModFrenchTextProvider.keybinds(t);
        GileModFrenchTextProvider.sounds(t);
        GileModFrenchTextProvider.misc(t);

        GileModFrenchNamesProvider.items(t);
        GileModFrenchNamesProvider.blocks(t);
        GileModFrenchNamesProvider.entities(t);
        GileModFrenchNamesProvider.effects(t);
    }
}