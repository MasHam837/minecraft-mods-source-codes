package mh837.gile.client.model.layer;

import mh837.gile.GileMod;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public final class GlitterModelLayer {

    public static final ModelLayerLocation GLITTER_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            GileMod.MOD_ID,
                            "glitter"
                    ),
                    "main"
            );

    private GlitterModelLayer() {
    }
}
