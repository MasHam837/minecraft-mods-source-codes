package mh837.gile.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.client.renderer.entity.feature.HoveringGhostTransparencyFeatureRenderer;
import mh837.gile.entity.HoveringGhostEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class HoveringGhostRenderer extends MobRenderer<
        HoveringGhostEntity,
        HoveringGhostRenderer.HoveringGhostRenderState,
        EntityModel<HoveringGhostRenderer.HoveringGhostRenderState>
        > {

    public static final ModelLayerLocation GHOST_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "hovering_ghost"
                    ),
                    "main"
            );

    public static final ModelLayerLocation GHOST_BABY_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "hovering_ghost_baby"
                    ),
                    "main"
            );

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(
                    "gilemod",
                    "textures/entity/hovering_ghost/hovering_ghost.png"
            );

    private final HoveringGhostModel adultModel;
    private final HoveringGhostBabyModel babyModel;

    public HoveringGhostRenderer(
            EntityRendererProvider.Context context
    ) {
        super(
                context,
                new HoveringGhostModel(
                        context.bakeLayer(GHOST_LAYER)
                ),
                0.0F
        );

        this.adultModel = (HoveringGhostModel) this.model;

        this.babyModel = new HoveringGhostBabyModel(
                context.bakeLayer(GHOST_BABY_LAYER)
        );

        this.addLayer(
                new HoveringGhostTransparencyFeatureRenderer(this)
        );
    }

    @Override
    public HoveringGhostRenderState createRenderState() {
        return new HoveringGhostRenderState();
    }

    @Override
    public void extractRenderState(
            HoveringGhostEntity entity,
            HoveringGhostRenderState state,
            float partialTick
    ) {
        super.extractRenderState(
                entity,
                state,
                partialTick
        );

        state.isNyan =
                entity.hasCustomName()
                        && "Nyan Cat".equalsIgnoreCase(
                        entity.getCustomName().getString()
                );

        state.isSaddled = entity.isSaddled();

        this.model = state.isBaby
                ? this.babyModel
                : this.adultModel;
    }

    @Override
    public void submit(
            HoveringGhostRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState camera
    ) {
        this.model = state.isBaby
                ? this.babyModel
                : this.adultModel;

        super.submit(
                state,
                poseStack,
                collector,
                camera
        );
    }

    @Override
    public Identifier getTextureLocation(
            HoveringGhostRenderState state
    ) {
        return TEXTURE;
    }

    @Override
    protected void scale(
            HoveringGhostRenderState state,
            PoseStack poseStack
    ) {
        /*
         * No baby scaling.
         *
         * Baby proportions are handled by HoveringGhostBabyModel.
         */
    }

    public static class HoveringGhostRenderState
            extends LivingEntityRenderState {

        public boolean isNyan;
        public boolean isSaddled;
    }

    // ============================================================
    // ADULT MODEL
    // ============================================================

    public static class HoveringGhostModel
            extends EntityModel<HoveringGhostRenderState> {

        private final ModelPart root;

        private final ModelPart cleanBodyNormal;
        private final ModelPart saddledBodyNormal;
        private final ModelPart earsNormal;

        private final ModelPart cleanBodyNyan;
        private final ModelPart saddledBodyNyan;
        private final ModelPart earsNyan;

        public HoveringGhostModel(ModelPart root) {
            super(root);

            this.root = root;

            this.cleanBodyNormal =
                    root.getChild("clean_body_normal");
            this.saddledBodyNormal =
                    root.getChild("saddled_body_normal");
            this.earsNormal =
                    root.getChild("ears_normal");

            this.cleanBodyNyan =
                    root.getChild("clean_body_nyan");
            this.saddledBodyNyan =
                    root.getChild("saddled_body_nyan");
            this.earsNyan =
                    root.getChild("ears_nyan");
        }

        public static LayerDefinition getTexturedModelData() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();

            // NORMAL

            root.addOrReplaceChild(
                    "clean_body_normal",
                    CubeListBuilder.create()
                            .texOffs(0, 0)
                            .addBox(
                                    -12.0F, -12.0F, -20.0F,
                                    24.0F, 12.0F, 40.0F
                            ),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            root.addOrReplaceChild(
                    "saddled_body_normal",
                    CubeListBuilder.create()
                            .texOffs(128, 0)
                            .addBox(
                                    -12.0F, -12.0F, -20.0F,
                                    24.0F, 12.0F, 40.0F
                            ),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            root.addOrReplaceChild(
                    "ears_normal",
                    CubeListBuilder.create()
                            .texOffs(0, 52)
                            .addBox(
                                    -12.0F, -18.0F, -19.99F,
                                    24.0F, 6.0F, 0.0F
                            ),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            // NYAN

            root.addOrReplaceChild(
                    "clean_body_nyan",
                    CubeListBuilder.create()
                            .texOffs(0, 64)
                            .addBox(
                                    -12.0F, -12.0F, -20.0F,
                                    24.0F, 12.0F, 40.0F
                            ),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            root.addOrReplaceChild(
                    "saddled_body_nyan",
                    CubeListBuilder.create()
                            .texOffs(128, 64)
                            .addBox(
                                    -12.0F, -12.0F, -20.0F,
                                    24.0F, 12.0F, 40.0F
                            ),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            root.addOrReplaceChild(
                    "ears_nyan",
                    CubeListBuilder.create()
                            .texOffs(0, 116)
                            .addBox(
                                    -12.0F, -18.0F, -19.99F,
                                    24.0F, 6.0F, 0.0F
                            ),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            return LayerDefinition.create(
                    mesh,
                    256,
                    128
            );
        }

        @Override
        public void setupAnim(
                HoveringGhostRenderState state
        ) {
            root.resetPose();

            float bob =
                    Mth.sin(state.ageInTicks * 0.15F) * 1.5F;

            cleanBodyNormal.y = 24F + bob;
            saddledBodyNormal.y = 24F + bob;
            earsNormal.y = 24F + bob;

            cleanBodyNyan.y = 24F + bob;
            saddledBodyNyan.y = 24F + bob;
            earsNyan.y = 24F + bob;

            cleanBodyNormal.visible =
                    !state.isNyan && !state.isSaddled;
            saddledBodyNormal.visible =
                    !state.isNyan && state.isSaddled;
            earsNormal.visible =
                    !state.isNyan;

            cleanBodyNyan.visible =
                    state.isNyan && !state.isSaddled;
            saddledBodyNyan.visible =
                    state.isNyan && state.isSaddled;
            earsNyan.visible =
                    state.isNyan;
        }
    }

    // ============================================================
    // BABY MODEL
    // ============================================================

    public static class HoveringGhostBabyModel
            extends EntityModel<HoveringGhostRenderState> {

        private final ModelPart root;

        private final ModelPart cleanBodyNormal;
        private final ModelPart saddledBodyNormal;
        private final ModelPart earsNormal;
        private final ModelPart cleanBodyNyan;
        private final ModelPart saddledBodyNyan;
        private final ModelPart earsNyan;

        public HoveringGhostBabyModel(ModelPart root) {
            super(root);
            this.root = root;
            cleanBodyNormal = root.getChild("clean_body_normal");
            saddledBodyNormal = root.getChild("saddled_body_normal");
            earsNormal = root.getChild("ears_normal");
            cleanBodyNyan = root.getChild("clean_body_nyan");
            saddledBodyNyan = root.getChild("saddled_body_nyan");
            earsNyan = root.getChild("ears_nyan");
        }

        public static LayerDefinition getTexturedModelData() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();

            addVariant(root, "clean_body_normal", "ears_normal", 0, 0);
            addVariant(root, "saddled_body_normal", "ears_normal_unused", 128, 0);
            // Nyan texture is the lower half of the 256x128 texture.
            addVariant(root, "clean_body_nyan", "ears_nyan", 0, 64);
            addVariant(root, "saddled_body_nyan", "ears_nyan_unused", 128, 64);

            // The normal/saddled and Nyan/saddled variants each need their own
            // body geometry, but ears are separate parts so the existing
            // visibility logic can continue to work.
            return LayerDefinition.create(mesh, 256, 128);
        }

        private static void addVariant(
                PartDefinition root,
                String bodyName,
                String earsName,
                int uOffset,
                int vOffset
        ) {
            root.addOrReplaceChild(
                    bodyName,
                    CubeListBuilder.create()
                            .texOffs(89 + uOffset, 1 + vOffset)
                            .addBox(-6.0F, -7.0F, -4.0F, 12.0F, 6.0F, 20.0F),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            if (!earsName.endsWith("_unused")) {
                root.addOrReplaceChild(
                        earsName,
                        CubeListBuilder.create()
                                .texOffs(90 + uOffset, 28 + vOffset)
                                .addBox(-5.0F, -9.0F, -4.0F, 10.0F, 2.0F, 0.0F),
                        PartPose.offset(0.0F, 24.0F, 0.0F)
                );
            }
        }

        @Override
        public void setupAnim(HoveringGhostRenderState state) {
            root.resetPose();

            float bob = Mth.sin(state.ageInTicks * 0.15F) * 1.0F;

            cleanBodyNormal.y = 24F + bob;
            saddledBodyNormal.y = 24F + bob;
            earsNormal.y = 24F + bob;
            cleanBodyNyan.y = 24F + bob;
            saddledBodyNyan.y = 24F + bob;
            earsNyan.y = 24F + bob;

            cleanBodyNormal.visible = !state.isNyan && !state.isSaddled;
            saddledBodyNormal.visible = !state.isNyan && state.isSaddled;
            earsNormal.visible = !state.isNyan;
            cleanBodyNyan.visible = state.isNyan && !state.isSaddled;
            saddledBodyNyan.visible = state.isNyan && state.isSaddled;
            earsNyan.visible = state.isNyan;
        }
    }
}