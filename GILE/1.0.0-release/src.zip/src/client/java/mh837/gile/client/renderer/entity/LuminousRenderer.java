package mh837.gile.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.client.renderer.entity.feature.LuminousGlowFeatureRenderer;
import mh837.gile.entity.LuminousEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class LuminousRenderer extends MobRenderer<
        LuminousEntity,
        LuminousRenderer.LuminousRenderState,
        EntityModel<LuminousRenderer.LuminousRenderState>> {

    public static final ModelLayerLocation LUMINOUS_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "luminous"
                    ),
                    "main"
            );

    public static final ModelLayerLocation LUMINOUS_BABY_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "luminous_baby"
                    ),
                    "main"
            );

    static final Identifier YELLOW_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    "gilemod",
                    "textures/entity/luminous/yellow.png"
            );

    static final Identifier LIGHT_BLUE_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    "gilemod",
                    "textures/entity/luminous/light_blue.png"
            );

    static final Identifier PINK_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    "gilemod",
                    "textures/entity/luminous/pink.png"
            );

    private final LuminousModel adultModel;
    private final LuminousBabyModel babyModel;

    public LuminousRenderer(
            EntityRendererProvider.Context context
    ) {
        super(
                context,
                new LuminousModel(
                        context.bakeLayer(
                                LUMINOUS_LAYER
                        )
                ),
                0.0f
        );

        this.adultModel = (LuminousModel) this.model;

        this.babyModel =
                new LuminousBabyModel(
                        context.bakeLayer(
                                LUMINOUS_BABY_LAYER
                        )
                );

        this.addLayer(
                new LuminousGlowFeatureRenderer(this)
        );
    }

    @Override
    public LuminousRenderState createRenderState() {
        return new LuminousRenderState();
    }

    @Override
    public void extractRenderState(
            LuminousEntity entity,
            LuminousRenderState state,
            float partialTick
    ) {
        super.extractRenderState(
                entity,
                state,
                partialTick
        );

        state.variant = entity.getVariant();

        state.texture =
                switch (state.variant) {
                    case 1 -> LIGHT_BLUE_TEXTURE;
                    case 2 -> PINK_TEXTURE;
                    default -> YELLOW_TEXTURE;
                };
    }

    @Override
    public void submit(
            LuminousRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState camera
    ) {
        this.model = state.isBaby
                ? this.babyModel
                : this.adultModel;

        super.submit(
                state,
                poseStack,
                collector,
                camera
        );
    }

    @Override
    protected void scale(
            LuminousRenderState state,
            PoseStack poseStack
    ) {
        /*
         * No baby scale.
         *
         * The juvenile proportions are contained entirely inside
         * LuminousBabyModel.
         */
    }

    @Override
    public Identifier getTextureLocation(
            LuminousRenderState state
    ) {
        return state.texture;
    }

    public static class LuminousRenderState
            extends LivingEntityRenderState {

        public int variant;
        public Identifier texture;
    }

    // ============================================================
    // ADULT MODEL
    // ============================================================

    public static class LuminousModel
            extends EntityModel<LuminousRenderState> {

        private final ModelPart root;
        private final ModelPart body;
        private final ModelPart leftEar;
        private final ModelPart rightEar;

        private final ModelPart[] feet =
                new ModelPart[8];

        public LuminousModel(ModelPart root) {
            super(root);

            this.root = root;

            body =
                    root.getChild("body");

            leftEar =
                    body.getChild("left_ear");

            rightEar =
                    body.getChild("right_ear");

            for (int i = 0; i < 8; i++) {
                feet[i] =
                        body.getChild("foot_" + i);
            }
        }

        public static LayerDefinition getTexturedModelData() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();

            PartDefinition bodyData =
                    root.addOrReplaceChild(
                            "body",
                            CubeListBuilder.create()
                                    .texOffs(0, 0)
                                    .addBox(
                                            -6.0F, -13.5F, -6.0F,
                                            12.0F, 12.0F, 12.0F
                                    ),
                            PartPose.offset(
                                    0.0F, 24.0F, 0.0F
                            )
                    );

            bodyData.addOrReplaceChild(
                    "left_ear",
                    CubeListBuilder.create()
                            .texOffs(0, 24)
                            .addBox(
                                    0.0F, 0.0F, 0.0F,
                                    4.0F, 4.0F, 1.0F
                            ),
                    PartPose.offsetAndRotation(
                            6.0F, -10.0F, 0.0F,
                            0.0F, 1.5708F, -0.2F
                    )
            );

            bodyData.addOrReplaceChild(
                    "right_ear",
                    CubeListBuilder.create()
                            .texOffs(0, 24)
                            .mirror()
                            .addBox(
                                    -4.0F, 0.0F, 0.0F,
                                    4.0F, 4.0F, 1.0F
                            ),
                    PartPose.offsetAndRotation(
                            -6.0F, -10.0F, 0.0F,
                            0.0F, -1.5708F, 0.2F
                    )
            );

            float[][] footPositions = {
                    {4.0F, -5.0F},
                    {4.0F, 0.0F},
                    {4.0F, 5.0F},
                    {-4.0F, -5.0F},
                    {-4.0F, 0.0F},
                    {-4.0F, 5.0F},
                    {0.0F, -5.0F},
                    {0.0F, 5.0F}
            };

            for (int i = 0; i < 8; i++) {
                bodyData.addOrReplaceChild(
                        "foot_" + i,
                        CubeListBuilder.create()
                                .texOffs(0, 30)
                                .addBox(
                                        -1.5F, -1.5F, -1.5F,
                                        3.0F, 1.0F, 3.0F
                                ),
                        PartPose.offset(
                                footPositions[i][0],
                                0.0F,
                                footPositions[i][1]
                        )
                );
            }

            return LayerDefinition.create(
                    mesh,
                    64,
                    64
            );
        }

        @Override
        public void setupAnim(
                LuminousRenderState state
        ) {
            super.setupAnim(state);

            root.resetPose();

            float idleSpeed =
                    state.ageInTicks * 0.1F;

            leftEar.zRot =
                    -0.2F
                            - Mth.sin(idleSpeed) * 0.08F;

            rightEar.zRot =
                    0.2F
                            + Mth.sin(idleSpeed) * 0.08F;

            leftEar.xRot =
                    Mth.cos(idleSpeed) * 0.05F;

            rightEar.xRot =
                    Mth.cos(idleSpeed) * 0.05F;

            for (int i = 0; i < 8; i++) {
                float phaseOffset =
                        i * 0.4F;

                feet[i].xRot =
                        Mth.sin(
                                state.ageInTicks * 0.2F
                                        + phaseOffset
                        ) * 0.15F;

                feet[i].zRot =
                        Mth.cos(
                                state.ageInTicks * 0.2F
                                        + phaseOffset
                        ) * 0.1F;
            }
        }
    }

    // ============================================================
    // BABY MODEL
    // ============================================================

    public static class LuminousBabyModel
            extends EntityModel<LuminousRenderState> {

        private final ModelPart root;
        private final ModelPart body;
        private final ModelPart[] feet = new ModelPart[8];

        public LuminousBabyModel(ModelPart root) {
            super(root);
            this.root = root;
            body = root.getChild("body");
            for (int i = 0; i < 8; i++) feet[i] = body.getChild("foot_" + i);
        }

        public static LayerDefinition getTexturedModelData() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();
            PartDefinition body = root.addOrReplaceChild(
                    "body",
                    CubeListBuilder.create()
                            .texOffs(13, 25)
                            .addBox(-3.0F, -7.0F, -3.0F, 6.0F, 6.0F, 6.0F),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );
            float[][] footBoxes = {
                    {-3.25F, -1.0F, -3.25F},
                    {-3.25F, -1.0F, -0.5F},
                    {-3.25F, -1.0F, 2.25F},
                    {2.25F, -1.0F, 2.25F},
                    {-0.5F, -1.0F, 2.25F},
                    {-0.5F, -1.0F, -3.25F},
                    {2.25F, -1.0F, -3.25F},
                    {2.25F, -1.0F, -0.5F}
            };
            for (int i = 0; i < 8; i++) {
                body.addOrReplaceChild(
                        "foot_" + i,
                        CubeListBuilder.create().texOffs(4, 32).addBox(
                                footBoxes[i][0], footBoxes[i][1], footBoxes[i][2],
                                1.0F, 1.0F, 1.0F),
                        PartPose.ZERO
                );
            }
            return LayerDefinition.create(mesh, 64, 64);
        }

        @Override
        public void setupAnim(LuminousRenderState state) {
            super.setupAnim(state);
            root.resetPose();
            for (int i = 0; i < 8; i++) {
                float phaseOffset = i * 0.4F;
                feet[i].xRot = Mth.sin(state.ageInTicks * 0.2F + phaseOffset) * 0.12F;
                feet[i].zRot = Mth.cos(state.ageInTicks * 0.2F + phaseOffset) * 0.1F;
            }
        }
    }
}