package mh837.gile.client.renderer.entity.feature;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.GileMod;
import mh837.gile.client.renderer.entity.HoveringGhostRenderer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

public class HoveringGhostTransparencyFeatureRenderer
        extends RenderLayer<
        HoveringGhostRenderer.HoveringGhostRenderState,
        EntityModel<HoveringGhostRenderer.HoveringGhostRenderState>
        > {

    private static final Identifier TRANSLUCENT_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/hovering_ghost/hovering_ghost_translucent.png"
            );

    public HoveringGhostTransparencyFeatureRenderer(
            RenderLayerParent<
                    HoveringGhostRenderer.HoveringGhostRenderState,
                    EntityModel<HoveringGhostRenderer.HoveringGhostRenderState>
                    > parent
    ) {
        super(parent);
    }

    @Override
    public void submit(
            PoseStack poseStack,
            SubmitNodeCollector collector,
            int packedLight,
            HoveringGhostRenderer.HoveringGhostRenderState state,
            float limbSwing,
            float limbSwingAmount
    ) {
        collector.submitModel(
                this.getParentModel(),
                state,
                poseStack,
                RenderTypes.entityTranslucent(
                        TRANSLUCENT_TEXTURE,
                        false
                ),
                packedLight,
                OverlayTexture.NO_OVERLAY,
                0x95FFFFFF,
                null
        );
    }
}