package mh837.gile.client.renderer.blockentity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import mh837.gile.block.entity.WishTableBlockEntity;
import mh837.gile.client.renderer.blockentity.state.WishTableRenderState;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

public class WishTableRenderer
        implements BlockEntityRenderer<WishTableBlockEntity, WishTableRenderState> {

    private final ItemModelResolver itemModelResolver;

    public WishTableRenderer(BlockEntityRendererProvider.Context context) {
        this.itemModelResolver = context.itemModelResolver();
    }

    @Override
    public WishTableRenderState createRenderState() {
        return new WishTableRenderState();
    }

    @Override
    public void extractRenderState(
            WishTableBlockEntity blockEntity,
            WishTableRenderState state,
            float partialTicks,
            Vec3 cameraPosition,
            ModelFeatureRenderer.@Nullable CrumblingOverlay breakProgress
    ) {
        BlockEntityRenderer.super.extractRenderState(
                blockEntity,
                state,
                partialTicks,
                cameraPosition,
                breakProgress
        );

        ItemStack stack = blockEntity.getItem(WishTableBlockEntity.SIGIL_SLOT);

        state.sigil = new ItemStackRenderState();

        this.itemModelResolver.updateForTopItem(
                state.sigil,
                stack,
                ItemDisplayContext.FIXED,
                blockEntity.getLevel(),
                null,
                (int) blockEntity.getBlockPos().asLong()
        );
    }

    @Override
    public void submit(
            WishTableRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState camera
    ) {
        ItemStackRenderState itemState = state.sigil;

        if (itemState.isEmpty()) {
            return;
        }

        poseStack.pushPose();

        poseStack.translate(0.5F, 1.01F, 0.5F);
        poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
        poseStack.scale(0.5F, 0.5F, 0.5F);

        itemState.submit(
                poseStack,
                submitNodeCollector,
                state.lightCoords,
                OverlayTexture.NO_OVERLAY,
                0
        );

        poseStack.popPose();
    }
}