package mh837.gile.client.model.layer;

import mh837.gile.GileMod;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public final class EnderFlyModelLayer {

    public static final ModelLayerLocation ENDER_FLY_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            GileMod.MOD_ID,
                            "ender_fly"
                    ),
                    "main"
            );

    private EnderFlyModelLayer() {
    }
}