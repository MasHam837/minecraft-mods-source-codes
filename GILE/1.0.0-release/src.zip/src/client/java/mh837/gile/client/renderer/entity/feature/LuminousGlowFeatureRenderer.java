package mh837.gile.client.renderer.entity.feature;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.client.renderer.entity.LuminousRenderer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;

public class LuminousGlowFeatureRenderer
        extends RenderLayer<
        LuminousRenderer.LuminousRenderState,
        EntityModel<LuminousRenderer.LuminousRenderState>
        > {

    public LuminousGlowFeatureRenderer(
            RenderLayerParent<
                    LuminousRenderer.LuminousRenderState,
                    EntityModel<LuminousRenderer.LuminousRenderState>
                    > parent
    ) {
        super(parent);
    }

    @Override
    public void submit(
            PoseStack poseStack,
            SubmitNodeCollector collector,
            int packedLight,
            LuminousRenderer.LuminousRenderState state,
            float limbSwing,
            float limbSwingAmount
    ) {
        if (state.texture == null) {
            return;
        }

        collector.submitModel(
                this.getParentModel(),
                state,
                poseStack,
                RenderTypes.eyes(state.texture),
                15728640,
                OverlayTexture.NO_OVERLAY,
                0xFFFFFFFF,
                null
        );
    }
}
