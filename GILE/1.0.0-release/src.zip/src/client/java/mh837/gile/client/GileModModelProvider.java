package mh837.gile.client;

import mh837.gile.*;
import mh837.gile.item.weapon.legendary.LegendaryWeaponItems;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.minecraft.client.data.models.BlockModelGenerators;
import net.minecraft.client.data.models.ItemModelGenerators;
import net.minecraft.client.data.models.MultiVariant;
import net.minecraft.client.data.models.model.*;
import net.minecraft.client.renderer.item.ItemModel;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Blocks;

public class GileModModelProvider extends FabricModelProvider {

    public GileModModelProvider(FabricPackOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(BlockModelGenerators blockStateModelGenerator) {

        // MISCELLANEOUS
        blockStateModelGenerator.createTrivialCube(GileModBlocks.PRIMOGEM_ORE);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.DEEPSLATE_PRIMOGEM_ORE);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.END_PRIMOGEM_ORE);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.ENDERITE_ORE);

        blockStateModelGenerator.createTrivialCube(GileModBlocks.ENDERITE_BLOCK);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.MOON_SAND);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.GLITTER_BLOCK);

        blockStateModelGenerator.family(GileModBlocks.PEARLESCENT_BRICKS)
                .stairs(GileModBlocks.PEARLESCENT_BRICKS_STAIRS)
                .slab(GileModBlocks.PEARLESCENT_BRICKS_SLAB)
                .wall(GileModBlocks.PEARLESCENT_BRICKS_WALL);

        //MOON SANDSTONE
        TextureMapping moonSandstoneTextures = new TextureMapping()
                .put(TextureSlot.TOP, TextureMapping.getBlockTexture(GileModBlocks.MOON_SANDSTONE, "_top"))
                .put(TextureSlot.BOTTOM, TextureMapping.getBlockTexture(GileModBlocks.MOON_SANDSTONE, "_bottom"))
                .put(TextureSlot.SIDE, TextureMapping.getBlockTexture(GileModBlocks.MOON_SANDSTONE))
                .put(TextureSlot.WALL, TextureMapping.getBlockTexture(GileModBlocks.MOON_SANDSTONE));
        Identifier moonSandstoneModel = ModelTemplates.CUBE_BOTTOM_TOP.create(GileModBlocks.MOON_SANDSTONE, moonSandstoneTextures, blockStateModelGenerator.modelOutput);
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.MOON_SANDSTONE, BlockModelGenerators.plainVariant(moonSandstoneModel)));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createStairs(GileModBlocks.MOON_SANDSTONE_STAIRS,
                BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_INNER.create(GileModBlocks.MOON_SANDSTONE_STAIRS, moonSandstoneTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_STRAIGHT.create(GileModBlocks.MOON_SANDSTONE_STAIRS, moonSandstoneTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_OUTER.create(GileModBlocks.MOON_SANDSTONE_STAIRS, moonSandstoneTextures, blockStateModelGenerator.modelOutput))));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSlab(GileModBlocks.MOON_SANDSTONE_SLAB,
                BlockModelGenerators.plainVariant(ModelTemplates.SLAB_BOTTOM.create(GileModBlocks.MOON_SANDSTONE_SLAB, moonSandstoneTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.SLAB_TOP.create(GileModBlocks.MOON_SANDSTONE_SLAB, moonSandstoneTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(moonSandstoneModel)));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createWall(GileModBlocks.MOON_SANDSTONE_WALL,
                BlockModelGenerators.plainVariant(ModelTemplates.WALL_POST.create(GileModBlocks.MOON_SANDSTONE_WALL, moonSandstoneTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.WALL_LOW_SIDE.create(GileModBlocks.MOON_SANDSTONE_WALL, moonSandstoneTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.WALL_TALL_SIDE.create(GileModBlocks.MOON_SANDSTONE_WALL, moonSandstoneTextures, blockStateModelGenerator.modelOutput))));
        blockStateModelGenerator.registerSimpleItemModel(GileModBlocks.MOON_SANDSTONE_WALL, ModelTemplates.WALL_INVENTORY.create(GileModBlocks.MOON_SANDSTONE_WALL, moonSandstoneTextures, blockStateModelGenerator.modelOutput));

        // SMOOTH MOON SANDSTONE
        TextureMapping smoothTextures = new TextureMapping()
                .put(TextureSlot.SIDE, TextureMapping.getBlockTexture(GileModBlocks.MOON_SMOOTH_SANDSTONE))
                .put(TextureSlot.END, TextureMapping.getBlockTexture(GileModBlocks.MOON_SANDSTONE, "_top")); // END covers both Top & Bottom for Columns
        Identifier smoothModel = ModelTemplates.CUBE_COLUMN.create(GileModBlocks.MOON_SMOOTH_SANDSTONE, smoothTextures, blockStateModelGenerator.modelOutput);
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.MOON_SMOOTH_SANDSTONE, BlockModelGenerators.plainVariant(smoothModel)));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createStairs(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS,
                BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_INNER.create(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS, smoothTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_STRAIGHT.create(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS, smoothTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_OUTER.create(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS, smoothTextures, blockStateModelGenerator.modelOutput))));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSlab(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB,
                BlockModelGenerators.plainVariant(ModelTemplates.SLAB_BOTTOM.create(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB, smoothTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.SLAB_TOP.create(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB, smoothTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(smoothModel)));

        // CUT MOON SANDSTONE
        TextureMapping cutTextures = new TextureMapping()
                .put(TextureSlot.SIDE, TextureMapping.getBlockTexture(GileModBlocks.MOON_CUT_SANDSTONE))
                .put(TextureSlot.END, TextureMapping.getBlockTexture(GileModBlocks.MOON_SANDSTONE, "_top"));
        Identifier cutModel = ModelTemplates.CUBE_COLUMN.create(GileModBlocks.MOON_CUT_SANDSTONE, cutTextures, blockStateModelGenerator.modelOutput);
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.MOON_CUT_SANDSTONE, BlockModelGenerators.plainVariant(cutModel)));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSlab(GileModBlocks.MOON_CUT_SANDSTONE_SLAB,
                BlockModelGenerators.plainVariant(ModelTemplates.SLAB_BOTTOM.create(GileModBlocks.MOON_CUT_SANDSTONE_SLAB, cutTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(ModelTemplates.SLAB_TOP.create(GileModBlocks.MOON_CUT_SANDSTONE_SLAB, cutTextures, blockStateModelGenerator.modelOutput)),
                BlockModelGenerators.plainVariant(cutModel)));

        // CHISELED MOON SANDSTONE
        TextureMapping chiseledTextures = new TextureMapping()
                .put(TextureSlot.SIDE, TextureMapping.getBlockTexture(GileModBlocks.MOON_CHISELED_SANDSTONE))
                .put(TextureSlot.END, TextureMapping.getBlockTexture(GileModBlocks.MOON_SANDSTONE, "_top"));
        Identifier chiseledModel = ModelTemplates.CUBE_COLUMN.create(GileModBlocks.MOON_CHISELED_SANDSTONE, chiseledTextures, blockStateModelGenerator.modelOutput);
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.MOON_CHISELED_SANDSTONE, BlockModelGenerators.plainVariant(chiseledModel)));

        // WISH
        TextureMapping WishTextures = new TextureMapping()
                .put(TextureSlot.UP, TextureMapping.getBlockTexture(GileModBlocks.WISH, "_top"))
                .put(TextureSlot.DOWN, TextureMapping.getBlockTexture(GileModBlocks.WISH, "_bottom"))
                .put(TextureSlot.NORTH, TextureMapping.getBlockTexture(GileModBlocks.WISH, "_north"))
                .put(TextureSlot.SOUTH, TextureMapping.getBlockTexture(GileModBlocks.WISH, "_south"))
                .put(TextureSlot.EAST, TextureMapping.getBlockTexture(GileModBlocks.WISH, "_east"))
                .put(TextureSlot.WEST, TextureMapping.getBlockTexture(GileModBlocks.WISH, "_west"))
                .put(TextureSlot.PARTICLE, TextureMapping.getBlockTexture(GileModBlocks.WISH, "_top"));
        MultiVariant wishModel = BlockModelGenerators.plainVariant(ModelTemplates.CUBE.create(GileModBlocks.WISH, WishTextures, blockStateModelGenerator.modelOutput));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.WISH, wishModel));

        // PEARLESCENT BLOCK FAMILY
        TextureMapping textureMap = new TextureMapping()
                .put(TextureSlot.TOP, TextureMapping.getBlockTexture(GileModBlocks.PEARLESCENT_BLOCK, "_top"))
                .put(TextureSlot.BOTTOM, TextureMapping.getBlockTexture(GileModBlocks.PEARLESCENT_BLOCK, "_bottom"))
                .put(TextureSlot.SIDE, TextureMapping.getBlockTexture(GileModBlocks.PEARLESCENT_BLOCK))
                .put(TextureSlot.WALL, TextureMapping.getBlockTexture(GileModBlocks.PEARLESCENT_BLOCK));

        Identifier baseModelId = ModelTemplates.CUBE_BOTTOM_TOP.create(GileModBlocks.PEARLESCENT_BLOCK, textureMap, blockStateModelGenerator.modelOutput);
        MultiVariant pearlescentModel = BlockModelGenerators.plainVariant(baseModelId);
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.PEARLESCENT_BLOCK, pearlescentModel));

        MultiVariant stairsStraight = BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_STRAIGHT.create(GileModBlocks.PEARLESCENT_STAIRS, textureMap, blockStateModelGenerator.modelOutput));
        MultiVariant stairsInner = BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_INNER.create(GileModBlocks.PEARLESCENT_STAIRS, textureMap, blockStateModelGenerator.modelOutput));
        MultiVariant stairsOuter = BlockModelGenerators.plainVariant(ModelTemplates.STAIRS_OUTER.create(GileModBlocks.PEARLESCENT_STAIRS, textureMap, blockStateModelGenerator.modelOutput));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createStairs(GileModBlocks.PEARLESCENT_STAIRS, stairsInner, stairsStraight, stairsOuter));

        MultiVariant slabBottom = BlockModelGenerators.plainVariant(ModelTemplates.SLAB_BOTTOM.create(GileModBlocks.PEARLESCENT_SLAB, textureMap, blockStateModelGenerator.modelOutput));
        MultiVariant slabTop = BlockModelGenerators.plainVariant(ModelTemplates.SLAB_TOP.create(GileModBlocks.PEARLESCENT_SLAB, textureMap, blockStateModelGenerator.modelOutput));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSlab(GileModBlocks.PEARLESCENT_SLAB, slabBottom, slabTop, pearlescentModel));

        MultiVariant wallPost = BlockModelGenerators.plainVariant(ModelTemplates.WALL_POST.create(GileModBlocks.PEARLESCENT_WALL, textureMap, blockStateModelGenerator.modelOutput));
        MultiVariant wallLowSide = BlockModelGenerators.plainVariant(ModelTemplates.WALL_LOW_SIDE.create(GileModBlocks.PEARLESCENT_WALL, textureMap, blockStateModelGenerator.modelOutput));
        MultiVariant wallTallSide = BlockModelGenerators.plainVariant(ModelTemplates.WALL_TALL_SIDE.create(GileModBlocks.PEARLESCENT_WALL, textureMap, blockStateModelGenerator.modelOutput));
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createWall(GileModBlocks.PEARLESCENT_WALL, wallPost, wallLowSide, wallTallSide));
        blockStateModelGenerator.registerSimpleItemModel(GileModBlocks.PEARLESCENT_WALL, ModelTemplates.WALL_INVENTORY.create(GileModBlocks.PEARLESCENT_WALL, textureMap, blockStateModelGenerator.modelOutput));

        // WOOD FAMILIES
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.GHOSTLY_LOG, TexturedModel.COLUMN);
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.STRIPPED_GHOSTLY_LOG, TexturedModel.COLUMN);
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.GHOSTLY_WOOD, TexturedModel.COLUMN_ALT);
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.STRIPPED_GHOSTLY_WOOD, TexturedModel.COLUMN_ALT);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.GHOSTLY_LEAVES);
        blockStateModelGenerator.family(GileModBlocks.GHOSTLY_PLANKS)
                .stairs(GileModBlocks.GHOSTLY_STAIRS).slab(GileModBlocks.GHOSTLY_SLAB)
                .fence(GileModBlocks.GHOSTLY_FENCE).fenceGate(GileModBlocks.GHOSTLY_FENCE_GATE)
                .button(GileModBlocks.GHOSTLY_BUTTON).pressurePlate(GileModBlocks.GHOSTLY_PRESSURE_PLATE);
        blockStateModelGenerator.createDoor(GileModBlocks.GHOSTLY_DOOR);
        blockStateModelGenerator.createOrientableTrapdoor(GileModBlocks.GHOSTLY_TRAPDOOR);
        blockStateModelGenerator.createShelf(GileModBlocks.GHOSTLY_SHELF, GileModBlocks.STRIPPED_GHOSTLY_WOOD);

        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.INVERTED_OAK_LOG, TexturedModel.COLUMN);
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.STRIPPED_INVERTED_OAK_LOG, TexturedModel.COLUMN);
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.INVERTED_OAK_WOOD, TexturedModel.COLUMN_ALT);
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD, TexturedModel.COLUMN_ALT);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.INVERTED_OAK_LEAVES);
        blockStateModelGenerator.family(GileModBlocks.INVERTED_OAK_PLANKS)
                .stairs(GileModBlocks.INVERTED_OAK_STAIRS).slab(GileModBlocks.INVERTED_OAK_SLAB)
                .fence(GileModBlocks.INVERTED_OAK_FENCE).fenceGate(GileModBlocks.INVERTED_OAK_FENCE_GATE)
                .button(GileModBlocks.INVERTED_OAK_BUTTON).pressurePlate(GileModBlocks.INVERTED_OAK_PRESSURE_PLATE);
        blockStateModelGenerator.createDoor(GileModBlocks.INVERTED_OAK_DOOR);
        blockStateModelGenerator.createOrientableTrapdoor(GileModBlocks.INVERTED_OAK_TRAPDOOR);
        blockStateModelGenerator.createShelf(GileModBlocks.INVERTED_OAK_SHELF, GileModBlocks.STRIPPED_INVERTED_OAK_WOOD);

        // PLANTS & FLOWERS
        blockStateModelGenerator.createPlant(GileModBlocks.GHOSTLY_SAPLING, GileModBlocks.POTTED_GHOSTLY_SAPLING, BlockModelGenerators.PlantType.NOT_TINTED);
        blockStateModelGenerator.createPlant(GileModBlocks.INVERTED_OAK_SAPLING, GileModBlocks.POTTED_INVERTED_OAK_SAPLING, BlockModelGenerators.PlantType.NOT_TINTED);
        blockStateModelGenerator.createPlant(GileModBlocks.MOON_FLOWER, GileModBlocks.POTTED_MOON_FLOWER, BlockModelGenerators.PlantType.NOT_TINTED);
        blockStateModelGenerator.createPlant(GileModBlocks.GLOOMY_FLOWER, GileModBlocks.POTTED_GLOOMY_FLOWER, BlockModelGenerators.PlantType.NOT_TINTED);
        blockStateModelGenerator.createPlant(GileModBlocks.DRY_FLOWER, GileModBlocks.POTTED_DRY_FLOWER, BlockModelGenerators.PlantType.NOT_TINTED);

        blockStateModelGenerator.createCrossBlock(GileModBlocks.END_GRASS, BlockModelGenerators.PlantType.NOT_TINTED);
        blockStateModelGenerator.createCrossBlock(GileModBlocks.TALL_END_GRASS, BlockModelGenerators.PlantType.NOT_TINTED);

        blockStateModelGenerator.family(GileModBlocks.FLUO_BLOCK).stairs(GileModBlocks.FLUO_STAIRS).slab(GileModBlocks.FLUO_SLAB);
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.FLUO_PILLAR, TexturedModel.COLUMN);

        // MISCELLANEOUS
        blockStateModelGenerator.createAxisAlignedPillarBlock(GileModBlocks.PEARLESCENT_CHAIN, TexturedModel.CHAIN);
        blockStateModelGenerator.createNormalTorch(GileModBlocks.MOON_TORCH, GileModBlocks.MOON_WALL_TORCH);
        blockStateModelGenerator.createLantern(GileModBlocks.MOON_LANTERN);
        blockStateModelGenerator.createCampfires(GileModBlocks.MOON_CAMPFIRE);
        blockStateModelGenerator.createTrivialCube(GileModBlocks.END_CLOUD);

        // STAR (Custom Model)
        Identifier starModelId = Identifier.fromNamespaceAndPath("gilemod", "block/star");
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.STAR, BlockModelGenerators.plainVariant(starModelId)));

        // END GRASS BLOCK
        TextureMapping endGrassBlockTextures = new TextureMapping()
                .put(TextureSlot.TOP, TextureMapping.getBlockTexture(GileModBlocks.END_GRASS_BLOCK, "_top"))
                .put(TextureSlot.BOTTOM, TextureMapping.getBlockTexture(Blocks.END_STONE))
                .put(TextureSlot.SIDE, TextureMapping.getBlockTexture(GileModBlocks.END_GRASS_BLOCK, "_side"));
        Identifier endGrassBlockModel = ModelTemplates.CUBE_BOTTOM_TOP.create(GileModBlocks.END_GRASS_BLOCK, endGrassBlockTextures, blockStateModelGenerator.modelOutput);
        blockStateModelGenerator.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(GileModBlocks.END_GRASS_BLOCK, BlockModelGenerators.plainVariant(endGrassBlockModel)));

    }

    @Override
    public void generateItemModels(ItemModelGenerators itemModelGenerator) {

        itemModelGenerator.generateFlatItem(GileModItems.MORA, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ANEMO_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.GEO_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ELECTRO_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.DENDRO_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.HYDRO_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.PYRO_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.CRYO_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.LUNA_SIGIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.SIGILS_ANIMATION, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModItems.PRIMOGEM, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.WISH_INGOT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.WISH_NUGGET, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.CRYSTAL, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModItems.VOID_SLIMEBALL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.MOTH_WING, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.JERBOAS_TAIL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.PHASMA, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.CHRONO_GEAR, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModItems.GHOSTLY_SIGN_ITEM, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.GHOSTLY_HANGING_SIGN_ITEM, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.INVERTED_OAK_SIGN_ITEM, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.INVERTED_OAK_HANGING_SIGN_ITEM, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModBlocks.PEARLESCENT_CHAIN.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModBlocks.STAR.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.STAR_FRAGMENT, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModItems.JELLY, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.JAM, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.COOKED_PHASMA, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.OFFERING, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModBlocks.GHOSTLY_SAPLING.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModBlocks.INVERTED_OAK_SAPLING.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModBlocks.MOON_FLOWER.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModBlocks.GLOOMY_FLOWER.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModBlocks.DRY_FLOWER.asItem(), ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModBlocks.END_GRASS.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModBlocks.TALL_END_GRASS.asItem(), ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModItems.SHRINKER, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ENLARGER, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.JELLY_ON_A_STICK, ModelTemplates.FLAT_HANDHELD_ROD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.HEART_OF_EMERGENCY, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.WARP_CLOCK, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE, ModelTemplates.FLAT_ITEM);

        ItemModel.Unbaked nuclearCannonNormal = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.NUCLEAR_CANNON, ModelTemplates.FLAT_HANDHELD_ITEM));
        ItemModel.Unbaked nuclearCannonBroken = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.NUCLEAR_CANNON, "_broken", ModelTemplates.FLAT_HANDHELD_ITEM));
        itemModelGenerator.generateBooleanDispatch(GileModItems.NUCLEAR_CANNON, ItemModelUtils.hasComponent(GileModDataComponents.NUCLEAR_CANNON_BROKEN), nuclearCannonBroken, nuclearCannonNormal);
        ItemModel.Unbaked active = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.GRAPPLING_HOOK, "_active", ModelTemplates.FLAT_HANDHELD_ITEM));
        ItemModel.Unbaked normal = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.GRAPPLING_HOOK, ModelTemplates.FLAT_HANDHELD_ITEM));
        itemModelGenerator.generateBooleanDispatch(GileModItems.GRAPPLING_HOOK, ItemModelUtils.hasComponent(GileModDataComponents.GRAPPLE_ACTIVE), active, normal);

        itemModelGenerator.generateFlatItem(GileModEntities.VOID_SLIME_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.MOTH_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.LUMINOUS_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.HOVERING_GHOST_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.JERBOA_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.GLOOMY_LYNX_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.WEASEL_THIEF_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.GLITTER_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.SALON_MEMBER_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.ENDER_FLY_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModEntities.RUIN_GUARD_SPAWN_EGG.asItem(), ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModItems.FATE_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.FATE_ARROW, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.generateFlatItem(GileModItems.ENDERITE_PICKAXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ENDERITE_SHOVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ENDERITE_AXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ENDERITE_HOE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ENDERITE_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateSpear(GileModItems.ENDERITE_SPEAR);

        itemModelGenerator.generateFlatItem(GileModItems.STAR_DUST, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.STAR_SHINE, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.PEARLESCENT_MATERIAL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.GENESIS_CRYSTAL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.DUST, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ENDERITE_SHARD, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.ENDERITE_INGOT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.END_COMPASS, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.FLUTTERER, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.COGWORK_CORE, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.GLOWING_CHORUS_FRUIT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.GLOWING_POPPED_CHORUS_FRUIT, ModelTemplates.FLAT_ITEM);

        itemModelGenerator.itemModelOutput.accept(GileModBlocks.WISH_TABLE.asItem(), ItemModelUtils.plainModel(Identifier.fromNamespaceAndPath("gilemod", "block/wish_table")));
        itemModelGenerator.itemModelOutput.accept(GileModBlocks.GLITTER_CARPET.asItem(), ItemModelUtils.plainModel(Identifier.fromNamespaceAndPath("gilemod", "block/glitter_carpet")));
        itemModelGenerator.itemModelOutput.accept(GileModBlocks.GLOWING_CHORUS_PLANT.asItem(), ItemModelUtils.plainModel(Identifier.fromNamespaceAndPath("gilemod", "block/glowing_chorus_plant")));
        itemModelGenerator.itemModelOutput.accept(GileModBlocks.GLOWING_CHORUS_FLOWER.asItem(), ItemModelUtils.plainModel(Identifier.fromNamespaceAndPath("gilemod", "block/glowing_chorus_flower")));

        // FATE BOW
        ItemModel.Unbaked baseModel = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.FATE_BOW, ModelTemplates.BOW));
        ItemModel.Unbaked pull0 = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.FATE_BOW, "_pulling_0", ModelTemplates.BOW));
        ItemModel.Unbaked pull1 = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.FATE_BOW, "_pulling_1", ModelTemplates.BOW));
        ItemModel.Unbaked pull2 = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.FATE_BOW, "_pulling_2", ModelTemplates.BOW));

        ItemModel.Unbaked bowModel = ItemModelUtils.conditional(ItemModelUtils.isUsingItem(), ItemModelUtils.rangeSelect(
                new net.minecraft.client.renderer.item.properties.numeric.UseDuration(false), 0.05F, pull2,
                        ItemModelUtils.override(pull0, 0.0F), ItemModelUtils.override(pull1, 0.65F), ItemModelUtils.override(pull2, 0.9F)), baseModel);
        itemModelGenerator.itemModelOutput.accept(GileModItems.FATE_BOW, bowModel);

        // WEAPONS
        ItemModel.Unbaked ventiBaseModel = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.DAYBREAK_CHRONICLES, ModelTemplates.BOW));
        ItemModel.Unbaked ventiPull0 = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.DAYBREAK_CHRONICLES, "_pulling_0", ModelTemplates.BOW));
        ItemModel.Unbaked ventiPull1 = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.DAYBREAK_CHRONICLES, "_pulling_1", ModelTemplates.BOW));
        ItemModel.Unbaked ventiPull2 = ItemModelUtils.plainModel(itemModelGenerator.createFlatItemModel(GileModItems.DAYBREAK_CHRONICLES, "_pulling_2", ModelTemplates.BOW));
        ItemModel.Unbaked ventiBowModel = ItemModelUtils.conditional(ItemModelUtils.isUsingItem(), ItemModelUtils.rangeSelect(
                new net.minecraft.client.renderer.item.properties.numeric.UseDuration(false), 0.05F, pull2,
                ItemModelUtils.override(ventiPull0, 0.0F), ItemModelUtils.override(ventiPull1, 0.65F), ItemModelUtils.override(ventiPull2, 0.9F)), ventiBaseModel);
        itemModelGenerator.itemModelOutput.accept(GileModItems.DAYBREAK_CHRONICLES, ventiBowModel);
        itemModelGenerator.generateSpear(GileModItems.VORTEX_VANQUISHER);
        itemModelGenerator.generateFlatItem(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.THOUSAND_BLAZING_SUNS, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.HIEMAL_MANDATE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(GileModItems.PHANES_BLADE, ModelTemplates.FLAT_HANDHELD_ITEM);

    }
}