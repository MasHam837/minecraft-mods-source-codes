package mh837.gile.client.renderer.entity;

import mh837.gile.GileMod;
import mh837.gile.client.model.GlitterModel;
import mh837.gile.client.model.layer.GlitterModelLayer;
import mh837.gile.entity.GlitterEntity;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;

public class GlitterRenderer
        extends MobRenderer<GlitterEntity, LivingEntityRenderState, GlitterModel> {

    public static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/glitter.png"
            );

    public GlitterRenderer(EntityRendererProvider.Context context) {
        super(
                context,
                new GlitterModel(
                        context.bakeLayer(GlitterModelLayer.GLITTER_LAYER)
                ),
                0.0F
        );
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    /**
     * Jeb-style continuously cycling rainbow tint.
     */
    @Override
    protected int getModelTint(LivingEntityRenderState state) {
        /*
         * Lower number = slower rainbow.
         *
         * 0.01F = slow
         * 0.02F = medium
         * 0.04F = fast
         */
        float hue = (state.ageInTicks * 0.01F) % 1.0F;

        float[] rgb = hsvToRgb(hue, 1.0F, 1.0F);

        return ARGB.colorFromFloat(
                1.0F,
                rgb[0],
                rgb[1],
                rgb[2]
        );
    }

    /**
     * Converts HSV to packed RGB.
     */
    private static float[] hsvToRgb(
            float h,
            float s,
            float v
    ) {
        float r;
        float g;
        float b;

        float i = Mth.floor(h * 6.0F);
        float f = h * 6.0F - i;
        float p = v * (1.0F - s);
        float q = v * (1.0F - f * s);
        float t = v * (1.0F - (1.0F - f) * s);

        switch ((int) i % 6) {
            case 0 -> {
                r = v;
                g = t;
                b = p;
            }
            case 1 -> {
                r = q;
                g = v;
                b = p;
            }
            case 2 -> {
                r = p;
                g = v;
                b = t;
            }
            case 3 -> {
                r = p;
                g = q;
                b = v;
            }
            case 4 -> {
                r = t;
                g = p;
                b = v;
            }
            default -> {
                r = v;
                g = p;
                b = q;
            }
        }

        return new float[]{r, g, b};
    }
}