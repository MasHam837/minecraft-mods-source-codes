package mh837.gile.client;

import java.util.concurrent.CompletableFuture;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModItems;
import net.minecraft.core.HolderLookup;

import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootSubProvider;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.AlternativesEntry;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.ApplyBonusCount;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.BonusLevelTableCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

public class GileModBlockLootTablesProvider extends FabricBlockLootSubProvider {
    protected GileModBlockLootTablesProvider(FabricPackOutput dataOutput, CompletableFuture<HolderLookup.Provider> registryLookup) {
        super(dataOutput, registryLookup);
    }

    private LootTable.Builder createPrimogemOreDrops(Block block) {HolderLookup.RegistryLookup<Enchantment> enchantments = this.registries.lookupOrThrow(Registries.ENCHANTMENT);
        return this.createSilkTouchDispatchTable(block, this.applyExplosionDecay(block, LootItem.lootTableItem(GileModItems.PRIMOGEM).apply(SetItemCountFunction.setCount(
                UniformGenerator.between(1.0F, 3.0F))).apply(ApplyBonusCount.addOreBonusCount(enchantments.getOrThrow(Enchantments.FORTUNE)))));}

    private LootTable.Builder createEnderiteOreDrops(Block block) {HolderLookup.RegistryLookup<Enchantment> enchantments = this.registries.lookupOrThrow(Registries.ENCHANTMENT);
        return this.createSilkTouchDispatchTable(block, this.applyExplosionDecay(block, LootItem.lootTableItem(GileModItems.ENDERITE_SHARD).apply(SetItemCountFunction
                        .setCount(UniformGenerator.between(1.0F, 1.0F))).apply(ApplyBonusCount.addOreBonusCount(enchantments.getOrThrow(Enchantments.FORTUNE)))));}

    private LootTable.Builder createGhostlyLeavesDrops(Block block) {HolderLookup.RegistryLookup<Enchantment> enchantments = this.registries.lookupOrThrow(Registries.ENCHANTMENT);
        return LootTable.lootTable()
                .withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F))
                        .add(AlternativesEntry.alternatives(LootItem.lootTableItem(block).when(this.hasShearsOrSilkTouch()),
                                LootItem.lootTableItem(GileModBlocks.GHOSTLY_SAPLING).when(BonusLevelTableCondition.bonusLevelFlatChance(
                                        enchantments.getOrThrow(Enchantments.FORTUNE), 0.05F, 0.0625F, 0.083333336F, 0.1F)))))
                .withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).when(this.doesNotHaveShearsOrSilkTouch())
                        .add(LootItem.lootTableItem(GileModItems.JELLY).when(BonusLevelTableCondition.bonusLevelFlatChance(
                                enchantments.getOrThrow(Enchantments.FORTUNE), 0.1F, 0.125F, 0.166666667F, 0.2F))))
                .withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).when(this.doesNotHaveShearsOrSilkTouch()).add(LootItem.lootTableItem(Items.STICK).when(BonusLevelTableCondition.bonusLevelFlatChance(
                                enchantments.getOrThrow(Enchantments.FORTUNE), 0.02F, 0.022222223F, 0.025F, 0.033333335F))
                                        .apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F)))));}

    private LootTable.Builder createInvertedOakLeavesDrops(Block block) {HolderLookup.RegistryLookup<Enchantment> enchantments = this.registries.lookupOrThrow(Registries.ENCHANTMENT);
        return LootTable.lootTable()
                .withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F))
                        .add(AlternativesEntry.alternatives(LootItem.lootTableItem(block).when(this.hasShearsOrSilkTouch()),
                                LootItem.lootTableItem(GileModBlocks.INVERTED_OAK_SAPLING).when(BonusLevelTableCondition.bonusLevelFlatChance(
                                        enchantments.getOrThrow(Enchantments.FORTUNE), 0.05F, 0.0625F, 0.083333336F, 0.1F)))))
                .withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).when(this.doesNotHaveShearsOrSilkTouch())
                        .add(LootItem.lootTableItem(Items.APPLE).when(BonusLevelTableCondition.bonusLevelFlatChance(
                                enchantments.getOrThrow(Enchantments.FORTUNE), 0.1F, 0.125F, 0.166666667F, 0.2F))))
                .withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).when(this.doesNotHaveShearsOrSilkTouch()).add(LootItem.lootTableItem(Items.STICK).when(BonusLevelTableCondition.bonusLevelFlatChance(
                                enchantments.getOrThrow(Enchantments.FORTUNE), 0.02F, 0.022222223F, 0.025F, 0.033333335F))
                        .apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F)))));}

    private LootTable.Builder createStarDrops(Block block) {HolderLookup.RegistryLookup<Enchantment> enchantments = this.registries.lookupOrThrow(Registries.ENCHANTMENT);
        return this.createSilkTouchDispatchTable(block, this.applyExplosionDecay(block, LootItem.lootTableItem(GileModItems.STAR_FRAGMENT).apply(SetItemCountFunction.setCount(
                UniformGenerator.between(1.0F, 3.0F))).apply(ApplyBonusCount.addUniformBonusCount(enchantments.getOrThrow(Enchantments.FORTUNE), 1))));}

    private LootTable.Builder createGlowingChorusPlantDrops(Block block) {
        return LootTable.lootTable()
                .withPool(LootPool.lootPool()
                        .setRolls(ConstantValue.exactly(1.0F))
                        .add(this.applyExplosionDecay(
                                block,
                                LootItem.lootTableItem(GileModItems.GLOWING_CHORUS_FRUIT)
                                        .apply(SetItemCountFunction.setCount(
                                                UniformGenerator.between(0.0F, 1.0F))))));
    }

    private LootTable.Builder createGlowingChorusFlowerDrops(Block block) {
        return LootTable.lootTable()
                .withPool(LootPool.lootPool()
                        .setRolls(ConstantValue.exactly(1.0F))
                        .add(LootItem.lootTableItem(block)));
    }

    private void dropWallSign(Block wallSign, Item signItem) {
        this.add(wallSign, LootTable.lootTable()
                .withPool(LootPool.lootPool()
                        .setRolls(ConstantValue.exactly(1.0F))
                        .add(LootItem.lootTableItem(signItem))));
    }

    @Override
    public void generate() {

        // Ores
        add(GileModBlocks.PRIMOGEM_ORE, this::createPrimogemOreDrops);
        add(GileModBlocks.DEEPSLATE_PRIMOGEM_ORE, this::createPrimogemOreDrops);
        add(GileModBlocks.END_PRIMOGEM_ORE, this::createPrimogemOreDrops);
        add(GileModBlocks.ENDERITE_ORE, this::createEnderiteOreDrops);

        // Pearlescent & Fire
        dropSelf(GileModBlocks.WISH); dropSelf(GileModBlocks.WISH_TABLE);
        dropSelf(GileModBlocks.PEARLESCENT_BLOCK); dropSelf(GileModBlocks.PEARLESCENT_STAIRS); dropSelf(GileModBlocks.PEARLESCENT_WALL);
        dropSelf(GileModBlocks.PEARLESCENT_BRICKS); dropSelf(GileModBlocks.PEARLESCENT_BRICKS_STAIRS); dropSelf(GileModBlocks.PEARLESCENT_BRICKS_WALL);

        dropSelf(GileModBlocks.PEARLESCENT_CHAIN); dropSelf(GileModBlocks.MOON_LANTERN);
        dropSelf(GileModBlocks.MOON_TORCH); dropSelf(GileModBlocks.MOON_WALL_TORCH);
        add(GileModBlocks.MOON_CAMPFIRE, createSilkTouchDispatchTable(GileModBlocks.MOON_CAMPFIRE, this.applyExplosionDecay(
                GileModBlocks.MOON_CAMPFIRE, LootItem.lootTableItem(GileModBlocks.MOON_SAND)) ));

        // Wood
        dropSelf(GileModBlocks.GHOSTLY_LOG); dropSelf(GileModBlocks.STRIPPED_GHOSTLY_LOG); dropSelf(GileModBlocks.GHOSTLY_WOOD); dropSelf(GileModBlocks.STRIPPED_GHOSTLY_WOOD);
        dropSelf(GileModBlocks.GHOSTLY_PLANKS); dropSelf(GileModBlocks.GHOSTLY_STAIRS); dropSelf(GileModBlocks.GHOSTLY_FENCE); dropSelf(GileModBlocks.GHOSTLY_FENCE_GATE);
        dropSelf(GileModBlocks.GHOSTLY_TRAPDOOR); dropSelf(GileModBlocks.GHOSTLY_PRESSURE_PLATE); dropSelf(GileModBlocks.GHOSTLY_BUTTON);
        dropSelf(GileModBlocks.GHOSTLY_SIGN); dropWallSign(GileModBlocks.GHOSTLY_WALL_SIGN, GileModItems.GHOSTLY_SIGN_ITEM);
        dropSelf(GileModBlocks.GHOSTLY_HANGING_SIGN); dropWallSign(GileModBlocks.GHOSTLY_WALL_HANGING_SIGN, GileModItems.GHOSTLY_HANGING_SIGN_ITEM);
        add(GileModBlocks.GHOSTLY_DOOR, createDoorTable(GileModBlocks.GHOSTLY_DOOR));
        add(GileModBlocks.GHOSTLY_LEAVES, this::createGhostlyLeavesDrops);

        dropSelf(GileModBlocks.INVERTED_OAK_LOG); dropSelf(GileModBlocks.STRIPPED_INVERTED_OAK_LOG); dropSelf(GileModBlocks.INVERTED_OAK_WOOD); dropSelf(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD);
        dropSelf(GileModBlocks.INVERTED_OAK_PLANKS); dropSelf(GileModBlocks.INVERTED_OAK_STAIRS); dropSelf(GileModBlocks.INVERTED_OAK_FENCE); dropSelf(GileModBlocks.INVERTED_OAK_FENCE_GATE);
        dropSelf(GileModBlocks.INVERTED_OAK_TRAPDOOR); dropSelf(GileModBlocks.INVERTED_OAK_PRESSURE_PLATE); dropSelf(GileModBlocks.INVERTED_OAK_BUTTON);
        dropSelf(GileModBlocks.INVERTED_OAK_SIGN); dropWallSign(GileModBlocks.INVERTED_OAK_WALL_SIGN, GileModItems.INVERTED_OAK_SIGN_ITEM);
        dropSelf(GileModBlocks.INVERTED_OAK_HANGING_SIGN); dropWallSign(GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN, GileModItems.INVERTED_OAK_HANGING_SIGN_ITEM);
        add(GileModBlocks.INVERTED_OAK_DOOR, createDoorTable(GileModBlocks.INVERTED_OAK_DOOR));
        add(GileModBlocks.INVERTED_OAK_LEAVES, this::createInvertedOakLeavesDrops);

        // Sand(stone)
        dropSelf(GileModBlocks.MOON_SAND);
        dropSelf(GileModBlocks.MOON_SANDSTONE); dropSelf(GileModBlocks.MOON_SANDSTONE_STAIRS); dropSelf(GileModBlocks.MOON_SANDSTONE_WALL);
        dropSelf(GileModBlocks.MOON_SMOOTH_SANDSTONE); dropSelf(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS); dropSelf(GileModBlocks.MOON_CUT_SANDSTONE);

        // Slabs
        add(GileModBlocks.PEARLESCENT_SLAB, createSlabItemTable(GileModBlocks.PEARLESCENT_SLAB));
        add(GileModBlocks.PEARLESCENT_BRICKS_SLAB, createSlabItemTable(GileModBlocks.PEARLESCENT_BRICKS_SLAB));
        add(GileModBlocks.GHOSTLY_SLAB, createSlabItemTable(GileModBlocks.GHOSTLY_SLAB));
        add(GileModBlocks.INVERTED_OAK_SLAB, createSlabItemTable(GileModBlocks.INVERTED_OAK_SLAB));
        add(GileModBlocks.MOON_SANDSTONE_SLAB, createSlabItemTable(GileModBlocks.MOON_SANDSTONE_SLAB));
        add(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB, createSlabItemTable(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB));
        add(GileModBlocks.MOON_CUT_SANDSTONE_SLAB, createSlabItemTable(GileModBlocks.MOON_CUT_SANDSTONE_SLAB));
        add(GileModBlocks.FLUO_SLAB, createSlabItemTable(GileModBlocks.FLUO_SLAB));

        // Plants
        dropSelf(GileModBlocks.GHOSTLY_SAPLING); dropPottedContents(GileModBlocks.POTTED_GHOSTLY_SAPLING);
        dropSelf(GileModBlocks.INVERTED_OAK_SAPLING); dropPottedContents(GileModBlocks.POTTED_INVERTED_OAK_SAPLING);
        dropSelf(GileModBlocks.MOON_FLOWER); dropSelf(GileModBlocks.GLOOMY_FLOWER); dropSelf(GileModBlocks.DRY_FLOWER);
        dropPottedContents(GileModBlocks.POTTED_MOON_FLOWER); dropPottedContents(GileModBlocks.POTTED_GLOOMY_FLOWER); dropPottedContents(GileModBlocks.POTTED_DRY_FLOWER);
        add(GileModBlocks.END_GRASS, createShearsOnlyDrop(GileModBlocks.END_GRASS));
        add(GileModBlocks.TALL_END_GRASS, createShearsOnlyDrop(GileModBlocks.TALL_END_GRASS));

        dropSelf(GileModBlocks.FLUO_BLOCK); dropSelf(GileModBlocks.FLUO_STAIRS); dropSelf(GileModBlocks.FLUO_SLAB);

        // Miscellaneous
        add(GileModBlocks.END_GRASS_BLOCK, createSingleItemTableWithSilkTouch(GileModBlocks.END_GRASS_BLOCK, Blocks.END_STONE));
        dropSelf(GileModBlocks.END_CLOUD); add(GileModBlocks.STAR, this::createStarDrops);
        dropSelf(GileModBlocks.ENDERITE_BLOCK); dropSelf(GileModBlocks.GLITTER_BLOCK); dropSelf(GileModBlocks.GLITTER_CARPET);
        add(GileModBlocks.GLOWING_CHORUS_PLANT, this::createGlowingChorusPlantDrops);
        add(GileModBlocks.GLOWING_CHORUS_FLOWER, this::createGlowingChorusFlowerDrops);

        // Complement
        dropSelf(Blocks.OAK_SIGN); dropSelf(Blocks.OAK_HANGING_SIGN);
        dropSelf(Blocks.BIRCH_SIGN); dropSelf(Blocks.BIRCH_HANGING_SIGN);

    }
}