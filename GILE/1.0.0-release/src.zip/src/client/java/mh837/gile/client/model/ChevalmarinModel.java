package mh837.gile.client.model;

import mh837.gile.client.renderer.state.SalonMembersRenderState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class ChevalmarinModel extends EntityModel<SalonMembersRenderState> {
    private final ModelPart chevalmarin;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart bow;
    private final ModelPart fins;
    private final ModelPart fin_left;
    private final ModelPart fin_right;

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath("gilemod", "salon_members/chevalmarin"), "main"
    );

    public ChevalmarinModel(ModelPart root) {
        super(root, RenderTypes::entityTranslucent);
        this.chevalmarin = root.getChild("chevalmarin");
        this.body = this.chevalmarin.getChild("body");
        this.head = this.chevalmarin.getChild("head");
        this.bow = this.head.getChild("bow");
        this.fins = this.chevalmarin.getChild("fins");
        this.fin_left = this.fins.getChild("fin_left");
        this.fin_right = this.fins.getChild("fin_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        PartDefinition chevalmarin = partdefinition.addOrReplaceChild("chevalmarin", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));

        PartDefinition body = chevalmarin.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 20).addBox(-2.4929F, -2.1231F, -3.9567F, 5.0F, 6.0F, 6.0F, new CubeDeformation(0.0F))
                .texOffs(0, 12).addBox(-3.4929F, -3.1231F, -4.4567F, 7.0F, 1.0F, 7.0F, new CubeDeformation(0.0F)), PartPose.offset(-0.0071F, -5.3769F, 0.9567F));

        PartDefinition wing_right_r1 = body.addOrReplaceChild("wing_right_r1", CubeListBuilder.create().texOffs(26, 14).mirror().addBox(-2.0F, -2.0F, -1.0F, 3.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.2429F, 0.8769F, 3.0433F, 0.0F, 0.2182F, 0.3927F));

        PartDefinition wing_left_r1 = body.addOrReplaceChild("wing_left_r1", CubeListBuilder.create().texOffs(26, 14).addBox(-1.0F, -2.0F, -1.0F, 3.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.2571F, 0.8769F, 3.0433F, 0.0F, -0.2182F, -0.3927F));

        PartDefinition shell_r1 = body.addOrReplaceChild("shell_r1", CubeListBuilder.create().texOffs(24, 5).addBox(-1.0F, -2.0F, 0.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.7429F, -0.8731F, -4.9567F, 0.0F, 0.0F, 0.7854F));

        PartDefinition tail_r1 = body.addOrReplaceChild("tail_r1", CubeListBuilder.create().texOffs(7, 32).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0071F, 3.8769F, 1.2933F, 0.0F, 0.0F, -0.7854F));

        PartDefinition head = chevalmarin.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -2.8469F, -3.3226F, 6.0F, 6.0F, 6.0F, new CubeDeformation(0.0F))
                .texOffs(30, 3).addBox(-1.0F, 0.1531F, -4.3226F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, -11.6531F, 0.3226F));

        PartDefinition crown_r1 = head.addOrReplaceChild("crown_r1", CubeListBuilder.create().texOffs(24, 8).addBox(-3.0F, -1.0F, -3.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -2.3469F, 3.6774F, -0.6155F, -0.5236F, -0.6155F));

        PartDefinition ear_left_r1 = head.addOrReplaceChild("ear_left_r1", CubeListBuilder.create().texOffs(28, 17).mirror().addBox(-1.0F, -3.0F, -1.0F, 1.0F, 3.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(3.5F, 1.4031F, -0.0726F, -0.8077F, 0.3036F, 0.0038F));

        PartDefinition ear_right_r1 = head.addOrReplaceChild("ear_right_r1", CubeListBuilder.create().texOffs(28, 17).addBox(0.0F, -3.0F, -1.0F, 1.0F, 3.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.5F, 1.4031F, -0.0726F, -0.8077F, -0.3036F, -0.0038F));

        PartDefinition bow = head.addOrReplaceChild("bow", CubeListBuilder.create(), PartPose.offset(-0.0286F, -3.2598F, -1.0869F));

        PartDefinition bow_right_r1 = bow.addOrReplaceChild("bow_right_r1", CubeListBuilder.create().texOffs(30, 0).addBox(-2.0F, 0.0F, 1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.9714F, -1.3371F, -1.4857F, 0.0F, 0.0F, -1.0036F));

        PartDefinition bow_left_r1 = bow.addOrReplaceChild("bow_left_r1", CubeListBuilder.create().texOffs(30, 0).mirror().addBox(0.0F, 0.0F, 1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0286F, -1.3371F, -1.4857F, 0.0F, 0.0F, 1.0036F));

        PartDefinition pearl_r1 = bow.addOrReplaceChild("pearl_r1", CubeListBuilder.create().texOffs(30, 6).addBox(0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.4714F, -1.5871F, -0.7357F, 0.0F, 0.7854F, 0.0F));

        PartDefinition fins = chevalmarin.addOrReplaceChild("fins", CubeListBuilder.create(), PartPose.offset(0.0F, -5.2561F, 0.1352F));

        PartDefinition fin_left = fins.addOrReplaceChild("fin_left", CubeListBuilder.create(), PartPose.offset(3.1849F, 0.0F, 0.0F));

        PartDefinition fin_left_back_r1 = fin_left.addOrReplaceChild("fin_left_back_r1", CubeListBuilder.create().texOffs(22, 28).mirror().addBox(-1.0F, -2.0F, -1.0F, 1.0F, 3.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.8151F, 0.2561F, 1.6148F, 0.3326F, -0.147F, -0.3655F));

        PartDefinition fin_left_front_r1 = fin_left.addOrReplaceChild("fin_left_front_r1", CubeListBuilder.create().texOffs(22, 20).mirror().addBox(-1.0F, -2.0F, -1.0F, 1.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.0651F, -0.2439F, -2.8852F, -0.3146F, 0.2221F, -0.3672F));

        PartDefinition fin_right = fins.addOrReplaceChild("fin_right", CubeListBuilder.create(), PartPose.offset(-3.1849F, 0.0F, 0.0F));

        PartDefinition fin_right_back_r1 = fin_right.addOrReplaceChild("fin_right_back_r1", CubeListBuilder.create().texOffs(22, 28).addBox(0.0F, -2.0F, -1.0F, 1.0F, 3.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.8151F, 0.2561F, 1.6148F, 0.3326F, 0.147F, 0.3655F));

        PartDefinition fin_right_front_r1 = fin_right.addOrReplaceChild("fin_right_front_r1", CubeListBuilder.create().texOffs(22, 20).addBox(0.0F, -2.0F, -1.0F, 1.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.0651F, -0.2439F, -2.8852F, -0.3146F, -0.2221F, 0.3672F));

        return LayerDefinition.create(meshdefinition, 64, 64);
    }

    @Override
    public void setupAnim(SalonMembersRenderState state) {
        float time = state.ageInTicks;

        // Subtle forward inclination.
        this.chevalmarin.xRot = 0.08F;

        // Fin movement.
        float finMovement = Mth.sin(time * 0.12F) * 0.18F;

        this.fin_left.xRot = -finMovement;
        this.fin_right.xRot = -finMovement;

        // Slight alternating side movement.
        float finSide = Mth.sin(time * 0.12F) * 0.05F;

        this.fin_left.zRot = -0.05F + finSide;
        this.fin_right.zRot = 0.05F - finSide;
    }
}