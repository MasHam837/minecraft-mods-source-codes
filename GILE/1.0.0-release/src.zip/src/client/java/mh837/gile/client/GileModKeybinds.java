package mh837.gile.client;

import com.mojang.blaze3d.platform.InputConstants;
import mh837.gile.network.ActiveAbilityPayload;
import mh837.gile.network.DivineAbilityPayload;
import mh837.gile.network.FluttererJumpPayload;

import mh837.gile.network.LegendaryAbilityPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import net.minecraft.client.KeyMapping;

import org.lwjgl.glfw.GLFW;

public class GileModKeybinds {

    private static boolean fluttererJumpWasDown = false; // SPACE
    public static KeyMapping activeAbilityKey;       // V
    public static KeyMapping divineAbilityKey;       // B

    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(
                    net.minecraft.resources.Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "keys"
                    )
            );

    private static boolean wasOnGround = true;

    public static void initialize() {

        // ============================================================
        // V — WAND / ELEMENTAL / LEGENDARY / PHANES FIRST ABILITY
        // ============================================================

        activeAbilityKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping(
                        "key.gilemod.active_ability",
                        InputConstants.Type.KEYSYM,
                        GLFW.GLFW_KEY_V,
                        CATEGORY
                )
        );

        // ============================================================
        // B — PHANES DIVINE ABILITY
        // ============================================================

        divineAbilityKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping(
                        "key.gilemod.divine_ability",
                        InputConstants.Type.KEYSYM,
                        GLFW.GLFW_KEY_B,
                        CATEGORY
                )
        );

        // CHECK

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            if (client.player == null) {
                return;
            }

            while (activeAbilityKey.consumeClick()) {
                ClientPlayNetworking.send(
                        new ActiveAbilityPayload()
                );
            }

            while (divineAbilityKey.consumeClick()) {
                ClientPlayNetworking.send(
                        new DivineAbilityPayload()
                );
            }
        });

        // ============================================================
        // SPACE - FLUTTERER AIR JUMP
        // ============================================================

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            if (client.player == null) {
                fluttererJumpWasDown = false;
                return;
            }

            boolean jumpDown = client.options.keyJump.isDown();

            if (client.player.onGround()) {
                fluttererJumpWasDown = jumpDown;
                return;
            }

            boolean jumpPressed = jumpDown && !fluttererJumpWasDown;

            fluttererJumpWasDown = jumpDown;

            if (!jumpPressed) {
                return;
            }

            ClientPlayNetworking.send(new FluttererJumpPayload());
        });
    }
}