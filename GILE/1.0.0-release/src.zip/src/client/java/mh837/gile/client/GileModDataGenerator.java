package mh837.gile.client;

import mh837.gile.client.lang.*;
import mh837.gile.worldgen.biome.GileModBiomes;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;

public class GileModDataGenerator implements DataGeneratorEntrypoint {

	@Override
	public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
		FabricDataGenerator.Pack pack = fabricDataGenerator.createPack();
		pack.addProvider(GileModModelProvider::new);
		pack.addProvider(GileModRecipeProvider::new);
		pack.addProvider(GileModBlockLootTablesProvider::new);
		pack.addProvider(GileModBlockTagsProvider::new);
		pack.addProvider(GileModItemTagsProvider::new);
		pack.addProvider(GileModWorldGenerationProvider::new);

		pack.addProvider(GileModEnglishLangProvider::new);
		pack.addProvider(GileModFrenchLangProvider::new);
		pack.addProvider(GileModRussianLangProvider::new);
	}

	@Override
	public void buildRegistry(RegistrySetBuilder registryBuilder) {
		// Bootstraps all biome keys into the dynamic registry builder during DataGen
		registryBuilder.add(Registries.BIOME, GileModBiomes::bootstrap);
	}
}