package mh837.gile.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.GileMod;
import mh837.gile.client.model.layer.VoidSlimeOuterLayer;
import mh837.gile.entity.VoidSlimeEntity;
import net.minecraft.client.model.monster.slime.SlimeModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.SlimeRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class VoidSlimeRenderer extends MobRenderer<VoidSlimeEntity, SlimeRenderState, SlimeModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "textures/entity/void_slime.png");

    public VoidSlimeRenderer(EntityRendererProvider.Context context) {
        super(context, new SlimeModel(context.bakeLayer(ModelLayers.SLIME)), 0.25F);
        // Overlay feature renderer for the semi-transparent outer layer
        this.addLayer(new VoidSlimeOuterLayer(this, context.getModelSet()));
    }

    @Override
    public SlimeRenderState createRenderState() {
        return new SlimeRenderState();
    }

    @Override
    public void extractRenderState(VoidSlimeEntity entity, SlimeRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        // Populate slime-specific state variables (Assuming your entity has these vanilla fields)
        state.squish = Mth.lerp(partialTick, entity.oSquish, entity.squish);
        state.size = entity.getSize();
    }

    @Override
    protected void scale(SlimeRenderState state, PoseStack poseStack) {
        // 1. Recreate the vanilla Slime scale behaviour based on size
        float f1 = (float)state.size;
        float f2 = state.squish / (f1 * 0.5F + 1.0F);
        float f3 = 1.0F / (f2 + 1.0F);
        poseStack.scale(f3 * f1, 1.0F / f3 * f1, f3 * f1);

        // 2. Apply your custom 1.5x scale for Void Slime
        poseStack.scale(1.5F, 1.5F, 1.5F);
    }

    @Override
    public Identifier getTextureLocation(SlimeRenderState state) {
        return TEXTURE;
    }
}