package mh837.gile.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.client.renderer.entity.feature.MothRadianceGlowFeatureRenderer;
import mh837.gile.entity.MothEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class MothRenderer extends MobRenderer<
        MothEntity,
        MothRenderer.MothRenderState,
        EntityModel<MothRenderer.MothRenderState>> {

    public static final ModelLayerLocation MOTH_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "moth"
                    ),
                    "main"
            );

    public static final ModelLayerLocation MOTH_RADIANCE_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "moth_radiance"
                    ),
                    "main"
            );

    public static final ModelLayerLocation MOTH_BABY_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "moth_baby"
                    ),
                    "main"
            );

    public static final ModelLayerLocation MOTH_RADIANCE_BABY_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "moth_radiance_baby"
                    ),
                    "main"
            );

    private static final Identifier MOTH_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    "gilemod",
                    "textures/entity/moth/moth.png"
            );

    private static final Identifier RADIANCE_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    "gilemod",
                    "textures/entity/moth/radiance.png"
            );

    private final MothModel normalModel;
    private final MothModel radianceModel;
    private final MothBabyModel normalBabyModel;
    private final MothBabyModel radianceBabyModel;

    public MothRenderer(
            EntityRendererProvider.Context context
    ) {
        super(
                context,
                new MothModel(
                        context.bakeLayer(MOTH_LAYER),
                        false
                ),
                0.3F
        );

        this.normalModel = (MothModel) this.model;

        this.radianceModel =
                new MothModel(
                        context.bakeLayer(MOTH_RADIANCE_LAYER),
                        true
                );

        this.normalBabyModel =
                new MothBabyModel(
                        context.bakeLayer(MOTH_BABY_LAYER),
                        false
                );

        this.radianceBabyModel =
                new MothBabyModel(
                        context.bakeLayer(MOTH_RADIANCE_BABY_LAYER),
                        true
                );

        this.addLayer(
                new MothRadianceGlowFeatureRenderer(this)
        );
    }

    @Override
    public MothRenderState createRenderState() {
        return new MothRenderState();
    }

    @Override
    public void extractRenderState(
            MothEntity entity,
            MothRenderState state,
            float partialTick
    ) {
        super.extractRenderState(
                entity,
                state,
                partialTick
        );

        state.isRadiance =
                entity.hasCustomName()
                        && entity.getCustomName()
                        .getString()
                        .equalsIgnoreCase("Radiance");
    }

    @Override
    public void submit(
            MothRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState camera
    ) {
        this.model = state.isBaby
                ? (state.isRadiance
                ? this.radianceBabyModel
                : this.normalBabyModel)
                : (state.isRadiance
                ? this.radianceModel
                : this.normalModel);

        super.submit(
                state,
                poseStack,
                collector,
                camera
        );
    }

    @Override
    protected void scale(
            MothRenderState state,
            PoseStack poseStack
    ) {
        if (state.isBaby) {
            poseStack.translate(
                    0.0F,
                    1.5F,
                    0.0F
            );
        }

        if (!state.isBaby && state.isRadiance) {
            poseStack.scale(
                    1.2F,
                    1.2F,
                    1.2F
            );
        }
    }

    @Override
    public Identifier getTextureLocation(
            MothRenderState state
    ) {
        return state.isRadiance
                ? RADIANCE_TEXTURE
                : MOTH_TEXTURE;
    }

    public static class MothRenderState
            extends LivingEntityRenderState {

        public boolean isRadiance;
    }

    public static class MothModel
            extends EntityModel<MothRenderState> {

        private final ModelPart root;
        private final ModelPart head;
        private final ModelPart leftWingFront;
        private final ModelPart leftWingBack;
        private final ModelPart rightWingFront;
        private final ModelPart rightWingBack;
        private final boolean isRadiance;

        public MothModel(
                ModelPart root,
                boolean isRadiance
        ) {
            super(root);

            this.root = root;
            this.isRadiance = isRadiance;

            this.head =
                    root.getChild("head");

            this.leftWingFront =
                    root.getChild("left_wing_front");

            this.leftWingBack =
                    root.getChild("left_wing_back");

            this.rightWingFront =
                    root.getChild("right_wing_front");

            this.rightWingBack =
                    root.getChild("right_wing_back");
        }

        public static LayerDefinition getTexturedModelData() {
            return createModelData(false);
        }

        public static LayerDefinition getRadianceTexturedModelData() {
            return createModelData(true);
        }

        private static LayerDefinition createModelData(
                boolean isRadiance
        ) {
            MeshDefinition mesh =
                    new MeshDefinition();

            PartDefinition root =
                    mesh.getRoot();

            root.addOrReplaceChild(
                    "body",
                    CubeListBuilder.create()
                            .texOffs(0, 17)
                            .addBox(
                                    -2.5F,
                                    -1.0F,
                                    -2.5F,
                                    5.0F,
                                    1.5F,
                                    6.0F
                            ),
                    PartPose.offset(
                            0.0F,
                            21.5F,
                            -1.0F
                    )
            );

            PartDefinition head =
                    root.addOrReplaceChild(
                            "head",
                            CubeListBuilder.create()
                                    .texOffs(0, 11)
                                    .addBox(
                                            -2.0F,
                                            -2.0F,
                                            -3.0F,
                                            4.0F,
                                            3.0F,
                                            3.0F
                                    ),
                            PartPose.offset(
                                    0.0F,
                                    21.5F,
                                    -2.5F
                            )
                    );

            head.addOrReplaceChild(
                    "eye_left",
                    CubeListBuilder.create()
                            .texOffs(11, 11)
                            .addBox(
                                    0.5F,
                                    -1.5F,
                                    -3.3F,
                                    2.0F,
                                    2.0F,
                                    1.0F
                            ),
                    PartPose.ZERO
            );

            head.addOrReplaceChild(
                    "eye_right",
                    CubeListBuilder.create()
                            .texOffs(11, 11)
                            .mirror()
                            .addBox(
                                    -2.5F,
                                    -1.5F,
                                    -3.3F,
                                    2.0F,
                                    2.0F,
                                    1.0F
                            ),
                    PartPose.ZERO
            );

            head.addOrReplaceChild(
                    "antenna_left",
                    CubeListBuilder.create()
                            .texOffs(14, 14)
                            .addBox(
                                    -1.0F,
                                    -3.0F,
                                    0.0F,
                                    2.0F,
                                    3.0F,
                                    0.0F
                            ),
                    PartPose.offsetAndRotation(
                            1.3F,
                            -1.5F,
                            -2.5F,
                            0.3F,
                            0.2F,
                            0.3F
                    )
            );

            head.addOrReplaceChild(
                    "antenna_right",
                    CubeListBuilder.create()
                            .texOffs(14, 14)
                            .mirror()
                            .addBox(
                                    -1.0F,
                                    -3.0F,
                                    0.0F,
                                    2.0F,
                                    3.0F,
                                    0.0F
                            ),
                    PartPose.offsetAndRotation(
                            -1.3F,
                            -1.5F,
                            -2.5F,
                            0.3F,
                            -0.2F,
                            -0.3F
                    )
            );

            root.addOrReplaceChild(
                    "left_wing_front",
                    CubeListBuilder.create()
                            .texOffs(0, 0)
                            .addBox(
                                    0.0F,
                                    0.0F,
                                    -3.0F,
                                    10.0F,
                                    0.0F,
                                    6.0F
                            ),
                    PartPose.offsetAndRotation(
                            2.0F,
                            21.0F,
                            -1.0F,
                            0.0F,
                            0.0F,
                            0.15F
                    )
            );

            root.addOrReplaceChild(
                    "right_wing_front",
                    CubeListBuilder.create()
                            .texOffs(0, 0)
                            .mirror()
                            .addBox(
                                    -10.0F,
                                    0.0F,
                                    -3.0F,
                                    10.0F,
                                    0.0F,
                                    6.0F
                            ),
                    PartPose.offsetAndRotation(
                            -2.0F,
                            21.0F,
                            -1.0F,
                            0.0F,
                            0.0F,
                            -0.15F
                    )
            );

            root.addOrReplaceChild(
                    "left_wing_back",
                    CubeListBuilder.create()
                            .texOffs(0, 6)
                            .addBox(
                                    0.0F,
                                    0.0F,
                                    -2.0F,
                                    8.0F,
                                    0.0F,
                                    5.0F
                            ),
                    PartPose.offsetAndRotation(
                            2.0F,
                            21.0F,
                            1.0F,
                            0.0F,
                            0.0F,
                            0.1F
                    )
            );

            root.addOrReplaceChild(
                    "right_wing_back",
                    CubeListBuilder.create()
                            .texOffs(0, 6)
                            .mirror()
                            .addBox(
                                    -8.0F,
                                    0.0F,
                                    -2.0F,
                                    8.0F,
                                    0.0F,
                                    5.0F
                            ),
                    PartPose.offsetAndRotation(
                            -2.0F,
                            21.0F,
                            1.0F,
                            0.0F,
                            0.0F,
                            -0.1F
                    )
            );

            for (int i = 0; i < 3; i++) {
                root.addOrReplaceChild(
                        "leg_left_" + i,
                        CubeListBuilder.create()
                                .texOffs(0, 21)
                                .addBox(
                                        0.0F,
                                        0.0F,
                                        0.0F,
                                        2.0F,
                                        1.0F,
                                        1.0F
                                ),
                        PartPose.offset(
                                2.0F,
                                22.5F,
                                -2.0F + i * 2.0F
                        )
                );

                root.addOrReplaceChild(
                        "leg_right_" + i,
                        CubeListBuilder.create()
                                .texOffs(0, 21)
                                .mirror()
                                .addBox(
                                        -2.0F,
                                        0.0F,
                                        0.0F,
                                        2.0F,
                                        1.0F,
                                        1.0F
                                ),
                        PartPose.offset(
                                -2.0F,
                                22.5F,
                                -2.0F + i * 2.0F
                        )
                );
            }

            return LayerDefinition.create(
                    mesh,
                    64,
                    64
            );
        }

        @Override
        public void setupAnim(
                MothRenderState state
        ) {
            root.resetPose();

            float flapSpeed =
                    isRadiance
                            ? 0.5F
                            : 0.7F;

            float flapAmount =
                    isRadiance
                            ? 0.7F
                            : 0.9F;

            float flap =
                    Mth.sin(
                            state.ageInTicks * flapSpeed
                    ) * flapAmount;

            leftWingFront.zRot = flap;
            rightWingFront.zRot = -flap;

            float rearFlap =
                    Mth.sin(
                            state.ageInTicks * flapSpeed
                                    + 0.3F
                    ) * flapAmount * 0.8F;

            leftWingBack.zRot = rearFlap;
            rightWingBack.zRot = -rearFlap;

            head.yRot =
                    state.yRot *
                            ((float) Math.PI / 180F);

            head.xRot =
                    state.xRot *
                            ((float) Math.PI / 180F);

            root.y =
                    Mth.sin(
                            state.ageInTicks * 0.15F
                    ) * 0.25F;
        }
    }

    public static class MothBabyModel
            extends EntityModel<MothRenderState> {

        private final ModelPart body;
        private final ModelPart head;
        private final ModelPart wings;
        private final ModelPart wingsRight;
        private final ModelPart wingsLeft;

        private final boolean isRadiance;

        public MothBabyModel(
                ModelPart root,
                boolean isRadiance
        ) {
            super(root);

            this.isRadiance = isRadiance;

            this.body =
                    root.getChild("body");

            this.head =
                    this.body.getChild("head");

            this.wings =
                    this.body.getChild("wings");

            this.wingsRight =
                    this.wings.getChild("wings_right");

            this.wingsLeft =
                    this.wings.getChild("wings_left");
        }

        public static LayerDefinition getTexturedModelData() {
            return createBabyModelData(false);
        }

        public static LayerDefinition getRadianceTexturedModelData() {
            return createBabyModelData(true);
        }

        private static LayerDefinition createBabyModelData(
                boolean isRadiance
        ) {
            MeshDefinition meshdefinition =
                    new MeshDefinition();

            PartDefinition partdefinition =
                    meshdefinition.getRoot();

            PartDefinition body =
                    partdefinition.addOrReplaceChild(
                            "body",
                            CubeListBuilder.create()
                                    .texOffs(2, 25)
                                    .addBox(
                                            -1.5F,
                                            -2.0F,
                                            -0.5F,
                                            3.0F,
                                            2.0F,
                                            4.0F
                                    ),
                            PartPose.offset(
                                    0.0F,
                                    24.0F,
                                    0.0F
                            )
                    );

            PartDefinition head =
                    body.addOrReplaceChild(
                            "head",
                            CubeListBuilder.create()
                                    .texOffs(1, 12)
                                    .addBox(
                                            -1.5F,
                                            -2.5F,
                                            -2.5F,
                                            3.0F,
                                            2.0F,
                                            2.0F
                                    )
                                    .texOffs(11, 12)
                                    .addBox(
                                            -1.25F,
                                            -2.0F,
                                            -3.0F,
                                            1.0F,
                                            1.0F,
                                            1.0F
                                    )
                                    .texOffs(11, 12)
                                    .addBox(
                                            0.25F,
                                            -2.0F,
                                            -3.0F,
                                            1.0F,
                                            1.0F,
                                            1.0F
                                    ),
                            PartPose.offset(
                                    0.0F,
                                    0.0F,
                                    0.0F
                            )
                    );

            head.addOrReplaceChild(
                    "antenna_right_r1",
                    CubeListBuilder.create()
                            .texOffs(14, 15)
                            .addBox(
                                    -1.0F,
                                    -2.0F,
                                    -1.0F,
                                    1.0F,
                                    2.0F,
                                    0.0F
                            ),
                    PartPose.offsetAndRotation(
                            -0.5F,
                            -2.25F,
                            -1.0F,
                            -0.3473F,
                            -0.0101F,
                            -0.8837F
                    )
            );

            head.addOrReplaceChild(
                    "antenna_left_r1",
                    CubeListBuilder.create()
                            .texOffs(14, 15)
                            .addBox(
                                    -1.0F,
                                    -2.0F,
                                    -1.0F,
                                    1.0F,
                                    2.0F,
                                    0.0F
                            ),
                    PartPose.offsetAndRotation(
                            1.5F,
                            -1.5F,
                            -1.0F,
                            0.0F,
                            0.0F,
                            0.7854F
                    )
            );

            /*
             * Fresh Blockbench wing hierarchy:
             *
             * body
             *   └── wings
             *        ├── wings_right
             *        └── wings_left
             */

            PartDefinition wings =
                    body.addOrReplaceChild(
                            "wings",
                            CubeListBuilder.create(),
                            PartPose.offset(
                                    0.0F,
                                    0.0F,
                                    0.0F
                            )
                    );

            PartDefinition wingsRight =
                    wings.addOrReplaceChild(
                            "wings_right",
                            CubeListBuilder.create()
                                    .texOffs(4, 7)
                                    .addBox(
                                            -4.5F,
                                            0.0F,
                                            0.375F,
                                            3.0F,
                                            0.0F,
                                            2.0F
                                    )
                                    .texOffs(4, 1)
                                    .addBox(
                                            -5.5F,
                                            0.0F,
                                            -2.875F,
                                            4.0F,
                                            0.0F,
                                            3.0F
                                    ),
                            PartPose.offset(
                                    0.0F,
                                    -1.0F,
                                    1.375F
                            )
                    );

            PartDefinition wingsLeft =
                    wings.addOrReplaceChild(
                            "wings_left",
                            CubeListBuilder.create(),
                            PartPose.offset(
                                    0.0F,
                                    -1.0F,
                                    1.375F
                            )
                    );

            wingsLeft.addOrReplaceChild(
                    "front_wing_left_r1",
                    CubeListBuilder.create()
                            .texOffs(4, 1)
                            .addBox(
                                    -5.5F,
                                    0.0F,
                                    -2.875F,
                                    4.0F,
                                    0.0F,
                                    3.0F
                            )
                            .texOffs(4, 7)
                            .addBox(
                                    -4.5F,
                                    0.0F,
                                    0.375F,
                                    3.0F,
                                    0.0F,
                                    2.0F
                            ),
                    PartPose.offsetAndRotation(
                            0.0F,
                            0.0F,
                            0.0F,
                            0.0F,
                            0.0F,
                            -3.1416F
                    )
            );

            return LayerDefinition.create(
                    meshdefinition,
                    64,
                    64
            );
        }

        @Override
        public void setupAnim(
                MothRenderState state
        ) {
            root().resetPose();

            /*
             * Keep the baby head looking in the same direction
             * as the parent moth.
             */
            head.yRot =
                    state.yRot *
                            ((float) Math.PI / 180F);

            head.xRot =
                    state.xRot *
                            ((float) Math.PI / 180F);

            /*
             * EXACT SAME FLAPPING VALUES AS THE PARENT.
             */
            float flapSpeed =
                    isRadiance
                            ? 0.5F
                            : 0.7F;

            float flapAmount =
                    isRadiance
                            ? 0.7F
                            : 0.9F;

            float flap =
                    Mth.sin(
                            state.ageInTicks * flapSpeed
                    ) * flapAmount;

            /*
             * The fresh BB model has separate left/right
             * wing groups, so animate them independently.
             *
             * Right wing = negative rotation
             * Left wing  = positive rotation
             *
             * This mirrors the parent's:
             *
             * leftWingFront.zRot  = flap;
             * rightWingFront.zRot = -flap;
             */
            wingsLeft.zRot =
                    flap;

            wingsRight.zRot =
                    -flap;

            /*
             * The whole baby moth keeps the same gentle
             * hovering motion as before.
             */
            body.y =
                    Mth.sin(
                            state.ageInTicks * 0.15F
                    ) * 0.20F;
        }
    }
}