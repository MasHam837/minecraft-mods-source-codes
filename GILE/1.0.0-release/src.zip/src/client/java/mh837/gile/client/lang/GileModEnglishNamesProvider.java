package mh837.gile.client.lang;

import mh837.gile.*;
import mh837.gile.entity.WeaselVariant;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public final class GileModEnglishNamesProvider {

    private GileModEnglishNamesProvider() {}

    public static void items(FabricLanguageProvider.TranslationBuilder t) {
        // Currencies
        t.add(GileModItems.MORA, "Mora");
        t.add(GileModItems.ANEMO_SIGIL, "Anemo Sigil");
        t.add(GileModItems.GEO_SIGIL, "Geo Sigil");
        t.add(GileModItems.ELECTRO_SIGIL, "Electro Sigil");
        t.add(GileModItems.DENDRO_SIGIL, "Dendro Sigil");
        t.add(GileModItems.HYDRO_SIGIL, "Hydro Sigil");
        t.add(GileModItems.PYRO_SIGIL, "Pyro Sigil");
        t.add(GileModItems.CRYO_SIGIL, "Cryo Sigil");
        t.add(GileModItems.LUNA_SIGIL, "Luna Sigil");
        t.add(GileModItems.SIGILS_ANIMATION, "Sigils Animation");
        // Ores
        t.add(GileModItems.PRIMOGEM, "Primogem");
        t.add(GileModItems.PEARLESCENT_MATERIAL, "Pearlescent Material");
        t.add(GileModItems.WISH_INGOT, "Wish Ingot");
        t.add(GileModItems.WISH_NUGGET, "Wish Nugget");
        t.add(GileModItems.ENDERITE_INGOT, "Enderite Ingot");
        t.add(GileModItems.ENDERITE_SHARD, "Enderite Shard");
        t.add(GileModItems.CRYSTAL, "Crystal");
        // Weapons
        t.add(GileModItems.DAYBREAK_CHRONICLES, "§bDaybreak Chronicles");
        t.add(GileModItems.VORTEX_VANQUISHER, "§bVortex Vanquisher");
        t.add(GileModItems.ENGULFING_LIGHTNING, "§bEngulfing Lightning");
        t.add(GileModItems.THOUSAND_FLOATING_DREAMS, "§bThousand Floating Dreams");
        t.add(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS, "§bSplendor of Tranquil Waters");
        t.add(GileModItems.THOUSAND_BLAZING_SUNS, "§bThousand Blazing Suns");
        t.add(GileModItems.HIEMAL_MANDATE, "§bHiemal Mandate");
        t.add(GileModItems.NOCTURNES_CURTAIN_CALL, "§bNocturne's Curtain Call");
        t.add(GileModItems.TOME_OF_NABERIUS, "§dTome of Naberius");
        t.add(GileModItems.PALM_OF_ASMODAY, "§dPalm of Asmoday");
        t.add(GileModItems.HOURGLASS_OF_ISTAROTH, "§dHourglass of Istaroth");
        t.add(GileModItems.SCYTHE_OF_RONOVA, "§dScythe of Ronova");
        t.add(GileModItems.PHANES_BLADE, "§ePhanes' Blade");
        // Fate Collection
        t.add(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE, "§dFate Upgrade");
        t.add(GileModItems.FATE_ARROW, "§bFate Arrow");
        t.add(GileModItems.FATE_BOW, "§bFate Bow");
        t.add(GileModItems.FATE_SWORD, "§bFate Sword");
        // Tools
        t.add(GileModItems.ENDERITE_SPEAR, "Enderite Spear");
        t.add(GileModItems.ENDERITE_SWORD, "Enderite Sword");
        t.add(GileModItems.ENDERITE_PICKAXE, "Enderite Pickaxe");
        t.add(GileModItems.ENDERITE_SHOVEL, "Enderite Shovel");
        t.add(GileModItems.ENDERITE_AXE, "Enderite Axe");
        t.add(GileModItems.ENDERITE_HOE, "Enderite Hoe");
        t.add(GileModItems.ENDERITE_HELMET, "Enderite Helmet");
        t.add(GileModItems.ENDERITE_CHESTPLATE, "Enderite Chestplate");
        t.add(GileModItems.ENDERITE_LEGGINGS, "Enderite Leggings");
        t.add(GileModItems.ENDERITE_BOOTS, "Enderite Boots");
        // Special Tools
        t.add(GileModItems.SHRINKER, "Shrinker");
        t.add(GileModItems.ENLARGER, "Enlarger");
        t.add(GileModItems.JELLY_ON_A_STICK, "Jelly on a Stick");
        t.add(GileModItems.WARP_CLOCK, "Warp Clock");
        t.add(GileModItems.CHRONO_GEAR, "Chrono Gear");
        t.add(GileModItems.HEART_OF_EMERGENCY, "Heart of Emergency");
        t.add(GileModItems.GRAPPLING_HOOK, "Grappling Hook");
        t.add(GileModItems.GENESIS_CRYSTAL, "§dGenesis Crystal");
        t.add(GileModItems.END_COMPASS, "End Compass");
        t.add(GileModItems.FLUTTERER, "Flutterer");
        t.add(GileModItems.NUCLEAR_CANNON, "Nuclear Cannon");
        // Drops
        t.add(GileModItems.VOID_SLIMEBALL, "Void Slimeball");
        t.add(GileModItems.MOTH_WING, "Moth Wing");
        t.add(GileModItems.JERBOAS_TAIL, "Jerboa's Tail");
        t.add(GileModItems.COGWORK_CORE, "Cogwork Core");
        // Food
        t.add(GileModItems.JELLY, "Jelly");
        t.add(GileModItems.JAM, "Jam");
        t.add(GileModItems.PHASMA, "Phasma");
        t.add(GileModItems.COOKED_PHASMA, "Cooked Phasma");
        t.add(GileModItems.OFFERING, "Offering to the Moon Goddess");
        t.add(GileModItems.GLOWING_CHORUS_FRUIT, "Glowing Chorus Fruit");
        t.add(GileModItems.GLOWING_POPPED_CHORUS_FRUIT, "Popped Glowing Chorus Fruit");
        // Misc/Materials
        t.add(GileModItems.DUST, "Dust");
        t.add(GileModItems.STAR_DUST, "Star Dust");
        t.add(GileModItems.STAR_SHINE, "Star Shine");
        t.add(GileModItems.STAR_FRAGMENT, "Star Fragment");
    }

    public static void blocks(FabricLanguageProvider.TranslationBuilder t) {
        // Ores
        t.add(GileModBlocks.PRIMOGEM_ORE.asItem(), "Primogem Ore");
        t.add(GileModBlocks.DEEPSLATE_PRIMOGEM_ORE.asItem(), "Deepslate Primogem Ore");
        t.add(GileModBlocks.END_PRIMOGEM_ORE.asItem(), "End Primogem Ore");
        t.add(GileModBlocks.WISH.asItem(), "Wish");
        t.add(GileModBlocks.WISH_TABLE.asItem(), "Wish Table");
        t.add(GileModBlocks.ENDERITE_ORE.asItem(), "Enderite Ore");
        t.add(GileModBlocks.ENDERITE_BLOCK.asItem(), "Enderite Block");
        // Metall Blocks
        t.add(GileModBlocks.PEARLESCENT_BLOCK.asItem(), "Pearlescent Block");
        t.add(GileModBlocks.PEARLESCENT_STAIRS.asItem(), "Pearlescent Stairs");
        t.add(GileModBlocks.PEARLESCENT_SLAB.asItem(), "Pearlescent Slab");
        t.add(GileModBlocks.PEARLESCENT_WALL.asItem(), "Pearlescent Wall");
        t.add(GileModBlocks.PEARLESCENT_BRICKS.asItem(), "Pearlescent Bricks");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_STAIRS.asItem(), "Pearlescent Bricks Stairs");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_SLAB.asItem(), "Pearlescent Bricks Slab");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_WALL.asItem(), "Pearlescent Bricks Wall");
        // Stones
        t.add(GileModBlocks.MOON_SAND.asItem(), "Moon Sand");
        t.add(GileModBlocks.MOON_SANDSTONE.asItem(), "Moon Sandstone");
        t.add(GileModBlocks.MOON_SANDSTONE_STAIRS.asItem(), "Moon Sandstone Stairs");
        t.add(GileModBlocks.MOON_SANDSTONE_SLAB.asItem(), "Moon Sandstone Slab");
        t.add(GileModBlocks.MOON_SANDSTONE_WALL.asItem(), "Moon Sandstone Wall");
        t.add(GileModBlocks.MOON_CHISELED_SANDSTONE.asItem(), "Moon Chiseled Sandstone");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE.asItem(), "Moon Smooth Sandstone");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS.asItem(), "Moon Smooth Sandstone Stairs");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB.asItem(), "Moon Smooth Sandstone Slab");
        t.add(GileModBlocks.MOON_CUT_SANDSTONE.asItem(), "Moon Cut Sandstone");
        t.add(GileModBlocks.MOON_CUT_SANDSTONE_SLAB.asItem(), "Moon Cut Sandstone Slab");
        // Wood
        t.add(GileModBlocks.GHOSTLY_LOG.asItem(), "Ghostly Log");
        t.add(GileModBlocks.STRIPPED_GHOSTLY_LOG.asItem(), "Stripped Ghostly Log");
        t.add(GileModBlocks.GHOSTLY_WOOD.asItem(), "Ghostly Wood");
        t.add(GileModBlocks.STRIPPED_GHOSTLY_WOOD.asItem(), "Stripped Ghostly Wood");
        t.add(GileModBlocks.GHOSTLY_PLANKS.asItem(), "Ghostly Planks");
        t.add(GileModBlocks.GHOSTLY_STAIRS.asItem(), "Ghostly Stairs");
        t.add(GileModBlocks.GHOSTLY_SLAB.asItem(), "Ghostly Slab");
        t.add(GileModBlocks.GHOSTLY_FENCE.asItem(), "Ghostly Fence");
        t.add(GileModBlocks.GHOSTLY_FENCE_GATE.asItem(), "Ghostly Fence Gate");
        t.add(GileModBlocks.GHOSTLY_DOOR.asItem(), "Ghostly Door");
        t.add(GileModBlocks.GHOSTLY_TRAPDOOR.asItem(), "Ghostly Trapdoor");
        t.add(GileModBlocks.GHOSTLY_PRESSURE_PLATE.asItem(), "Ghostly Pressure Plate");
        t.add(GileModBlocks.GHOSTLY_BUTTON.asItem(), "Ghostly Button");
        t.add(GileModBlocks.GHOSTLY_SHELF.asItem(), "Ghostly Shelf");
        t.add(GileModBlocks.GHOSTLY_LEAVES.asItem(), "Ghostly Leaves");

        t.add(GileModBlocks.INVERTED_OAK_LOG.asItem(), "Inverted Oak Log");
        t.add(GileModBlocks.STRIPPED_INVERTED_OAK_LOG.asItem(), "Stripped Inverted Oak Log");
        t.add(GileModBlocks.INVERTED_OAK_WOOD.asItem(), "Inverted Oak Wood");
        t.add(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD.asItem(), "Stripped Inverted Oak Wood");
        t.add(GileModBlocks.INVERTED_OAK_PLANKS.asItem(), "Inverted Oak Planks");
        t.add(GileModBlocks.INVERTED_OAK_STAIRS.asItem(), "Inverted Oak Stairs");
        t.add(GileModBlocks.INVERTED_OAK_SLAB.asItem(), "Inverted Oak Slab");
        t.add(GileModBlocks.INVERTED_OAK_FENCE.asItem(), "Inverted Oak Fence");
        t.add(GileModBlocks.INVERTED_OAK_FENCE_GATE.asItem(), "Inverted Oak Fence Gate");
        t.add(GileModBlocks.INVERTED_OAK_DOOR.asItem(), "Inverted Oak Door");
        t.add(GileModBlocks.INVERTED_OAK_TRAPDOOR.asItem(), "Inverted Oak Trapdoor");
        t.add(GileModBlocks.INVERTED_OAK_PRESSURE_PLATE.asItem(), "Inverted Oak Pressure Plate");
        t.add(GileModBlocks.INVERTED_OAK_BUTTON.asItem(), "Inverted Oak Button");
        t.add(GileModBlocks.INVERTED_OAK_SHELF.asItem(), "Inverted Oak Shelf");
        t.add(GileModBlocks.INVERTED_OAK_LEAVES.asItem(), "Inverted Oak Leaves");
        // Signs
        t.add(GileModBlocks.GHOSTLY_SIGN, "Ghostly Sign");
        t.add(GileModBlocks.GHOSTLY_WALL_SIGN, "Ghostly Sign");
        t.add(GileModItems.GHOSTLY_SIGN_ITEM, "Ghostly Sign");
        t.add(GileModBlocks.GHOSTLY_HANGING_SIGN, "Ghostly Hanging Sign");
        t.add(GileModBlocks.GHOSTLY_WALL_HANGING_SIGN, "Ghostly Hanging Sign");
        t.add(GileModItems.GHOSTLY_HANGING_SIGN_ITEM, "Ghostly Hanging Sign");
        t.add(GileModBlocks.INVERTED_OAK_SIGN, "Inverted Oak Sign");
        t.add(GileModBlocks.INVERTED_OAK_WALL_SIGN, "Inverted Oak Sign");
        t.add(GileModItems.INVERTED_OAK_SIGN_ITEM, "Inverted Oak Sign");
        t.add(GileModBlocks.INVERTED_OAK_HANGING_SIGN, "Inverted Oak Hanging Sign");
        t.add(GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN, "Inverted Oak Hanging Sign");
        t.add(GileModItems.INVERTED_OAK_HANGING_SIGN_ITEM, "Inverted Oak Hanging Sign");
        // Plants
        t.add(GileModBlocks.GHOSTLY_SAPLING.asItem(), "Ghostly Sapling");
        t.add(GileModBlocks.POTTED_GHOSTLY_SAPLING, "Ghostly Sapling");
        t.add(GileModBlocks.INVERTED_OAK_SAPLING.asItem(), "Inverted Oak Sapling");
        t.add(GileModBlocks.POTTED_INVERTED_OAK_SAPLING, "Inverted Oak Sapling");
        t.add(GileModBlocks.END_GRASS_BLOCK.asItem(), "End Grass Block");
        t.add(GileModBlocks.END_GRASS.asItem(), "End Grass");
        t.add(GileModBlocks.TALL_END_GRASS.asItem(), "Tall End Grass");
        t.add(GileModBlocks.MOON_FLOWER.asItem(), "Moon Flower");
        t.add(GileModBlocks.POTTED_MOON_FLOWER, "Moon Flower");
        t.add(GileModBlocks.GLOOMY_FLOWER.asItem(), "Gloomy Flower");
        t.add(GileModBlocks.POTTED_GLOOMY_FLOWER, "Gloomy Flower");
        t.add(GileModBlocks.DRY_FLOWER.asItem(), "Dry Flower");
        t.add(GileModBlocks.POTTED_DRY_FLOWER, "Dry Flower");
        t.add(GileModBlocks.GLOWING_CHORUS_FLOWER.asItem(), "Glowing Chorus Flower");
        t.add(GileModBlocks.GLOWING_CHORUS_PLANT.asItem(), "Glowing Chorus Plant");
        t.add(GileModBlocks.FLUO_BLOCK.asItem(), "Fluo Block");
        t.add(GileModBlocks.FLUO_STAIRS.asItem(), "Fluo Stairs");
        t.add(GileModBlocks.FLUO_SLAB.asItem(), "Fluo Slab");
        t.add(GileModBlocks.FLUO_PILLAR.asItem(), "Fluo Pillar");
        // Moon Fire
        t.add(GileModBlocks.MOON_TORCH, "Moon Torch");
        t.add(GileModBlocks.MOON_WALL_TORCH, "Moon Torch");
        t.add(GileModItems.MOON_TORCH_ITEM, "Moon Torch");
        t.add(GileModBlocks.PEARLESCENT_CHAIN.asItem(), "Pearlescent Chain");
        t.add(GileModBlocks.MOON_LANTERN.asItem(), "Moon Lantern");
        t.add(GileModBlocks.MOON_CAMPFIRE.asItem(), "Moon Campfire");
        t.add(GileModBlocks.MOON_FIRE, "Moon Fire");
        //Misc
        t.add(GileModBlocks.STAR.asItem(), "Star");
        t.add(GileModBlocks.END_CLOUD.asItem(), "End Cloud");
        t.add(GileModBlocks.GLITTER_BLOCK.asItem(), "Glitter Block");
        t.add(GileModBlocks.GLITTER_CARPET.asItem(), "Glitter Carpet");
        t.add(GileModBlocks.JAR_OF_GLITTERS.asItem(), "Jar of Glitters");
    }

    public static void entities(FabricLanguageProvider.TranslationBuilder t) {
        t.add(GileModEntities.FATE_ARROW_TYPE, "Fate Arrow");
        t.add(GileModEntities.VENTI_ARROW_TYPE, "Venti Arrow");
        t.add(GileModEntities.ENDER_FLY_STING, "Ender Fly Sting");
        t.add(GileModEntities.VOID_SLIME, "Void Slime");
        t.add(GileModEntities.VOID_SLIME_SPAWN_EGG, "Void Slime Spawn Egg");
        t.add(GileModEntities.MOTH, "Moth");
        t.add(GileModEntities.MOTH_SPAWN_EGG, "Moth Spawn Egg");
        t.add(GileModEntities.LUMINOUS, "Luminous");
        t.add(GileModEntities.LUMINOUS_SPAWN_EGG, "Luminous Spawn Egg");
        t.add(GileModEntities.HOVERING_GHOST, "Hovering Ghost");
        t.add(GileModEntities.HOVERING_GHOST_SPAWN_EGG, "Hovering Ghost Spawn Egg");
        t.add(GileModEntities.GLOOMY_LYNX, "Gloomy Lynx");
        t.add(GileModEntities.GLOOMY_LYNX_SPAWN_EGG, "Gloomy Lynx Spawn Egg");
        t.add(GileModEntities.JERBOA, "Jerboa");
        t.add(GileModEntities.JERBOA_SPAWN_EGG, "Jerboa Spawn Egg");
        t.add(GileModEntities.WEASEL_THIEF, "Weasel Thief");
        t.add(GileModEntities.WEASEL_THIEF_SPAWN_EGG, "Weasel Thief Spawn Egg");
        t.add(String.valueOf(WeaselVariant.AMATEUR), "Amateur");
        t.add(String.valueOf(WeaselVariant.HOARDER), "Hoarder");
        t.add(String.valueOf(WeaselVariant.GOLDEN), "Golden");
        t.add(GileModEntities.GLITTER, "Glitter");
        t.add(GileModEntities.GLITTER_SPAWN_EGG, "Glitter Spawn Egg");
        t.add(GileModEntities.SALON_MEMBER, "Salon Member");
        t.add("entity.gilemod.salon_member_1", "Surintendante Chevalmarin");
        t.add("entity.gilemod.salon_member_2", "Gentilhomme Usher");
        t.add("entity.gilemod.salon_member_3", "Mademoiselle Crabaletta");
        t.add(GileModEntities.SALON_MEMBER_SPAWN_EGG, "Salon Member Spawn Egg");
        t.add(GileModEntities.ENDER_FLY, "Ender Fly");
        t.add(GileModEntities.ENDER_FLY_SPAWN_EGG, "Ender Fly Spawn Egg");
        t.add(GileModEntities.RUIN_GUARD, "Ruin Guard");
        t.add(GileModEntities.RUIN_GUARD_SPAWN_EGG, "Ruin Guard Spawn Egg");
    }

    public static void effects(FabricLanguageProvider.TranslationBuilder t) {
        t.add(GileModEffects.SHRINK.value(), "Shrinking");
        t.add(GileModEffects.ENLARGE.value(), "Enlarging");
    }
}
