package mh837.gile.client.model;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class WeaselThiefModel extends EntityModel<LivingEntityRenderState> {

    public static final ModelLayerLocation WEASEL_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath("gilemod", "weasel_thief"),
                    "main"
            );

    private final ModelPart head;
    private final ModelPart legs;

    public WeaselThiefModel(ModelPart root) {
        super(root);

        this.head = root.getChild("head");
        this.legs = root.getChild("legs");
    }


    public static LayerDefinition createBodyLayer() {

        MeshDefinition meshDefinition = new MeshDefinition();
        PartDefinition root = meshDefinition.getRoot();


        // Head
        root.addOrReplaceChild(
                "head",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        .addBox(
                                -2.0F,
                                -2.0F,
                                -3.0F,
                                4.0F,
                                4.0F,
                                5.0F
                        ),
                PartPose.offset(0.0F, 19.0F, -5.0F)
        );


        // Body
        root.addOrReplaceChild(
                "body",
                CubeListBuilder.create()
                        .texOffs(18, 0)
                        .addBox(
                                -2.5F,
                                -2.5F,
                                -5.0F,
                                5.0F,
                                4.0F,
                                10.0F
                        ),
                PartPose.offset(0.0F, 20.0F, 0.0F)
        );


        // Thief sack
        root.addOrReplaceChild(
                "sack",
                CubeListBuilder.create()
                        .texOffs(0, 14)
                        .addBox(
                                -3.5F,
                                -6.0F,
                                -3.0F,
                                7.0F,
                                6.0F,
                                8.0F
                        ),
                PartPose.offset(0.0F, 18.0F, 0.0F)
        );


        // Tail
        root.addOrReplaceChild(
                "tail",
                CubeListBuilder.create()
                        .texOffs(30, 14)
                        .addBox(
                                -1.0F,
                                -1.0F,
                                0.0F,
                                2.0F,
                                2.0F,
                                6.0F
                        ),
                PartPose.offset(0.0F, 19.5F, 5.0F)
        );


        // Legs group
        PartDefinition legs = root.addOrReplaceChild(
                "legs",
                CubeListBuilder.create(),
                PartPose.offset(0.0F, 24.0F, 0.0F)
        );


        legs.addOrReplaceChild(
                "leg1",
                CubeListBuilder.create()
                        .texOffs(0, 28)
                        .addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(-1.5F, 0.0F, -4.0F)
        );


        legs.addOrReplaceChild(
                "leg2",
                CubeListBuilder.create()
                        .texOffs(0, 28)
                        .addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(1.5F, 0.0F, -4.0F)
        );


        legs.addOrReplaceChild(
                "leg3",
                CubeListBuilder.create()
                        .texOffs(0, 28)
                        .addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(-1.5F, 0.0F, 4.0F)
        );


        legs.addOrReplaceChild(
                "leg4",
                CubeListBuilder.create()
                        .texOffs(0, 28)
                        .addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(1.5F, 0.0F, 4.0F)
        );


        return LayerDefinition.create(meshDefinition, 64, 32);
    }


    @Override
    public void setupAnim(LivingEntityRenderState state) {

        // Head movement
        this.head.xRot =
                state.xRot * ((float) Math.PI / 180F);

        this.head.yRot =
                state.yRot * ((float) Math.PI / 180F);


        // Walking animation
        float speed = state.walkAnimationSpeed;
        float pos = state.walkAnimationPos;


        this.legs.getChild("leg1").xRot =
                Mth.cos(pos * 0.6662F) * 1.4F * speed;

        this.legs.getChild("leg2").xRot =
                Mth.cos(pos * 0.6662F + (float)Math.PI) * 1.4F * speed;

        this.legs.getChild("leg3").xRot =
                Mth.cos(pos * 0.6662F + (float)Math.PI) * 1.4F * speed;

        this.legs.getChild("leg4").xRot =
                Mth.cos(pos * 0.6662F) * 1.4F * speed;
    }
}