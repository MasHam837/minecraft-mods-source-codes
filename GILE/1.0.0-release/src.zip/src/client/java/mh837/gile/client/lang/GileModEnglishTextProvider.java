package mh837.gile.client.lang;

import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public final class GileModEnglishTextProvider {

    private GileModEnglishTextProvider() {}

    public static void advancements(FabricLanguageProvider.TranslationBuilder t) {
        // Root
        t.add("advancements.gilemod._root.title", "GILE");
        t.add("advancements.gilemod._root.description", "Discover what lies beyond the familiar world");
        // Abilities
        t.add("advancements.gilemod.ability_anemo.title", "Whispers of the Wind");
        t.add("advancements.gilemod.ability_anemo.description", "Harness the power of Anemo");
        t.add("advancements.gilemod.ability_geo.title", "Stonebound");
        t.add("advancements.gilemod.ability_geo.description", "Harness the power of Geo");
        t.add("advancements.gilemod.ability_electro.title", "Wrath of the Sky");
        t.add("advancements.gilemod.ability_electro.description", "Harness the power of Electro");
        t.add("advancements.gilemod.ability_dendro.title", "Where Life Takes Root");
        t.add("advancements.gilemod.ability_dendro.description", "Harness the power of Dendro");
        t.add("advancements.gilemod.ability_hydro.title", "Flow Like Water");
        t.add("advancements.gilemod.ability_hydro.description", "Harness the power of Hydro");
        t.add("advancements.gilemod.ability_pyro.title", "A Spark Within");
        t.add("advancements.gilemod.ability_pyro.description", "Harness the power of Pyro");
        t.add("advancements.gilemod.ability_cryo.title", "Cold as the Void");
        t.add("advancements.gilemod.ability_cryo.description", "Harness the power of Cryo");
        t.add("advancements.gilemod.ability_luna.title", "Under the Pale Moon");
        t.add("advancements.gilemod.ability_luna.description", "Harness the power of Luna");
        t.add("advancements.gilemod.ability_life.title", "The Breath of Life");
        t.add("advancements.gilemod.ability_life.description", "Harness the power of Life");
        t.add("advancements.gilemod.ability_space.title", "Beyond the Stars");
        t.add("advancements.gilemod.ability_space.description", "Harness the power of Space");
        t.add("advancements.gilemod.ability_time.title", "A Moment Out of Time");
        t.add("advancements.gilemod.ability_time.description", "Harness the power of Time");
        t.add("advancements.gilemod.ability_death.title", "A Touch of Death");
        t.add("advancements.gilemod.ability_death.description", "Master the power of Death");
        t.add("advancements.gilemod.ability_divine.title", "The First Throne");
        t.add("advancements.gilemod.ability_divine.description", "Harness the power of Phanes");
        // Challenges
        t.add("advancements.gilemod.challenge_genshin.title", "Collect Them All");
        t.add("advancements.gilemod.challenge_genshin.description", "Collect every Genshin weapon");
        // Defeat
        t.add("advancements.gilemod.defeat_ruin_guard.title", "That's One Down");
        t.add("advancements.gilemod.defeat_ruin_guard.description", "Defeat a Ruin Guard");
        // Discover
        t.add("advancements.gilemod.ancient_ruins.title", "Echoes of Ages Past");
        t.add("advancements.gilemod.ancient_ruins.description", "Discover the Ancient Ruins");
        t.add("advancements.gilemod.discover_end_threshold.title", "Where Worlds Collide");
        t.add("advancements.gilemod.discover_end_threshold.description", "Discover the threshold between worlds");
        t.add("advancements.gilemod.ghostly_thickets.title", "A Forest of Ghosts");
        t.add("advancements.gilemod.ghostly_thickets.description", "Discover the Ghostly Thickets");
        t.add("advancements.gilemod.discover_moon.title", "One Small Step");
        t.add("advancements.gilemod.discover_moon.description", "Set foot on the Moon");
        t.add("advancements.gilemod.moon_desert.title", "The Sea of Silence");
        t.add("advancements.gilemod.moon_desert.description", "Discover the Moon Desert");
        // Encounter
        t.add("advancements.gilemod.encounter_gloomy_lynx.title", "Murder Mittens");
        t.add("advancements.gilemod.encounter_gloomy_lynx.description", "Encounter a Gloomy Lynx");
        t.add("advancements.gilemod.encounter_hovering_ghost.title", "Something's Hovering");
        t.add("advancements.gilemod.encounter_hovering_ghost.description", "Encounter a Hovering Ghost");
        t.add("advancements.gilemod.encounter_jerboa.title", "Pocket-Sized");
        t.add("advancements.gilemod.encounter_jerboa.description", "Encounter a Jerboa");
        t.add("advancements.gilemod.encounter_weasel_thief.title", "Sticky Fingers");
        t.add("advancements.gilemod.encounter_weasel_thief.description", "Encounter a Weasel Thief");
        t.add("advancements.gilemod.encounter_moon_mobs.title", "Not From Around Here");
        t.add("advancements.gilemod.encounter_moon_mobs.description", "Encounter a Moon Mob");
        // Get
        t.add("advancements.gilemod.get_any_sigil.title", "A Sign of Power");
        t.add("advancements.gilemod.get_any_sigil.description", "Obtain any Sigil");
        t.add("advancements.gilemod.get_end_cloud.title", "Walking on Air");
        t.add("advancements.gilemod.get_end_cloud.description", "Obtain an End Cloud");
        t.add("advancements.gilemod.get_enderite.title", "A Metal Beyond");
        t.add("advancements.gilemod.get_enderite.description", "Obtain an Enderite Ingot");
        t.add("advancements.gilemod.get_enderite_armor.title", "Forged for the End");
        t.add("advancements.gilemod.get_enderite_armor.description", "Obtain a full set of Enderite Armor");
        t.add("advancements.gilemod.get_enderite_tools.title", "Beyond Netherite");
        t.add("advancements.gilemod.get_enderite_tools.description", "Craft every Enderite tool");
        t.add("advancements.gilemod.get_fate_collection.title", "Written in the Stars");
        t.add("advancements.gilemod.get_fate_collection.description", "Collect the Sword, Bow and Arrow of Fate");
        t.add("advancements.gilemod.get_ghostly_log.title", "Wood from Beyond");
        t.add("advancements.gilemod.get_ghostly_log.description", "Obtain a Ghostly Log");
        t.add("advancements.gilemod.get_inverted_oak.title", "Turn the World Upside Down");
        t.add("advancements.gilemod.get_inverted_oak.description", "Obtain an Inverted Oak Log");
        t.add("advancements.gilemod.get_jar_of_glitters.title", "Pocketful of Dust");
        t.add("advancements.gilemod.get_jar_of_glitters.description", "Obtain a Jar of Glitters");
        t.add("advancements.gilemod.get_moon_fire_collection.title", "Fire Under Moonlight");
        t.add("advancements.gilemod.get_moon_fire_collection.description", "Obtain a Moon Torch, Lantern & Campfire");
        t.add("advancements.gilemod.get_moon_sandstone.title", "Dust of Another World");
        t.add("advancements.gilemod.get_moon_sandstone.description", "Obtain Moon Sandstone");
        t.add("advancements.gilemod.get_primogem.title", "A Shiny Little Wish");
        t.add("advancements.gilemod.get_primogem.description", "Obtain a Primogem");
        t.add("advancements.gilemod.get_sigils_collection.title", "Sigil Hoarder");
        t.add("advancements.gilemod.get_sigils_collection.description", "Collect every type of Sigil");
        t.add("advancements.gilemod.get_star_fragment.title", "A Piece of Heaven");
        t.add("advancements.gilemod.get_star_fragment.description", "Obtain a Star Fragment");
        t.add("advancements.gilemod.get_void_slimeball.title", "Something's Wrong With This Slime");
        t.add("advancements.gilemod.get_void_slimeball.description", "Obtain a Void Slimeball");
        t.add("advancements.gilemod.get_wish_table.title", "Make a Wish");
        t.add("advancements.gilemod.get_wish_table.description", "Obtain a Wish Table");
        t.add("advancements.gilemod.get_legendary_weapon.title", "Power Beyond Mortals");
        t.add("advancements.gilemod.get_legendary_weapon.description", "Obtain any Legendary Weapon");
        t.add("advancements.gilemod.get_nuclear_cannon.title", "There Goes the Neighborhood");
        t.add("advancements.gilemod.get_nuclear_cannon.description", "Obtain a Nuclear Cannon");
        t.add("advancements.gilemod.get_heart_of_emergency.title", "Break Glass in Case of Emergency");
        t.add("advancements.gilemod.get_heart_of_emergency.description", "Get the Heart of Emergency");
        // Hit By
        t.add("advancements.gilemod.ender_fly.title", "Look Up!");
        t.add("advancements.gilemod.ender_fly.description", "Get hit by an Ender Fly");
        // Make (Custom)
        t.add("advancements.gilemod.make_a_wish.title", "Wish Upon a Star");
        t.add("advancements.gilemod.make_a_wish.description", "Make a wish at the Wish Table");
        t.add("advancements.gilemod.make_jerboa_emerge.title", "Rise, Little One");
        t.add("advancements.gilemod.make_jerboa_emerge.description", "Make a Jerboa emerge");
        // Name
        t.add("advancements.gilemod.name_nyan.title", "Nyan!");
        t.add("advancements.gilemod.name_nyan.description", "Give a creature the name Nyan Cat");
        t.add("advancements.gilemod.name_radiance.title", "What, am I gonna fight the Sun?");
        t.add("advancements.gilemod.name_radiance.description", "Give a creature the name Radiance");
        // Ride
        t.add("advancements.gilemod.ride_hovering_ghost.title", "Ghost Rider");
        t.add("advancements.gilemod.ride_hovering_ghost.description", "Ride a Hovering Ghost");
        // Trade
        t.add("advancements.gilemod.trade_weasel_thief.title", "A Shady Deal");
        t.add("advancements.gilemod.trade_weasel_thief.description", "Trade with a Weasel Thief");
        t.add("advancements.gilemod.trade_with_wisher.title", "Wishful Trading");
        t.add("advancements.gilemod.trade_with_wisher.description", "Trade with a Wisher");
        // Use
        t.add("advancements.gilemod.use_flutterer.title", "I Believe I Can Fly");
        t.add("advancements.gilemod.use_flutterer.description", "Use a Flutterer");
        t.add("advancements.gilemod.use_enlarger.title", "Go Big or Go Home");
        t.add("advancements.gilemod.use_enlarger.description", "Use an Enlarger");
        t.add("advancements.gilemod.use_grappling_hook.title", "Grappling Around");
        t.add("advancements.gilemod.use_grappling_hook.description", "Use a Grappling Hook");
        t.add("advancements.gilemod.use_shrinker.title", "Small Problems");
        t.add("advancements.gilemod.use_shrinker.description", "Use a Shrinker");
        t.add("advancements.gilemod.use_warp_clock.title", "A Stitch in Time");
        t.add("advancements.gilemod.use_warp_clock.description", "Use a Warp Clock");
    }

    public static void tooltips(FabricLanguageProvider.TranslationBuilder t) {
        // Trim Materials
        t.add("trim_material.gilemod.wish_ingot","Wish Ingot");
        t.add("trim_material.gilemod.enderite_ingot","Enderite Ingot");
        // Fate Upgrade Smithing Template
        t.add("trim_pattern.gilemod.fate_upgrade", "Smithing Template");
        t.add("item.minecraft.smithing_template.applies_to", "Applies to:");
        t.add("smithing_template.gilemod.fate_upgrade.applies_to", " Netherite Equipment");
        t.add("item.minecraft.smithing_template.ingredients", "Ingredients:");
        t.add("smithing_template.gilemod.fate_upgrade.ingredients", " Enderite Ingot");
        // Warp Clock
        t.add("tooltip.gilemod.warp_clock.unlinked", "Unlinked");
        t.add("tooltip.gilemod.warp_clock.coordinates", "Warp Coordinates: ");
        t.add("tooltip.gilemod.warp_clock.linked_warp", "Linked Warp: ");
        t.add("tooltip.gilemod.warp_clock.consumes", "Consumes: ");
        // Weapons
        t.add("tooltip.gilemod.weapon_level", "Level %s");
        t.add("tooltip.gilemod.daybreak_chronicles.when_in_hand","When in Either Hand:");
        t.add("tooltip.gilemod.daybreak_chronicles.arrow_damage"," %s Arrow Damage");
        t.add("tooltip.gilemod.daybreak_chronicles.arrow_speed"," %s Arrow Speed");

    }

    public static void messages (FabricLanguageProvider.TranslationBuilder t) {
        // Abilities
        t.add("message.gilemod.stomp_cooldown", "Stomp is on cooldown!");
        t.add("message.gilemod.shrink_visibility_off", "Your form returns to view.");
        t.add("message.gilemod.shrink_visibility_on", "Your form vanishes from sight.");
        t.add("message.gilemod.stomp", "The earth trembles beneath your step.");
        // Elemental abilities
        t.add("message.gilemod.venti_vortex_activated", "§3Venti's Vortex Unleashed!");
        t.add("message.gilemod.venti_vortex_cooldown", "§3Venti's Vortex ready in %s §3seconds.");
        t.add("message.gilemod.zhong_li_barricade_activated", "§6Zhongli's Barricade Rises!");
        t.add("message.gilemod.zhong_li_barricade_cooldown", "§6Zhongli's Barricade ready in %s §6seconds.");
        t.add("message.gilemod.zhong_li_barricade_error", "§6Zhongli's Barricade: not enough Geo on the surface.");
        t.add("message.gilemod.raiden_thunder_activated", "§5Raiden's Thunder Descends!");
        t.add("message.gilemod.raiden_thunder_cooldown", "§5Raiden's Thunder ready in %s §5seconds.");
        t.add("message.gilemod.raiden_thunder_end", "§5⚡ The thunderstorm has subsided...");
        t.add("message.gilemod.nahida_sowing_activated", "§aNahida's Sowing Takes Root!");
        t.add("message.gilemod.nahida_sowing_cooldown", "§aNahida's Sowing ready in %s §aseconds.");
        t.add("message.gilemod.furina_salon_members_activated", "§1Furina's Salon Members Take the Stage!");
        t.add("message.gilemod.furina_salon_members_cooldown", "§1Furina's Salon Members ready in %s §1seconds.");
        t.add("message.gilemod.mavuika_rage_activated", "§cMavuika's Rage Ignites!");
        t.add("message.gilemod.mavuika_rage_cooldown", "§cMavuika's Rage ready in %s §cseconds.");
        t.add("message.gilemod.tsaritsas_blizzard_activated", "§bTsaritsa's Blizzard Descends!");
        t.add("message.gilemod.tsaritsas_blizzard_cooldown", "§bTsaritsa's Blizzard ready in %s §bseconds.");
        t.add("message.gilemod.lunar_domain_activated", "§7Columbina's Lunar Domain Unveils!");
        t.add("message.gilemod.lunar_domain_cooldown", "§7Columbina's Lunar Domain ready in %s §7seconds.");
        // Legendary abilities
        t.add("message.gilemod.naberius_benediction_activated", "§eNaberius' Benediction is bestowed!");
        t.add("message.gilemod.naberius_benediction_cooldown", "§eNaberius' Benediction ready in %s §eseconds");
        t.add("message.gilemod.naberius_life_utility_cooldown", "§eNaberius' Healing ready in %s §eseconds");
        t.add("message.gilemod.asmoday_event_horizon_activated", "§dAsmoday's Event Horizon Opens!");
        t.add("message.gilemod.asmoday_event_horizon_cooldown", "§dAsmoday's Event Horizon ready in %s §dseconds.");
        t.add("message.gilemod.asmoday_space_no_safe_position","§dNo safe position found.");
        t.add("message.gilemod.asmoday_space_utility_cooldown", "§dAsmoday's Teleportation ready in %s §dseconds.");
        t.add("message.gilemod.istaroth_time_manipulation_activated", "§9Istaroth's Time Bends!");
        t.add("message.gilemod.istaroth_time_manipulation_cooldown", "§9Istaroth's Time Manipulation ready in %s §9seconds.");
        t.add("message.gilemod.istaroth_time_utility_cooldown", "§6Istaroth's Time Stop ready in %s §6seconds.");
        t.add("message.gilemod.ronova_lifesteal_activated", "§4Ronova's Lifesteal Claims Its Due!");
        t.add("message.gilemod.ronova_lifesteal_cooldown", "§4Ronova's Lifesteal ready in %s §4seconds");
        t.add("message.gilemod.ronova_lifesteal_utility_cooldown", "§4Ronova's Death Touch ready in %s §4seconds");
        // Primordial abilities
        t.add("message.gilemod.phanes_ability_activated", "Phanes' Genesis has begun.");
        t.add("message.gilemod.phanes_ability_cooldown","Phanes' Genesis is on cooldown: %s seconds.");
        t.add("message.gilemod.divine_ability_activated","The Divine Presence of Phanes has descended.");
        t.add("message.gilemod.divine_ability_cooldown","The Divine Presence is on cooldown: %s seconds.");
        t.add("message.gilemod.phanes_utility_cooldown", "Phanes' Time Acceleration is on cooldown: %s seconds.");
        t.add("message.gilemod.phanes_utility_activated","Phanes' Time Acceleration has been activated. Gamerule random_tick_speed is now on 100.");
        t.add("message.gilemod.phanes_utility_deactivated","Phanes' Time Acceleration has been deactivated. Gamerule random_tick_speed is back to 3.");
        // End compass
        t.add("message.gilemod.end_compass.invalid_dimension", "The End Compass only works between the Overworld and the End.");
        t.add("message.gilemod.end_compass.destination_missing", "Nowhere to go...");
        t.add("message.gilemod.end_compass.no_safe_position", "No safe position found.");
        t.add("message.gilemod.end_compass.main_end_warning", "⚠ WARNING: This will teleport you to the Main End Island. Click again to continue.");
        // Warp clock
        t.add("message.gilemod.warp_clock.linked", "Warp Clock linked!");
        t.add("message.gilemod.warp_clock.unlinked", "Warp Clock unlinked.");
        t.add("message.gilemod.warp_clock.click_sign", "Click a sign to set a warp point.");
        t.add("message.gilemod.warp_clock.wrong_dimension", "This warp exists in another dimension.");
        t.add("message.gilemod.warp_clock.no_chrono_gear", "You need a Chrono Gear to activate this warp!");
        t.add("message.gilemod.warp_clock.missing_sign", "Error: The warp sign no longer exists!");
        // Nuclear Cannon
        t.add("message.gilemod.nuclear_cannon_broken", "§cYour Nuclear Cannon is out of ammo! Recharge it with Shift + Right-click while holding Wish Nuggets.");
        t.add("message.gilemod.nuclear_cannon_repaired", "§aNuclear Cannon recharged!");
        t.add("message.gilemod.nuclear_cannon_ammo", "§cYou need Wish Nuggets in your offhand to recharge this!");
        t.add("message.gilemod.nuclear_cannon_full","§aYour Nuclear Cannon is already fully recharged!");
    }

    public static void keybinds(FabricLanguageProvider.TranslationBuilder t) {
        t.add("key.category.gilemod.keys", "Genshin Impact: Lunar Expansion");
        t.add("key.gilemod.flutterer_jump", "Flutterer Jump");
        t.add("key.gilemod.active_ability", "Elemental/Magic Ability");
        t.add("key.gilemod.divine_ability", "Divine Ability");
    }

    public static void sounds(FabricLanguageProvider.TranslationBuilder t) {
        t.add("subtitles.gilemod.entity.luminous.ambient", "Luminous chitters");
        t.add("subtitles.gilemod.entity.luminous.hurt", "Luminous hurts");
        t.add("subtitles.gilemod.entity.weasel_thief.ambient", "Weasel Thief chimes");
        t.add("subtitles.gilemod.entity.hovering_ghost.nyan_ambient", "Nyan Cat plays");
        t.add("subtitles.gilemod.entity.ruin_guard.hit", "Ruin Guard strikes");
        t.add("subtitles.gilemod.entity.ruin_guard.rotation", "Ruin Guard rotates");
    }

    public static void misc(FabricLanguageProvider.TranslationBuilder t) {
        // Item Groups
        t.add("itemgroup.gilemod.gile", "GILE");
        // Villager Professions
        t.add("entity.gilemod.villager.wisher", "Wisher");
        // GUIs
        t.add("container.gilemod.wish_table", "Wish Table");
        // Enchantments
        t.add("enchantment.gilemod.fluttering", "Fluttering");
        t.add("enchantment.gilemod.range", "Range");
        // Item Tags
        t.add("tag.item.gilemod.enchantable.range", "Items Enchantable with Range");
        t.add("tag.item.gilemod.wish_input", "Wish Input");
        t.add("tag.item.gilemod.sigil_input", "Sigil Input");
        t.add("tag.item.gilemod.elemental_weapon", "Elemental Weapons");
        t.add("tag.item.gilemod.legendary_weapon", "Legendary Weapons");
        t.add("tag.item.gilemod.primordial_weapon", "Primordial Weapons");
        t.add("tag.item.gilemod.enderite_mining_tools", "Enderite Mining Tools");
        t.add("tag.item.gilemod.enderite_tool_materials", "Enderite Tool Materials");
    }
}
