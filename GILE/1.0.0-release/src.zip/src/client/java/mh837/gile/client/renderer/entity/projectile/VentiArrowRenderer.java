package mh837.gile.client.renderer.entity.projectile;

import mh837.gile.entity.projectile.VentiArrowEntity;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.ArrowRenderState;
import net.minecraft.resources.Identifier;

public class VentiArrowRenderer extends ArrowRenderer<VentiArrowEntity, ArrowRenderState> {

    public static final Identifier TEXTURE = Identifier.fromNamespaceAndPath("gilemod", "textures/entity/projectiles/venti_arrow.png");

    public VentiArrowRenderer(EntityRendererProvider.Context context) {super(context);}

    @Override
    public ArrowRenderState createRenderState() {return new ArrowRenderState();}

    @Override
    protected Identifier getTextureLocation(ArrowRenderState state) {return TEXTURE;}

}