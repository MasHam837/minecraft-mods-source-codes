package mh837.gile.client.renderer.state;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class EnderFlyRenderState extends LivingEntityRenderState {

}