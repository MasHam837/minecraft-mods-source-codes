package mh837.gile.client.renderer.entity.projectile.state;

import net.minecraft.client.renderer.entity.state.ArrowRenderState;

public class EnderFlyStingRenderState extends ArrowRenderState {

}