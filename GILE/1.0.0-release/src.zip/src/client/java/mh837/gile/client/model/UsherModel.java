package mh837.gile.client.model;

import mh837.gile.client.renderer.state.SalonMembersRenderState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class UsherModel extends EntityModel<SalonMembersRenderState> {

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath("gilemod", "salon_members/usher"), "main"
    );

    private final ModelPart usher;
    private final ModelPart head;
    private final ModelPart eyes;
    private final ModelPart tentacles;
    private final ModelPart back_left;
    private final ModelPart back_right;
    private final ModelPart front_left;
    private final ModelPart front_right;

    public UsherModel(ModelPart root) {
        super(root, RenderTypes::entityTranslucent);
        this.usher = root.getChild("usher");
        this.head = this.usher.getChild("head");
        this.eyes = this.head.getChild("eyes");
        this.tentacles = this.usher.getChild("tentacles");
        this.back_left = this.tentacles.getChild("back_left");
        this.back_right = this.tentacles.getChild("back_right");
        this.front_left = this.tentacles.getChild("front_left");
        this.front_right = this.tentacles.getChild("front_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        PartDefinition usher = partdefinition.addOrReplaceChild("usher", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));

        PartDefinition head = usher.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 9).addBox(-3.0F, -8.25F, -3.0F, 6.0F, 3.0F, 6.0F, new CubeDeformation(0.0F))
                .texOffs(0, 0).addBox(-4.0F, -9.25F, -4.0F, 8.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition hat_top_r1 = head.addOrReplaceChild("hat_top_r1", CubeListBuilder.create().texOffs(24, 9).addBox(-2.5152F, -5.75F, -2.4848F, 5.0F, 6.0F, 5.0F, new CubeDeformation(0.0F))
                .texOffs(0, 18).addBox(-2.9848F, -2.75F, -3.0152F, 6.0F, 2.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -9.5F, 0.0214F, 0.0F, 0.7854F, 0.0F));

        PartDefinition eyes = head.addOrReplaceChild("eyes", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition right_eye_r1 = eyes.addOrReplaceChild("right_eye_r1", CubeListBuilder.create().texOffs(32, 6).addBox(1.0F, 0.0F, -1.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.25F, -8.25F, -2.5F, 0.0F, 0.0F, 0.7854F));

        PartDefinition left_eye_r1 = eyes.addOrReplaceChild("left_eye_r1", CubeListBuilder.create().texOffs(32, 6).addBox(-2.0F, 0.0F, -1.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(2.25F, -8.25F, -2.5F, 0.0F, 0.0F, -0.7854F));

        PartDefinition tentacles = usher.addOrReplaceChild("tentacles", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition back_left = tentacles.addOrReplaceChild("back_left", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition tentacle_bl_up_r1 = back_left.addOrReplaceChild("tentacle_bl_up_r1", CubeListBuilder.create().texOffs(24, 20).addBox(0.2731F, 0.2113F, 0.1837F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -5.6446F, 0.0F, 0.2182F, 0.0F, -0.2182F));

        PartDefinition tentacle_bl_down_r1 = back_left.addOrReplaceChild("tentacle_bl_down_r1", CubeListBuilder.create().texOffs(32, 20).addBox(-0.8813F, -0.1036F, -0.7966F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.74F, -3.1432F, 1.6683F, 0.0468F, 0.0376F, -0.0477F));

        PartDefinition back_right = tentacles.addOrReplaceChild("back_right", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition tentacle_br_up_r1 = back_right.addOrReplaceChild("tentacle_br_up_r1", CubeListBuilder.create().texOffs(24, 20).mirror().addBox(-2.2731F, 0.2113F, 0.1837F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.0F, -5.6446F, 0.0F, 0.2182F, 0.0F, 0.2182F));

        PartDefinition tentacle_br_donw_r1 = back_right.addOrReplaceChild("tentacle_br_donw_r1", CubeListBuilder.create().texOffs(32, 20).mirror().addBox(-1.1187F, -0.1036F, -0.7966F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.74F, -3.1432F, 1.6683F, 0.0468F, -0.0376F, 0.0477F));

        PartDefinition front_left = tentacles.addOrReplaceChild("front_left", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition tentacle_fl_up_r1 = front_left.addOrReplaceChild("tentacle_fl_up_r1", CubeListBuilder.create().texOffs(24, 20).addBox(0.2731F, 0.2113F, -2.1837F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -5.6446F, 0.0F, -0.2182F, 0.0F, -0.2182F));

        PartDefinition tentacle_fl_down_r1 = front_left.addOrReplaceChild("tentacle_fl_down_r1", CubeListBuilder.create().texOffs(32, 20).addBox(-0.8682F, -0.0895F, -1.145F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.74F, -3.1432F, -1.7327F, -0.0404F, 0.0376F, -0.0477F));

        PartDefinition front_right = tentacles.addOrReplaceChild("front_right", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition tentacle_fr_up_r1 = front_right.addOrReplaceChild("tentacle_fr_up_r1", CubeListBuilder.create().texOffs(24, 20).mirror().addBox(-2.2731F, 0.2113F, -2.1837F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.0F, -5.6446F, 0.0F, -0.2182F, 0.0F, 0.2182F));

        PartDefinition tentacle_fr_down_r1 = front_right.addOrReplaceChild("tentacle_fr_down_r1", CubeListBuilder.create().texOffs(32, 20).mirror().addBox(-1.1318F, -0.0895F, -1.145F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.74F, -3.1432F, -1.7327F, -0.0404F, -0.0376F, 0.0477F));

        return LayerDefinition.create(meshdefinition, 64, 64);
    }

    @Override
    public void setupAnim(SalonMembersRenderState state) {
        float time = state.ageInTicks;

        // Gentle, continuous tentacle movement.
        float wave1 = Mth.cos(time * 0.10F) * 0.12F;
        float wave2 = Mth.cos(time * 0.10F + 1.2F) * 0.12F;
        float wave3 = Mth.cos(time * 0.10F + 2.4F) * 0.12F;
        float wave4 = Mth.cos(time * 0.10F + 3.6F) * 0.12F;

        this.back_left.xRot = wave1;
        this.back_left.zRot = -0.18F + wave2 * 0.5F;

        this.back_right.xRot = wave2;
        this.back_right.zRot = 0.18F - wave3 * 0.5F;

        this.front_left.xRot = wave3;
        this.front_left.zRot = -0.18F + wave4 * 0.5F;

        this.front_right.xRot = wave4;
        this.front_right.zRot = 0.18F - wave1 * 0.5F;
    }
}