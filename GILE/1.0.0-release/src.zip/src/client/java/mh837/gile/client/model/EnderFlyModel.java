package mh837.gile.client.model;

import mh837.gile.client.renderer.state.EnderFlyRenderState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

public class EnderFlyModel extends EntityModel<EnderFlyRenderState> {

    private final ModelPart wingUpperLeft;
    private final ModelPart wingUpperRight;
    private final ModelPart wingMiddleLeft;
    private final ModelPart wingMiddleRight;
    private final ModelPart wingLowerLeft;
    private final ModelPart wingLowerRight;

    public EnderFlyModel(ModelPart root) {
        super(root);
        this.wingUpperLeft = root.getChild("wing_upper_left");
        this.wingUpperRight = root.getChild("wing_upper_right");
        this.wingMiddleLeft = root.getChild("wing_middle_left");
        this.wingMiddleRight = root.getChild("wing_middle_right");
        this.wingLowerLeft = root.getChild("wing_lower_left");
        this.wingLowerRight = root.getChild("wing_lower_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition root = meshdefinition.getRoot();

        // Body and Eyes (Kept at the center pivot)
        root.addOrReplaceChild("body", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-3.0F, -15.0F, -2.0F, 6.0F, 12.0F, 4.0F)
                        .texOffs(10, 18).addBox(-3.0F, -13.0F, -3.0F, 2.0F, 2.0F, 1.0F)
                        .texOffs(10, 18).mirror().addBox(1.0F, -13.0F, -3.0F, 2.0F, 2.0F, 1.0F).mirror(false),
                PartPose.offset(0.0F, 24.0F, 0.0F));

        // Upper Wings (Pivots shifted to the shoulder joints at Y=7)
        root.addOrReplaceChild("wing_upper_left", CubeListBuilder.create()
                        .texOffs(0, 18).addBox(-5.0F, 0.0F, 0.0F, 5.0F, 5.0F, 0.0F),
                PartPose.offset(-3.0F, 7.0F, 0.0F));

        root.addOrReplaceChild("wing_upper_right", CubeListBuilder.create()
                        .texOffs(0, 18).mirror().addBox(0.0F, 0.0F, 0.0F, 5.0F, 5.0F, 0.0F).mirror(false),
                PartPose.offset(3.0F, 7.0F, 0.0F));

        // Middle Wings (Pivots shifted to the shoulder joints at Y=13)
        root.addOrReplaceChild("wing_middle_left", CubeListBuilder.create()
                        .texOffs(0, 23).mirror().addBox(-4.0F, 0.0F, 0.0F, 4.0F, 4.0F, 0.0F).mirror(false),
                PartPose.offset(-3.0F, 13.0F, 0.0F));

        root.addOrReplaceChild("wing_middle_right", CubeListBuilder.create()
                        .texOffs(0, 23).addBox(0.0F, 0.0F, 0.0F, 4.0F, 4.0F, 0.0F),
                PartPose.offset(3.0F, 13.0F, 0.0F));

        // Lower Wings (Pivots shifted to the shoulder joints at Y=18)
        root.addOrReplaceChild("wing_lower_left", CubeListBuilder.create()
                        .texOffs(0, 27).addBox(-5.0F, 0.0F, 0.0F, 5.0F, 5.0F, 0.0F),
                PartPose.offset(-3.0F, 18.0F, 0.0F));

        root.addOrReplaceChild("wing_lower_right", CubeListBuilder.create()
                        .texOffs(0, 27).mirror().addBox(0.0F, 0.0F, 0.0F, 5.0F, 5.0F, 0.0F).mirror(false),
                PartPose.offset(3.0F, 18.0F, 0.0F));

        return LayerDefinition.create(meshdefinition, 32, 32);
    }

    @Override
    public void setupAnim(EnderFlyRenderState state) {
        super.setupAnim(state);
        float age = state.ageInTicks;
        float flap = Mth.cos(age * 1.1F) * 1.1F;
        this.wingUpperLeft.yRot = -0.10F - flap * 0.85F;
        this.wingUpperRight.yRot = 0.10F + flap * 0.85F;
        this.wingMiddleLeft.yRot = -0.08F - flap;
        this.wingMiddleRight.yRot = 0.08F + flap;
        this.wingLowerLeft.yRot = -0.10F - flap * 0.75F;
        this.wingLowerRight.yRot = 0.10F + flap * 0.75F;
    }
}