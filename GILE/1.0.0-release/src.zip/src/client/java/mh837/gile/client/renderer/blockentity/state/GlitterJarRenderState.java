package mh837.gile.client.renderer.blockentity.state;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;

public class GlitterJarRenderState extends BlockEntityRenderState {

    public int glitterCount = 1;
    public float age;
}