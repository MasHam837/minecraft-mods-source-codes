package mh837.gile.client.model;

import mh837.gile.client.renderer.state.SalonMembersRenderState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class CrabalettaModel extends EntityModel<SalonMembersRenderState> {
    private final ModelPart crabaletta;
    private final ModelPart body;
    private final ModelPart legs;
    private final ModelPart legs_back;
    private final ModelPart leg_back_left;
    private final ModelPart leg_back_right;
    private final ModelPart legs_central;
    private final ModelPart leg_central_left;
    private final ModelPart leg_central_right;
    private final ModelPart claws;
    private final ModelPart arm_left;
    private final ModelPart claw_left;
    private final ModelPart arm_right;
    private final ModelPart claw_right;

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath("gilemod", "salon_members/crabaletta"), "main"
    );

    public CrabalettaModel(ModelPart root) {
        super(root, RenderTypes::entityTranslucent);
        this.crabaletta = root.getChild("crabaletta");
        this.body = this.crabaletta.getChild("body");
        this.legs = this.crabaletta.getChild("legs");
        this.legs_back = this.legs.getChild("legs_back");
        this.leg_back_left = this.legs_back.getChild("leg_back_left");
        this.leg_back_right = this.legs_back.getChild("leg_back_right");
        this.legs_central = this.legs.getChild("legs_central");
        this.leg_central_left = this.legs_central.getChild("leg_central_left");
        this.leg_central_right = this.legs_central.getChild("leg_central_right");
        this.claws = this.crabaletta.getChild("claws");
        this.arm_left = this.claws.getChild("arm_left");
        this.claw_left = this.arm_left.getChild("claw_left");
        this.arm_right = this.claws.getChild("arm_right");
        this.claw_right = this.arm_right.getChild("claw_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        PartDefinition crabaletta = partdefinition.addOrReplaceChild("crabaletta", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));

        PartDefinition body = crabaletta.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, 3.1F, -5.1F, 10.0F, 3.0F, 14.0F, new CubeDeformation(0.0F))
                .texOffs(48, 16).addBox(1.0F, -0.9F, -5.35F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(48, 16).addBox(-3.0F, -0.9F, -5.35F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(0, 17).addBox(-5.5F, -3.9F, -2.6F, 11.0F, 7.0F, 12.0F, new CubeDeformation(0.0F))
                .texOffs(0, 36).addBox(-4.5F, -6.9F, -1.6F, 9.0F, 3.0F, 10.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, -9.1F, -1.9F));

        PartDefinition bow_left_r1 = body.addOrReplaceChild("bow_left_r1", CubeListBuilder.create().texOffs(54, 23).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.0F, -5.0F, -3.0F, -0.6155F, 0.5236F, -0.9553F));

        PartDefinition bow_right_r1 = body.addOrReplaceChild("bow_right_r1", CubeListBuilder.create().texOffs(48, 23).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-4.5F, -5.0F, -1.5F, -0.6155F, 0.5236F, -0.9553F));

        PartDefinition upper_shell_right_r1 = body.addOrReplaceChild("upper_shell_right_r1", CubeListBuilder.create().texOffs(30, 49).addBox(-4.3879F, -3.476F, -3.9934F, 2.0F, 1.0F, 9.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.9019F, -7.934F, 2.7496F, -0.124F, -0.1231F, -0.7777F));

        PartDefinition upper_shell_left_r1 = body.addOrReplaceChild("upper_shell_left_r1", CubeListBuilder.create().texOffs(30, 49).mirror().addBox(3.0427F, -2.4978F, -3.9934F, 2.0F, 1.0F, 9.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.0981F, -7.934F, 2.7496F, -0.1551F, 0.0803F, 0.4737F));

        PartDefinition upper_shell_center_r1 = body.addOrReplaceChild("upper_shell_center_r1", CubeListBuilder.create().texOffs(0, 49).addBox(-3.1519F, -0.7913F, -4.0066F, 6.0F, 1.0F, 9.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.0981F, -7.934F, 2.7496F, -0.1745F, 0.0F, 0.0F));

        PartDefinition legs = crabaletta.addOrReplaceChild("legs", CubeListBuilder.create(), PartPose.offset(0.0F, -1.5F, 1.5F));

        PartDefinition legs_back = legs.addOrReplaceChild("legs_back", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 2.5F));

        PartDefinition leg_back_left = legs_back.addOrReplaceChild("leg_back_left", CubeListBuilder.create().texOffs(48, 0).addBox(-1.0F, -1.5F, -1.0F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 0.0F, 0.0F));

        PartDefinition leg_back_right = legs_back.addOrReplaceChild("leg_back_right", CubeListBuilder.create().texOffs(48, 0).addBox(-1.0F, -1.5F, -1.0F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-5.0F, 0.0F, 0.0F));

        PartDefinition legs_central = legs.addOrReplaceChild("legs_central", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, -2.5F));

        PartDefinition leg_central_left = legs_central.addOrReplaceChild("leg_central_left", CubeListBuilder.create().texOffs(48, 0).addBox(-1.0F, -1.5F, -1.5F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 0.0F, 0.0F));

        PartDefinition leg_central_right = legs_central.addOrReplaceChild("leg_central_right", CubeListBuilder.create().texOffs(48, 0).addBox(-1.0F, -1.5F, -1.5F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-5.0F, 0.0F, 0.0F));

        PartDefinition claws = crabaletta.addOrReplaceChild("claws", CubeListBuilder.create(), PartPose.offset(0.0F, -2.4283F, -7.3723F));

        PartDefinition arm_left = claws.addOrReplaceChild("arm_left", CubeListBuilder.create(), PartPose.offset(3.7119F, 0.0F, 0.0F));

        PartDefinition arm_left_r1 = arm_left.addOrReplaceChild("arm_left_r1", CubeListBuilder.create().texOffs(48, 11).mirror().addBox(-1.5F, -2.5F, -1.0F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(1.0F, 0.0F, -1.0F, -0.9368F, 0.1528F, 1.2282F));

        PartDefinition claw_left = arm_left.addOrReplaceChild("claw_left", CubeListBuilder.create(), PartPose.offset(-7.4238F, 0.0F, 0.0F));

        PartDefinition claw_shell_top_r1 = claw_left.addOrReplaceChild("claw_shell_top_r1", CubeListBuilder.create().texOffs(48, 26).addBox(-1.0858F, -2.9142F, -0.5F, 4.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(6.0048F, -1.0717F, -4.1277F, 0.3021F, -0.4127F, -0.9317F));

        PartDefinition claw_shell_bottom_r1 = claw_left.addOrReplaceChild("claw_shell_bottom_r1", CubeListBuilder.create().texOffs(48, 31).addBox(-1.9142F, -0.0858F, -0.5F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(6.0048F, -1.0717F, -4.3777F, 0.3021F, -0.4127F, -0.9317F));

        PartDefinition claw_left_r1 = claw_left.addOrReplaceChild("claw_left_r1", CubeListBuilder.create().texOffs(48, 5).mirror().addBox(-1.5F, -2.5F, -1.0F, 3.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(6.4238F, -0.5F, -2.5F, -0.4969F, 0.1603F, 1.6015F));

        PartDefinition arm_right = claws.addOrReplaceChild("arm_right", CubeListBuilder.create(), PartPose.offset(-3.7119F, 0.0F, 0.0F));

        PartDefinition arm_right_r1 = arm_right.addOrReplaceChild("arm_right_r1", CubeListBuilder.create().texOffs(48, 11).addBox(-1.5F, -2.5F, -1.0F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.0F, 0.0F, -1.0F, -0.9368F, -0.1528F, -1.2282F));

        PartDefinition claw_right = arm_right.addOrReplaceChild("claw_right", CubeListBuilder.create(), PartPose.offset(7.4238F, 0.0F, 0.0F));

        PartDefinition claw_right_r1 = claw_right.addOrReplaceChild("claw_right_r1", CubeListBuilder.create().texOffs(48, 5).addBox(-1.5F, -2.5F, -1.0F, 3.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-6.4238F, -0.5F, -2.5F, -0.4969F, -0.1603F, -1.6015F));

        return LayerDefinition.create(meshdefinition, 64, 64);
    }

    @Override
    public void setupAnim(SalonMembersRenderState state) {
        float time = state.ageInTicks;

        // Put the arms slightly forward.
        this.arm_left.xRot = -0.20F;
        this.arm_right.xRot = -0.20F;

        // Slight outward angle.
        this.arm_left.zRot = 0.12F;
        this.arm_right.zRot = -0.12F;

        // Vertical claw movement.
        float clawMovement = Mth.sin(time * 0.14F) * 0.20F;

        this.claw_left.xRot = clawMovement;
        this.claw_right.xRot = -clawMovement;

        // Very subtle eye/head-area movement.
        float eyeMovement = Mth.sin(time * 0.08F) * 0.04F;

        this.body.yRot = eyeMovement;
    }
}