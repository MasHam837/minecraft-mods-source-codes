package mh837.gile.client.lang;

import mh837.gile.*;
import mh837.gile.entity.WeaselVariant;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public final class GileModFrenchNamesProvider {

    private GileModFrenchNamesProvider() {}

    public static void items(FabricLanguageProvider.TranslationBuilder t) {
        // Currencies
        t.add(GileModItems.MORA, "Mora");
        t.add(GileModItems.ANEMO_SIGIL, "Sceau d'Anémo");
        t.add(GileModItems.GEO_SIGIL, "Sceau de Géo");
        t.add(GileModItems.ELECTRO_SIGIL, "Sceau d'Électro");
        t.add(GileModItems.DENDRO_SIGIL, "Sceau de Dendro");
        t.add(GileModItems.HYDRO_SIGIL, "Sceau d'Hydro");
        t.add(GileModItems.PYRO_SIGIL, "Sceau de Pyro");
        t.add(GileModItems.CRYO_SIGIL, "Sceau de Cryo");
        t.add(GileModItems.LUNA_SIGIL, "Sceau lunaire");
        t.add(GileModItems.SIGILS_ANIMATION, "Animation des sceaux");

        // Ores
        t.add(GileModItems.PRIMOGEM, "Primo-gemme");
        t.add(GileModItems.PEARLESCENT_MATERIAL, "Matériau nacré");
        t.add(GileModItems.WISH_INGOT, "Lingot de vœu");
        t.add(GileModItems.WISH_NUGGET, "Pépite de vœu");
        t.add(GileModItems.ENDERITE_INGOT, "Lingot d'Endérite");
        t.add(GileModItems.ENDERITE_SHARD, "Éclat d'Endérite");
        t.add(GileModItems.CRYSTAL, "Cristal");

        // Weapons
        t.add(GileModItems.DAYBREAK_CHRONICLES, "§bChroniques de l'aube");
        t.add(GileModItems.VORTEX_VANQUISHER, "§bPerceur prismatique");
        t.add(GileModItems.ENGULFING_LIGHTNING, "§bLumière du faucheur");
        t.add(GileModItems.THOUSAND_FLOATING_DREAMS, "§bMille rêves flottants");
        t.add(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS, "§bSplendeur des eaux calmes");
        t.add(GileModItems.THOUSAND_BLAZING_SUNS, "§bMille soleils ardents");
        t.add(GileModItems.HIEMAL_MANDATE, "§bMandat hivernal");
        t.add(GileModItems.NOCTURNES_CURTAIN_CALL, "§bSalut final du nocturne");
        t.add(GileModItems.TOME_OF_NABERIUS, "§dTome de Naberius");
        t.add(GileModItems.PALM_OF_ASMODAY, "§dPaume d'Asmoday");
        t.add(GileModItems.HOURGLASS_OF_ISTAROTH, "§dSablier d'Istaroth");
        t.add(GileModItems.SCYTHE_OF_RONOVA, "§dFaux de Ronova");
        t.add(GileModItems.PHANES_BLADE, "§eLame de Phanès");

        // Fate Collection
        t.add(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE, "§dAmélioration du destin");
        t.add(GileModItems.FATE_ARROW, "§bFlèche du destin");
        t.add(GileModItems.FATE_BOW, "§bArc du destin");
        t.add(GileModItems.FATE_SWORD, "§bÉpée du destin");

        // Tools
        t.add(GileModItems.ENDERITE_SPEAR, "Lance en Endérite");
        t.add(GileModItems.ENDERITE_SWORD, "Épée en Endérite");
        t.add(GileModItems.ENDERITE_PICKAXE, "Pioche en Endérite");
        t.add(GileModItems.ENDERITE_SHOVEL, "Pelle en Endérite");
        t.add(GileModItems.ENDERITE_AXE, "Hache en Endérite");
        t.add(GileModItems.ENDERITE_HOE, "Houe en Endérite");
        t.add(GileModItems.ENDERITE_HELMET, "Casque en Endérite");
        t.add(GileModItems.ENDERITE_CHESTPLATE, "Plastron en Endérite");
        t.add(GileModItems.ENDERITE_LEGGINGS, "Jambières en Endérite");
        t.add(GileModItems.ENDERITE_BOOTS, "Bottes en Endérite");

        // Special Tools
        t.add(GileModItems.SHRINKER, "Rétrécisseur");
        t.add(GileModItems.ENLARGER, "Agrandisseur");
        t.add(GileModItems.JELLY_ON_A_STICK, "Gelée sur un bâton");
        t.add(GileModItems.WARP_CLOCK, "Horloge de distorsion");
        t.add(GileModItems.CHRONO_GEAR, "Engrenage chrono");
        t.add(GileModItems.HEART_OF_EMERGENCY, "Cœur d'urgence");
        t.add(GileModItems.GRAPPLING_HOOK, "Grappin");
        t.add(GileModItems.GENESIS_CRYSTAL, "§dCristal de genèse");
        t.add(GileModItems.END_COMPASS, "Boussole de l'End");
        t.add(GileModItems.FLUTTERER, "Planeur");
        t.add(GileModItems.NUCLEAR_CANNON, "Canon nucléaire");

        // Drops
        t.add(GileModItems.VOID_SLIMEBALL, "Boule de slime du Vide");
        t.add(GileModItems.MOTH_WING, "Aile de papillon de nuit");
        t.add(GileModItems.JERBOAS_TAIL, "Queue de gerboise");
        t.add(GileModItems.COGWORK_CORE, "Cœur mécanique");

        // Food
        t.add(GileModItems.JELLY, "Gelée");
        t.add(GileModItems.JAM, "Confiture");
        t.add(GileModItems.PHASMA, "Phasma");
        t.add(GileModItems.COOKED_PHASMA, "Phasma cuit");
        t.add(GileModItems.OFFERING, "Offrande à la déesse de la Lune");
        t.add(GileModItems.GLOWING_CHORUS_FRUIT, "Fruit de chorus lumineux");
        t.add(GileModItems.GLOWING_POPPED_CHORUS_FRUIT, "Fruit de chorus lumineux éclaté");

        // Misc/Materials
        t.add(GileModItems.DUST, "Poussière");
        t.add(GileModItems.STAR_DUST, "Poussière d'étoile");
        t.add(GileModItems.STAR_SHINE, "Éclat d'étoile");
        t.add(GileModItems.STAR_FRAGMENT, "Fragment d'étoile");
    }

    public static void blocks(FabricLanguageProvider.TranslationBuilder t) {
        // Ores
        t.add(GileModBlocks.PRIMOGEM_ORE.asItem(), "Minerai de primo-gemme");
        t.add(GileModBlocks.DEEPSLATE_PRIMOGEM_ORE.asItem(), "Minerai de primo-gemme des abîmes");
        t.add(GileModBlocks.END_PRIMOGEM_ORE.asItem(), "Minerai de primo-gemme de l'End");
        t.add(GileModBlocks.WISH.asItem(), "Vœu");
        t.add(GileModBlocks.WISH_TABLE.asItem(), "Table des vœux");
        t.add(GileModBlocks.ENDERITE_ORE.asItem(), "Minerai d'Endérite");
        t.add(GileModBlocks.ENDERITE_BLOCK.asItem(), "Bloc d'Endérite");

        // Metall Blocks
        t.add(GileModBlocks.PEARLESCENT_BLOCK.asItem(), "Bloc nacré");
        t.add(GileModBlocks.PEARLESCENT_STAIRS.asItem(), "Escaliers nacrés");
        t.add(GileModBlocks.PEARLESCENT_SLAB.asItem(), "Dalle nacrée");
        t.add(GileModBlocks.PEARLESCENT_WALL.asItem(), "Muret nacré");
        t.add(GileModBlocks.PEARLESCENT_BRICKS.asItem(), "Briques nacrées");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_STAIRS.asItem(), "Escaliers en briques nacrées");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_SLAB.asItem(), "Dalle en briques nacrées");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_WALL.asItem(), "Muret en briques nacrées");

        // Stones
        t.add(GileModBlocks.MOON_SAND.asItem(), "Sable lunaire");
        t.add(GileModBlocks.MOON_SANDSTONE.asItem(), "Grès lunaire");
        t.add(GileModBlocks.MOON_SANDSTONE_STAIRS.asItem(), "Escaliers en grès lunaire");
        t.add(GileModBlocks.MOON_SANDSTONE_SLAB.asItem(), "Dalle en grès lunaire");
        t.add(GileModBlocks.MOON_SANDSTONE_WALL.asItem(), "Muret en grès lunaire");
        t.add(GileModBlocks.MOON_CHISELED_SANDSTONE.asItem(), "Grès lunaire sculpté");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE.asItem(), "Grès lunaire lisse");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS.asItem(), "Escaliers en grès lunaire lisse");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB.asItem(), "Dalle en grès lunaire lisse");
        t.add(GileModBlocks.MOON_CUT_SANDSTONE.asItem(), "Grès lunaire taillé");
        t.add(GileModBlocks.MOON_CUT_SANDSTONE_SLAB.asItem(), "Dalle en grès lunaire taillé");

        // Wood
        t.add(GileModBlocks.GHOSTLY_LOG.asItem(), "Bûche spectrale");
        t.add(GileModBlocks.STRIPPED_GHOSTLY_LOG.asItem(), "Bûche spectrale écorcée");
        t.add(GileModBlocks.GHOSTLY_WOOD.asItem(), "Bois spectral");
        t.add(GileModBlocks.STRIPPED_GHOSTLY_WOOD.asItem(), "Bois spectral écorcé");
        t.add(GileModBlocks.GHOSTLY_PLANKS.asItem(), "Planches spectrales");
        t.add(GileModBlocks.GHOSTLY_STAIRS.asItem(), "Escaliers spectraux");
        t.add(GileModBlocks.GHOSTLY_SLAB.asItem(), "Dalle spectrale");
        t.add(GileModBlocks.GHOSTLY_FENCE.asItem(), "Barrière spectrale");
        t.add(GileModBlocks.GHOSTLY_FENCE_GATE.asItem(), "Portillon spectral");
        t.add(GileModBlocks.GHOSTLY_DOOR.asItem(), "Porte spectrale");
        t.add(GileModBlocks.GHOSTLY_TRAPDOOR.asItem(), "Trappe spectrale");
        t.add(GileModBlocks.GHOSTLY_PRESSURE_PLATE.asItem(), "Plaque de pression spectrale");
        t.add(GileModBlocks.GHOSTLY_BUTTON.asItem(), "Bouton spectral");
        t.add(GileModBlocks.GHOSTLY_SHELF.asItem(), "Étagère spectrale");
        t.add(GileModBlocks.GHOSTLY_LEAVES.asItem(), "Feuilles spectrales");

        t.add(GileModBlocks.INVERTED_OAK_LOG.asItem(), "Bûche de chêne inversée");
        t.add(GileModBlocks.STRIPPED_INVERTED_OAK_LOG.asItem(), "Bûche de chêne inversée écorcée");
        t.add(GileModBlocks.INVERTED_OAK_WOOD.asItem(), "Bois de chêne inversé");
        t.add(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD.asItem(), "Bois de chêne inversé écorcé");
        t.add(GileModBlocks.INVERTED_OAK_PLANKS.asItem(), "Planches de chêne inversées");
        t.add(GileModBlocks.INVERTED_OAK_STAIRS.asItem(), "Escaliers en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_SLAB.asItem(), "Dalle en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_FENCE.asItem(), "Barrière en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_FENCE_GATE.asItem(), "Portillon en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_DOOR.asItem(), "Porte en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_TRAPDOOR.asItem(), "Trappe en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_PRESSURE_PLATE.asItem(), "Plaque de pression en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_BUTTON.asItem(), "Bouton en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_SHELF.asItem(), "Étagère en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_LEAVES.asItem(), "Feuilles de chêne inversées");

        // Signs
        t.add(GileModBlocks.GHOSTLY_SIGN, "Panneau spectral");
        t.add(GileModBlocks.GHOSTLY_WALL_SIGN, "Panneau spectral");
        t.add(GileModItems.GHOSTLY_SIGN_ITEM, "Panneau spectral");
        t.add(GileModBlocks.GHOSTLY_HANGING_SIGN, "Panneau suspendu spectral");
        t.add(GileModBlocks.GHOSTLY_WALL_HANGING_SIGN, "Panneau suspendu spectral");
        t.add(GileModItems.GHOSTLY_HANGING_SIGN_ITEM, "Panneau suspendu spectral");
        t.add(GileModBlocks.INVERTED_OAK_SIGN, "Panneau en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_WALL_SIGN, "Panneau en chêne inversé");
        t.add(GileModItems.INVERTED_OAK_SIGN_ITEM, "Panneau en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_HANGING_SIGN, "Panneau suspendu en chêne inversé");
        t.add(GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN, "Panneau suspendu en chêne inversé");
        t.add(GileModItems.INVERTED_OAK_HANGING_SIGN_ITEM, "Panneau suspendu en chêne inversé");

        // Plants
        t.add(GileModBlocks.GHOSTLY_SAPLING.asItem(), "Pousse d'arbre spectral");
        t.add(GileModBlocks.POTTED_GHOSTLY_SAPLING, "Pousse d'arbre spectral");
        t.add(GileModBlocks.INVERTED_OAK_SAPLING.asItem(), "Pousse de chêne inversé");
        t.add(GileModBlocks.POTTED_INVERTED_OAK_SAPLING, "Pousse de chêne inversé");
        t.add(GileModBlocks.END_GRASS_BLOCK.asItem(), "Bloc d'herbe de l'End");
        t.add(GileModBlocks.END_GRASS.asItem(), "Herbe de l'End");
        t.add(GileModBlocks.TALL_END_GRASS.asItem(), "Hautes herbes de l'End");
        t.add(GileModBlocks.MOON_FLOWER.asItem(), "Fleur lunaire");
        t.add(GileModBlocks.POTTED_MOON_FLOWER, "Fleur lunaire");
        t.add(GileModBlocks.GLOOMY_FLOWER.asItem(), "Fleur lugubre");
        t.add(GileModBlocks.POTTED_GLOOMY_FLOWER, "Fleur lugubre");
        t.add(GileModBlocks.DRY_FLOWER.asItem(), "Fleur sèche");
        t.add(GileModBlocks.POTTED_DRY_FLOWER, "Fleur sèche");
        t.add(GileModBlocks.GLOWING_CHORUS_FLOWER.asItem(), "Fleur de chorus lumineuse");
        t.add(GileModBlocks.GLOWING_CHORUS_PLANT.asItem(), "Plante de chorus lumineuse");
        t.add(GileModBlocks.FLUO_BLOCK.asItem(), "Bloc fluorescent");
        t.add(GileModBlocks.FLUO_STAIRS.asItem(), "Escaliers fluorescents");
        t.add(GileModBlocks.FLUO_SLAB.asItem(), "Dalle fluorescente");
        t.add(GileModBlocks.FLUO_PILLAR.asItem(), "Pilier fluorescent");

        // Moon Fire
        t.add(GileModBlocks.MOON_TORCH, "Torche lunaire");
        t.add(GileModBlocks.MOON_WALL_TORCH, "Torche lunaire");
        t.add(GileModItems.MOON_TORCH_ITEM, "Torche lunaire");
        t.add(GileModBlocks.PEARLESCENT_CHAIN.asItem(), "Chaîne nacrée");
        t.add(GileModBlocks.MOON_LANTERN.asItem(), "Lanterne lunaire");
        t.add(GileModBlocks.MOON_CAMPFIRE.asItem(), "Feu de camp lunaire");
        t.add(GileModBlocks.MOON_FIRE, "Feu lunaire");

        // Misc
        t.add(GileModBlocks.STAR.asItem(), "Étoile");
        t.add(GileModBlocks.END_CLOUD.asItem(), "Nuage de l'End");
        t.add(GileModBlocks.GLITTER_BLOCK.asItem(), "Bloc de paillettes");
        t.add(GileModBlocks.GLITTER_CARPET.asItem(), "Tapis de paillettes");
        t.add(GileModBlocks.JAR_OF_GLITTERS.asItem(), "Bocal de paillettes");
    }

    public static void entities(FabricLanguageProvider.TranslationBuilder t) {
        t.add(GileModEntities.FATE_ARROW_TYPE, "Flèche du destin");
        t.add(GileModEntities.VENTI_ARROW_TYPE, "Flèche de Venti");
        t.add(GileModEntities.ENDER_FLY_STING, "Dard de mouche de l'End");
        t.add(GileModEntities.VOID_SLIME, "Slime du Vide");
        t.add(GileModEntities.VOID_SLIME_SPAWN_EGG, "Œuf d'apparition de slime du Vide");
        t.add(GileModEntities.MOTH, "Papillon de nuit");
        t.add(GileModEntities.MOTH_SPAWN_EGG, "Œuf d'apparition de papillon de nuit");
        t.add(GileModEntities.LUMINOUS, "Lumineux");
        t.add(GileModEntities.LUMINOUS_SPAWN_EGG, "Œuf d'apparition de Lumineux");
        t.add(GileModEntities.HOVERING_GHOST, "Fantôme flottant");
        t.add(GileModEntities.HOVERING_GHOST_SPAWN_EGG, "Œuf d'apparition de fantôme flottant");
        t.add(GileModEntities.GLOOMY_LYNX, "Lynx lugubre");
        t.add(GileModEntities.GLOOMY_LYNX_SPAWN_EGG, "Œuf d'apparition de lynx lugubre");
        t.add(GileModEntities.JERBOA, "Gerboise");
        t.add(GileModEntities.JERBOA_SPAWN_EGG, "Œuf d'apparition de gerboise");
        t.add(GileModEntities.WEASEL_THIEF, "Belette voleuse");
        t.add(GileModEntities.WEASEL_THIEF_SPAWN_EGG, "Œuf d'apparition de belette voleuse");
        t.add(String.valueOf(WeaselVariant.AMATEUR), "Amateur");
        t.add(String.valueOf(WeaselVariant.HOARDER), "Collectionneur");
        t.add(String.valueOf(WeaselVariant.GOLDEN), "Doré");
        t.add(GileModEntities.GLITTER, "Paillette");
        t.add(GileModEntities.GLITTER_SPAWN_EGG, "Œuf d'apparition de paillette");
        t.add(GileModEntities.SALON_MEMBER, "Membre du Salon");
        t.add("entity.gilemod.salon_member_1", "Surintendante Chevalmarin");
        t.add("entity.gilemod.salon_member_2", "Gentilhomme Usher");
        t.add("entity.gilemod.salon_member_3", "Mademoiselle Crabaletta");
        t.add(GileModEntities.SALON_MEMBER_SPAWN_EGG, "Œuf d'apparition de membre du Salon");
        t.add(GileModEntities.ENDER_FLY, "Mouche de l'End");
        t.add(GileModEntities.ENDER_FLY_SPAWN_EGG, "Œuf d'apparition de mouche de l'End");
        t.add(GileModEntities.RUIN_GUARD, "Garde des ruines");
        t.add(GileModEntities.RUIN_GUARD_SPAWN_EGG, "Œuf d'apparition de garde des ruines");
    }

    public static void effects(FabricLanguageProvider.TranslationBuilder t) {
        t.add(GileModEffects.SHRINK.value(), "Rétrécissement");
        t.add(GileModEffects.ENLARGE.value(), "Agrandissement");
    }

}