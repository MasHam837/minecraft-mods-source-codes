package mh837.gile.client.renderer.blockentity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import java.util.ArrayList;
import java.util.List;

import mh837.gile.block.entity.GhostlyShelfBlockEntity;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ShelfBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

public class GhostlyShelfRenderer implements BlockEntityRenderer<GhostlyShelfBlockEntity, GhostlyShelfRenderer.State> {

    private final ItemModelResolver itemModelResolver;

    public GhostlyShelfRenderer(BlockEntityRendererProvider.Context context) {
        this.itemModelResolver = context.itemModelResolver();
    }

    public static class State extends BlockEntityRenderState {
        public Direction facing;
        public List<ItemStackRenderState> items = new ArrayList<>();
        public List<Float> scales = new ArrayList<>();
    }

    @Override
    public State createRenderState() {
        return new State();
    }

    @Override
    public void extractRenderState(
            GhostlyShelfBlockEntity blockEntity,
            State state,
            float partialTicks,
            Vec3 cameraPosition,
            ModelFeatureRenderer.@Nullable CrumblingOverlay breakProgress
    ) {
        BlockEntityRenderer.super.extractRenderState(
                blockEntity,
                state,
                partialTicks,
                cameraPosition,
                breakProgress
        );

        state.facing = blockEntity.getBlockState().getValue(ShelfBlock.FACING);
        state.items.clear();
        state.scales.clear();

        int seed = (int) blockEntity.getBlockPos().asLong();

        for (int slot = 0; slot < blockEntity.getItems().size(); slot++) {
            ItemStack stack = blockEntity.getItems().get(slot);

            ItemStackRenderState itemState = new ItemStackRenderState();

            itemModelResolver.updateForTopItem(
                    itemState,
                    stack,
                    ItemDisplayContext.FIXED,
                    blockEntity.getLevel(),
                    null,
                    seed + slot
            );

            state.items.add(itemState);
            state.scales.add(getScale(stack, blockEntity.getLevel()));
        }
    }

    private static float getScale(
            ItemStack stack,
            net.minecraft.world.level.Level level
    ) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return 0.25F;
        }

        Block block = blockItem.getBlock();

        AABB bounds = block.defaultBlockState()
                .getShape(level, BlockPos.ZERO)
                .bounds();

        double width = bounds.getXsize();
        double height = bounds.getYsize();
        double depth = bounds.getZsize();

        double max = Math.max(width, Math.max(height, depth));

        if (max >= 0.75D) {
            return 0.5F;
        }

        return 0.25F;
    }

    @Override
    public void submit(
            State state,
            PoseStack poseStack,
            SubmitNodeCollector submitNodeCollector,
            CameraRenderState camera
    ) {
        Direction facing = state.facing;

        for (int slot = 0; slot < state.items.size(); slot++) {
            ItemStackRenderState itemState = state.items.get(slot);

            if (itemState.isEmpty()) {
                continue;
            }

            poseStack.pushPose();

            poseStack.translate(0.5F, 0.5F, 0.5F);

            poseStack.mulPose(
                    Axis.YP.rotationDegrees(facing.toYRot())
            );

            float xOffset = switch (slot) {
                case 0 -> 0.3125F;
                case 1 -> 0.0F;
                case 2 -> -0.3125F;
                default -> 0.0F;
            };

            poseStack.translate(xOffset, 0.0F, 0.25F);

            float scale = state.scales.get(slot);
            poseStack.scale(scale, scale, scale);

            itemState.submit(
                    poseStack,
                    submitNodeCollector,
                    state.lightCoords,
                    OverlayTexture.NO_OVERLAY,
                    0
            );

            poseStack.popPose();
        }
    }
}