package mh837.gile.client.lang;

import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public final class GileModFrenchTextProvider {

    private GileModFrenchTextProvider() {}

    public static void advancements(FabricLanguageProvider.TranslationBuilder t) {
        // Root
        t.add("advancements.gilemod._root.title", "GILE");
        t.add("advancements.gilemod._root.description", "Découvrez ce qui se cache au-delà du monde familier");

        // Abilities
        t.add("advancements.gilemod.ability_anemo.title", "Murmures du vent");
        t.add("advancements.gilemod.ability_anemo.description", "Maîtrisez le pouvoir de l'Anémo");
        t.add("advancements.gilemod.ability_geo.title", "Lié à la pierre");
        t.add("advancements.gilemod.ability_geo.description", "Maîtrisez le pouvoir du Géo");
        t.add("advancements.gilemod.ability_electro.title", "Courroux des cieux");
        t.add("advancements.gilemod.ability_electro.description", "Maîtrisez le pouvoir de l'Électro");
        t.add("advancements.gilemod.ability_dendro.title", "Là où la vie prend racine");
        t.add("advancements.gilemod.ability_dendro.description", "Maîtrisez le pouvoir du Dendro");
        t.add("advancements.gilemod.ability_hydro.title", "Couler comme l'eau");
        t.add("advancements.gilemod.ability_hydro.description", "Maîtrisez le pouvoir de l'Hydro");
        t.add("advancements.gilemod.ability_pyro.title", "Une étincelle intérieure");
        t.add("advancements.gilemod.ability_pyro.description", "Maîtrisez le pouvoir du Pyro");
        t.add("advancements.gilemod.ability_cryo.title", "Plus froid que le Vide");
        t.add("advancements.gilemod.ability_cryo.description", "Maîtrisez le pouvoir du Cryo");
        t.add("advancements.gilemod.ability_luna.title", "Sous la lune pâle");
        t.add("advancements.gilemod.ability_luna.description", "Maîtrisez le pouvoir de la Lune");
        t.add("advancements.gilemod.ability_life.title", "Le souffle de la vie");
        t.add("advancements.gilemod.ability_life.description", "Maîtrisez le pouvoir de la Vie");
        t.add("advancements.gilemod.ability_space.title", "Au-delà des étoiles");
        t.add("advancements.gilemod.ability_space.description", "Maîtrisez le pouvoir de l'Espace");
        t.add("advancements.gilemod.ability_time.title", "Un instant hors du temps");
        t.add("advancements.gilemod.ability_time.description", "Maîtrisez le pouvoir du Temps");
        t.add("advancements.gilemod.ability_death.title", "Le toucher de la mort");
        t.add("advancements.gilemod.ability_death.description", "Maîtrisez le pouvoir de la Mort");
        t.add("advancements.gilemod.ability_divine.title", "Le premier trône");
        t.add("advancements.gilemod.ability_divine.description", "Maîtrisez le pouvoir de Phanès");

        // Challenges
        t.add("advancements.gilemod.challenge_genshin.title", "Collectionnez-les tous");
        t.add("advancements.gilemod.challenge_genshin.description", "Collectionnez toutes les armes de Genshin");

        // Defeat
        t.add("advancements.gilemod.defeat_ruin_guard.title", "Un de moins");
        t.add("advancements.gilemod.defeat_ruin_guard.description", "Vainquez un Garde des ruines");

        // Discover
        t.add("advancements.gilemod.ancient_ruins.title", "Échos des temps anciens");
        t.add("advancements.gilemod.ancient_ruins.description", "Découvrez les ruines antiques");
        t.add("advancements.gilemod.discover_end_threshold.title", "Là où les mondes se rencontrent");
        t.add("advancements.gilemod.discover_end_threshold.description", "Découvrez le seuil entre les mondes");
        t.add("advancements.gilemod.ghostly_thickets.title", "Une forêt de fantômes");
        t.add("advancements.gilemod.ghostly_thickets.description", "Découvrez les Fourrés spectraux");
        t.add("advancements.gilemod.discover_moon.title", "Un petit pas");
        t.add("advancements.gilemod.discover_moon.description", "Posez le pied sur la Lune");
        t.add("advancements.gilemod.moon_desert.title", "La mer du silence");
        t.add("advancements.gilemod.moon_desert.description", "Découvrez le Désert lunaire");

        // Encounter
        t.add("advancements.gilemod.encounter_gloomy_lynx.title", "Pattes meurtrières");
        t.add("advancements.gilemod.encounter_gloomy_lynx.description", "Rencontrez un Lynx lugubre");
        t.add("advancements.gilemod.encounter_hovering_ghost.title", "Quelque chose flotte");
        t.add("advancements.gilemod.encounter_hovering_ghost.description", "Rencontrez un Fantôme flottant");
        t.add("advancements.gilemod.encounter_jerboa.title", "Format de poche");
        t.add("advancements.gilemod.encounter_jerboa.description", "Rencontrez une Gerboise");
        t.add("advancements.gilemod.encounter_weasel_thief.title", "Des doigts agiles");
        t.add("advancements.gilemod.encounter_weasel_thief.description", "Rencontrez une Belette voleuse");
        t.add("advancements.gilemod.encounter_moon_mobs.title", "Pas d'ici");
        t.add("advancements.gilemod.encounter_moon_mobs.description", "Rencontrez une créature lunaire");

        // Get
        t.add("advancements.gilemod.get_any_sigil.title", "Un signe de puissance");
        t.add("advancements.gilemod.get_any_sigil.description", "Obtenez n'importe quel Sceau");
        t.add("advancements.gilemod.get_end_cloud.title", "Marcher dans les airs");
        t.add("advancements.gilemod.get_end_cloud.description", "Obtenez un nuage de l'End");
        t.add("advancements.gilemod.get_enderite.title", "Un métal venu d'ailleurs");
        t.add("advancements.gilemod.get_enderite.description", "Obtenez un lingot d'endérite");
        t.add("advancements.gilemod.get_enderite_armor.title", "Forgé pour l'End");
        t.add("advancements.gilemod.get_enderite_armor.description", "Obtenez ensemble complet d'armure en endérite");
        t.add("advancements.gilemod.get_enderite_tools.title", "Au-delà de la netherite");
        t.add("advancements.gilemod.get_enderite_tools.description", "Fabriquez tous les outils en endérite");
        t.add("advancements.gilemod.get_fate_collection.title", "Écrit dans les étoiles");
        t.add("advancements.gilemod.get_fate_collection.description", "Collectionnez l'épée, l'arc et la flèche du destin");
        t.add("advancements.gilemod.get_ghostly_log.title", "Du bois venu d'ailleurs");
        t.add("advancements.gilemod.get_ghostly_log.description", "Obtenez une bûche spectrale");
        t.add("advancements.gilemod.get_inverted_oak.title", "Le monde à l'envers");
        t.add("advancements.gilemod.get_inverted_oak.description", "Obtenez une bûche de chêne inversée");
        t.add("advancements.gilemod.get_jar_of_glitters.title", "Une poignée de poussière");
        t.add("advancements.gilemod.get_jar_of_glitters.description", "Obtenez un bocal de paillettes");
        t.add("advancements.gilemod.get_moon_fire_collection.title", "Feu au clair de lune");
        t.add("advancements.gilemod.get_moon_fire_collection.description", "Obtenez une torche lunaire, une lanterne lunaire et un feu de camp lunaire");
        t.add("advancements.gilemod.get_moon_sandstone.title", "Poussière d'un autre monde");
        t.add("advancements.gilemod.get_moon_sandstone.description", "Obtenez du grès lunaire");
        t.add("advancements.gilemod.get_primogem.title", "Un petit vœu brillant");
        t.add("advancements.gilemod.get_primogem.description", "Obtenez une Primo-gemme");
        t.add("advancements.gilemod.get_sigils_collection.title", "Collectionneur de sceaux");
        t.add("advancements.gilemod.get_sigils_collection.description", "Collectionnez tous les types de sceaux");
        t.add("advancements.gilemod.get_star_fragment.title", "Un fragment du paradis");
        t.add("advancements.gilemod.get_star_fragment.description", "Obtenez un fragment d'étoile");
        t.add("advancements.gilemod.get_void_slimeball.title", "Quelque chose ne va pas avec ce slime");
        t.add("advancements.gilemod.get_void_slimeball.description", "Obtenez une boule de slime du Vide");
        t.add("advancements.gilemod.get_wish_table.title", "Faites un vœu");
        t.add("advancements.gilemod.get_wish_table.description", "Obtenez une table des vœux");
        t.add("advancements.gilemod.get_legendary_weapon.title", "Une puissance au-delà des mortels");
        t.add("advancements.gilemod.get_legendary_weapon.description", "Obtenez une arme légendaire");
        t.add("advancements.gilemod.get_nuclear_cannon.title", "Le voisinage va apprécier");
        t.add("advancements.gilemod.get_nuclear_cannon.description", "Obtenez un canon nucléaire");
        t.add("advancements.gilemod.get_heart_of_emergency.title", "Brisez la vitre en cas d'urgence");
        t.add("advancements.gilemod.get_heart_of_emergency.description", "Obtenez le Cœur d'urgence");

        // Hit By
        t.add("advancements.gilemod.ender_fly.title", "Regardez en l'air !");
        t.add("advancements.gilemod.ender_fly.description", "Soyez touché par une mouche de l'End");

        // Make
        t.add("advancements.gilemod.make_a_wish.title", "Faites un vœu aux étoiles");
        t.add("advancements.gilemod.make_a_wish.description", "Faites un vœu à la table des vœux");
        t.add("advancements.gilemod.make_jerboa_emerge.title", "Lève-toi, petit être");
        t.add("advancements.gilemod.make_jerboa_emerge.description", "Faites apparaître une gerboise");

        // Name
        t.add("advancements.gilemod.name_nyan.title", "Nyan !");
        t.add("advancements.gilemod.name_nyan.description", "Donnez le nom Nyan Cat à une créature");
        t.add("advancements.gilemod.name_radiance.title", "Radiance");
        t.add("advancements.gilemod.name_radiance.description", "Donnez le nom Radiance à une créature");

        // Ride
        t.add("advancements.gilemod.ride_hovering_ghost.title", "Cavalier fantôme");
        t.add("advancements.gilemod.ride_hovering_ghost.description", "Montez un fantôme flottant");

        // Trade
        t.add("advancements.gilemod.trade_weasel_thief.title", "Une affaire louche");
        t.add("advancements.gilemod.trade_weasel_thief.description", "Faites du commerce avec une belette voleuse");
        t.add("advancements.gilemod.trade_with_wisher.title", "Commerce de vœux");
        t.add("advancements.gilemod.trade_with_wisher.description", "Faites du commerce avec un Faiseur de vœux");

        // Use
        t.add("advancements.gilemod.use_flutterer.title", "Je crois que je peux voler");
        t.add("advancements.gilemod.use_flutterer.description", "Utilisez un Planeur");
        t.add("advancements.gilemod.use_enlarger.title", "Voir grand ou rentrer chez soi");
        t.add("advancements.gilemod.use_enlarger.description", "Utilisez un Agrandisseur");
        t.add("advancements.gilemod.use_grappling_hook.title", "Accroché au monde");
        t.add("advancements.gilemod.use_grappling_hook.description", "Utilisez un Grappin");
        t.add("advancements.gilemod.use_shrinker.title", "Petits problèmes");
        t.add("advancements.gilemod.use_shrinker.description", "Utilisez un Rétrécisseur");
        t.add("advancements.gilemod.use_warp_clock.title", "Une maille du temps");
        t.add("advancements.gilemod.use_warp_clock.description", "Utilisez une Horloge de distorsion");
    }

    public static void tooltips(FabricLanguageProvider.TranslationBuilder t) {
        // Trim Materials
        t.add("trim_material.gilemod.wish_ingot","Lingot de vœu");
        t.add("trim_material.gilemod.enderite_ingot","Lingot d'endérite");

        // Fate Upgrade Smithing Template
        t.add("trim_pattern.gilemod.fate_upgrade", "Modèle de forge");
        t.add("item.minecraft.smithing_template.applies_to", "S'applique à :");
        t.add("smithing_template.gilemod.fate_upgrade.applies_to", "  Équipement en netherite");
        t.add("item.minecraft.smithing_template.ingredients", "Ingrédients :");
        t.add("smithing_template.gilemod.fate_upgrade.ingredients", "  Lingot d'endérite");

        // Warp Clock
        t.add("tooltip.gilemod.warp_clock.unlinked", "Non liée");
        t.add("tooltip.gilemod.warp_clock.coordinates", "Coordonnées de distorsion : ");
        t.add("tooltip.gilemod.warp_clock.linked_warp", "Distorsion liée : ");
        t.add("tooltip.gilemod.warp_clock.consumes", "Consomme : ");

        // Weapons
        t.add("tooltip.gilemod.weapon_level", "Niveau %s");
        t.add("tooltip.gilemod.daybreak_chronicles.when_in_hand","Dans l'une ou l'autre main :");
        t.add("tooltip.gilemod.daybreak_chronicles.arrow_damage"," %s Dégâts de flèche");
        t.add("tooltip.gilemod.daybreak_chronicles.arrow_speed"," %s Vitesse de flèche");
    }

    public static void messages (FabricLanguageProvider.TranslationBuilder t) {
        // Abilities
        t.add("message.gilemod.stomp_cooldown", "Le Piétinement est en récupération !");
        t.add("message.gilemod.shrink_visibility_off", "Votre forme redevient visible.");
        t.add("message.gilemod.shrink_visibility_on", "Votre forme disparaît.");
        t.add("message.gilemod.stomp", "La terre tremble sous vos pas.");

        // Elemental abilities
        t.add("message.gilemod.venti_vortex_activated", "§3Le vortex de Venti est déchaîné !");
        t.add("message.gilemod.venti_vortex_cooldown", "§3Le vortex de Venti sera prêt dans %s §3secondes.");
        t.add("message.gilemod.zhong_li_barricade_activated", "§6La barrière de Zhongli s'élève !");
        t.add("message.gilemod.zhong_li_barricade_cooldown", "§6La barrière de Zhongli sera prête dans %s §6secondes.");
        t.add("message.gilemod.zhong_li_barricade_error", "§6Barrière de Zhongli : pas assez de Géo à la surface.");
        t.add("message.gilemod.raiden_thunder_activated", "§5Le tonnerre de Raiden s'abat !");
        t.add("message.gilemod.raiden_thunder_cooldown", "§5Le tonnerre de Raiden sera prêt dans %s §5secondes.");
        t.add("message.gilemod.raiden_thunder_end", "§5⚡ L'orage s'est calmé...");
        t.add("message.gilemod.nahida_sowing_activated", "§aLes semailles de Nahida prennent racine !");
        t.add("message.gilemod.nahida_sowing_cooldown", "§aLes semailles de Nahida seront prêtes dans %s §asecondes.");
        t.add("message.gilemod.furina_salon_members_activated", "§1Les membres du Salon solitaire de Furina entrent en scène !");
        t.add("message.gilemod.furina_salon_members_cooldown", "§1Les membres du Salon solitaire de Furina seront prêts dans %s §1secondes.");
        t.add("message.gilemod.mavuika_rage_activated", "§cLa rage de Mavuika s'embrase !");
        t.add("message.gilemod.mavuika_rage_cooldown", "§cLa rage de Mavuika sera prête dans %s §csecondes.");
        t.add("message.gilemod.tsaritsas_blizzard_activated", "§bLe blizzard de la Tsarine s'abat !");
        t.add("message.gilemod.tsaritsas_blizzard_cooldown", "§bLe blizzard de la Tsarine sera prêt dans %s §bsecondes.");
        t.add("message.gilemod.lunar_domain_activated", "§7Le domaine lunaire de Columbina se dévoile !");
        t.add("message.gilemod.lunar_domain_cooldown", "§7Le domaine lunaire de Columbina sera prêt dans %s §7secondes.");

        // Legendary abilities
        t.add("message.gilemod.naberius_benediction_activated", "§eLa bénédiction de Naberius vous est accordée !");
        t.add("message.gilemod.naberius_benediction_cooldown", "§eLa bénédiction de Naberius sera prête dans %s §esecondes");
        t.add("message.gilemod.naberius_life_utility_cooldown", "§eLa guérison de Naberius sera prête dans %s §esecondes");
        t.add("message.gilemod.asmoday_event_horizon_activated", "§dL'horizon des événements d'Asmodée s'ouvre !");
        t.add("message.gilemod.asmoday_event_horizon_cooldown", "§dL'horizon des événements d'Asmodée sera prêt dans %s §dsecondes.");
        t.add("message.gilemod.asmoday_space_no_safe_position","§dAucune position sûre trouvée.");
        t.add("message.gilemod.asmoday_space_utility_cooldown", "§dLa téléportation d'Asmodée sera prête dans %s §dsecondes.");
        t.add("message.gilemod.istaroth_time_manipulation_activated", "§9Istaroth plie le temps !");
        t.add("message.gilemod.istaroth_time_manipulation_cooldown", "§9La manipulation du temps d'Istaroth sera prête dans %s §9secondes.");
        t.add("message.gilemod.istaroth_time_utility_cooldown", "§6L'arrêt du temps d'Istaroth sera prêt dans %s §6secondes.");
        t.add("message.gilemod.ronova_lifesteal_activated", "§4Le vol de vie de Ronova réclame son dû !");
        t.add("message.gilemod.ronova_lifesteal_cooldown", "§4Le vol de vie de Ronova sera prêt dans %s §4secondes");
        t.add("message.gilemod.ronova_lifesteal_utility_cooldown", "§4Le toucher de mort de Ronova sera prêt dans %s §4secondes");

        // Primordial abilities
        t.add("message.gilemod.phanes_ability_activated", "La Genèse de Phanes a commencé.");
        t.add("message.gilemod.phanes_ability_cooldown","La Genèse de Phanes est en récupération : %s secondes");
        t.add("message.gilemod.divine_ability_activated","La présence divine de Phanes est descendue.");
        t.add("message.gilemod.divine_ability_cooldown","La présence divine de Phanes est en récupération : %s secondes");
        t.add("message.gilemod.phanes_utility_cooldown", "L'accélération temporelle de Phanes est en récupération : %s secondes");
        t.add("message.gilemod.phanes_utility_activated", "L'accélération temporelle de Phanes a été activée. La règle de jeu random_tick_speed est maintenant réglée sur 100.");
        t.add("message.gilemod.phanes_utility_deactivated", "L'accélération temporelle de Phanes a été désactivée. La règle de jeu random_tick_speed est de nouveau réglée sur 3.");

        // End compass
        t.add("message.gilemod.end_compass.invalid_dimension", "La boussole de l'End ne fonctionne qu'entre le Monde normal et l'End.");
        t.add("message.gilemod.end_compass.destination_missing", "Nulle part où aller...");
        t.add("message.gilemod.end_compass.no_safe_position", "Aucune position sûre trouvée.");
        t.add("message.gilemod.end_compass.main_end_warning", "⚠ AVERTISSEMENT : vous serez téléporté sur l'île principale de l'End. Cliquez à nouveau pour continuer.");

        // Warp clock
        t.add("message.gilemod.warp_clock.linked", "Horloge de distorsion liée !");
        t.add("message.gilemod.warp_clock.unlinked", "Horloge de distorsion déliée.");
        t.add("message.gilemod.warp_clock.click_sign", "Cliquez sur une pancarte pour définir un point de distorsion.");
        t.add("message.gilemod.warp_clock.wrong_dimension", "Cette distorsion se trouve dans une autre dimension.");
        t.add("message.gilemod.warp_clock.no_chrono_gear", "Vous avez besoin d'un Engrenage chrono pour activer cette distorsion !");
        t.add("message.gilemod.warp_clock.missing_sign", "Erreur : la pancarte de distorsion n'existe plus !");

        // Nuclear Cannon
        t.add("message.gilemod.nuclear_cannon_broken", "§cVotre Canon nucléaire n'a plus de munitions ! Rechargez-le avec des pépites de vœu en maintenant Shift et en faisant un clic droit.");
        t.add("message.gilemod.nuclear_cannon_repaired", "§aCanon nucléaire rechargé !");
        t.add("message.gilemod.nuclear_cannon_ammo", "§cVous devez avoir des pépites de vœu dans votre main secondaire pour recharger ceci !");
        t.add("message.gilemod.nuclear_cannon_full","§aVotre Canon nucléaire est déjà complètement rechargé !");
    }

    public static void keybinds(FabricLanguageProvider.TranslationBuilder t) {
        t.add("key.category.gilemod.keys", "Genshin Impact : Extension lunaire");
        t.add("key.gilemod.flutterer_jump", "Saut du Planeur");
        t.add("key.gilemod.active_ability", "Capacité élémentaire/magique");
        t.add("key.gilemod.divine_ability", "Capacité divine");
    }

    public static void sounds(FabricLanguageProvider.TranslationBuilder t) {
        t.add("subtitles.gilemod.entity.luminous.ambient", "Le Lumineux pépie");
        t.add("subtitles.gilemod.entity.luminous.hurt", "Le Lumineux subit des dégâts");
        t.add("subtitles.gilemod.entity.weasel_thief.ambient", "La belette voleuse fait tinter ses grelots");
        t.add("subtitles.gilemod.entity.hovering_ghost.nyan_ambient", "Nyan Cat joue");
        t.add("subtitles.gilemod.entity.ruin_guard.hit", "Le Garde des ruines frappe");
        t.add("subtitles.gilemod.entity.ruin_guard.rotation", "Le Garde des ruines tourne");
    }

    public static void misc(FabricLanguageProvider.TranslationBuilder t) {
        // Item Groups
        t.add("itemgroup.gilemod.gile", "GILE");

        // Villager Professions
        t.add("entity.gilemod.villager.wisher", "Faiseur de vœux");

        // GUIs
        t.add("container.gilemod.wish_table", "Table des vœux");

        // Enchantments
        t.add("enchantment.gilemod.fluttering", "Voltige");
        t.add("enchantment.gilemod.range", "Portée");

        // Item Tags
        t.add("tag.item.gilemod.enchantable.range", "Objets pouvant recevoir l'enchantement Portée");
        t.add("tag.item.gilemod.wish_input", "Objets pour les vœux");
        t.add("tag.item.gilemod.sigil_input", "Objets pour les sceaux");
        t.add("tag.item.gilemod.elemental_weapon", "Armes élémentaires");
        t.add("tag.item.gilemod.legendary_weapon", "Armes légendaires");
        t.add("tag.item.gilemod.primordial_weapon", "Armes primordiales");
        t.add("tag.item.gilemod.enderite_mining_tools", "Outils de minage en endérite");
        t.add("tag.item.gilemod.enderite_tool_materials", "Matériaux d'outils en endérite");
    }

}
