package mh837.gile.client.lang;

import mh837.gile.client.lang.GileModEnglishNamesProvider;
import mh837.gile.client.lang.GileModEnglishTextProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.core.HolderLookup;

import java.util.concurrent.CompletableFuture;

public final class GileModEnglishLangProvider extends FabricLanguageProvider {

    public GileModEnglishLangProvider(
            FabricPackOutput output,
            CompletableFuture<HolderLookup.Provider> lookup
    ) {
        super(output, "en_us", lookup);
    }

    @Override
    public void generateTranslations(
            HolderLookup.Provider lookup,
            TranslationBuilder t
    ) {
        GileModEnglishTextProvider.advancements(t);
        GileModEnglishTextProvider.tooltips(t);
        GileModEnglishTextProvider.messages(t);
        GileModEnglishTextProvider.keybinds(t);
        GileModEnglishTextProvider.sounds(t);
        GileModEnglishTextProvider.misc(t);

        GileModEnglishNamesProvider.items(t);
        GileModEnglishNamesProvider.blocks(t);
        GileModEnglishNamesProvider.entities(t);
        GileModEnglishNamesProvider.effects(t);
    }
}