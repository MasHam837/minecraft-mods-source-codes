package mh837.gile.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import mh837.gile.client.animation.RuinGuardModelAnimation;
import mh837.gile.client.renderer.state.RuinGuardRenderState;
import net.minecraft.client.animation.KeyframeAnimation;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;

public class RuinGuardModel extends EntityModel<RuinGuardRenderState> {

	public static final ModelLayerLocation GUARD_LAYER = new ModelLayerLocation(Identifier
			.fromNamespaceAndPath("gilemod", "ruin_guard"), "main");

	private final KeyframeAnimation walkingAnimation;
	private final KeyframeAnimation meleeAnimation;
	private final KeyframeAnimation rangedAnimation;
	private final KeyframeAnimation rotationAnimation;

	private final ModelPart upper_body;
	private final ModelPart arm_left;
	private final ModelPart elbow_left;
	private final ModelPart arm_right;
	private final ModelPart elbow_right;
	private final ModelPart chest;
	private final ModelPart rockets;
	private final ModelPart valve;
	private final ModelPart airing;
	private final ModelPart lower_body;
	private final ModelPart leg_left;
	private final ModelPart knee_left;
	private final ModelPart leg_right;
	private final ModelPart knee_right;
	private final ModelPart waist;

	public RuinGuardModel(ModelPart root) {
        super(root);
        this.upper_body = root.getChild("upper_body");
		this.arm_left = this.upper_body.getChild("arm_left");
		this.elbow_left = this.arm_left.getChild("elbow_left");
		this.arm_right = this.upper_body.getChild("arm_right");
		this.elbow_right = this.arm_right.getChild("elbow_right");
		this.chest = this.upper_body.getChild("chest");
		this.rockets = this.chest.getChild("rockets");
		this.valve = this.chest.getChild("valve");
		this.airing = this.chest.getChild("airing");

		this.lower_body = root.getChild("lower_body");
		this.leg_left = this.lower_body.getChild("leg_left");
		this.knee_left = this.leg_left.getChild("knee_left");
		this.leg_right = this.lower_body.getChild("leg_right");
		this.knee_right = this.leg_right.getChild("knee_right");
		this.waist = this.lower_body.getChild("waist");

		this.walkingAnimation = RuinGuardModelAnimation.walking.bake(root);
		this.meleeAnimation = RuinGuardModelAnimation.attack_melee.bake(root);
		this.rangedAnimation = RuinGuardModelAnimation.attack_range.bake(root);
		this.rotationAnimation = RuinGuardModelAnimation.attack_rotation.bake(root);
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition upper_body = partdefinition.addOrReplaceChild("upper_body", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0425F, -38.5432F, 2.3324F, 0.0F, 3.1416F, 0.0F));

		PartDefinition arm_left = upper_body.addOrReplaceChild("arm_left", CubeListBuilder.create(), PartPose.offset(-24.9858F, -4.4568F, 5.7775F));

		PartDefinition arm_left_r1 = arm_left.addOrReplaceChild("arm_left_r1", CubeListBuilder.create().texOffs(48, 58).addBox(-4.4231F, 6.7182F, -6.161F, 10.0F, 26.0F, 10.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.1584F, -3.3287F, -1.3858F, 0.2164F, -0.0283F, 0.1278F));

		PartDefinition elbow_left = arm_left.addOrReplaceChild("elbow_left", CubeListBuilder.create(), PartPose.offset(-3.75F, 27.9821F, 2.9821F));

		PartDefinition wrist_left_r1 = elbow_left.addOrReplaceChild("wrist_left_r1", CubeListBuilder.create().texOffs(0, 104).addBox(-6.0F, 23.0167F, -7.7417F, 12.0F, 12.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.48F, 0.0F, 0.0F));

		PartDefinition forearm_left_r1 = elbow_left.addOrReplaceChild("forearm_left_r1", CubeListBuilder.create().texOffs(48, 94).addBox(-5.0F, -0.6481F, -5.758F, 10.0F, 24.0F, 10.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.2679F, 2.2679F, 0.3491F, 0.0F, 0.0F));

		PartDefinition arm_right = upper_body.addOrReplaceChild("arm_right", CubeListBuilder.create(), PartPose.offset(25.0142F, -4.4568F, 5.7775F));

		PartDefinition arm_right_r1 = arm_right.addOrReplaceChild("arm_right_r1", CubeListBuilder.create().texOffs(48, 58).mirror().addBox(-5.6078F, 6.1743F, -7.0777F, 10.0F, 26.0F, 10.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.26F, -3.0046F, -0.375F, 0.2164F, 0.0283F, -0.1278F));

		PartDefinition elbow_right = arm_right.addOrReplaceChild("elbow_right", CubeListBuilder.create(), PartPose.offset(2.0F, 28.0F, 4.0F));

		PartDefinition wrist_right_r1 = elbow_right.addOrReplaceChild("wrist_right_r1", CubeListBuilder.create().texOffs(0, 104).mirror().addBox(-6.0F, 21.8358F, -8.7411F, 12.0F, 12.0F, 12.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(1.75F, 0.505F, 0.438F, 0.5236F, 0.0F, 0.0F));

		PartDefinition forearm_right_r1 = elbow_right.addOrReplaceChild("forearm_right_r1", CubeListBuilder.create().texOffs(48, 94).mirror().addBox(-5.0F, -0.5729F, -4.9102F, 10.0F, 24.0F, 10.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(1.75F, 0.505F, 0.438F, 0.3927F, 0.0F, 0.0F));

		PartDefinition chest = upper_body.addOrReplaceChild("chest", CubeListBuilder.create(), PartPose.offset(0.074F, -3.2409F, 5.942F));

		PartDefinition nape_center_r1 = chest.addOrReplaceChild("nape_center_r1", CubeListBuilder.create().texOffs(192, 9).addBox(-2.0F, -7.0F, -2.0F, 7.0F, 7.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.8098F, 3.2841F, -15.6645F, -0.0928F, 0.0924F, 0.7811F));

		PartDefinition nape_sides_r1 = chest.addOrReplaceChild("nape_sides_r1", CubeListBuilder.create().texOffs(204, 18).addBox(-4.0F, -12.0F, 1.0F, 14.0F, 14.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.0598F, 6.2841F, -17.4145F, -0.1309F, 0.0F, 0.0F));

		PartDefinition rockets_right_r1 = chest.addOrReplaceChild("rockets_right_r1", CubeListBuilder.create().texOffs(236, 108).mirror().addBox(-8.0F, 7.0F, 0.0F, 6.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(17.9402F, -12.7159F, -12.6645F, -0.1309F, 0.0F, 0.0F));

		PartDefinition rockets_left_r1 = chest.addOrReplaceChild("rockets_left_r1", CubeListBuilder.create().texOffs(236, 108).mirror().addBox(-8.0F, 7.0F, 0.0F, 6.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-8.0598F, -12.9659F, -12.6645F, -0.1309F, 0.0F, 0.0F));

		PartDefinition back_top_r1 = chest.addOrReplaceChild("back_top_r1", CubeListBuilder.create().texOffs(108, 0).addBox(-11.0F, -12.0F, -5.0F, 24.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.8098F, 1.7841F, -7.6645F, -0.1309F, 0.0F, 0.0F));

		PartDefinition back_bottom_r1 = chest.addOrReplaceChild("back_bottom_r1", CubeListBuilder.create().texOffs(108, 5).addBox(-14.0F, -5.0F, -5.0F, 24.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.9402F, 17.5341F, -9.9145F, -0.1309F, 0.0F, 0.0F));

		PartDefinition back_center_r1 = chest.addOrReplaceChild("back_center_r1", CubeListBuilder.create().texOffs(108, 10).addBox(-14.0F, -15.0F, -6.0F, 28.0F, 20.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.0598F, 7.7841F, -9.1645F, -0.1309F, 0.0F, 0.0F));

		PartDefinition face_center_r1 = chest.addOrReplaceChild("face_center_r1", CubeListBuilder.create().texOffs(172, 8).addBox(-2.0F, -8.0F, -2.0F, 8.0F, 8.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0598F, 10.0341F, 15.5855F, -0.1309F, 0.0F, 0.0F));

		PartDefinition face_sides_r1 = chest.addOrReplaceChild("face_sides_r1", CubeListBuilder.create().texOffs(172, 18).addBox(-4.0F, -12.0F, 1.0F, 14.0F, 14.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.5598F, 6.7841F, 11.8355F, -0.0928F, 0.0924F, 0.7811F));

		PartDefinition breast_front_right_r1 = chest.addOrReplaceChild("breast_front_right_r1", CubeListBuilder.create().texOffs(108, 34).addBox(-11.0F, -8.0F, -5.0F, 15.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(7.4402F, 9.7841F, 16.5855F, 0.0F, 0.1309F, 1.5708F));

		PartDefinition breast_front_bottom_right_r1 = chest.addOrReplaceChild("breast_front_bottom_right_r1", CubeListBuilder.create().texOffs(142, 34).addBox(-3.0F, -7.0F, -5.0F, 5.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(5.4402F, 12.2841F, 16.0855F, 0.0928F, 0.0924F, 2.3605F));

		PartDefinition breast_front_left_r1 = chest.addOrReplaceChild("breast_front_left_r1", CubeListBuilder.create().texOffs(108, 34).mirror().addBox(-10.0F, -9.0F, -5.0F, 15.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-6.5598F, 3.7841F, 17.5855F, 0.0F, -0.1309F, -1.5708F));

		PartDefinition breast_front_bottom_left_r1 = chest.addOrReplaceChild("breast_front_bottom_left_r1", CubeListBuilder.create().texOffs(142, 34).mirror().addBox(-2.0F, -7.0F, -5.0F, 5.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-5.5598F, 12.2841F, 16.0855F, 0.0928F, -0.0924F, -2.3605F));

		PartDefinition breast_front_bottom_r1 = chest.addOrReplaceChild("breast_front_bottom_r1", CubeListBuilder.create().texOffs(156, 34).addBox(-5.0F, -11.0F, -6.0F, 15.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0598F, 27.0341F, 15.3355F, -0.1309F, 0.0F, 0.0F));

		PartDefinition breast_top_r1 = chest.addOrReplaceChild("breast_top_r1", CubeListBuilder.create().texOffs(108, 0).addBox(-12.0F, -12.0F, -5.0F, 24.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.3098F, 4.7841F, 14.3355F, -0.1309F, 0.0F, 0.0F));

		PartDefinition breast_bottom_r1 = chest.addOrReplaceChild("breast_bottom_r1", CubeListBuilder.create().texOffs(108, 5).addBox(-14.0F, -5.0F, -5.0F, 24.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.9402F, 20.5341F, 12.0855F, -0.1309F, 0.0F, 0.0F));

		PartDefinition breast_center_r1 = chest.addOrReplaceChild("breast_center_r1", CubeListBuilder.create().texOffs(108, 10).addBox(-14.0F, -15.0F, -6.0F, 28.0F, 20.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.0598F, 10.7841F, 13.8355F, -0.1309F, 0.0F, 0.0F));

		PartDefinition chest_r1 = chest.addOrReplaceChild("chest_r1", CubeListBuilder.create().texOffs(0, 0).addBox(-17.0F, -14.0F, -10.0F, 34.0F, 28.0F, 20.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.1902F, 3.5709F, -0.7901F, -0.1309F, 0.0F, 0.0F));

		PartDefinition shoulder_right_inner_r1 = chest.addOrReplaceChild("shoulder_right_inner_r1", CubeListBuilder.create().texOffs(24, 57).mirror().addBox(-0.9057F, -3.5966F, -4.125F, 3.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(17.2002F, -1.2205F, -0.5395F, 0.0F, 0.0F, -0.1309F));

		PartDefinition shoulder_right_r1 = chest.addOrReplaceChild("shoulder_right_r1", CubeListBuilder.create().texOffs(0, 80).mirror().addBox(-0.9057F, -5.5966F, -6.125F, 12.0F, 12.0F, 12.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(20.2002F, -1.2205F, -0.5395F, 0.0F, 0.0F, -0.1309F));

		PartDefinition shoulder_right_top_r1 = chest.addOrReplaceChild("shoulder_right_top_r1", CubeListBuilder.create().texOffs(0, 65).mirror().addBox(2.1254F, -12.5126F, -3.875F, 8.0F, 7.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(18.9502F, -1.2205F, -1.0395F, 0.0F, 0.0F, -0.1309F));

		PartDefinition shoulder_left_inner_r1 = chest.addOrReplaceChild("shoulder_left_inner_r1", CubeListBuilder.create().texOffs(24, 57).addBox(-4.1528F, -3.262F, -3.1142F, 3.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-15.2182F, -1.5446F, -1.5504F, 0.0F, 0.0F, 0.1309F));

		PartDefinition shoulder_left_r1 = chest.addOrReplaceChild("shoulder_left_r1", CubeListBuilder.create().texOffs(0, 80).addBox(-11.1528F, -5.262F, -5.1142F, 12.0F, 12.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-20.2182F, -1.5446F, -1.5504F, 0.0F, 0.0F, 0.1309F));

		PartDefinition shoulder_left_top_down_r1 = chest.addOrReplaceChild("shoulder_left_top_down_r1", CubeListBuilder.create().texOffs(38, 48).mirror().addBox(2.1254F, -7.5126F, -3.875F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-31.2998F, -2.7205F, -0.7895F, 0.0F, 0.0F, 0.1309F));

		PartDefinition shoulder_left_top_inside_r1 = chest.addOrReplaceChild("shoulder_left_top_inside_r1", CubeListBuilder.create().texOffs(8, 48).mirror().addBox(4.1254F, -12.5126F, -1.875F, 4.0F, 3.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-31.2998F, -0.2205F, -0.7895F, 0.0F, 0.0F, 0.1309F));

		PartDefinition shoulder_left_top_up_r1 = chest.addOrReplaceChild("shoulder_left_top_up_r1", CubeListBuilder.create().texOffs(2, 55).mirror().addBox(2.1254F, -12.5126F, -2.875F, 7.0F, 3.0F, 7.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-30.7998F, -2.2205F, -1.2895F, 0.0F, 0.0F, 0.1309F));

		PartDefinition rockets = chest.addOrReplaceChild("rockets", CubeListBuilder.create(), PartPose.offset(-0.0173F, 3.2409F, -0.8322F));

		PartDefinition rocket_right_top_r1 = rockets.addOrReplaceChild("rocket_right_top_r1", CubeListBuilder.create().texOffs(226, 119).mirror().addBox(-2.0F, -4.0F, -1.0F, 4.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false)
				.texOffs(226, 119).addBox(-28.0F, -4.0F, -1.0F, 4.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(12.9574F, -4.4568F, -13.3324F, -0.1309F, 0.0F, 0.0F));

		PartDefinition rocket_right_center_r1 = rockets.addOrReplaceChild("rocket_right_center_r1", CubeListBuilder.create().texOffs(226, 119).mirror().addBox(-2.0F, -4.0F, -1.0F, 4.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false)
				.texOffs(226, 119).addBox(-28.0F, -4.0F, -1.0F, 4.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(12.9574F, 0.5432F, -14.0824F, -0.1309F, 0.0F, 0.0F));

		PartDefinition rocket_right_bottom_r1 = rockets.addOrReplaceChild("rocket_right_bottom_r1", CubeListBuilder.create().texOffs(226, 119).mirror().addBox(-2.0F, -4.0F, -1.0F, 4.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false)
				.texOffs(226, 119).addBox(-28.0F, -4.0F, -1.0F, 4.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(12.9574F, 5.5432F, -14.5824F, -0.1309F, 0.0F, 0.0F));

		PartDefinition valve = chest.addOrReplaceChild("valve", CubeListBuilder.create(), PartPose.offset(-1.0F, -10.0F, 0.0F));

		PartDefinition valve_front_r1 = valve.addOrReplaceChild("valve_front_r1", CubeListBuilder.create().texOffs(190, 34).addBox(4.0F, -0.5F, -3.0F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F))
				.texOffs(190, 34).addBox(-5.0F, -0.5F, -3.0F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.0F, -0.5F, 3.0F, -1.5708F, -1.4399F, 1.5708F));

		PartDefinition valve_left_r1 = valve.addOrReplaceChild("valve_left_r1", CubeListBuilder.create().texOffs(190, 34).addBox(-5.0F, -0.5F, -3.0F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F))
				.texOffs(190, 34).addBox(4.0F, -0.5F, -3.0F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.0F, -0.5F, 3.0F, -0.1309F, 0.0F, 0.0F));

		PartDefinition valve_center_r1 = valve.addOrReplaceChild("valve_center_r1", CubeListBuilder.create().texOffs(197, 34).addBox(-4.0F, -16.6242F, -4.1055F, 8.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.0F, 15.5F, 1.0F, -0.1309F, 0.0F, 0.0F));

		PartDefinition airing = chest.addOrReplaceChild("airing", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition airing_right_back_r1 = airing.addOrReplaceChild("airing_right_back_r1", CubeListBuilder.create().texOffs(236, 78).addBox(6.0F, -3.0F, -4.0F, 2.0F, 6.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(11.9402F, -14.7159F, -14.6645F, -1.5708F, -1.4399F, 1.5708F));

		PartDefinition airing_right_inner_r1 = airing.addOrReplaceChild("airing_right_inner_r1", CubeListBuilder.create().texOffs(216, 78).addBox(6.0F, -3.0F, -4.0F, 2.0F, 6.0F, 8.0F, new CubeDeformation(0.0F))
				.texOffs(224, 92).addBox(8.0F, -5.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F))
				.texOffs(216, 78).mirror().addBox(-8.0F, -3.0F, -4.0F, 2.0F, 6.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false)
				.texOffs(224, 92).mirror().addBox(-16.0F, -5.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-0.0598F, -13.2159F, -2.6645F, -0.1309F, 0.0F, 0.0F));

		PartDefinition airing_left_back_r1 = airing.addOrReplaceChild("airing_left_back_r1", CubeListBuilder.create().texOffs(236, 78).mirror().addBox(-8.0F, -3.0F, -4.0F, 2.0F, 6.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-12.0598F, -14.7159F, -14.6645F, -1.5708F, 1.4399F, -1.5708F));

		PartDefinition lower_body = partdefinition.addOrReplaceChild("lower_body", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -15.0244F, -0.3179F, 0.0F, 3.1416F, 0.0F));

		PartDefinition leg_left = lower_body.addOrReplaceChild("leg_left", CubeListBuilder.create(), PartPose.offset(-7.0F, 9.0244F, 0.3179F));

		PartDefinition knee_left_top_r1 = leg_left.addOrReplaceChild("knee_left_top_r1", CubeListBuilder.create().texOffs(118, 67).addBox(-3.3777F, -3.6857F, -4.5F, 6.0F, 4.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0F, 11.0F, 0.0F, 0.0F, 0.0F, 0.1745F));

		PartDefinition hip_left_r1 = leg_left.addOrReplaceChild("hip_left_r1", CubeListBuilder.create().texOffs(88, 67).addBox(-4.0F, -7.0F, -6.0F, 10.0F, 10.0F, 10.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.5F, 4.25F, -0.5F, 0.0F, 0.0F, 0.2182F));

		PartDefinition knee_left = leg_left.addOrReplaceChild("knee_left", CubeListBuilder.create().texOffs(88, 87).mirror().addBox(-5.25F, 4.0F, -6.25F, 10.0F, 10.0F, 10.0F, new CubeDeformation(0.0F)).mirror(false)
				.texOffs(88, 107).addBox(-6.0F, 14.0F, -8.0F, 12.0F, 5.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(-2.0F, 11.0F, 0.0F));

		PartDefinition knee_left_bottom_r1 = knee_left.addOrReplaceChild("knee_left_bottom_r1", CubeListBuilder.create().texOffs(118, 87).addBox(-3.0567F, -0.1475F, -3.0F, 6.0F, 4.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.2F, 0.15F, -1.5F, 0.0F, 0.0F, 0.0436F));

		PartDefinition leg_right = lower_body.addOrReplaceChild("leg_right", CubeListBuilder.create(), PartPose.offset(7.0F, 9.0244F, 0.3179F));

		PartDefinition knee_right_top_r1 = leg_right.addOrReplaceChild("knee_right_top_r1", CubeListBuilder.create().texOffs(118, 67).mirror().addBox(-2.6223F, -3.6857F, -4.5F, 6.0F, 4.0F, 6.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0F, 11.0F, 0.0F, 0.0F, 0.0F, -0.1745F));

		PartDefinition hip_right_r1 = leg_right.addOrReplaceChild("hip_right_r1", CubeListBuilder.create().texOffs(88, 67).mirror().addBox(-6.0F, -7.0F, -6.0F, 10.0F, 10.0F, 10.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.5F, 4.25F, -0.5F, 0.0F, 0.0F, -0.2182F));

		PartDefinition knee_right = leg_right.addOrReplaceChild("knee_right", CubeListBuilder.create().texOffs(88, 87).addBox(-4.75F, 4.0F, -6.25F, 10.0F, 10.0F, 10.0F, new CubeDeformation(0.0F))
				.texOffs(88, 107).mirror().addBox(-6.0F, 14.0F, -8.0F, 12.0F, 5.0F, 16.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(2.0F, 11.0F, 0.0F));

		PartDefinition knee_right_bottom_r1 = knee_right.addOrReplaceChild("knee_right_bottom_r1", CubeListBuilder.create().texOffs(118, 87).mirror().addBox(-2.9433F, -0.1475F, -3.0F, 6.0F, 4.0F, 6.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.2F, 0.15F, -1.5F, 0.0F, 0.0F, -0.0436F));

		PartDefinition waist = lower_body.addOrReplaceChild("waist", CubeListBuilder.create().texOffs(144, 43).addBox(-10.0F, 5.5244F, -6.6821F, 20.0F, 4.0F, 12.0F, new CubeDeformation(0.0F))
				.texOffs(144, 59).addBox(-13.0F, 2.0244F, -7.4321F, 26.0F, 4.0F, 13.0F, new CubeDeformation(0.0F))
				.texOffs(144, 76).addBox(-12.0F, -1.9756F, -5.6821F, 24.0F, 4.0F, 11.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition stomach_r1 = waist.addOrReplaceChild("stomach_r1", CubeListBuilder.create().texOffs(144, 108).addBox(-15.0F, -4.0F, -5.0F, 30.0F, 4.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -5.9756F, -2.4321F, -0.0873F, 0.0F, 0.0F));

		PartDefinition waist_top_r1 = waist.addOrReplaceChild("waist_top_r1", CubeListBuilder.create().texOffs(144, 91).addBox(-14.0F, -2.0F, -4.0F, 26.0F, 4.0F, 13.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.0F, -3.9756F, -2.1821F, -0.0436F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 256, 128);
	}

	@Override
	public void setupAnim(RuinGuardRenderState state) {
		super.setupAnim(state);
		root().getAllParts().forEach(ModelPart::resetPose);

		boolean attacking =
				state.attackMeleeAnimationState.isStarted()
						|| state.attackRangeAnimationState.isStarted()
						|| state.attackRotationAnimationState.isStarted();

		if (!attacking)
			walkingAnimation.apply(state.walkAnimationState, state.ageInTicks);

		meleeAnimation.apply(state.attackMeleeAnimationState, state.ageInTicks);
		rangedAnimation.apply(state.attackRangeAnimationState, state.ageInTicks);
		rotationAnimation.apply(state.attackRotationAnimationState, state.ageInTicks);
	}

}