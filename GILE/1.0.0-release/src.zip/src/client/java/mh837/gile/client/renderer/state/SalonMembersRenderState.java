package mh837.gile.client.renderer.state;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class SalonMembersRenderState extends LivingEntityRenderState {

    public int memberIndex = 0;
    public float scale = 1.0F;
    public String modelType = "usher";
}