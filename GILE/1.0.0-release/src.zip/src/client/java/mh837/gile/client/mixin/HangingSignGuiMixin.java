package mh837.gile.client.mixin;

import mh837.gile.block.entity.signs.GhostlyHangingSignBlockEntity;
import mh837.gile.block.entity.signs.InvertedOakHangingSignBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.HangingSignEditScreen;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.PacketUtils;
import net.minecraft.network.protocol.game.ClientboundOpenSignEditorPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public class HangingSignGuiMixin {

	@Inject(method = "handleOpenSignEditor", at = @At("HEAD"), cancellable = true)
	private void onOpenSignEditor(ClientboundOpenSignEditorPacket packet, CallbackInfo ci) {
		Minecraft minecraft = Minecraft.getInstance();

		PacketUtils.ensureRunningOnSameThread(packet, (ClientPacketListener) (Object) this, minecraft.packetProcessor());
		if (minecraft.level == null) return;

		BlockEntity blockEntity = minecraft.level.getBlockEntity(packet.getPos());

		if (blockEntity instanceof GhostlyHangingSignBlockEntity customHangingSign) {minecraft.setScreen(new HangingSignEditScreen(
				customHangingSign, packet.isFrontText(), minecraft.isTextFilteringEnabled()));ci.cancel();}

		if (blockEntity instanceof InvertedOakHangingSignBlockEntity customHangingSign) {minecraft.setScreen(new HangingSignEditScreen(
				customHangingSign, packet.isFrontText(), minecraft.isTextFilteringEnabled()));ci.cancel();}

	}
}