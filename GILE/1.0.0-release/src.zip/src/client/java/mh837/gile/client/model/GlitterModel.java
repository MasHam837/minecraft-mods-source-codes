package mh837.gile.client.model;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.util.Mth;

public class GlitterModel extends EntityModel<LivingEntityRenderState> {

    private final ModelPart leftWing;
    private final ModelPart rightWing;

    public GlitterModel(ModelPart root) {
        super(root, RenderTypes::entityTranslucent);

        this.leftWing = root.getChild("left_wing");
        this.rightWing = root.getChild("right_wing");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        var root = mesh.getRoot();

        root.addOrReplaceChild("left_wing",
                CubeListBuilder.create().texOffs(0, 4)
                        .addBox(0.0F, -0.05F, -1.5F, 2.0F, 0.1F, 3.0F),
                PartPose.offset(0.0F, 22.0F, 0.0F));

        root.addOrReplaceChild("right_wing",
                CubeListBuilder.create().texOffs(0, 4).mirror()
                        .addBox(-2.0F, -0.05F, -1.5F, 2.0F, 0.1F, 3.0F),
                PartPose.offset(0.0F, 22.0F, 0.0F));

        return LayerDefinition.create(mesh, 16, 16);}

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        super.setupAnim(state);

        float flap = Mth.cos(state.ageInTicks * 0.75F) * 1.1F;

        this.leftWing.zRot = flap; this.rightWing.zRot = -flap;

    }
}