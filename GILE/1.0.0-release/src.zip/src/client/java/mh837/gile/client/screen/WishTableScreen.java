package mh837.gile.client.screen;

import mh837.gile.block.entity.WishRarity;
import mh837.gile.block.entity.WishTableScreenHandler;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;

public class WishTableScreen extends AbstractContainerScreen<WishTableScreenHandler> {

    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath("gilemod", "textures/gui/wish_table.png");
    private static final Identifier STAR_TEXTURE = Identifier.fromNamespaceAndPath("gilemod", "textures/gui/wish_star.png");
    private static final Identifier ARROW_TEXTURE = Identifier.fromNamespaceAndPath("gilemod", "textures/gui/wish_arrow.png");
    private static final Identifier PROGRESS_TEXTURE = Identifier.fromNamespaceAndPath("gilemod", "textures/gui/wish_progress.png");

    // GUI size
    private static final int GUI_WIDTH = 176; private static final int GUI_HEIGHT = 166;

    // ARROW
    private static final int ARROW_X = 77; private static final int ARROW_Y = 46;
    private static final int ARROW_WIDTH = 22; private static final int ARROW_HEIGHT = 15;

    // STAR
    private static final int STAR_X = 14; private static final int STAR_Y = 18;
    private static final int STAR_WIDTH = 15; private static final int STAR_HEIGHT = 15;

    // PERMANENT PROGRESS BAR
    private static final int PROGRESS_X = 36; private static final int PROGRESS_Y = 23;
    private static final int PROGRESS_WIDTH = 126; private static final int PROGRESS_HEIGHT = 6;

    public WishTableScreen(WishTableScreenHandler handler, Inventory inventory, Component title) {super(handler, inventory, title, GUI_WIDTH, GUI_HEIGHT);}

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // Background
        graphics.blit(RenderPipelines.GUI_TEXTURED, TEXTURE, this.leftPos, this.topPos, 0.0F, 0.0F,
                GUI_WIDTH, GUI_HEIGHT, GUI_WIDTH, GUI_HEIGHT, 256, 256);
        extractPermanentProgress(graphics); extractWishAnimation(graphics); super.extractRenderState(graphics, mouseX, mouseY, partialTick);}

    private void extractPermanentProgress(GuiGraphicsExtractor graphics) { int permanentProgress = this.menu.getPermanentProgress();
        float progressPercent = Math.clamp(permanentProgress / 100.0F, 0.0F, 1.0F);
        int filledWidth = Math.round(PROGRESS_WIDTH * progressPercent); if (filledWidth <= 0) {return;}
        graphics.blit(RenderPipelines.GUI_TEXTURED, PROGRESS_TEXTURE, this.leftPos + PROGRESS_X, this.topPos + PROGRESS_Y, 0.0F, 0.0F,
                filledWidth, PROGRESS_HEIGHT, filledWidth, PROGRESS_HEIGHT, PROGRESS_WIDTH, PROGRESS_HEIGHT);}

    private void extractWishAnimation(GuiGraphicsExtractor graphics) {if (!this.menu.isProcessing()) {return;}
        int wishProgress = this.menu.getWishProgress();int wishDuration = this.menu.getWishDuration(); if (wishDuration <= 0) {return;}
        float progressPercent = Math.clamp((float) wishProgress / (float) wishDuration, 0.0F, 1.0F);int filledWidth = Math.round(ARROW_WIDTH * progressPercent);
        if (filledWidth > 0) {graphics.blit(RenderPipelines.GUI_TEXTURED, ARROW_TEXTURE, this.leftPos + ARROW_X, this.topPos + ARROW_Y, 0.0F, 0.0F,
                filledWidth, ARROW_HEIGHT, filledWidth, ARROW_HEIGHT, ARROW_WIDTH, ARROW_HEIGHT);} WishRarity rarity = this.menu.getCurrentRarity();
        if (rarity == WishRarity.NONE) {return;}
        int rgb = switch (rarity) {case COMMON -> 0x55AAFF;case RARE -> 0xAA55FF;case LEGENDARY -> 0xFFD700;default -> 0xFFFFFF;};
        int alpha = Math.clamp(Math.round(255.0F * progressPercent), 0, 255); int color = (alpha << 24) | rgb;
        graphics.blit(RenderPipelines.GUI_TEXTURED, STAR_TEXTURE, this.leftPos + STAR_X, this.topPos + STAR_Y, 0.0F, 0.0F,
                STAR_WIDTH, STAR_HEIGHT, STAR_WIDTH, STAR_HEIGHT, STAR_WIDTH, STAR_HEIGHT, color);}

}