package mh837.gile.client.renderer.entity;

import mh837.gile.GileMod;
import mh837.gile.client.model.EnderFlyModel;
import mh837.gile.client.model.layer.EnderFlyModelLayer;
import mh837.gile.client.renderer.state.EnderFlyRenderState;
import mh837.gile.entity.EnderFlyEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class EnderFlyRenderer
        extends MobRenderer<
        EnderFlyEntity,
        EnderFlyRenderState,
        EnderFlyModel
        > {

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/ender_fly.png"
            );

    public EnderFlyRenderer(
            EntityRendererProvider.Context context
    ) {
        super(
                context,
                new EnderFlyModel(
                        context.bakeLayer(
                                EnderFlyModelLayer.ENDER_FLY_LAYER
                        )
                ),
                0.25F
        );
    }

    @Override
    public EnderFlyRenderState createRenderState() {return new EnderFlyRenderState();}

    @Override
    public Identifier getTextureLocation(EnderFlyRenderState state) {return TEXTURE;}

}