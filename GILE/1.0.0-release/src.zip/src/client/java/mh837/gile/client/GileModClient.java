package mh837.gile.client;

import mh837.gile.*;
import mh837.gile.client.model.*;
import mh837.gile.client.model.layer.EnderFlyModelLayer;
import mh837.gile.client.model.layer.GlitterModelLayer;
import mh837.gile.client.particle.GlitterParticle;
import mh837.gile.client.renderer.NuclearCannonRenderer;
import mh837.gile.client.renderer.blockentity.*;
import mh837.gile.client.renderer.entity.projectile.RocketRenderer;
import mh837.gile.client.screen.WishTableScreen;
import mh837.gile.client.renderer.entity.*;
import mh837.gile.client.renderer.entity.projectile.EnderFlyStingRenderer;
import mh837.gile.client.renderer.entity.projectile.FateArrowRenderer;
import mh837.gile.client.renderer.entity.projectile.VentiArrowRenderer;

import mh837.gile.item.tool.FluttererUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.particle.v1.ParticleProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockColorRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;

import net.minecraft.client.color.block.BlockTintSource;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.particle.*;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.client.renderer.blockentity.HangingSignRenderer;
import net.minecraft.client.renderer.blockentity.StandingSignRenderer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.world.level.FoliageColor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

public class GileModClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {

		GileModKeybinds.initialize();
		NuclearCannonRenderer.initialize();

		// Block entities
		BlockEntityRenderers.register(GileModBlockEntities.GHOSTLY_SIGN_ENTITY, StandingSignRenderer::new);
		BlockEntityRenderers.register(GileModBlockEntities.GHOSTLY_HANGING_SIGN_ENTITY, HangingSignRenderer::new);
		BlockEntityRenderers.register(GileModBlockEntities.GHOSTLY_SHELF_ENTITY, GhostlyShelfRenderer::new);
		BlockEntityRenderers.register(GileModBlockEntities.INVERTED_OAK_SIGN_ENTITY, StandingSignRenderer::new);
		BlockEntityRenderers.register(GileModBlockEntities.INVERTED_OAK_HANGING_SIGN_ENTITY, HangingSignRenderer::new);
		BlockEntityRenderers.register(GileModBlockEntities.INVERTED_OAK_SHELF_ENTITY, InvertedOakShelfRenderer::new);
		BlockEntityRenderers.register(GileModBlockEntities.MOON_CAMPFIRE_ENTITY, MoonCampfireRenderer::new);
		BlockEntityRenderers.register(GileModBlockEntities.GLITTER_JAR_ENTITY, GlitterJarRenderer::new);
		MenuScreens.register(GileModBlockEntities.WISH_TABLE_SCREEN_HANDLER, WishTableScreen::new);
		BlockEntityRenderers.register(GileModBlockEntities.WISH_TABLE_BLOCK_ENTITY, WishTableRenderer::new);

		// Projectiles
		EntityRendererRegistry.register(GileModEntities.FATE_ARROW_TYPE, FateArrowRenderer::new);
		EntityRendererRegistry.register(GileModEntities.VENTI_ARROW_TYPE, VentiArrowRenderer::new);
		EntityRendererRegistry.register(GileModEntities.ENDER_FLY_STING, EnderFlyStingRenderer::new);
		EntityRendererRegistry.register(GileModEntities.ROCKET_ENTITY, RocketRenderer::new);

		// Entities
		EntityRendererRegistry.register(GileModEntities.VOID_SLIME, VoidSlimeRenderer::new);
		EntityRendererRegistry.register(GileModEntities.MOTH, MothRenderer::new);
		EntityRendererRegistry.register(GileModEntities.LUMINOUS, LuminousRenderer::new);
		EntityRendererRegistry.register(GileModEntities.HOVERING_GHOST, HoveringGhostRenderer::new);
		EntityRendererRegistry.register(GileModEntities.JERBOA, JerboaRenderer::new);
		EntityRendererRegistry.register(GileModEntities.GLOOMY_LYNX, GloomyLynxRenderer::new);
		EntityRendererRegistry.register(GileModEntities.WEASEL_THIEF, WeaselThiefRenderer::new);
		EntityRendererRegistry.register(GileModEntities.GLITTER, GlitterRenderer::new);
		EntityRendererRegistry.register(GileModEntities.SALON_MEMBER, SalonMemberRenderer::new);
		EntityRendererRegistry.register(GileModEntities.ENDER_FLY, EnderFlyRenderer::new);
		EntityRendererRegistry.register(GileModEntities.RUIN_GUARD, RuinGuardRenderer::new);

		// Model layers
		ModelLayerRegistry.registerModelLayer(MothRenderer.MOTH_LAYER, MothRenderer.MothModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(MothRenderer.MOTH_BABY_LAYER, MothRenderer.MothBabyModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(MothRenderer.MOTH_RADIANCE_LAYER, MothRenderer.MothModel::getRadianceTexturedModelData);
		ModelLayerRegistry.registerModelLayer(MothRenderer.MOTH_RADIANCE_BABY_LAYER, MothRenderer.MothBabyModel::getRadianceTexturedModelData);
		ModelLayerRegistry.registerModelLayer(LuminousRenderer.LUMINOUS_LAYER, LuminousRenderer.LuminousModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(LuminousRenderer.LUMINOUS_BABY_LAYER, LuminousRenderer.LuminousBabyModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(HoveringGhostRenderer.GHOST_LAYER, HoveringGhostRenderer.HoveringGhostModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(HoveringGhostRenderer.GHOST_BABY_LAYER, HoveringGhostRenderer.HoveringGhostBabyModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(JerboaRenderer.JERBOA_LAYER, JerboaRenderer.JerboaModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(JerboaRenderer.JERBOA_BABY_LAYER, JerboaRenderer.JerboaBabyModel::getTexturedModelData);
		ModelLayerRegistry.registerModelLayer(GloomyLynxRenderer.LYNX_LAYER, GloomyLynxRenderer.LynxModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(GloomyLynxRenderer.LYNX_BABY_LAYER, GloomyLynxRenderer.LynxBabyModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(WeaselThiefModel.WEASEL_LAYER, WeaselThiefModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(GlitterModelLayer.GLITTER_LAYER, GlitterModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(EnderFlyModelLayer.ENDER_FLY_LAYER, EnderFlyModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(RuinGuardModel.GUARD_LAYER, RuinGuardModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(UsherModel.LAYER, UsherModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(ChevalmarinModel.LAYER, ChevalmarinModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(CrabalettaModel.LAYER, CrabalettaModel::createBodyLayer);

		// Particles - misc
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.GHOSTLY_BUBBLE, WhiteAshParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.GLITTER, GlitterParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.END_FLAME, FlameParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.FEATHER, FallingLeavesParticle.PaleOakProvider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.ROPE, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.GUARD_SWEEP, AttackSweepParticle.Provider::new);
		// Particles - elemental
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.ANEMO, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.GEO, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.ELECTRO, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.DENDRO, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.HYDRO, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.PYRO, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.CRYO, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.LUNA, EndRodParticle.Provider::new);
		// Particles - legendary
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.LIFE, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.SPACE, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.TIME, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.DEATH, EndRodParticle.Provider::new);
		ParticleProviderRegistry.getInstance().register(GileModParticleTypes.PHANES, EndRodParticle.Provider::new);

		// Rainbow Glitter Carpet
		BlockColorRegistry.register(List.of(new BlockTintSource() {
					@Override public int colorInWorld(BlockState state, BlockAndTintGetter level, BlockPos pos) {return ARGB.opaque(0xFFFFFF);}
					@Override public int color(BlockState state) {
						return ARGB.opaque(0xFFFFFF);
					}}), GileModBlocks.GLITTER_CARPET);

		// Client-side biome & flutterer particle spawning
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null || client.level == null || client.isPaused()) {return;}
			Holder<Biome> biomeHolder = client.level.getBiome(client.player.blockPosition());
			boolean isGhostlyThickets = biomeHolder.unwrapKey().map(key -> key.identifier().equals(
					Identifier.fromNamespaceAndPath("gilemod", "ghostly_thickets"))).orElse(false);
			if (isGhostlyThickets) { if (client.level.getRandom().nextFloat() < 0.15F) { double radius = 19.0D;
					double x = client.player.getX() + (client.level.getRandom().nextDouble() - 0.5D) * radius;
					double y = client.player.getY() + client.level.getRandom().nextDouble() * 5.0D - 1.0D;
					double z = client.player.getZ() + (client.level.getRandom().nextDouble() - 0.5D) * radius;
					client.level.addParticle(GileModParticleTypes.GHOSTLY_BUBBLE, x, y, z, 0.0D, -0.01D, 0.0D);}
			}
			if (FluttererUtil.isActive(client.player) && FluttererUtil.isFalling(client.player)) {
				if (client.level.getRandom().nextFloat() < 0.125F) {
					double x = client.player.getX() + (client.level.getRandom().nextDouble() - 0.5D) * 0.8D;
					double y = client.player.getY() + 0.8D;
					double z = client.player.getZ() + (client.level.getRandom().nextDouble() - 0.5D) * 0.8D;
					client.level.addParticle(GileModParticleTypes.FEATHER, x, y, z, 0.0D, -0.03D, 0.0D);
				}
			}
		});
	}
}
