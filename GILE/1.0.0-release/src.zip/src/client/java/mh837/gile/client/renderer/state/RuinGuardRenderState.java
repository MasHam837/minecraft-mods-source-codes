package mh837.gile.client.renderer.state;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.AnimationState;

public class RuinGuardRenderState extends LivingEntityRenderState {
    public final AnimationState walkAnimationState = new AnimationState();
    public final AnimationState attackMeleeAnimationState = new AnimationState();
    public final AnimationState attackRangeAnimationState = new AnimationState();
    public final AnimationState attackRotationAnimationState = new AnimationState();
}