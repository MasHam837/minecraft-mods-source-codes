package mh837.gile.client.renderer.entity;

import mh837.gile.client.model.WeaselThiefModel;
import mh837.gile.client.renderer.state.WeaselThiefRenderState;
import mh837.gile.entity.WeaselThiefEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class WeaselThiefRenderer extends MobRenderer<
        WeaselThiefEntity,
        WeaselThiefRenderState,
        WeaselThiefModel> {

    public WeaselThiefRenderer(EntityRendererProvider.Context context) {
        super(
                context,
                new WeaselThiefModel(
                        context.getModelSet()
                                .bakeLayer(WeaselThiefModel.WEASEL_LAYER)
                ),
                0.4F
        );
    }

    @Override
    public WeaselThiefRenderState createRenderState() {
        return new WeaselThiefRenderState();
    }

    @Override
    public void extractRenderState(
            WeaselThiefEntity entity,
            WeaselThiefRenderState state,
            float partialTick
    ) {
        super.extractRenderState(entity, state, partialTick);

        state.variant = entity.getVariant().getSerializedName();
    }

    @Override
    public Identifier getTextureLocation(WeaselThiefRenderState state) {
        return Identifier.fromNamespaceAndPath(
                "gilemod",
                "textures/entity/weasel/" + state.variant + ".png"
        );
    }
}