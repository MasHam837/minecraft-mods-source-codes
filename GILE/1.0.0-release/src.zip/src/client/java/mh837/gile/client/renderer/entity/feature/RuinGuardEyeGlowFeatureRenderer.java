package mh837.gile.client.renderer.entity.feature;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.GileMod;
import mh837.gile.client.model.RuinGuardModel;
import mh837.gile.client.renderer.state.RuinGuardRenderState;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

public class RuinGuardEyeGlowFeatureRenderer
        extends RenderLayer<RuinGuardRenderState, RuinGuardModel> {

    private static final Identifier GLOW_TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/ruin_guard/ruin_guard_glow.png"
            );

    public RuinGuardEyeGlowFeatureRenderer(
            RenderLayerParent<RuinGuardRenderState, RuinGuardModel> parent
    ) {
        super(parent);
    }

    @Override
    public void submit(
            PoseStack poseStack,
            SubmitNodeCollector collector,
            int packedLight,
            RuinGuardRenderState state,
            float limbSwing,
            float limbSwingAmount
    ) {
        collector.submitModel(
                this.getParentModel(),
                state,
                poseStack,
                RenderTypes.eyes(GLOW_TEXTURE),
                15728640,
                OverlayTexture.NO_OVERLAY,
                0xFFFFFFFF,
                null
        );
    }
}