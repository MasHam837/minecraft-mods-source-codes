package mh837.gile.client.mixin;

import mh837.gile.GileModItems;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {

    // In 1.21.2, this method takes (boolean firstPerson, float partialTick)
    @Inject(method = "getFieldOfViewModifier", at = @At("RETURN"), cancellable = true)
    private void gilemod$applyCustomBowFov(boolean firstPerson, float partialTick, CallbackInfoReturnable<Float> cir) {
        AbstractClientPlayer player = (AbstractClientPlayer) (Object) this;
        ItemStack itemStack = player.getUseItem();

        // If the player is using OUR custom bow
        if (player.isUsingItem() && itemStack.is(GileModItems.FATE_BOW)  || itemStack.is(GileModItems.DAYBREAK_CHRONICLES)) {
            int useTicks = player.getTicksUsingItem();
            float pullProgress = (float) useTicks / 20.0f;

            // Replicate Vanilla's exact math curve for the FOV pull
            if (pullProgress > 1.0f) {
                pullProgress = 1.0f;
            } else {
                pullProgress *= pullProgress; // Square it for a smooth zoom curve
            }

            // Apply our modifier on top of whatever the current FOV is (respects slowness/speed effects)
            float fovModifier = cir.getReturnValue() * (1.0f - pullProgress * 0.15f);
            cir.setReturnValue(fovModifier);
        }
    }
}