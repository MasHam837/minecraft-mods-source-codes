package mh837.gile.client.lang;

import mh837.gile.*;
import mh837.gile.entity.WeaselVariant;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public final class GileModRussianNamesProvider {

    private GileModRussianNamesProvider() {}

    public static void items(FabricLanguageProvider.TranslationBuilder t) {
        // Currencies
        t.add(GileModItems.MORA, "Мора");
        t.add(GileModItems.ANEMO_SIGIL, "Печать Анемо");
        t.add(GileModItems.GEO_SIGIL, "Печать Гео");
        t.add(GileModItems.ELECTRO_SIGIL, "Печать Электро");
        t.add(GileModItems.DENDRO_SIGIL, "Печать Дендро");
        t.add(GileModItems.HYDRO_SIGIL, "Печать Гидро");
        t.add(GileModItems.PYRO_SIGIL, "Печать Пиро");
        t.add(GileModItems.CRYO_SIGIL, "Печать Крио");
        t.add(GileModItems.LUNA_SIGIL, "Печать Луны");
        t.add(GileModItems.SIGILS_ANIMATION, "Анимация печатей");

        // Ores
        t.add(GileModItems.PRIMOGEM, "Камень Истока");
        t.add(GileModItems.PEARLESCENT_MATERIAL, "Перламутровый материал");
        t.add(GileModItems.WISH_INGOT, "Слиток желания");
        t.add(GileModItems.WISH_NUGGET, "Самородок желания");
        t.add(GileModItems.ENDERITE_INGOT, "Слиток эндерита");
        t.add(GileModItems.ENDERITE_SHARD, "Осколок эндерита");
        t.add(GileModItems.CRYSTAL, "Кристалл");

        // Weapons
        t.add(GileModItems.DAYBREAK_CHRONICLES, "§bХроники рассвета");
        t.add(GileModItems.VORTEX_VANQUISHER, "§bПокоритель вихря");
        t.add(GileModItems.ENGULFING_LIGHTNING, "§bСияющая жатва");
        t.add(GileModItems.THOUSAND_FLOATING_DREAMS, "§bСновидения тысячи ночей");
        t.add(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS, "§bБлеск тихих вод");
        t.add(GileModItems.THOUSAND_BLAZING_SUNS, "§bТысяча пылающих солнц");
        t.add(GileModItems.HIEMAL_MANDATE, "§bЗимний приказ");
        t.add(GileModItems.NOCTURNES_CURTAIN_CALL, "§bФинальный занавес ноктюрна");
        t.add(GileModItems.TOME_OF_NABERIUS, "§dФолиант Набериуса");
        t.add(GileModItems.PALM_OF_ASMODAY, "§dДлань Асмодей");
        t.add(GileModItems.HOURGLASS_OF_ISTAROTH, "§dЧасы Астарот");
        t.add(GileModItems.SCYTHE_OF_RONOVA, "§dКоса Роновы");
        t.add(GileModItems.PHANES_BLADE, "§eКлинок Фанета");

        // Fate Collection
        t.add(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE, "§dУлучшение судьбы");
        t.add(GileModItems.FATE_ARROW, "§bСтрела судьбы");
        t.add(GileModItems.FATE_BOW, "§bЛук судьбы");
        t.add(GileModItems.FATE_SWORD, "§bМеч судьбы");

        // Tools
        t.add(GileModItems.ENDERITE_SPEAR, "Эндеритовое копьё");
        t.add(GileModItems.ENDERITE_SWORD, "Эндеритовый меч");
        t.add(GileModItems.ENDERITE_PICKAXE, "Эндеритовая кирка");
        t.add(GileModItems.ENDERITE_SHOVEL, "Эндеритовая лопата");
        t.add(GileModItems.ENDERITE_AXE, "Эндеритовый топор");
        t.add(GileModItems.ENDERITE_HOE, "Эндеритовая мотыга");
        t.add(GileModItems.ENDERITE_HELMET, "Эндеритовый шлем");
        t.add(GileModItems.ENDERITE_CHESTPLATE, "Эндеритовый нагрудник");
        t.add(GileModItems.ENDERITE_LEGGINGS, "Эндеритовые поножи");
        t.add(GileModItems.ENDERITE_BOOTS, "Эндеритовые ботинки");

        // Special Tools
        t.add(GileModItems.SHRINKER, "Уменьшитель");
        t.add(GileModItems.ENLARGER, "Увеличитель");
        t.add(GileModItems.JELLY_ON_A_STICK, "Желейка на палочке");
        t.add(GileModItems.WARP_CLOCK, "Варп-часы");
        t.add(GileModItems.CHRONO_GEAR, "Хроно-шестерёнка");
        t.add(GileModItems.HEART_OF_EMERGENCY, "Сердце спасения");
        t.add(GileModItems.GRAPPLING_HOOK, "Абордажный крюк");
        t.add(GileModItems.GENESIS_CRYSTAL, "§dКристалл Сотворения");
        t.add(GileModItems.END_COMPASS, "Компас Края");
        t.add(GileModItems.FLUTTERER, "Порхатель");
        t.add(GileModItems.NUCLEAR_CANNON, "Ядерная пушка");

        // Drops
        t.add(GileModItems.VOID_SLIMEBALL, "Сгусток пустотной слизи");
        t.add(GileModItems.MOTH_WING, "Крыло мотылька");
        t.add(GileModItems.JERBOAS_TAIL, "Хвост тушканчика");
        t.add(GileModItems.COGWORK_CORE, "Механическое ядро");

        // Food
        t.add(GileModItems.JELLY, "Желейка");
        t.add(GileModItems.JAM, "Джем");
        t.add(GileModItems.PHASMA, "Фазма");
        t.add(GileModItems.COOKED_PHASMA, "Жареная фазма");
        t.add(GileModItems.OFFERING, "Подношение Лунной Богине");
        t.add(GileModItems.GLOWING_CHORUS_FRUIT, "Светящийся плод хоруса");
        t.add(GileModItems.GLOWING_POPPED_CHORUS_FRUIT, "Приготовленный светящийся плод хоруса");

        // Misc/Materials
        t.add(GileModItems.DUST, "Пыль");
        t.add(GileModItems.STAR_DUST, "Звёздная пыль");
        t.add(GileModItems.STAR_SHINE, "Звёздное сияние");
        t.add(GileModItems.STAR_FRAGMENT, "Осколок звезды");
    }

    public static void blocks(FabricLanguageProvider.TranslationBuilder t) {
        // Ores
        t.add(GileModBlocks.PRIMOGEM_ORE.asItem(), "Руда камней Истока");
        t.add(GileModBlocks.DEEPSLATE_PRIMOGEM_ORE.asItem(), "Глубинная руда камней Истока");
        t.add(GileModBlocks.END_PRIMOGEM_ORE.asItem(), "Эндерская руда камней Истока");
        t.add(GileModBlocks.WISH.asItem(), "Желание");
        t.add(GileModBlocks.WISH_TABLE.asItem(), "Алтарь желаний");
        t.add(GileModBlocks.ENDERITE_ORE.asItem(), "Эндеритовая руда");
        t.add(GileModBlocks.ENDERITE_BLOCK.asItem(), "Блок эндерита");

        // Metall Blocks
        t.add(GileModBlocks.PEARLESCENT_BLOCK.asItem(), "Перламутровый блок");
        t.add(GileModBlocks.PEARLESCENT_STAIRS.asItem(), "Перламутровые ступени");
        t.add(GileModBlocks.PEARLESCENT_SLAB.asItem(), "Перламутровая плита");
        t.add(GileModBlocks.PEARLESCENT_WALL.asItem(), "Перламутровая ограда");
        t.add(GileModBlocks.PEARLESCENT_BRICKS.asItem(), "Перламутровый кирпич");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_STAIRS.asItem(), "Ступени из перламутрового кирпича");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_SLAB.asItem(), "Плита из перламутрового кирпича");
        t.add(GileModBlocks.PEARLESCENT_BRICKS_WALL.asItem(), "Ограда из перламутрового кирпича");

        // Stones
        t.add(GileModBlocks.MOON_SAND.asItem(), "Лунный песок");
        t.add(GileModBlocks.MOON_SANDSTONE.asItem(), "Лунный песчаник");
        t.add(GileModBlocks.MOON_SANDSTONE_STAIRS.asItem(), "Ступени из лунного песчаника");
        t.add(GileModBlocks.MOON_SANDSTONE_SLAB.asItem(), "Плита из лунного песчаника");
        t.add(GileModBlocks.MOON_SANDSTONE_WALL.asItem(), "Ограда из лунного песчаника");
        t.add(GileModBlocks.MOON_CHISELED_SANDSTONE.asItem(), "Резной лунный песчаник");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE.asItem(), "Гладкий лунный песчаник");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS.asItem(), "Ступени из гладкого лунного песчаника");
        t.add(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB.asItem(), "Плита из гладкого лунного песчаника");
        t.add(GileModBlocks.MOON_CUT_SANDSTONE.asItem(), "Пиленый лунный песчаник");
        t.add(GileModBlocks.MOON_CUT_SANDSTONE_SLAB.asItem(), "Плита из пиленого лунного песчаника");

        // Wood
        t.add(GileModBlocks.GHOSTLY_LOG.asItem(), "Призрачное бревно");
        t.add(GileModBlocks.STRIPPED_GHOSTLY_LOG.asItem(), "Очищенное призрачное бревно");
        t.add(GileModBlocks.GHOSTLY_WOOD.asItem(), "Призрачная древесина");
        t.add(GileModBlocks.STRIPPED_GHOSTLY_WOOD.asItem(), "Очищенная призрачная древесина");
        t.add(GileModBlocks.GHOSTLY_PLANKS.asItem(), "Призрачные доски");
        t.add(GileModBlocks.GHOSTLY_STAIRS.asItem(), "Призрачные ступени");
        t.add(GileModBlocks.GHOSTLY_SLAB.asItem(), "Призрачная плита");
        t.add(GileModBlocks.GHOSTLY_FENCE.asItem(), "Призрачная ограда");
        t.add(GileModBlocks.GHOSTLY_FENCE_GATE.asItem(), "Призрачные ворота");
        t.add(GileModBlocks.GHOSTLY_DOOR.asItem(), "Призрачная дверь");
        t.add(GileModBlocks.GHOSTLY_TRAPDOOR.asItem(), "Призрачный люк");
        t.add(GileModBlocks.GHOSTLY_PRESSURE_PLATE.asItem(), "Призрачная нажимная плита");
        t.add(GileModBlocks.GHOSTLY_BUTTON.asItem(), "Призрачная кнопка");
        t.add(GileModBlocks.GHOSTLY_SHELF.asItem(), "Призрачная полка");
        t.add(GileModBlocks.GHOSTLY_LEAVES.asItem(), "Призрачные листья");

        t.add(GileModBlocks.INVERTED_OAK_LOG.asItem(), "Бревно инвертированного дуба");
        t.add(GileModBlocks.STRIPPED_INVERTED_OAK_LOG.asItem(), "Очищенное бревно инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_WOOD.asItem(), "Древесина инвертированного дуба");
        t.add(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD.asItem(), "Очищенная древесина инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_PLANKS.asItem(), "Доски из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_STAIRS.asItem(), "Ступени из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_SLAB.asItem(), "Плита из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_FENCE.asItem(), "Ограда из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_FENCE_GATE.asItem(), "Ворота из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_DOOR.asItem(), "Дверь из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_TRAPDOOR.asItem(), "Люк из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_PRESSURE_PLATE.asItem(), "Нажимная плита из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_BUTTON.asItem(), "Кнопка из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_SHELF.asItem(), "Полка из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_LEAVES.asItem(), "Листья инвертированного дуба");

        // Signs
        t.add(GileModBlocks.GHOSTLY_SIGN, "Призрачная табличка");
        t.add(GileModBlocks.GHOSTLY_WALL_SIGN, "Призрачная табличка");
        t.add(GileModItems.GHOSTLY_SIGN_ITEM, "Призрачная табличка");
        t.add(GileModBlocks.GHOSTLY_HANGING_SIGN, "Призрачная подвесная табличка");
        t.add(GileModBlocks.GHOSTLY_WALL_HANGING_SIGN, "Призрачная подвесная табличка");
        t.add(GileModItems.GHOSTLY_HANGING_SIGN_ITEM, "Призрачная подвесная табличка");
        t.add(GileModBlocks.INVERTED_OAK_SIGN, "Табличка из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_WALL_SIGN, "Табличка из инвертированного дуба");
        t.add(GileModItems.INVERTED_OAK_SIGN_ITEM, "Табличка из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_HANGING_SIGN, "Подвесная табличка из инвертированного дуба");
        t.add(GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN, "Подвесная табличка из инвертированного дуба");
        t.add(GileModItems.INVERTED_OAK_HANGING_SIGN_ITEM, "Подвесная табличка из инвертированного дуба");

        // Plants
        t.add(GileModBlocks.GHOSTLY_SAPLING.asItem(), "Саженец призрачного дерева");
        t.add(GileModBlocks.POTTED_GHOSTLY_SAPLING, "Саженец призрачного дерева");
        t.add(GileModBlocks.INVERTED_OAK_SAPLING.asItem(), "Саженец инвертированного дуба");
        t.add(GileModBlocks.POTTED_INVERTED_OAK_SAPLING, "Саженец инвертированного дуба");
        t.add(GileModBlocks.END_GRASS_BLOCK.asItem(), "Блок эндерской травы");
        t.add(GileModBlocks.END_GRASS.asItem(), "Эндерская трава");
        t.add(GileModBlocks.TALL_END_GRASS.asItem(), "Высокая эндерская трава");
        t.add(GileModBlocks.MOON_FLOWER.asItem(), "Лунный цветок");
        t.add(GileModBlocks.POTTED_MOON_FLOWER, "Лунный цветок");
        t.add(GileModBlocks.GLOOMY_FLOWER.asItem(), "Мрачный цветок");
        t.add(GileModBlocks.POTTED_GLOOMY_FLOWER, "Мрачный цветок");
        t.add(GileModBlocks.DRY_FLOWER.asItem(), "Сухой цветок");
        t.add(GileModBlocks.POTTED_DRY_FLOWER, "Сухой цветок");
        t.add(GileModBlocks.GLOWING_CHORUS_FLOWER.asItem(), "Цветок светящегося хоруса");
        t.add(GileModBlocks.GLOWING_CHORUS_PLANT.asItem(), "Растение светящегося хоруса");
        t.add(GileModBlocks.FLUO_BLOCK.asItem(), "Флюо-блок");
        t.add(GileModBlocks.FLUO_STAIRS.asItem(), "Флюо-ступени");
        t.add(GileModBlocks.FLUO_SLAB.asItem(), "Флюо-плита");
        t.add(GileModBlocks.FLUO_PILLAR.asItem(), "Флюо-колонна");

        // Moon Fire
        t.add(GileModBlocks.MOON_TORCH, "Лунный факел");
        t.add(GileModBlocks.MOON_WALL_TORCH, "Лунный факел");
        t.add(GileModItems.MOON_TORCH_ITEM, "Лунный факел");
        t.add(GileModBlocks.PEARLESCENT_CHAIN.asItem(), "Перламутровая цепь");
        t.add(GileModBlocks.MOON_LANTERN.asItem(), "Лунный фонарь");
        t.add(GileModBlocks.MOON_CAMPFIRE.asItem(), "Лунный костёр");
        t.add(GileModBlocks.MOON_FIRE, "Лунный огонь");

        // Misc
        t.add(GileModBlocks.STAR.asItem(), "Звезда");
        t.add(GileModBlocks.END_CLOUD.asItem(), "Облако Края");
        t.add(GileModBlocks.GLITTER_BLOCK.asItem(), "Блок блёсток");
        t.add(GileModBlocks.GLITTER_CARPET.asItem(), "Ковёр из блёсток");
        t.add(GileModBlocks.JAR_OF_GLITTERS.asItem(), "Банка блёсток");
    }

    public static void entities(FabricLanguageProvider.TranslationBuilder t) {
        t.add(GileModEntities.FATE_ARROW_TYPE, "Стрела судьбы");
        t.add(GileModEntities.VENTI_ARROW_TYPE, "Стрела Венти");
        t.add(GileModEntities.ENDER_FLY_STING, "Жало эндерской мухи");
        t.add(GileModEntities.VOID_SLIME, "Пустотный слизень");
        t.add(GileModEntities.VOID_SLIME_SPAWN_EGG, "Яйцо призыва пустотного слизня");
        t.add(GileModEntities.MOTH, "Мотылёк");
        t.add(GileModEntities.MOTH_SPAWN_EGG, "Яйцо призыва мотылька");
        t.add(GileModEntities.LUMINOUS, "Светяшка");
        t.add(GileModEntities.LUMINOUS_SPAWN_EGG, "Яйцо призыва светяшки");
        t.add(GileModEntities.HOVERING_GHOST, "Парящий призрак");
        t.add(GileModEntities.HOVERING_GHOST_SPAWN_EGG, "Яйцо призыва парящего призрака");
        t.add(GileModEntities.GLOOMY_LYNX, "Мрачная рысь");
        t.add(GileModEntities.GLOOMY_LYNX_SPAWN_EGG, "Яйцо призыва мрачной рыси");
        t.add(GileModEntities.JERBOA, "Тушканчик");
        t.add(GileModEntities.JERBOA_SPAWN_EGG, "Яйцо призыва тушканчика");
        t.add(GileModEntities.WEASEL_THIEF, "Хорёк-барахольщик");
        t.add(GileModEntities.WEASEL_THIEF_SPAWN_EGG, "Яйцо призыва хорька-барахольщика");
        t.add(String.valueOf(WeaselVariant.AMATEUR), "Любитель");
        t.add(String.valueOf(WeaselVariant.HOARDER), "Барахольщик");
        t.add(String.valueOf(WeaselVariant.GOLDEN), "Золотой");
        t.add(GileModEntities.GLITTER, "Блёстка");
        t.add(GileModEntities.GLITTER_SPAWN_EGG, "Яйцо призыва блёстки");
        t.add(GileModEntities.SALON_MEMBER, "Участник салона");
        t.add("entity.gilemod.salon_member_1", "Месье Уше");
        t.add("entity.gilemod.salon_member_2", "Управляющая Шевальмарен");
        t.add("entity.gilemod.salon_member_3", "Мадемуазель Крабалетта");
        t.add(GileModEntities.SALON_MEMBER_SPAWN_EGG, "Яйцо призыва участника салона");
        t.add(GileModEntities.ENDER_FLY, "Эндер муха");
        t.add(GileModEntities.ENDER_FLY_SPAWN_EGG, "Яйцо призыва эндер мухи");
        t.add(GileModEntities.RUIN_GUARD, "Страж руин");
        t.add(GileModEntities.RUIN_GUARD_SPAWN_EGG, "Яйцо призыва стража руин");
    }

    public static void effects(FabricLanguageProvider.TranslationBuilder t) {
        t.add(GileModEffects.SHRINK.value(), "Уменьшение");
        t.add(GileModEffects.ENLARGE.value(), "Увеличение");
    }

}
