package mh837.gile.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import mh837.gile.GileMod;
import mh837.gile.entity.GloomyLynxEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class GloomyLynxRenderer extends MobRenderer<
        GloomyLynxEntity,
        GloomyLynxRenderer.LynxRenderState,
        EntityModel<GloomyLynxRenderer.LynxRenderState>
        > {

    public static final ModelLayerLocation LYNX_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            GileMod.MOD_ID,
                            "gloomy_lynx"
                    ),
                    "main"
            );

    public static final ModelLayerLocation LYNX_BABY_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath(
                            GileMod.MOD_ID,
                            "gloomy_lynx_baby"
                    ),
                    "main"
            );

    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(
                    GileMod.MOD_ID,
                    "textures/entity/gloomy_lynx.png"
            );

    private final LynxModel adultModel;
    private final LynxBabyModel babyModel;

    public GloomyLynxRenderer(
            EntityRendererProvider.Context context
    ) {
        super(
                context,
                new LynxModel(
                        context.bakeLayer(LYNX_LAYER)
                ),
                0.5F
        );

        this.adultModel = (LynxModel) this.model;

        this.babyModel = new LynxBabyModel(
                context.bakeLayer(LYNX_BABY_LAYER)
        );
    }

    @Override
    public LynxRenderState createRenderState() {
        return new LynxRenderState();
    }

    @Override
    public void extractRenderState(
            GloomyLynxEntity entity,
            LynxRenderState state,
            float partialTick
    ) {
        super.extractRenderState(
                entity,
                state,
                partialTick
        );

        state.isAngry = entity.isAngry();
    }

    @Override
    public void submit(
            LynxRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState camera
    ) {
        this.model = state.isBaby
                ? this.babyModel
                : this.adultModel;

        super.submit(
                state,
                poseStack,
                collector,
                camera
        );
    }

    @Override
    public Identifier getTextureLocation(
            LynxRenderState state
    ) {
        return TEXTURE;
    }

    @Override
    protected void scale(
            LynxRenderState state,
            PoseStack poseStack
    ) {
    }

    public static class LynxRenderState
            extends LivingEntityRenderState {

        public boolean isAngry;
    }

    public static class LynxModel
            extends EntityModel<LynxRenderState> {

        private final ModelPart root;
        private final ModelPart headNormal;
        private final ModelPart headAngry;
        private final ModelPart body;
        private final ModelPart frontLeftLeg;
        private final ModelPart frontRightLeg;
        private final ModelPart backLeftLeg;
        private final ModelPart backRightLeg;
        private final ModelPart tail;

        public LynxModel(ModelPart root) {
            super(root);

            this.root = root;
            this.headNormal = root.getChild("head_normal");
            this.headAngry = root.getChild("head_angry");
            this.body = root.getChild("body");
            this.frontLeftLeg = root.getChild("front_left_leg");
            this.frontRightLeg = root.getChild("front_right_leg");
            this.backLeftLeg = root.getChild("back_left_leg");
            this.backRightLeg = root.getChild("back_right_leg");
            this.tail = root.getChild("tail");
        }

        public static LayerDefinition createBodyLayer() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();

            root.addOrReplaceChild(
                    "head_normal",
                    CubeListBuilder.create()
                            .texOffs(0, 0)
                            .addBox(-3.0F, -4.0F, -4.0F, 6.0F, 6.0F, 5.0F)
                            .texOffs(0, 11)
                            .addBox(-4.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                            .texOffs(0, 11)
                            .addBox(2.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F),
                    PartPose.offset(0.0F, 13.0F, -8.0F)
            );

            root.addOrReplaceChild(
                    "head_angry",
                    CubeListBuilder.create()
                            .texOffs(32, 0)
                            .addBox(-3.0F, -4.0F, -4.0F, 6.0F, 6.0F, 5.0F)
                            .texOffs(32, 11)
                            .addBox(-4.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                            .texOffs(32, 11)
                            .addBox(2.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F),
                    PartPose.offset(0.0F, 13.0F, -8.0F)
            );

            root.addOrReplaceChild(
                    "body",
                    CubeListBuilder.create()
                            .texOffs(0, 16)
                            .addBox(-4.0F, -8.0F, -4.0F, 8.0F, 18.0F, 8.0F),
                    PartPose.offsetAndRotation(
                            0.0F,
                            14.0F,
                            0.0F,
                            1.5708F,
                            0.0F,
                            0.0F
                    )
            );

            root.addOrReplaceChild(
                    "front_left_leg",
                    CubeListBuilder.create()
                            .texOffs(32, 16)
                            .addBox(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    PartPose.offset(2.0F, 14.0F, -6.0F)
            );

            root.addOrReplaceChild(
                    "front_right_leg",
                    CubeListBuilder.create()
                            .texOffs(32, 16)
                            .addBox(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    PartPose.offset(-2.0F, 14.0F, -6.0F)
            );

            root.addOrReplaceChild(
                    "back_left_leg",
                    CubeListBuilder.create()
                            .texOffs(44, 16)
                            .addBox(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    PartPose.offset(2.0F, 14.0F, 7.0F)
            );

            root.addOrReplaceChild(
                    "back_right_leg",
                    CubeListBuilder.create()
                            .texOffs(44, 16)
                            .addBox(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    PartPose.offset(-2.0F, 14.0F, 7.0F)
            );

            root.addOrReplaceChild(
                    "tail",
                    CubeListBuilder.create()
                            .texOffs(0, 42)
                            .addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                    PartPose.offsetAndRotation(
                            0.0F,
                            13.0F,
                            8.0F,
                            0.7854F,
                            0.0F,
                            0.0F
                    )
            );

            return LayerDefinition.create(mesh, 64, 64);
        }

        @Override
        public void setupAnim(LynxRenderState state) {
            super.setupAnim(state);

            root.getAllParts().forEach(ModelPart::resetPose);

            headNormal.visible = !state.isAngry;
            headAngry.visible = state.isAngry;

            float yaw = state.yRot * ((float) Math.PI / 180F);
            float pitch = state.xRot * ((float) Math.PI / 180F);

            headNormal.yRot = yaw;
            headNormal.xRot = pitch;

            headAngry.yRot = yaw;
            headAngry.xRot = pitch;

            float walk = state.walkAnimationPos * 0.6662F;
            float amount = 1.4F * state.walkAnimationSpeed;

            frontRightLeg.xRot =
                    Mth.cos(walk) * amount;

            frontLeftLeg.xRot =
                    Mth.cos(walk + (float) Math.PI) * amount;

            backRightLeg.xRot =
                    Mth.cos(walk + (float) Math.PI) * amount;

            backLeftLeg.xRot =
                    Mth.cos(walk) * amount;

            if (state.isAngry) {
                tail.yRot =
                        Mth.cos(state.ageInTicks * 0.5F) * 0.5F;
                tail.xRot = 1.0F;
            } else {
                tail.yRot =
                        Mth.cos(walk)
                                * 0.3F
                                * state.walkAnimationSpeed;
                tail.xRot = 0.7854F;
            }
        }
    }

    public static class LynxBabyModel
            extends EntityModel<LynxRenderState> {

        private final ModelPart body;
        private final ModelPart frontLegRight;
        private final ModelPart frontLegLeft;
        private final ModelPart backLegRight;
        private final ModelPart backLegLeft;
        private final ModelPart tail;
        private final ModelPart head;

        public LynxBabyModel(ModelPart root) {
            super(root);

            this.body = root.getChild("body");
            this.frontLegRight = this.body.getChild("front_leg_right");
            this.frontLegLeft = this.body.getChild("front_leg_left");
            this.backLegRight = this.body.getChild("back_leg_right");
            this.backLegLeft = this.body.getChild("back_leg_left");
            this.tail = this.body.getChild("tail");
            this.head = this.body.getChild("head");
        }

        public static LayerDefinition createBodyLayer() {
            MeshDefinition meshdefinition = new MeshDefinition();
            PartDefinition partdefinition = meshdefinition.getRoot();

            PartDefinition body = partdefinition.addOrReplaceChild(
                    "body",
                    CubeListBuilder.create(),
                    PartPose.offset(0.0F, 24.0F, 0.0F)
            );

            body.addOrReplaceChild(
                    "body_r1",
                    CubeListBuilder.create()
                            .texOffs(3, 19)
                            .addBox(
                                    -2.5F, -4.5F, -2.5F,
                                    5.0F, 9.0F, 5.0F,
                                    new CubeDeformation(0.0F)
                            ),
                    PartPose.offsetAndRotation(
                            -0.5F, -6.5F, -0.25F,
                            1.5708F, 0.0F, 0.0F
                    )
            );

            body.addOrReplaceChild(
                    "front_leg_right",
                    CubeListBuilder.create()
                            .texOffs(45, 17)
                            .mirror()
                            .addBox(
                                    -1.0F, -1.0F, -1.0F,
                                    2.0F, 5.0F, 2.0F,
                                    new CubeDeformation(0.0F)
                            )
                            .mirror(false),
                    PartPose.offset(
                            -1.75F, -4.0F, -2.75F
                    )
            );

            body.addOrReplaceChild(
                    "front_leg_left",
                    CubeListBuilder.create()
                            .texOffs(34, 24)
                            .addBox(
                                    -1.0F, -1.0F, -1.0F,
                                    2.0F, 5.0F, 2.0F,
                                    new CubeDeformation(0.0F)
                            ),
                    PartPose.offset(
                            0.75F, -4.0F, -2.75F
                    )
            );

            body.addOrReplaceChild(
                    "back_leg_right",
                    CubeListBuilder.create()
                            .texOffs(44, 24)
                            .addBox(
                                    -3.5F, -1.0F, 4.5F,
                                    2.0F, 5.0F, 2.0F,
                                    new CubeDeformation(0.0F)
                            ),
                    PartPose.offset(
                            0.75F, -4.0F, -2.75F
                    )
            );

            body.addOrReplaceChild(
                    "back_leg_left",
                    CubeListBuilder.create()
                            .texOffs(33, 17)
                            .addBox(
                                    -1.0F, -1.0F, 4.5F,
                                    2.0F, 5.0F, 2.0F,
                                    new CubeDeformation(0.0F)
                            ),
                    PartPose.offset(
                            0.75F, -4.0F, -2.75F
                    )
            );

            PartDefinition tail = body.addOrReplaceChild(
                    "tail",
                    CubeListBuilder.create(),
                    PartPose.offset(
                            -0.5F,
                            -6.4821F,
                            3.0939F
                    )
            );

            tail.addOrReplaceChild(
                    "tail_r1",
                    CubeListBuilder.create()
                            .texOffs(0, 42)
                            .addBox(
                                    -1.0F, 0.0382F, 0.397F,
                                    2.0F, 6.0F, 2.0F,
                                    new CubeDeformation(0.0F)
                            ),
                    PartPose.offsetAndRotation(
                            0.0F, 0.0F, 0.0F,
                            0.0F, 0.0F, 0.0F
                    )
            );

            body.addOrReplaceChild(
                    "head",
                    CubeListBuilder.create()
                            .texOffs(0, 57)
                            .addBox(
                                    -2.0F, -2.75F, -3.125F,
                                    4.0F, 4.0F, 3.0F,
                                    new CubeDeformation(0.0F)
                            )
                            .texOffs(0, 11)
                            .mirror()
                            .addBox(
                                    1.0F, -3.75F, -1.375F,
                                    2.0F, 2.0F, 1.0F,
                                    new CubeDeformation(0.0F)
                            )
                            .mirror(false)
                            .texOffs(0, 11)
                            .addBox(
                                    -3.0F, -3.75F, -1.375F,
                                    2.0F, 2.0F, 1.0F,
                                    new CubeDeformation(0.0F)
                            ),
                    PartPose.offset(
                            -0.5F,
                            -7.25F,
                            -4.625F
                    )
            );

            return LayerDefinition.create(
                    meshdefinition,
                    64,
                    64
            );
        }

        @Override
        public void setupAnim(LynxRenderState state) {
            super.setupAnim(state);

            body.getAllParts().forEach(ModelPart::resetPose);

            // Head rotation
            float yaw =
                    state.yRot * ((float) Math.PI / 180F);

            float pitch =
                    state.xRot * ((float) Math.PI / 180F);

            head.yRot = yaw;
            head.xRot = pitch;

            // Baby walking animation.
            // Slower than the adult and with a much smaller
            // movement range on the rear legs.
            float walk =
                    state.walkAnimationPos * 0.45F;

            float frontAmount =
                    0.55F * state.walkAnimationSpeed;

            float backAmount =
                    0.30F * state.walkAnimationSpeed;

            // Front legs
            frontLegRight.xRot =
                    Mth.cos(walk) * frontAmount;

            frontLegLeft.xRot =
                    Mth.cos(
                            walk + (float) Math.PI
                    ) * frontAmount;

            // Back legs
            backLegRight.xRot =
                    Mth.cos(
                            walk + (float) Math.PI
                    ) * backAmount;

            backLegLeft.xRot =
                    Mth.cos(walk) * backAmount;

            // Tail follows the walking motion gently.
            tail.yRot =
                    Mth.cos(walk)
                            * 0.3F
                            * state.walkAnimationSpeed;

            // Preserve the tail's exported BB base rotation.
            tail.xRot = 1.1345F;
        }
    }
}