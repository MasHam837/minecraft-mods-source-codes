package mh837.gile.mixin;

import mh837.gile.item.tool.FluttererUtil;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class PlayerMixin {

    @Inject(
            method = "tick",
            at = @At("TAIL")
    )
    private void gile$fluttererTick(CallbackInfo ci) {

        Player player = (Player) (Object) this;

        if (!player.level().isClientSide()) {
            FluttererUtil.applySlowFalling((ServerPlayer) player);
        }
    }

    @Inject(
            method = "causeFallDamage",
            at = @At("HEAD"),
            cancellable = true
    )
    private void gile$cancelFluttererFallDamage(
            double fallDistance,
            float damageMultiplier,
            DamageSource damageSource,
            CallbackInfoReturnable<Boolean> cir
    ) {

        Player player = (Player) (Object) this;

        if (FluttererUtil.isActive(player)) {
            cir.setReturnValue(false);
        }
    }
}