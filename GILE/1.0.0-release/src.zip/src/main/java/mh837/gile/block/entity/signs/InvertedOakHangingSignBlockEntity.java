package mh837.gile.block.entity.signs;

import mh837.gile.GileModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class InvertedOakHangingSignBlockEntity extends SignBlockEntity {

    public InvertedOakHangingSignBlockEntity(BlockPos pos, BlockState state) {
        // Now you can pass your 3 arguments successfully!
        super(GileModBlockEntities.INVERTED_OAK_HANGING_SIGN_ENTITY, pos, state);
    }

    @Override
    public int getTextLineHeight() {
        return 9; // Hanging sign text line height
    }

    @Override
    public int getMaxTextLineWidth() {
        return 60; // Hanging sign text max line width
    }

    @Override
    public SoundEvent getSignInteractionFailedSoundEvent() {
        return SoundEvents.WAXED_HANGING_SIGN_INTERACT_FAIL;
    }

    @Override
    public BlockEntityType<?> getType() {
        return GileModBlockEntities.INVERTED_OAK_HANGING_SIGN_ENTITY;
    }
}