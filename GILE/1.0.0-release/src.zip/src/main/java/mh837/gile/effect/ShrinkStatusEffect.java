package mh837.gile.effect;

import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class ShrinkStatusEffect extends MobEffect {

    private static final Identifier SCALE_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.scale");
    private static final Identifier HEALTH_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.health");
    private static final Identifier SPEED_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.speed");
    private static final Identifier JUMP_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.jump");
    private static final Identifier STRENGTH_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.strength");
    private static final Identifier REACH_ENTITY_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.reach_entity");
    private static final Identifier REACH_BLOCK_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.reach_block");
    private static final Identifier GRAVITY_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.gravity");
    private static final Identifier STEP_HEIGHT_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.step_height");
    private static final Identifier FALL_DIST_ID = Identifier.fromNamespaceAndPath("gilemod", "shrink.fall_distance");

    public ShrinkStatusEffect() {
        super(MobEffectCategory.NEUTRAL, 0x6743CA);
    }

    @Override
    public void addAttributeModifiers(AttributeMap attributes, int amplifier) {
        super.addAttributeModifiers(attributes, amplifier);

        double scaleShrink = calculateScaleShrink(amplifier);
        double statsShrink = calculateStatsShrink(amplifier);

        applyModifier(attributes, Attributes.SCALE, SCALE_ID, -scaleShrink);
        applyModifier(attributes, Attributes.MAX_HEALTH, HEALTH_ID, -statsShrink);
        applyModifier(attributes, Attributes.MOVEMENT_SPEED, SPEED_ID, -statsShrink);
        applyModifier(attributes, Attributes.JUMP_STRENGTH, JUMP_ID, -statsShrink);
        applyModifier(attributes, Attributes.ATTACK_DAMAGE, STRENGTH_ID, -statsShrink);
        applyModifier(attributes, Attributes.ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID, -statsShrink);
        applyModifier(attributes, Attributes.BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID, -statsShrink);
        applyModifier(attributes, Attributes.GRAVITY, GRAVITY_ID, -statsShrink);
        applyModifier(attributes, Attributes.STEP_HEIGHT, STEP_HEIGHT_ID, -statsShrink);
        applyModifier(attributes, Attributes.SAFE_FALL_DISTANCE, FALL_DIST_ID, -statsShrink);
    }

    @Override
    public void removeAttributeModifiers(AttributeMap attributes) {
        super.removeAttributeModifiers(attributes);

        removeModifier(attributes, Attributes.SCALE, SCALE_ID);
        removeModifier(attributes, Attributes.MAX_HEALTH, HEALTH_ID);
        removeModifier(attributes, Attributes.MOVEMENT_SPEED, SPEED_ID);
        removeModifier(attributes, Attributes.JUMP_STRENGTH, JUMP_ID);
        removeModifier(attributes, Attributes.ATTACK_DAMAGE, STRENGTH_ID);
        removeModifier(attributes, Attributes.ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID);
        removeModifier(attributes, Attributes.BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID);
        removeModifier(attributes, Attributes.GRAVITY, GRAVITY_ID);
        removeModifier(attributes, Attributes.STEP_HEIGHT, STEP_HEIGHT_ID);
        removeModifier(attributes, Attributes.SAFE_FALL_DISTANCE, FALL_DIST_ID);
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        // Return true every tick so we can check if re-login stripped our modifiers
        return true;
    }

    @Override
    public boolean applyEffectTick(ServerLevel serverLevel, LivingEntity mob, int amplifier) {
        // Complement logic: Check if a player/entity rejoined and lost their attribute modifiers
        // while the effect instance was still active on them.
        checkAndReapplyModifiersIfNeeded(mob, amplifier);
        return super.applyEffectTick(serverLevel, mob, amplifier);
    }

    private void checkAndReapplyModifiersIfNeeded(LivingEntity mob, int amplifier) {
        AttributeInstance healthInstance = mob.getAttribute(Attributes.MAX_HEALTH);
        if (healthInstance != null && healthInstance.getModifier(HEALTH_ID) == null) {
            // Modifiers got wiped (e.g. from a game reload or client-server sync glitch), re-apply them!
            addAttributeModifiers(mob.getAttributes(), amplifier);
        }
    }

    // ---------------------------------

    private double calculateScaleShrink(int amplifier) {
        double scaleShrink = 0.2 * (amplifier + 1);
        return Math.min(scaleShrink, 0.95);
    }

    private double calculateStatsShrink(int amplifier) {
        double statsShrink = 0.1 * (amplifier + 1);
        return Math.min(statsShrink, 0.95);
    }

    private void applyModifier(AttributeMap attributes, Holder<Attribute> attribute, Identifier id, double value) {
        AttributeInstance instance = attributes.getInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id); // Safely ensures no duplicate stacking
            instance.addTransientModifier(new AttributeModifier(
                    id, value, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
            ));
        }
    }

    private void removeModifier(AttributeMap attributes, Holder<Attribute> attribute, Identifier id) {
        AttributeInstance instance = attributes.getInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id);
        }
    }
}