package mh837.gile.block;

import com.mojang.serialization.MapCodec;
import mh837.gile.GileModBlocks;
import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import mh837.gile.block.entity.GlitterJarBlockEntity;
import mh837.gile.entity.GlitterEntity;
import mh837.gile.item.GlitterJarItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class GlitterJarBlock extends BaseEntityBlock {

    public static final MapCodec<GlitterJarBlock> CODEC =
            simpleCodec(GlitterJarBlock::new);

    public static final IntegerProperty GLITTERS =
            IntegerProperty.create("glitters", 1, 4);

    public GlitterJarBlock(BlockBehaviour.Properties properties) {
        super(properties);

        registerDefaultState(
                stateDefinition.any()
                        .setValue(GLITTERS, 1)
        );
    }

    private static final VoxelShape BASE_SHAPE = Block.box(0, 0, 0, 16, 14, 16);
    private static final VoxelShape TOP_SHAPE = Block.box(2, 14, 2, 14, 16, 14);
    private static final VoxelShape SHAPE = Shapes.or(BASE_SHAPE, TOP_SHAPE);

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {return SHAPE;}

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {return SHAPE;}

    @Override
    protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {return SHAPE;}

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    public BlockEntity newBlockEntity(
            BlockPos pos,
            BlockState state
    ) {
        return new GlitterJarBlockEntity(pos, state);
    }

    @Override
    protected void createBlockStateDefinition(
            StateDefinition.Builder<Block, BlockState> builder
    ) {
        builder.add(GLITTERS);
    }

    @Override
    protected InteractionResult useItemOn(
            ItemStack stack,
            BlockState state,
            Level level,
            BlockPos pos,
            Player player,
            InteractionHand hand,
            BlockHitResult hit
    ) {
        if (!stack.is(GileModItems.DUST)) {
            return InteractionResult.PASS;
        }

        int currentCount =
                state.getValue(GLITTERS);

        if (currentCount >= GlitterJarBlockEntity.MAX_GLITTERS) {
            return InteractionResult.FAIL;
        }

        if (!level.isClientSide()) {

            int newCount = currentCount + 1;

            // Change the block state.
            level.setBlock(
                    pos,
                    state.setValue(GLITTERS, newCount),
                    3
            );

            // Keep the BlockEntity's persistent value synchronized.
            BlockEntity blockEntity =
                    level.getBlockEntity(pos);

            if (blockEntity instanceof GlitterJarBlockEntity jar) {
                jar.setGlitterCount(newCount);
            }

            // Consume exactly one Dust in survival.
            if (!player.getAbilities().instabuild) {
                player.getItemInHand(hand).shrink(1);
            }
        }

        return InteractionResult.SUCCESS;
    }

    @Override
    public void playerDestroy(
            Level level,
            Player player,
            BlockPos pos,
            BlockState state,
            BlockEntity blockEntity,
            ItemStack tool
    ) {
        if (level.isClientSide()) {
            return;
        }

        int glitterCount =
                state.getValue(GLITTERS);

        boolean silkTouch =
                tool.getEnchantments()
                        .getLevel(
                                level.registryAccess()
                                        .lookupOrThrow(
                                                Registries.ENCHANTMENT
                                        )
                                        .getOrThrow(
                                                Enchantments.SILK_TOUCH
                                        )
                        ) > 0;

// True only when the held item actually has Minecraft's Tool component.
        boolean isTool =
                !tool.isEmpty()
                        && tool.has(DataComponents.TOOL);

        /*
         * HAND, NON-TOOL ITEM, OR SILK TOUCH
         *
         * Preserve the jar and its Glitter count.
         */
        if (!isTool || silkTouch) {

            ItemStack result =
                    new ItemStack(
                            GileModBlocks.JAR_OF_GLITTERS
                    );

            GlitterJarItem.setGlitterCount(
                    result,
                    glitterCount
            );

            popResource(
                    level,
                    pos,
                    result
            );

            return;
        }

        /*
         * ACTUAL TOOL WITHOUT SILK TOUCH
         *
         * Break the jar and release the Glitters.
         */
        for (int i = 0; i < glitterCount; i++) {

            GlitterEntity glitter =
                    new GlitterEntity(
                            GileModEntities.GLITTER,
                            level
                    );

            double x =
                    pos.getX()
                            + 0.5D
                            + (level.getRandom().nextDouble() - 0.5D) * 0.4D;

            double y =
                    pos.getY()
                            + 0.5D
                            + (level.getRandom().nextDouble() - 0.5D) * 0.4D;

            double z =
                    pos.getZ()
                            + 0.5D
                            + (level.getRandom().nextDouble() - 0.5D) * 0.4D;

            glitter.setPos(x, y, z);

            glitter.setYRot(
                    level.getRandom().nextFloat() * 360.0F
            );

            level.addFreshEntity(glitter);
        }
    }

    @Override
    public void setPlacedBy(
            Level level,
            BlockPos pos,
            BlockState state,
            LivingEntity placer,
            ItemStack stack
    ) {
        super.setPlacedBy(
                level,
                pos,
                state,
                placer,
                stack
        );

        if (level.isClientSide()) {
            return;
        }

        BlockEntity blockEntity =
                level.getBlockEntity(pos);

        if (!(blockEntity instanceof GlitterJarBlockEntity jar)) {
            return;
        }

        jar.setGlitterCount(
                GlitterJarItem.getGlitterCount(stack)
        );
    }

}