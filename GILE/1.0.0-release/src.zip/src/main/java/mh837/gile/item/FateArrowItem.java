package mh837.gile.item;

import mh837.gile.entity.projectile.FateArrowEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class FateArrowItem extends ArrowItem {
    public FateArrowItem(Properties properties) {
        super(properties);
    }

    @Override
    public AbstractArrow createArrow(Level level, ItemStack ammoStack, LivingEntity shooter, @Nullable ItemStack weaponStack) {
        // This is where we link the Item to the Entity!
        return new FateArrowEntity(level, shooter, ammoStack, weaponStack);
    }
}