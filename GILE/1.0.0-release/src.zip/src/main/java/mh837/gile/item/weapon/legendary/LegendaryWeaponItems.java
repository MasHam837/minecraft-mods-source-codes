package mh837.gile.item.weapon.legendary;

import mh837.gile.GileModDataComponents;
import mh837.gile.item.weapon.CatalystItem;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;

public class LegendaryWeaponItems {

    private static void tickHeld(ItemStack stack, ServerLevel level, Entity owner, EquipmentSlot slot) {
        if (!(owner instanceof Player player) || player.isSpectator()) return;
        if (slot != EquipmentSlot.MAINHAND && slot != EquipmentSlot.OFFHAND) return;
        LegendaryEffects.tick(level, player);
    }
    public static final class LegendaryWeaponAttributes {
        public static ItemAttributeModifiers create(double attackDamage, double attackSpeed) {
            return ItemAttributeModifiers.builder()
                    .add(
                            Attributes.ATTACK_DAMAGE,
                            new AttributeModifier(
                                    Item.BASE_ATTACK_DAMAGE_ID,
                                    attackDamage,
                                    AttributeModifier.Operation.ADD_VALUE
                            ),
                            EquipmentSlotGroup.MAINHAND
                    )
                    .add(
                            Attributes.ATTACK_SPEED,
                            new AttributeModifier(
                                    Item.BASE_ATTACK_SPEED_ID,
                                    attackSpeed,
                                    AttributeModifier.Operation.ADD_VALUE
                            ),
                            EquipmentSlotGroup.MAINHAND
                    )
                    .build();
        }
    }

    // LIFE
    public static class TomeOfNaberius extends CatalystItem {

        public TomeOfNaberius(Properties properties) {
            super(properties);
        }

        @Override
        public void inventoryTick(
                ItemStack stack,
                ServerLevel level,
                Entity owner,
                EquipmentSlot slot
        ) {
            super.inventoryTick(stack, level, owner, slot);
            tickHeld(stack, level, owner, slot);
        }

        @Override
        public void hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {
            super.hurtEnemy(stack, target, attacker);

            if (!(attacker instanceof Player player)) {
                return;
            }

            if (!(player.level() instanceof ServerLevel level)) {
                return;
            }

            LegendaryEffects.naberiusOnHit(level, target);
        }

        @Override
        public InteractionResult use(
                Level level,
                Player player,
                InteractionHand hand
        ) {
            if (!(level instanceof ServerLevel serverLevel)) {
                return InteractionResult.PASS;
            }

            if (!(player instanceof ServerPlayer serverPlayer)) {
                return InteractionResult.PASS;
            }

            if (player.isSpectator()) {
                return InteractionResult.PASS;
            }

            ItemStack stack = player.getItemInHand(hand);

            LegendaryAbilities.NaberiusHealing.touch(
                    serverLevel,
                    serverPlayer,
                    null,
                    stack
            );

            return InteractionResult.SUCCESS;
        }

        /**
         * Right-click utility:
         * Give the clicked living entity Instant Health.
         *
         * This intentionally heals undead by the normal Minecraft
         * Instant Health rules, meaning it damages/kills them.
         */
        @Override
        public InteractionResult interactLivingEntity(
                ItemStack stack,
                Player player,
                LivingEntity target,
                InteractionHand hand
        ) {
            if (!(player.level() instanceof ServerLevel level)) {
                return InteractionResult.PASS;
            }

            if (player.isSpectator()) {
                return InteractionResult.PASS;
            }

            LegendaryAbilities.NaberiusHealing.touch(
                    level,
                    (ServerPlayer) player,
                    target,
                    stack
            );

            return InteractionResult.SUCCESS;
        }
    }

    // SPACE
    public static class PalmOfAsmoday extends CatalystItem {

        public PalmOfAsmoday(Properties properties) {
            super(properties);
        }

        @Override
        public void inventoryTick(
                ItemStack stack,
                ServerLevel level,
                Entity owner,
                EquipmentSlot slot
        ) {
            super.inventoryTick(stack, level, owner, slot);
            tickHeld(stack, level, owner, slot);
        }

        @Override
        public void hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {
            super.hurtEnemy(stack, target, attacker);

            if (!(attacker instanceof Player player)) {
                return;
            }

            if (!(attacker.level() instanceof ServerLevel level)) {
                return;
            }

            LegendaryEffects.asmodayOnHit(
                    level,
                    player,
                    target
            );
        }

        @Override
        public InteractionResult use(
                Level level,
                Player player,
                InteractionHand hand
        ) {
            ItemStack stack =
                    player.getItemInHand(hand);

            if (!(level instanceof ServerLevel serverLevel)) {
                return InteractionResult.SUCCESS;
            }

            if (!(player instanceof ServerPlayer serverPlayer)) {
                return InteractionResult.PASS;
            }

            if (player.isSpectator()) {
                return InteractionResult.PASS;
            }

            if (player.getCooldowns().isOnCooldown(stack)) {
                LegendaryAbilities.AsmodaySpace.activate(
                        serverLevel,
                        serverPlayer,
                        stack
                );

                return InteractionResult.CONSUME;
            }

            boolean teleported =
                    LegendaryAbilities.AsmodaySpace.activate(
                            serverLevel,
                            serverPlayer,
                            stack
                    );

            return teleported
                    ? InteractionResult.SUCCESS
                    : InteractionResult.PASS;
        }
    }

    // TIME
    public static class HourglassOfIstaroth extends CatalystItem {

        public HourglassOfIstaroth(Properties properties) {
            super(properties);
        }

        @Override
        public void inventoryTick(
                ItemStack stack,
                ServerLevel level,
                Entity owner,
                EquipmentSlot slot
        ) {
            super.inventoryTick(stack, level, owner, slot);
            tickHeld(stack, level, owner, slot);
        }

        // ------------------------------------------------------------
        // ON HIT
        // ------------------------------------------------------------

        @Override
        public void hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {
            super.hurtEnemy(stack, target, attacker);

            if (!(attacker instanceof Player player)) {
                return;
            }

            if (!(attacker.level() instanceof ServerLevel level)) {
                return;
            }

            LegendaryEffects.istarothOnHit(
                    level,
                    player,
                    target
            );
        }

        // ------------------------------------------------------------
        // RIGHT CLICK — TEMPORAL BONEMEAL
        // ------------------------------------------------------------

        @Override
        public InteractionResult use(
                Level level,
                Player player,
                InteractionHand hand
        ) {
            ItemStack stack = player.getItemInHand(hand);

            if (!(level instanceof ServerLevel serverLevel)) {
                return InteractionResult.SUCCESS;
            }

            if (!(player instanceof ServerPlayer serverPlayer)) {
                return InteractionResult.PASS;
            }

            if (player.isSpectator()) {
                return InteractionResult.PASS;
            }

            boolean used =
                    LegendaryAbilities.IstarothTimeManipulation.utility(
                            serverLevel,
                            serverPlayer,
                            stack
                    );

            if (player.getCooldowns().isOnCooldown(stack)) {
                return InteractionResult.SUCCESS;
            }

            return used
                    ? InteractionResult.SUCCESS
                    : InteractionResult.PASS;
        }
    }

    // DEATH
    public static class ScytheOfRonova extends CatalystItem {

        public ScytheOfRonova(Properties properties) {
            super(properties);
        }

        @Override
        public void inventoryTick(
                ItemStack stack,
                ServerLevel level,
                Entity owner,
                EquipmentSlot slot
        ) {
            super.inventoryTick(
                    stack,
                    level,
                    owner,
                    slot
            );

            tickHeld(
                    stack,
                    level,
                    owner,
                    slot
            );

            if (!(owner instanceof ServerPlayer player)) {
                return;
            }

            /*
             * Never show the spear texture while the utility
             * is on cooldown.
             */
            if (player.getCooldowns().isOnCooldown(stack)) {
                stack.remove(
                        GileModDataComponents.RONOVA_SPEAR
                );

                return;
            }

            /*
             * The spear texture is only valid while the player
             * is actively holding right-click with this stack.
             *
             * If using has ended, immediately restore the normal
             * scythe texture.
             */
            if (!player.isUsingItem()
                    || player.getUseItem() != stack) {

                stack.remove(
                        GileModDataComponents.RONOVA_SPEAR
                );
            }
        }

        @Override
        public void hurtEnemy(
                ItemStack stack,
                LivingEntity target,
                LivingEntity attacker
        ) {
            super.hurtEnemy(
                    stack,
                    target,
                    attacker
            );

            if (!(attacker instanceof ServerPlayer player)) {
                return;
            }

            if (!(attacker.level() instanceof ServerLevel level)) {
                return;
            }

            LegendaryAbilities.RonovaLifeSteal.mortalExchange(
                    level,
                    player,
                    target,
                    stack
            );
        }

        @Override
        public ItemUseAnimation getUseAnimation(
                ItemStack stack
        ) {
            return ItemUseAnimation.SPEAR;
        }

        @Override
        public int getUseDuration(
                ItemStack stack,
                LivingEntity entity
        ) {
            return 72000;
        }

        @Override
        public InteractionResult use(
                Level level,
                Player player,
                InteractionHand hand
        ) {
            ItemStack stack =
                    player.getItemInHand(hand);

            if (player.isSpectator()) {
                return InteractionResult.PASS;
            }

            /*
             * Never display the spear while the utility
             * is cooling down.
             */
            if (player.getCooldowns().isOnCooldown(stack)) {
                stack.remove(
                        GileModDataComponents.RONOVA_SPEAR
                );

                return InteractionResult.PASS;
            }

            /*
             * Right-click is currently being held.
             * Switch this particular ItemStack to the
             * spear visual.
             */
            stack.set(
                    GileModDataComponents.RONOVA_SPEAR,
                    true
            );

            player.startUsingItem(hand);

            return InteractionResult.SUCCESS;
        }
    }

}