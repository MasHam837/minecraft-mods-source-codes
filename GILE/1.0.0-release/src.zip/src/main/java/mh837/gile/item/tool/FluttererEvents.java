package mh837.gile.item.tool;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;

public final class FluttererEvents {

    private FluttererEvents() {
    }

    public static void initialize() {

        ServerTickEvents.END_SERVER_TICK.register(server -> {

            for (ServerPlayer player : server.getPlayerList().getPlayers()) {

                if (FluttererUtil.isActive(player) && FluttererUtil.isFalling(player)) {
                    FluttererUtil.applySlowFalling(player);
                }
            }
        });
    }
}