package mh837.gile.mixin;

import mh837.gile.item.weapon.WeaponLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RepairItemRecipe;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(RepairItemRecipe.class)
public class UpgradeItemRecipeMixin {

    @Inject(method = "matches", at = @At("HEAD"), cancellable = true)
    private void gilemod$preventVanillaWeaponRepair(CraftingInput input, Level level, CallbackInfoReturnable<Boolean> cir) {
        // Scan the crafting grid for your mod's weapons
        for (int i = 0; i < input.size(); i++) {
            ItemStack stack = input.getItem(i);
            if (WeaponLevel.isWeapon(stack)) {
                // If it's your weapon, block vanilla's repair recipe from hijacking it
                cir.setReturnValue(false);
                return;
            }
        }
    }
}