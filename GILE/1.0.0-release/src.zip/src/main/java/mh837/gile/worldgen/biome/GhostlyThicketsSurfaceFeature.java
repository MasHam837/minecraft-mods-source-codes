package mh837.gile.worldgen.biome;

import com.mojang.serialization.Codec;
import mh837.gile.GileModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;

public class GhostlyThicketsSurfaceFeature extends Feature<SimpleBlockConfiguration> {

    public GhostlyThicketsSurfaceFeature(Codec<SimpleBlockConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<SimpleBlockConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        RandomSource random = context.random();

        boolean placed = false;
        int radius = 6;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double distSq = dx * dx + dz * dz;
                if (distSq > radius * radius) continue;

                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;

                double dist = Math.sqrt(distSq);
                double noise = Math.sin(x * 0.09) + Math.cos(z * 0.09) + Math.sin((x + z) * 0.05);
                noise *= 2.2;

                double warpedDist = dist + noise;
                double edge = 1.0 - (warpedDist / radius);
                edge = Mth.clamp(edge, 0.0, 1.0);

                if (edge <= 0.08) continue;

                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos groundPos = new BlockPos(x, y - 1, z);
                BlockPos topPos = groundPos.above();

                if (!level.getBlockState(groundPos).is(Blocks.END_STONE)) continue;

                level.setBlock(groundPos, GileModBlocks.END_GRASS_BLOCK.defaultBlockState(), 2);
                placed = true;

                if (level.isEmptyBlock(topPos)) {
                    double plantDensity = edge + (random.nextDouble() * 0.25);
                    if (plantDensity > 0.78 && random.nextFloat() < 0.45f) {
                        level.setBlock(topPos, GileModBlocks.TALL_END_GRASS.defaultBlockState(), 2);
                    } else if (plantDensity > 0.45 && random.nextFloat() < 0.75f) {
                        level.setBlock(topPos, GileModBlocks.END_GRASS.defaultBlockState(), 2);
                    }
                }
            }
        }
        return placed;
    }
}