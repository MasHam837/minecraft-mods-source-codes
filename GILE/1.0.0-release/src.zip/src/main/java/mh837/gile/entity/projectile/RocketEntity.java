package mh837.gile.entity.projectile;

import mh837.gile.GileModEntities;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class RocketEntity extends Projectile {
    private static final double SPEED = 0.85D, TARGET_RANGE = 32.0D, HOMING_STRENGTH = 0.18D;
    private static final float DAMAGE = 6.0F, EXPLOSION_POWER = 2.5F;
    private static final int MAX_LIFETIME = 200;

    private static final DustParticleOptions TRAIL_PARTICLE = new DustParticleOptions(0xFF6B35, 0.8F);
    private static final DustParticleOptions IMPACT_PARTICLE = new DustParticleOptions(0xFF3B12, 1.5F);

    public RocketEntity(EntityType<? extends RocketEntity> type, Level level) { super(type, level); }

    public RocketEntity(Level level, LivingEntity owner) {
        this(GileModEntities.ROCKET_ENTITY, level);
        setOwner(owner);
        setPos(owner.getX(), owner.getEyeY() - 0.1D, owner.getZ());
        setDeltaMovement(owner.getViewVector(1.0F).normalize().scale(SPEED));
        updateRotationFromMovement();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    @Override
    public void tick() {
        super.tick();
        if (tickCount > MAX_LIFETIME) { discard(); return; }

        if (!level().isClientSide()) {
            LivingEntity target = findNearestTarget();
            if (target != null) homeTowards(target);

            Vec3 v = getDeltaMovement();
            if (v.lengthSqr() > 0.0001D) setDeltaMovement(v.normalize().scale(SPEED));

            updateRotationFromMovement();

            HitResult hitResult = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
            if (hitResult.getType() != HitResult.Type.MISS) {
                onHit(hitResult);
                return;
            }
            setPos(getX() + v.x, getY() + v.y, getZ() + v.z);
        } else {
            for (int i = 0; i < 2; i++) {
                double ox = (random.nextDouble() - 0.5D) * 0.08D;
                double oy = (random.nextDouble() - 0.5D) * 0.08D;
                double oz = (random.nextDouble() - 0.5D) * 0.08D;
                level().addParticle(TRAIL_PARTICLE, getX() + ox, getY() + oy, getZ() + oz, 0.0D, 0.0D, 0.0D);
            }
            if (tickCount % 3 == 0) {
                level().addParticle(ParticleTypes.SMOKE, getX(), getY(), getZ(), 0.0D, 0.01D, 0.0D);
            }
        }
    }

    @Nullable
    private LivingEntity findNearestTarget() {
        double closestDist = TARGET_RANGE * TARGET_RANGE;
        LivingEntity closest = null;

        for (Player p : level().players()) {
            if (!isValidTarget(p)) continue;
            double d = distanceToSqr(p);
            if (d < closestDist) { closestDist = d; closest = p; }
        }

        for (AbstractVillager v : level().getEntitiesOfClass(AbstractVillager.class, getBoundingBox().inflate(TARGET_RANGE), this::isValidTarget)) {
            double d = distanceToSqr(v);
            if (d < closestDist) { closestDist = d; closest = v; }
        }

        return closest;
    }

    private boolean isValidTarget(LivingEntity e) {
        if (!e.isAlive() || e == getOwner()) return false;
        if (e instanceof Player player) {if (player.isCreative() || player.isSpectator()) return false;}
        return e instanceof Player || e instanceof AbstractVillager;
    }

    private void homeTowards(LivingEntity target) {
        Vec3 targetPos = target.position().add(0.0D, target.getBbHeight() * 0.55D, 0.0D);
        Vec3 diff = targetPos.subtract(position());
        if (diff.lengthSqr() < 0.0001D) return;

        Vec3 desired = diff.normalize();
        Vec3 current = getDeltaMovement();
        current = current.lengthSqr() < 0.0001D ? desired : current.normalize();

        setDeltaMovement(current.scale(1.0D - HOMING_STRENGTH).add(desired.scale(HOMING_STRENGTH)).normalize().scale(SPEED));
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        if (target == getOwner()) return;

        if (target instanceof LivingEntity lt) {
            lt.hurt(damageSources().mobProjectile(this, getOwner() instanceof LivingEntity owner ? owner : null), DAMAGE);
        }
        explode();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        explode();
        level().gameEvent(GameEvent.PROJECTILE_LAND, result.getLocation(), GameEvent.Context.of(this, null));
        discard();
    }

    private void explode() {
        if (!(level() instanceof ServerLevel sl)) return;

        double x = getX(), y = getY(), z = getZ();
        sl.explode(this, x, y, z, EXPLOSION_POWER, Level.ExplosionInteraction.MOB);

        sl.sendParticles(IMPACT_PARTICLE, x, y, z, 35, 0.35D, 0.35D, 0.35D, 0.08D);
        sl.sendParticles(ParticleTypes.SMOKE, x, y, z, 15, 0.25D, 0.25D, 0.25D, 0.05D);
        sl.sendParticles(ParticleTypes.FLAME, x, y, z, 12, 0.25D, 0.25D, 0.25D, 0.08D);
        sl.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 2, 0.1D, 0.1D, 0.1D, 0.0D);
        sl.playSound(null, x, y, z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 0.6F, 1.5F);

        discard();
    }

    private void updateRotationFromMovement() {
        Vec3 v = getDeltaMovement();
        if (v.lengthSqr() < 0.0001D) return;

        double horiz = Math.sqrt(v.x * v.x + v.z * v.z);
        setYRot(Mth.wrapDegrees((float) (Mth.atan2(v.z, v.x) * 180.0D / Math.PI) - 90.0F));
        setXRot((float) -(Mth.atan2(v.y, horiz) * 180.0D / Math.PI));
    }

    @Override
    protected boolean canHitEntity(Entity e) {
        return super.canHitEntity(e) && e != getOwner();
    }

    @Override
    protected double getDefaultGravity() {
        return 0.0D;
    }
}