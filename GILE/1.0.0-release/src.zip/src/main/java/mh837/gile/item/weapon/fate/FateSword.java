package mh837.gile.item.weapon.fate;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class FateSword extends Item {

    public FateSword(Properties properties) {
        super(properties);
    }

    @Override
    public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Call the parent method (returns void in 1.21.5+)
        super.hurtEnemy(stack, target, attacker);

        // Spawn particles and play sound on hit using attacker's server level
        if (attacker.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(
                    ParticleTypes.FIREWORK,
                    target.getX(),
                    target.getY() + target.getBbHeight() / 2.0f,
                    target.getZ(),
                    40,
                    0.5, 0.5, 0.5,
                    0.1
            );

            serverLevel.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.AMETHYST_BLOCK_BREAK,
                    SoundSource.PLAYERS,
                    1.0f,
                    1.0f
            );
        }
    }
}