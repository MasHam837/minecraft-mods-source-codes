package mh837.gile.item.weapon.elemental;

import mh837.gile.GileModParticleTypes;
import mh837.gile.entity.projectile.VentiArrowEntity;

import mh837.gile.item.weapon.WeaponLevel;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;
import java.util.function.Consumer;

public class ElementalWeaponItems {

    // ANEMO
    public static class DaybreakChronicles extends Item {
        private static final int MAX_DRAW_DURATION = 72000;
        private static final float ARROW_SPEED = 2.8F;
        private static final float ARROW_DIVERGENCE = 0.0F;

        public static final ParticleOptions ANEMO_DUST =
                new DustParticleOptions(0x5DE8D0, 1.25F);

        public class ElementalWeaponAttributes {

            public static ItemAttributeModifiers create(
                    double attackDamage,
                    double attackSpeed
            ) {
                return ItemAttributeModifiers.builder()
                        .add(
                                Attributes.ATTACK_DAMAGE,
                                new AttributeModifier(
                                        Item.BASE_ATTACK_DAMAGE_ID,
                                        attackDamage,
                                        AttributeModifier.Operation.ADD_VALUE
                                ),
                                EquipmentSlotGroup.MAINHAND
                        )
                        .add(
                                Attributes.ATTACK_SPEED,
                                new AttributeModifier(
                                        Item.BASE_ATTACK_SPEED_ID,
                                        attackSpeed,
                                        AttributeModifier.Operation.ADD_VALUE
                                ),
                                EquipmentSlotGroup.MAINHAND
                        )
                        .build();
            }

            public static ItemAttributeModifiers createBow() {
                return ItemAttributeModifiers.builder()
                        .build();
            }
        }

        private static int getMaxArrowDamage(int weaponLevel) {
            return weaponLevel + 7;
        }

        public DaybreakChronicles(Properties properties) {
            super(properties);
        }

        @Override
        public void appendHoverText(
                ItemStack stack,
                TooltipContext context,
                TooltipDisplay display,
                Consumer<Component> builder,
                TooltipFlag flag
        ) {
            super.appendHoverText(stack, context, display, builder, flag);

            WeaponLevel.appendLevelTooltip(stack, builder);
            builder.accept(Component.empty());

            builder.accept(
                    Component.translatable(
                            "tooltip.gilemod.daybreak_chronicles.when_in_hand"
                    ).withStyle(ChatFormatting.GRAY)
            );

            int weaponLevel = WeaponLevel.get(stack);

            int maxDamage = getMaxArrowDamage(weaponLevel);

            builder.accept(
                    Component.translatable(
                            "tooltip.gilemod.daybreak_chronicles.arrow_damage",
                            Component.literal(
                                    String.format(Locale.ROOT, "%d", maxDamage)
                            ).withStyle(ChatFormatting.DARK_GREEN)
                    ).withStyle(ChatFormatting.DARK_GREEN)
            );

            builder.accept(
                    Component.translatable(
                            "tooltip.gilemod.daybreak_chronicles.arrow_speed",
                            Component.literal("2.8")
                                    .withStyle(ChatFormatting.DARK_GREEN)
                    ).withStyle(ChatFormatting.DARK_GREEN)
            );
        }

        @Override
        public InteractionResult use(
                Level level,
                Player player,
                InteractionHand hand
        ) {
            player.startUsingItem(hand);
            return InteractionResult.CONSUME;
        }

        @Override
        public int getUseDuration(
                ItemStack stack,
                LivingEntity user
        ) {
            return MAX_DRAW_DURATION;
        }

        @Override
        public void inventoryTick(
                ItemStack stack,
                ServerLevel level,
                Entity entity,
                EquipmentSlot slot
        ) {
            super.inventoryTick(stack, level, entity, slot);

            if (!(entity instanceof Player player)) {
                return;
            }

            if (slot != EquipmentSlot.MAINHAND &&
                    slot != EquipmentSlot.OFFHAND) {
                return;
            }

            boolean mainHand = player.getMainHandItem() == stack;
            boolean offHand = player.getOffhandItem() == stack;

            if (!mainHand && !offHand) {
                return;
            }

            ElementalEffects.ventiFootParticles(level, player);
        }

        @Override
        public boolean releaseUsing(
                ItemStack stack,
                Level level,
                LivingEntity user,
                int remainingUseTicks
        ) {
            if (!(user instanceof Player player)) {
                return false;
            }

            int useTicks =
                    getUseDuration(stack, player) - remainingUseTicks;

            if (useTicks < 5) {
                return false;
            }

            float pullProgress = getPullProgress(useTicks);

            if (pullProgress < 0.1F) {
                return false;
            }

            if (!(level instanceof ServerLevel serverLevel)) {
                return false;
            }

            VentiArrowEntity arrow = new VentiArrowEntity(
                    serverLevel,
                    player,
                    ItemStack.EMPTY,
                    stack
            );

            arrow.setOwner(player);

            Vec3 look = player.getLookAngle();

            arrow.setPos(
                    player.getX() + look.x * 0.5D,
                    player.getEyeY() - 0.1D,
                    player.getZ() + look.z * 0.5D
            );

            arrow.shootFromRotation(
                    player,
                    player.getXRot(),
                    player.getYRot(),
                    0.0F,
                    ARROW_SPEED * pullProgress,
                    ARROW_DIVERGENCE
            );

            arrow.setVortexStrength(pullProgress);

            int weaponLevel = WeaponLevel.get(stack);

            arrow.setBaseDamage(
                    (2.0D + pullProgress * (5.0D + weaponLevel)) / 2.0D
            );

            arrow.setPushStrength(
                    1.05F + pullProgress * 1.05F
            );

            serverLevel.addFreshEntity(arrow);

            spawnReleaseEffect(
                    serverLevel,
                    player,
                    pullProgress
            );

            serverLevel.playSound(
                    null,
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    SoundEvents.ARROW_SHOOT,
                    SoundSource.PLAYERS,
                    1.0F,
                    0.75F + pullProgress * 0.4F
            );

            return true;
        }

        private static float getPullProgress(int charge) {
            float f = (float) charge / 20.0F;
            f = (f * f + f * 2.0F) / 3.0F;
            return Math.min(f, 1.0F);
        }

        private static void spawnReleaseEffect(
                ServerLevel level,
                Player player,
                float strength
        ) {
            double radius = 0.8D + strength * 1.2D;
            int count = 12 + (int) (strength * 20.0F);

            for (int i = 0; i < count; i++) {
                double angle =
                        Math.PI * 2.0D * i / count;

                double x =
                        player.getX()
                                + Math.cos(angle) * radius;

                double y =
                        player.getY()
                                + 0.8D
                                + Math.sin(angle * 2.0D) * 0.35D;

                double z =
                        player.getZ()
                                + Math.sin(angle) * radius;

                level.sendParticles(
                        ANEMO_DUST,
                        x,
                        y,
                        z,
                        1,
                        0.0D,
                        0.06D + strength * 0.08D,
                        0.0D,
                        0.02D
                );
            }

            level.sendParticles(
                    ParticleTypes.CLOUD,
                    player.getX(),
                    player.getY() + 0.15D,
                    player.getZ(),
                    10 + (int) (strength * 10.0F),
                    0.65D + strength * 0.3D,
                    0.15D,
                    0.65D + strength * 0.3D,
                    0.04D
            );

            if (strength >= 0.95F) {
                level.sendParticles(
                        ParticleTypes.GUST,
                        player.getX(),
                        player.getY() + 0.6D,
                        player.getZ(),
                        8,
                        0.8D,
                        0.4D,
                        0.8D,
                        0.15D
                );

                level.playSound(
                        null,
                        player.getX(),
                        player.getY(),
                        player.getZ(),
                        SoundEvents.BREEZE_CHARGE,
                        SoundSource.PLAYERS,
                        1.0F,
                        0.7F
                );
            }
        }

        @Override
        public ItemUseAnimation getUseAnimation(ItemStack stack) {
            return ItemUseAnimation.BOW;
        }
    }

    // GEO
    public static class VortexVanquisher extends Item { public VortexVanquisher(Properties properties) { super(properties); }

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag flag) {
            super.appendHoverText(stack, context, display, builder, flag); WeaponLevel.appendLevelTooltip(stack, builder);
        }

        @Override
        public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {super.hurtEnemy(stack, target, attacker);
            target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 0, false, true, true));
            if (attacker.level() instanceof ServerLevel level) {
                double x = target.getX(), y = target.getY() + target.getBbHeight() * 0.5D, z = target.getZ();
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()), x, y, z,
                        12, .32D, .42D, .32D, .14D);
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()), x, y, z,
                        8, .38D, .30D, .38D, .10D);
                level.sendParticles(ParticleTypes.CLOUD, x, y, z, 12, .35D, .40D, .35D, .045D);
                level.sendParticles(ParticleTypes.GUST, x, y + .15D, z, 5, .30D, .30D, .30D, .08D);
                level.sendParticles(ParticleTypes.CRIT, x, y, z, 8, .30D, .35D, .30D, .12D);
                level.playSound(null, x, y, z, SoundEvents.STONE_HIT, SoundSource.PLAYERS, 1.0F, .65F + level.getRandom().nextFloat() * .25F);
                level.playSound(null, x, y, z, SoundEvents.ROOTED_DIRT_BREAK, SoundSource.PLAYERS, .65F, .75F + level.getRandom().nextFloat() * .2F);
                ElementalEffects.spawnZhongLiAttackEffect(level, attacker, target);}}
    }

    // ELECTRO
    public static class EngulfingLightning extends Item { public EngulfingLightning(Properties properties) {super(properties);}

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag flag) {
            super.appendHoverText(stack, context, display, builder, flag); WeaponLevel.appendLevelTooltip(stack, builder);
        }

        @Override
        public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {

            super.hurtEnemy(stack, target, attacker);

            if (attacker.level() instanceof ServerLevel level) {

                // 1. Play the standard attack particles on every hit
                spawnRaidenAttackParticles(level, target);

                // 2. 50% chance to trigger the massive lightning strike
                if (level.getRandom().nextFloat() < 0.5f) {
                    // Summon actual lightning
                    LightningBolt bolt = new LightningBolt(EntityType.LIGHTNING_BOLT, level);
                    bolt.setPos(target.getX(), target.getY(), target.getZ());
                    if (attacker instanceof ServerPlayer player) {
                        bolt.setCause(player);
                    }
                    level.addFreshEntity(bolt);

                    // Spawn the intense visual and sound effects
                    spawnRaidenAttackEffect(level, attacker, target);

                    // Keep your original beacon sound for that extra sci-fi/magical pop
                    Vec3 p = target.position().add(0, target.getBbHeight() * 0.5D, 0);
                    level.playSound(null, p.x, p.y, p.z, SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1F, 0.5F);
                }
            }
        }

        public static void spawnRaidenAttackEffect(ServerLevel level, LivingEntity attacker, LivingEntity target) {
            double x = target.getX();
            double y = target.getY() + target.getBbHeight() * 0.5D;
            double z = target.getZ();

            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 55, 0.65D, 0.75D, 0.65D, 0.35D);
            level.sendParticles(ParticleTypes.END_ROD, x, y, z, 25, 0.45D, 0.6D, 0.45D, 0.12D);
            level.sendParticles(ParticleTypes.CRIT, x, y, z, 20, 0.5D, 0.65D, 0.5D, 0.2D);
            level.sendParticles(ParticleTypes.CLOUD, x, target.getY() + 0.15D, z, 12, 0.55D, 0.12D, 0.55D, 0.045D);

            for (int i = 0; i < 4; i++) {
                double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
                double radius = 0.35D + level.getRandom().nextDouble() * 0.9D;
                double px = x + Math.cos(angle) * radius;
                double pz = z + Math.sin(angle) * radius;
                double py = target.getY() + 0.1D + level.getRandom().nextDouble() * 1.5D;

                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, px, py, pz, 8, 0.08D, 0.15D, 0.08D, 0.3D);
            }

            if (attacker != null) {
                double ax = attacker.getX();
                double ay = attacker.getY() + attacker.getBbHeight() * 0.5D;
                double az = attacker.getZ();

                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, ax, ay, az, 18, 0.35D, 0.45D, 0.35D, 0.25D);
            }

            level.playSound(null, x, y, z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.8F, 1.35F);
            level.playSound(null, x, y, z, SoundEvents.TRIDENT_THUNDER, SoundSource.PLAYERS, 0.5F, 1.5F);
        }

        public static void spawnRaidenAttackParticles(ServerLevel level, LivingEntity target) {
            double x = target.getX();
            double y = target.getY() + target.getBbHeight() * 0.45D;
            double z = target.getZ();

            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            double radius = 0.25D + level.getRandom().nextDouble() * 0.8D;
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            double py = target.getY() + 0.05D + level.getRandom().nextDouble() * target.getBbHeight();

            // Custom Electro particles
            level.sendParticles(GileModParticleTypes.ELECTRO, px, py, pz, 5, 0.06D, 0.12D, 0.06D, 0.28D);

            // Occasional ambient sparks
            if (level.getRandom().nextBoolean()) {
                level.sendParticles(ParticleTypes.END_ROD, x, y, z, 2, 0.25D, 0.3D, 0.25D, 0.1D);
            }
        }
    }

    // DENDRO
    public static class ThousandFloatingDreams extends Item { public ThousandFloatingDreams(Properties properties) {super(properties);}

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag flag) {
            super.appendHoverText(stack, context, display, builder, flag); WeaponLevel.appendLevelTooltip(stack, builder);
        }

        @Override
        public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {super.hurtEnemy(stack, target, attacker);
            if (attacker.level() instanceof ServerLevel level) {
                target.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 1, false, true, true));
                ElementalEffects.spawnNahidaAttackEffect(level, attacker, target);}
        }
    }

    // HYDRO
    public static class SplendorOfTranquilWaters extends Item { public SplendorOfTranquilWaters(Properties properties) {super(properties);}

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag flag) {
            super.appendHoverText(stack, context, display, builder, flag); WeaponLevel.appendLevelTooltip(stack, builder);
        }

        @Override
        public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {super.hurtEnemy(stack, target, attacker);
            if (attacker instanceof ServerPlayer player && attacker.level() instanceof ServerLevel level) {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 0, false, false));
                ElementalEffects.spawnFurinaFootWaves(level, player);ElementalEffects.spawnFurinaAttackEffect(level, player, target);}
        }

    }

    // PYRO
    public static class ThousandBlazingSuns extends Item { public ThousandBlazingSuns(Properties properties) {super(properties);}

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag flag) {
            super.appendHoverText(stack, context, display, builder, flag); WeaponLevel.appendLevelTooltip(stack, builder);
        }

        @Override
        public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), 100));
            if (attacker.level() instanceof ServerLevel serverLevel) {
                ElementalEffects.spawnMavuikaAttackEffect(serverLevel, attacker, target);}
        }
    }

    // CRYO
    public static class HiemalMandate extends Item { public HiemalMandate(Properties properties) { super(properties); }

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag flag) {
            super.appendHoverText(stack, context, display, builder, flag); WeaponLevel.appendLevelTooltip(stack, builder);
        }

        @Override
        public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
            super.inventoryTick(stack, level, entity, slot);
            if (!(entity instanceof LivingEntity living)) return;
            if (slot != EquipmentSlot.MAINHAND && slot != EquipmentSlot.OFFHAND) return;
            living.setTicksFrozen(0); living.setOnGround(true);
            int radius = 2; BlockPos center = living.blockPosition();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dz * dz <= radius * radius) {
                        BlockPos pos = center.offset(dx, -1, dz);
                        if (level.getBlockState(pos).is(Blocks.WATER)) {level.setBlock(
                                pos, Blocks.FROSTED_ICE.defaultBlockState(), 3);}}}}
            BlockState below = level.getBlockState(center.below());
            if (below.is(Blocks.ICE) || below.is(Blocks.FROSTED_ICE) || below.is(Blocks.PACKED_ICE) || below.is(Blocks.BLUE_ICE)) {
                living.addEffect(new MobEffectInstance(MobEffects.SPEED, 10, 1, false, false, true));
                if (living.getDeltaMovement().horizontalDistanceSqr() > 0.01D) {ElementalEffects.tsaritsaFootParticles(level, living);}}
        }

        @Override
        public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (attacker.level() instanceof ServerLevel serverLevel) {
                ElementalEffects.spawnTsaritsaAttackEffect(serverLevel, attacker, target);
                target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1, false, true, true));
            }
        }
    }

    // LUNA
    public static class NocturnesCurtainCall extends Item { public NocturnesCurtainCall(Properties properties) { super(properties); }

        @Override
        public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> builder, TooltipFlag flag) {
            super.appendHoverText(stack, context, display, builder, flag); WeaponLevel.appendLevelTooltip(stack, builder);
        }

        private static final Identifier GRAVITY_MODIFIER_ID =
                Identifier.fromNamespaceAndPath("gilemod", "nocturnes_curtain_call_gravity");
        private static final Identifier JUMP_STRENGTH_MODIFIER_ID =
                Identifier.fromNamespaceAndPath("gilemod", "nocturnes_curtain_call_jump_strength");

        private static final double GRAVITY_REDUCTION = -0.92D;
        private static final double JUMP_BUFF = -0.58D;

        @Override
        public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
            super.inventoryTick(stack, level, entity, slot);
            if (!(entity instanceof LivingEntity living)) return;

            var gravity = living.getAttribute(Attributes.GRAVITY);
            var jump = living.getAttribute(Attributes.JUMP_STRENGTH);
            if (gravity == null || jump == null) return;

            boolean holding = slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND;

            if (holding) {
                if (!gravity.hasModifier(GRAVITY_MODIFIER_ID)) {
                    gravity.addTransientModifier(new AttributeModifier(
                            GRAVITY_MODIFIER_ID,
                            GRAVITY_REDUCTION,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                }

                if (!jump.hasModifier(JUMP_STRENGTH_MODIFIER_ID)) {
                    jump.addTransientModifier(new AttributeModifier(
                            JUMP_STRENGTH_MODIFIER_ID,
                            JUMP_BUFF,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                }
            } else {
                if (gravity.hasModifier(GRAVITY_MODIFIER_ID))
                    gravity.removeModifier(GRAVITY_MODIFIER_ID);

                if (jump.hasModifier(JUMP_STRENGTH_MODIFIER_ID))
                    jump.removeModifier(JUMP_STRENGTH_MODIFIER_ID);
            }

            if (level.isClientSide() || !holding) return;

            if (living.getDeltaMovement().horizontalDistanceSqr() > 0.005D) {
                Vec3 motion = living.getDeltaMovement();
                Vec3 back = motion.lengthSqr() > 0.0001D
                        ? motion.normalize().scale(-0.28D)
                        : Vec3.ZERO;

                level.sendParticles(
                        ParticleTypes.END_ROD,
                        living.getX() + back.x,
                        living.getY() + 0.12D,
                        living.getZ() + back.z,
                        1, 0.08D, 0.04D, 0.08D, 0.008D);

                if (level.getGameTime() % 4L == 0L)
                    level.sendParticles(
                            ParticleTypes.END_ROD,
                            living.getX(),
                            living.getY() + 0.2D,
                            living.getZ(),
                            2, 0.22D, 0.12D, 0.22D, 0.012D);
            }
        }

        private static void removeNocturneModifiers(LivingEntity living) {
            var gravity = living.getAttribute(Attributes.GRAVITY);
            var jump = living.getAttribute(Attributes.JUMP_STRENGTH);

            if (gravity != null && gravity.hasModifier(GRAVITY_MODIFIER_ID))
                gravity.removeModifier(GRAVITY_MODIFIER_ID);

            if (jump != null && jump.hasModifier(JUMP_STRENGTH_MODIFIER_ID))
                jump.removeModifier(JUMP_STRENGTH_MODIFIER_ID);
        }

        public static void cleanupNocturneModifiers(ServerLevel level) {
            for (ServerPlayer player : level.players()) {
                boolean holding = player.getMainHandItem().getItem() instanceof NocturnesCurtainCall
                        || player.getOffhandItem().getItem() instanceof NocturnesCurtainCall;

                if (!holding)
                    removeNocturneModifiers(player);
            }
        }

        @Override
        public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (attacker.level() instanceof ServerLevel level) {
                target.removeEffect(MobEffects.SLOW_FALLING);
                target.addEffect(new MobEffectInstance(
                        MobEffects.LEVITATION, 40, 1, false, true, true));
                ElementalEffects.spawnNocturneAttackEffect(level, target);
            }
        }
    }

}