package mh837.gile.block;

import mh837.gile.GileModBlockEntities;
import mh837.gile.block.entity.MoonCampfireBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public class MoonCampfireBlock extends CampfireBlock {
    public MoonCampfireBlock(boolean spawnParticles, int fireDamage, BlockBehaviour.Properties properties) {
        super(spawnParticles, fireDamage, properties);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MoonCampfireBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
        if (level instanceof ServerLevel serverLevel) {
            if (state.getValue(LIT)) {
                return createTickerHelper(
                        blockEntityType,
                        GileModBlockEntities.MOON_CAMPFIRE_ENTITY,
                        (l, pos, s, entity) -> MoonCampfireBlockEntity.cookTick(
                                serverLevel,
                                pos,
                                s,
                                entity,
                                serverLevel.recipeAccess().createCheck(RecipeType.CAMPFIRE_COOKING)
                        )
                );
            } else {
                return createTickerHelper(
                        blockEntityType,
                        GileModBlockEntities.MOON_CAMPFIRE_ENTITY,
                        MoonCampfireBlockEntity::cooldownTick
                );
            }
        } else {
            return state.getValue(LIT)
                    ? createTickerHelper(
                    blockEntityType,
                    GileModBlockEntities.MOON_CAMPFIRE_ENTITY,
                    MoonCampfireBlockEntity::particleTick
            )
                    : null;
        }
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof MoonCampfireBlockEntity moonCampfireBE) {
            var itemStack = player.getItemInHand(InteractionHand.MAIN_HAND);
            if (!level.isClientSide() && level instanceof ServerLevel serverLevel) {
                if (moonCampfireBE.placeFood(serverLevel, player, itemStack)) {
                    return InteractionResult.SUCCESS;
                }
            } else {
                return InteractionResult.SUCCESS;
            }
        }
        return InteractionResult.PASS;
    }
}