package mh837.gile.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record LegendaryAbilityPayload() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<LegendaryAbilityPayload> TYPE =
            new CustomPacketPayload.Type<>(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "legendary_ability"
                    )
            );

    public static final StreamCodec<RegistryFriendlyByteBuf, LegendaryAbilityPayload> CODEC =
            StreamCodec.unit(new LegendaryAbilityPayload());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}