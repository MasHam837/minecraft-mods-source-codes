package mh837.gile.worldgen.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;

public class CloudBlobFeature extends Feature<SimpleBlockConfiguration> {
    public CloudBlobFeature(Codec<SimpleBlockConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<SimpleBlockConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        RandomSource random = context.random();
        SimpleBlockConfiguration config = context.config();

        int heightOffset = random.nextInt(11) + 15;
        BlockPos center = origin.above(heightOffset);

        int radiusX = 3 + random.nextInt(3);
        int radiusZ = 3 + random.nextInt(3);

        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();

        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                if (Math.abs(dx) == radiusX || Math.abs(dz) == radiusZ) {
                    if (random.nextFloat() > 0.6f) continue;
                }
                if (Math.abs(dx) == radiusX && Math.abs(dz) == radiusZ) {
                    if (random.nextFloat() > 0.3f) continue;
                }

                mutable.setWithOffset(center, dx, 0, dz);

                if (level.isEmptyBlock(mutable)) {
                    level.setBlock(mutable, config.toPlace().getState(level, random, mutable), 3);
                }
            }
        }
        return true;
    }
}