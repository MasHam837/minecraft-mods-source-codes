package mh837.gile.worldgen.feature;

import mh837.gile.GileModBlocks;
import mh837.gile.block.GlowingChorusPlantBlock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.ChorusFlowerBlock;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import static mh837.gile.GileModTags.Blocks.GLOWING_CHORUS_SUPPORT;

public class GlowingChorusFeature extends Feature<NoneFeatureConfiguration> {

    public GlowingChorusFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        LevelAccessor level = context.level();
        BlockPos origin = context.origin();
        RandomSource random = context.random();

        // Must be able to start on a valid support block.
        if (!level.getBlockState(origin.below()).is(GLOWING_CHORUS_SUPPORT)) {
            return false;
        }

        generatePlant(level, origin, random, 4);
        return true;
    }

    public static void generatePlant(
            LevelAccessor level,
            BlockPos target,
            RandomSource random,
            int maxHorizontalSpread
    ) {
        setPlant(level, target);
        growTreeRecursive(
                level,
                target,
                random,
                target,
                maxHorizontalSpread,
                0
        );
    }

    private static void growTreeRecursive(
            LevelAccessor level,
            BlockPos current,
            RandomSource random,
            BlockPos startPos,
            int maxHorizontalSpread,
            int depth
    ) {
        int height = random.nextInt(4) + 1;

        if (depth == 0) {
            ++height;
        }

        for (int i = 0; i < height; ++i) {
            BlockPos target = current.above(i + 1);

            if (!allNeighborsEmpty(level, target, null)) {
                return;
            }

            setPlant(level, target);
            setPlant(level, target.below());
        }

        boolean placedStem = false;

        if (depth < 4) {
            int stems = random.nextInt(4);

            if (depth == 0) {
                ++stems;
            }

            for (int i = 0; i < stems; ++i) {
                Direction direction =
                        Direction.Plane.HORIZONTAL.getRandomDirection(random);

                BlockPos target =
                        current.above(height).relative(direction);

                if (Math.abs(target.getX() - startPos.getX())
                        < maxHorizontalSpread
                        && Math.abs(target.getZ() - startPos.getZ())
                        < maxHorizontalSpread
                        && level.isEmptyBlock(target)
                        && level.isEmptyBlock(target.below())
                        && allNeighborsEmpty(
                        level,
                        target,
                        direction.getOpposite())) {

                    placedStem = true;

                    setPlant(level, target);

                    setPlant(
                            level,
                            target.relative(direction.getOpposite())
                    );

                    growTreeRecursive(
                            level,
                            target,
                            random,
                            startPos,
                            maxHorizontalSpread,
                            depth + 1
                    );
                }
            }
        }

        if (!placedStem) {
            BlockPos flowerPos = current.above(height);

            level.setBlock(
                    flowerPos,
                    GileModBlocks.GLOWING_CHORUS_FLOWER
                            .defaultBlockState()
                            .setValue(
                                    ChorusFlowerBlock.AGE,
                                    ChorusFlowerBlock.DEAD_AGE
                            ),
                    2
            );
        }
    }

    private static void setPlant(LevelAccessor level, BlockPos pos) {
        level.setBlock(
                pos,
                GlowingChorusPlantBlock.getGlowingStateWithConnections(
                        level,
                        pos,
                        GileModBlocks.GLOWING_CHORUS_PLANT.defaultBlockState()
                ),
                2
        );
    }

    private static boolean allNeighborsEmpty(
            LevelAccessor level,
            BlockPos pos,
            Direction ignore
    ) {
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            if (direction != ignore
                    && !level.isEmptyBlock(pos.relative(direction))) {
                return false;
            }
        }

        return true;
    }
}