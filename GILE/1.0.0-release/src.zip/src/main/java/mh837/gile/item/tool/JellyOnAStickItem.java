package mh837.gile.item.tool;

import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ItemSteerable;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

public class JellyOnAStickItem extends Item {
    public JellyOnAStickItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        if (player.getVehicle() instanceof ItemSteerable itemSteerable) {

            if (itemSteerable.boost()) {

                if (!level.isClientSide() && !player.getAbilities().instabuild) {
                    EquipmentSlot equipmentSlot = hand == InteractionHand.MAIN_HAND ?
                            EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND;

                    if (level instanceof ServerLevel serverLevel
                            && player instanceof ServerPlayer serverPlayer) {

                        int damage = serverLevel.getRandom().nextInt(7) + 1;

                        itemStack.hurtAndBreak(damage, serverLevel, serverPlayer, brokenItem -> {
                            serverPlayer.onEquippedItemBroken(brokenItem, equipmentSlot);
                        });
                    }

                    if (itemStack.isEmpty()) {
                        ItemStack fishingRod = new ItemStack(Items.FISHING_ROD);

                        CustomData customData = itemStack.get(DataComponents.CUSTOM_DATA);
                        if (customData != null) {
                            fishingRod.set(DataComponents.CUSTOM_DATA, customData);
                        }

                        return InteractionResult.SUCCESS.heldItemTransformedTo(fishingRod);
                    }
                }

                return InteractionResult.SUCCESS;
            }
        }

        return InteractionResult.PASS;
    }
}