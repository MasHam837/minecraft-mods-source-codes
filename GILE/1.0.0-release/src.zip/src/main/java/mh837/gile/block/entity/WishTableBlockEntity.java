package mh837.gile.block.entity;

import mh837.gile.GileModBlockEntities;
import mh837.gile.GileModItems;
import mh837.gile.GileModTags;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

import static net.minecraft.world.level.block.Block.popResource;

public class WishTableBlockEntity extends BlockEntity implements MenuProvider, WorldlyContainer {

    public static final int WISH_SLOT = 0;
    public static final int SIGIL_SLOT = 1;
    public static final int MAIN_OUTPUT_SLOT = 2;
    public static final int COMPLEMENTARY_OUTPUT_SLOT = 3;

    private static final int SLOT_COUNT = 4;

    // 5 seconds at 20 ticks per second.
    public static final int WISH_DURATION = 100;

    /*
     * ContainerData indices.
     *
     * 0 = current 5-second timer
     * 1 = timer duration
     * 2 = current rarity
     * 3 = permanent progress
     * 4 = whether a wish is currently processing
     */

    private static final int DATA_TIMER = 0;
    private static final int DATA_DURATION = 1;
    private static final int DATA_RARITY = 2;
    private static final int DATA_PERMANENT_PROGRESS = 3;
    private static final int DATA_PROCESSING = 4;

    private final ItemStack[] items = new ItemStack[SLOT_COUNT];

    private int wishProgress = 0;
    private int permanentProgress = 0;

    private WishRarity currentRarity = WishRarity.NONE;

    private boolean working = false;

    private final ContainerData data = new ContainerData() {

        @Override
        public int get(int index) {return switch (index) {
                case DATA_TIMER -> wishProgress; case DATA_DURATION -> WISH_DURATION; case DATA_RARITY -> currentRarity.getId();
                case DATA_PERMANENT_PROGRESS -> permanentProgress; case DATA_PROCESSING -> working ? 1 : 0;default -> 0;};}

        @Override
        public void set(int index, int value) {switch (index) {
                case DATA_TIMER -> wishProgress = value; case DATA_RARITY -> currentRarity = WishRarity.fromId(value);
                case DATA_PERMANENT_PROGRESS -> permanentProgress = value; case DATA_PROCESSING -> working = value != 0;}}

        @Override
        public int getCount() {
            return 5;
        }};

    private static final List<Item> ELEMENTAL_WEAPONS = List.of(
            GileModItems.DAYBREAK_CHRONICLES,
            GileModItems.VORTEX_VANQUISHER,
            GileModItems.ENGULFING_LIGHTNING,
            GileModItems.THOUSAND_FLOATING_DREAMS,
            GileModItems.SPLENDOR_OF_TRANQUIL_WATERS,
            GileModItems.THOUSAND_BLAZING_SUNS,
            GileModItems.HIEMAL_MANDATE,
            GileModItems.NOCTURNES_CURTAIN_CALL
    );

    private static final List<Item> LEGENDARY_WEAPONS = List.of(
            GileModItems.TOME_OF_NABERIUS, GileModItems.PALM_OF_ASMODAY, GileModItems.HOURGLASS_OF_ISTAROTH, GileModItems.SCYTHE_OF_RONOVA);

    private Item getWeaponForSigil(ItemStack sigil) {
        if (sigil.is(GileModItems.ANEMO_SIGIL)) {return GileModItems.DAYBREAK_CHRONICLES;}
        if (sigil.is(GileModItems.GEO_SIGIL)) {return GileModItems.VORTEX_VANQUISHER;}
        if (sigil.is(GileModItems.ELECTRO_SIGIL)) {return GileModItems.ENGULFING_LIGHTNING;}
        if (sigil.is(GileModItems.DENDRO_SIGIL)) {return GileModItems.THOUSAND_FLOATING_DREAMS;}
        if (sigil.is(GileModItems.HYDRO_SIGIL)) {return GileModItems.SPLENDOR_OF_TRANQUIL_WATERS;}
        if (sigil.is(GileModItems.PYRO_SIGIL)) {return GileModItems.THOUSAND_BLAZING_SUNS;}
        if (sigil.is(GileModItems.CRYO_SIGIL)) {return GileModItems.HIEMAL_MANDATE;}
        if (sigil.is(GileModItems.LUNA_SIGIL)) {return GileModItems.NOCTURNES_CURTAIN_CALL;}
        return null;}

    private ItemStack getRandomAlternateWeapon(Item desiredWeapon, RandomSource random) {
        List<Item> alternatives = ELEMENTAL_WEAPONS.stream().filter(item -> item != desiredWeapon).toList();
        Item alternate = alternatives.get(random.nextInt(alternatives.size()));return new ItemStack(alternate);}

    private Item desiredWeaponForWish = null;

    public WishTableBlockEntity(BlockPos pos, BlockState state) {super(GileModBlockEntities.WISH_TABLE_BLOCK_ENTITY, pos, state);
        for (int i = 0; i < SLOT_COUNT; i++) {items[i] = ItemStack.EMPTY;}}

    @Override
    public Component getDisplayName() {return Component.translatable("container.gilemod.wish_table");}

    @Override
    public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {return new WishTableScreenHandler(syncId, playerInventory, this);}

    // =========================================================
// TICK
// =========================================================

    public static void tick(
            Level level,
            BlockPos pos,
            BlockState state,
            WishTableBlockEntity table
    ) {
        if (level.isClientSide()) {
            return;
        }

        if (!table.working) {
            table.tryStartWish();
            return;
        }

        table.wishProgress++;

        // Continuous rarity particles while processing.
        table.playRarityEffect();

        table.setChanged();

        // The 5-second wish has finished.
        // Play the larger completion burst BEFORE finishWish()
        // resets currentRarity.
        if (table.wishProgress >= WISH_DURATION) {
            table.playWishCompletionBurst();
            table.finishWish();
        }
    }

    // =========================================================
    // TRIGGER STARTED ADVANCEMENT
    // =========================================================

    private void triggerWishAdvancement() {
        if (!(level instanceof ServerLevel serverLevel)) {return;} double radius = 10.0; double radiusSquared = radius * radius;
        for (ServerPlayer player : serverLevel.players()) {if (player.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5
        ) <= radiusSquared) {GileModTriggers.MAKE_A_WISH.trigger(player);}}
    }

    // =========================================================
// TRY START WISH
// =========================================================

    private void tryStartWish() {
        if (working) {
            return;
        }

        ItemStack wish = getItem(WISH_SLOT);
        ItemStack sigil = getItem(SIGIL_SLOT);

        if (wish.isEmpty() || sigil.isEmpty()) {
            return;
        }

        // Don't start if outputs cannot accept the next result.
        if (!getItem(MAIN_OUTPUT_SLOT).isEmpty()
                || !getItem(COMPLEMENTARY_OUTPUT_SLOT).isEmpty()) {
            return;
        }

        RandomSource random = getLevel().getRandom();

        // Determine rarity.
        int roll = random.nextInt(100);

        if (roll < 80) {
            currentRarity = WishRarity.COMMON;
        } else if (roll < 97) {
            currentRarity = WishRarity.RARE;
        } else {
            currentRarity = WishRarity.LEGENDARY;
        }

        // Remember which weapon belongs to this sigil.
        desiredWeaponForWish = getWeaponForSigil(sigil);

        // Consume exactly ONE wish.
        removeItem(WISH_SLOT, 1);

        // Start the 5-second process.
        wishProgress = 0;
        working = true;

        setChanged();

        // Trigger advancement.
        triggerWishAdvancement();
    }

    // =========================================================
// FINISH WISH
// =========================================================

    private void finishWish() {
        if (level == null) {
            return;
        }

        RandomSource random = level.getRandom();

        // =====================================================
        // PERMANENT PROGRESS
        // =====================================================

        if (currentRarity == WishRarity.COMMON) {
            // 2-4%
            permanentProgress += 2 + random.nextInt(3);

        } else if (currentRarity == WishRarity.RARE) {
            // 12-16%
            permanentProgress += 12 + random.nextInt(5);

        } else if (currentRarity == WishRarity.LEGENDARY) {
            // 36-48%
            permanentProgress += 36 + random.nextInt(13);
        }

        if (permanentProgress > 100) {
            permanentProgress = 100;
        }

        // =====================================================
        // WISH ACCOMPLISHED
        // =====================================================

        if (permanentProgress >= 100) {

            Item desiredWeapon = desiredWeaponForWish;

            if (desiredWeapon != null) {

                int roll = random.nextInt(100);

                if (roll < 60) {
                    // 60% — desired weapon.
                    giveOutput(
                            new ItemStack(desiredWeapon),
                            false
                    );

                } else if (roll < 85) {
                    // 25% — another elemental weapon.
                    giveOutput(
                            getRandomAlternateWeapon(
                                    desiredWeapon,
                                    random
                            ),
                            false
                    );

                } else {
                    // 15% — secret legendary weapon.
                    Item legendary =
                            LEGENDARY_WEAPONS.get(
                                    random.nextInt(
                                            LEGENDARY_WEAPONS.size()
                                    )
                            );

                    giveOutput(
                            new ItemStack(legendary),
                            false
                    );
                }

                // Successful accomplishment resets the permanent bar.
                permanentProgress = 0;

                // Successful wish gives 10 Star Shine.
                giveOutput(
                        new ItemStack(
                                GileModItems.STAR_SHINE,
                                10
                        ),
                        true
                );

                // Special effect ONLY for reaching 100%.
                playWishSuccessEffect();
            }

        } else {

            // =================================================
            // INCOMPLETE WISH
            // =================================================

            int dustCount = switch (currentRarity) {
                case COMMON -> 1;
                case RARE -> 1 + random.nextInt(2);
                case LEGENDARY -> 2 + random.nextInt(2);
                default -> 1;
            };

            giveOutput(
                    new ItemStack(
                            GileModItems.STAR_DUST,
                            dustCount
                    ),
                    true
            );
        }

        // =====================================================
        // RESET CURRENT WISH
        // =====================================================

        wishProgress = 0;
        currentRarity = WishRarity.NONE;
        desiredWeaponForWish = null;
        working = false;

        setChanged();
    }

    // =========================================================
// OUTPUT
// =========================================================

    private void giveOutput(
            ItemStack stack,
            boolean complementary
    ) {
        int slot = complementary
                ? COMPLEMENTARY_OUTPUT_SLOT
                : MAIN_OUTPUT_SLOT;

        ItemStack existing = getItem(slot);

        if (existing.isEmpty()) {
            setItem(slot, stack);
            return;
        }

        if (ItemStack.isSameItemSameComponents(
                existing,
                stack
        ) && existing.getCount() + stack.getCount()
                <= existing.getMaxStackSize()) {

            existing.grow(stack.getCount());
            setChanged();
            return;
        }

        if (level != null && !level.isClientSide()) {
            popResource(
                    level,
                    worldPosition,
                    stack
            );
        }
    }

    // GUI DATA
    public ContainerData getData() {return data;}

    // CONTAINER
    @Override
    public int getContainerSize() {return SLOT_COUNT;}

    @Override
    public boolean isEmpty() {for (ItemStack stack : items) {if (!stack.isEmpty()) {return false;}}return true;}

    @Override
    public ItemStack getItem(int slot) {return items[slot];}

    @Override
    public ItemStack removeItem(int slot, int amount) { ItemStack stack = items[slot]; if (stack.isEmpty()) {return ItemStack.EMPTY;}
        int removed = Math.min(amount, stack.getCount()); ItemStack result = stack.split(removed);
        if (stack.isEmpty()) {items[slot] = ItemStack.EMPTY;} setChanged();
        if (level != null && !level.isClientSide()) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);}return result;}

    @Override
    public ItemStack removeItemNoUpdate(int slot) {ItemStack result = items[slot]; items[slot] = ItemStack.EMPTY; setChanged();
        if (level != null && !level.isClientSide()) {level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);}
        return result;}

    @Override
    public void setItem(int slot, ItemStack stack) {
        if (stack.getCount() > stack.getMaxStackSize()) {stack.setCount(stack.getMaxStackSize());} items[slot] = stack; setChanged();
        if (level != null && !level.isClientSide()) {level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);}}

    @Override
    public boolean stillValid(Player player) {return player.distanceToSqr(
            worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) <= 64.0;}

    @Override
    public void setChanged() {super.setChanged();}

    @Override
    public void clearContent() {for (int i = 0; i < SLOT_COUNT; i++) {items[i] = ItemStack.EMPTY;}setChanged();}

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {return false;}

    @Override
    protected void saveAdditional(ValueOutput output) {super.saveAdditional(output);
        output.putInt("PermanentProgress", permanentProgress);
        for (int i = 0; i < SLOT_COUNT; i++) {ItemStack stack = items[i];
            if (!stack.isEmpty()) {output.store("Item" + i, ItemStack.CODEC, stack);}}}

    @Override
    protected void loadAdditional(ValueInput input) { super.loadAdditional(input);
        permanentProgress = input.getInt("PermanentProgress").orElse(0);
        for (int i = 0; i < SLOT_COUNT; i++) {items[i] = input.read("Item" + i, ItemStack.CODEC).orElse(ItemStack.EMPTY);}}

    @Override
    public int[] getSlotsForFace(Direction side) {if (side == Direction.DOWN) {return new int[] {MAIN_OUTPUT_SLOT, COMPLEMENTARY_OUTPUT_SLOT};}
        return new int[] {WISH_SLOT, SIGIL_SLOT};}

    @Override
    public boolean canPlaceItemThroughFace(int slot, ItemStack stack, @Nullable Direction side) {
        if (side == Direction.DOWN) {return false;}
        if (slot == WISH_SLOT) {return stack.is(GileModTags.Items.WISH_INPUT);}
        if (slot == SIGIL_SLOT) {return stack.is(GileModTags.Items.SIGIL_INPUT);}return false;}

    @Override
    public boolean canTakeItemThroughFace(
            int slot, ItemStack stack, Direction side) {return side == Direction.DOWN && (slot == MAIN_OUTPUT_SLOT || slot == COMPLEMENTARY_OUTPUT_SLOT);}

    // =========================================================
// WISH ACCOMPLISHMENT EFFECT
// =========================================================

    private void playWishSuccessEffect() {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }

        serverLevel.playSound(
                null,
                worldPosition,
                SoundEvents.UI_TOAST_CHALLENGE_COMPLETE,
                SoundSource.BLOCKS,
                0.25F,
                1.15F
        );

        double x = worldPosition.getX() + 0.5;
        double y = worldPosition.getY() + 1.0;
        double z = worldPosition.getZ() + 0.5;

        DustParticleOptions pinkDust =
                new DustParticleOptions(
                        0xE2BBE7,
                        1.0F
                );

        DustParticleOptions blueDust =
                new DustParticleOptions(
                        0x3CC2E8,
                        1.0F
                );

        DustParticleOptions whiteDust =
                new DustParticleOptions(
                        0xFFFFFF,
                        0.8F
                );

        serverLevel.sendParticles(
                pinkDust,
                x,
                y,
                z,
                15,
                0.45,
                0.45,
                0.45,
                0.04
        );

        serverLevel.sendParticles(
                blueDust,
                x,
                y,
                z,
                15,
                0.45,
                0.45,
                0.45,
                0.04
        );

        serverLevel.sendParticles(
                whiteDust,
                x,
                y,
                z,
                10,
                0.35,
                0.5,
                0.35,
                0.05
        );

        serverLevel.sendParticles(
                ParticleTypes.ENCHANT,
                x,
                y,
                z,
                20,
                0.5,
                0.5,
                0.5,
                0.08
        );
    }

    // =========================================================
// RARITY EFFECT
// =========================================================

    private void playRarityEffect() {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }

        // Emit particles every 3 ticks.
        if (wishProgress % 3 != 0) {
            return;
        }

        double x = worldPosition.getX() + 0.5;
        double y = worldPosition.getY() + 1.05;
        double z = worldPosition.getZ() + 0.5;

        DustParticleOptions rarityDust;

        switch (currentRarity) {
            case COMMON -> rarityDust =
                    new DustParticleOptions(
                            0x55AAFF,
                            0.65F
                    );

            case RARE -> rarityDust =
                    new DustParticleOptions(
                            0xAA55FF,
                            0.65F
                    );

            case LEGENDARY -> rarityDust =
                    new DustParticleOptions(
                            0xFFD700,
                            0.65F
                    );

            default -> {
                return;
            }
        }

        int count = switch (currentRarity) {
            case COMMON -> 1;
            case RARE -> 1;
            case LEGENDARY -> 2;
            default -> 0;
        };

        RandomSource random = serverLevel.getRandom();

        for (int i = 0; i < count; i++) {

            double angle =
                    random.nextDouble()
                            * Math.PI
                            * 2.0;

            double radius =
                    0.12
                            + random.nextDouble()
                            * 0.18;

            double px =
                    x
                            + Math.cos(angle)
                            * radius;

            double pz =
                    z
                            + Math.sin(angle)
                            * radius;

            double py =
                    y
                            + random.nextDouble()
                            * 0.15;

            double vx =
                    Math.cos(angle)
                            * 0.005;

            double vz =
                    Math.sin(angle)
                            * 0.005;

            double vy =
                    0.018
                            + random.nextDouble()
                            * 0.012;

            serverLevel.sendParticles(
                    rarityDust,
                    px,
                    py,
                    pz,
                    1,
                    vx,
                    vy,
                    vz,
                    1.0
            );
        }

        // Occasional white star particle.
        if (wishProgress % 15 == 0) {
            serverLevel.sendParticles(
                    ParticleTypes.END_ROD,
                    x + (random.nextDouble() - 0.5) * 0.45,
                    y + random.nextDouble() * 0.2,
                    z + (random.nextDouble() - 0.5) * 0.45,
                    1,
                    0.0,
                    0.025,
                    0.0,
                    0.01
            );
        }
    }

    // NORMAL WISH COMPLETION BURST
    private void playWishCompletionBurst() {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }

        double x = worldPosition.getX() + 0.5;
        double y = worldPosition.getY() + 1.05;
        double z = worldPosition.getZ() + 0.5;

        DustParticleOptions rarityDust;

        switch (currentRarity) {
            case COMMON -> rarityDust =
                    new DustParticleOptions(
                            0x55AAFF,
                            0.8F
                    );

            case RARE -> rarityDust =
                    new DustParticleOptions(
                            0xAA55FF,
                            0.8F
                    );

            case LEGENDARY -> rarityDust =
                    new DustParticleOptions(
                            0xFFD700,
                            0.9F
                    );

            default -> {
                return;
            }
        }

        // Bigger than the continuous rarity effect.
        int rarityCount = switch (currentRarity) {
            case COMMON -> 12;
            case RARE -> 16;
            case LEGENDARY -> 22;
            default -> 0;
        };

        serverLevel.sendParticles(
                rarityDust,
                x,
                y,
                z,
                rarityCount,
                0.38,
                0.28,
                0.38,
                0.045
        );

        // White sparkles.
        int sparkleCount = switch (currentRarity) {
            case COMMON -> 4;
            case RARE -> 6;
            case LEGENDARY -> 8;
            default -> 0;
        };

        serverLevel.sendParticles(
                ParticleTypes.END_ROD,
                x,
                y + 0.05,
                z,
                sparkleCount,
                0.30,
                0.25,
                0.30,
                0.035
        );

        // Small enchantment burst.
        int enchantCount = switch (currentRarity) {
            case COMMON -> 5;
            case RARE -> 8;
            case LEGENDARY -> 12;
            default -> 0;
        };

        serverLevel.sendParticles(
                ParticleTypes.ENCHANT,
                x,
                y,
                z,
                enchantCount,
                0.35,
                0.30,
                0.35,
                0.06
        );
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {return this.saveWithoutMetadata(registries);
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {return ClientboundBlockEntityDataPacket.create(this);
    }

}