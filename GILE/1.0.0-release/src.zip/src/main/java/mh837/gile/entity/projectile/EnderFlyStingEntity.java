package mh837.gile.entity.projectile;

import mh837.gile.advancement.GileModTriggers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.BlockHitResult;

public class EnderFlyStingEntity extends AbstractArrow {

    private static final float DAMAGE = 2.0F;

    /*
     * Constructor required by EntityType.Builder.
     */
    public EnderFlyStingEntity(
            EntityType<? extends EnderFlyStingEntity> entityType,
            Level level
    ) {
        super(entityType, level);
    }

    /*
     * Constructor used when the Ender Fly fires a sting.
     */
    public EnderFlyStingEntity(
            EntityType<? extends EnderFlyStingEntity> entityType,
            Level level,
            Entity owner
    ) {
        super(entityType, level);
        this.setOwner(owner);
    }

    /*
     * The sting is not a collectible arrow.
     */
    @Override
    protected ItemStack getDefaultPickupItem() {
        return ItemStack.EMPTY;
    }

    /*
     * Entity hit.
     */
    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity hit = result.getEntity();

        if (!this.level().isClientSide()) {

            Entity owner = this.getOwner();

            if (owner instanceof LivingEntity livingOwner) {
                hit.hurt(
                        this.damageSources().mobProjectile(
                                this,
                                livingOwner
                        ),
                        DAMAGE
                );

                if (hit instanceof ServerPlayer serverPlayer) {
                    GileModTriggers.HIT_BY_ENDER_FLY.trigger(serverPlayer);
                }

            } else {
                hit.hurt(
                        this.damageSources().generic(),
                        DAMAGE
                );
            }

            this.discard();
        }

    }

    /*
     * Block hit.
     */
    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (!this.level().isClientSide()) {
            this.discard();
        }
    }

    /*
     * Never allow players to pick up the sting.
     */
    @Override
    protected boolean tryPickup(
            net.minecraft.world.entity.player.Player player
    ) {
        return false;
    }

    /*
     * Normal projectile gravity.
     *
     * Set to true because you described it as a short arrow/bee-sting
     * projectile rather than a magical straight-line projectile.
     */
    @Override
    public boolean isNoGravity() {
        return false;
    }

    /*
     * Slightly reduced speed in water.
     */
    @Override
    protected float getWaterInertia() {
        return 0.8F;
    }
}