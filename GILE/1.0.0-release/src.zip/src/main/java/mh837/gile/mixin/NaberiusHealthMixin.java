package mh837.gile.mixin;

import mh837.gile.GileModItems;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Player.class)
public class NaberiusHealthMixin {

    private static final Identifier NABERIUS_HEALTH_ID =
            Identifier.fromNamespaceAndPath(
                    "gilemod",
                    "naberius_health"
            );

    private static final AttributeModifier NABERIUS_HEALTH_MODIFIER =
            new AttributeModifier(
                    NABERIUS_HEALTH_ID,
                    20.0D,
                    AttributeModifier.Operation.ADD_VALUE
            );

    @Inject(
            method = "tick",
            at = @At("TAIL")
    )
    private void gilemod$naberiusHealthTick(
            CallbackInfo ci
    ) {
        Player player = (Player) (Object) this;

        boolean holdingBook =
                player.getMainHandItem().is(GileModItems.TOME_OF_NABERIUS)
                        || player.getOffhandItem().is(GileModItems.TOME_OF_NABERIUS);

        AttributeInstance maxHealth =
                player.getAttribute(Attributes.MAX_HEALTH);

        if (maxHealth == null) {
            return;
        }

        boolean hasModifier =
                maxHealth.hasModifier(NABERIUS_HEALTH_ID);

        // =========================================================
        // HOLDING TOME
        // =========================================================

        if (holdingBook && !hasModifier) {

            maxHealth.addPermanentModifier(
                    NABERIUS_HEALTH_MODIFIER
            );

        }

        // =========================================================
        // NOT HOLDING TOME
        // =========================================================

        else if (!holdingBook && hasModifier) {

            maxHealth.removeModifier(
                    NABERIUS_HEALTH_ID
            );

            // Prevent health from remaining above the new maximum.
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
        }
    }
}