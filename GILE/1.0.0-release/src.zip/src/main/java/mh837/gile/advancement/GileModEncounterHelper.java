package mh837.gile.advancement;

import mh837.gile.entity.GloomyLynxEntity;
import mh837.gile.entity.JerboaEntity;
import mh837.gile.entity.WeaselThiefEntity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class GileModEncounterHelper {

    private GileModEncounterHelper() {
    }

    public static void checkEncounters(ServerPlayer player) {

        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }

        AABB box = player.getBoundingBox().inflate(5.0);

        // Gloomy Lynx
        for (GloomyLynxEntity lynx :
                level.getEntitiesOfClass(GloomyLynxEntity.class, box)) {

            if (isLookingAt(player, lynx, 5.0)) {
                GileModTriggers.ENCOUNTER_GLOOMY_LYNX.trigger(player);
                break;
            }
        }

        // Jerboa
        for (JerboaEntity jerboa :
                level.getEntitiesOfClass(JerboaEntity.class, box)) {

            if (isLookingAt(player, jerboa, 5.0)) {
                GileModTriggers.ENCOUNTER_JERBOA.trigger(player);
                break;
            }
        }

        // Weasel Thief
        for (WeaselThiefEntity weasel :
                level.getEntitiesOfClass(WeaselThiefEntity.class, box)) {

            if (isLookingAt(player, weasel, 5.0)) {
                GileModTriggers.ENCOUNTER_WEASEL_THIEF.trigger(player);
                break;
            }
        }
    }

    public static boolean isLookingAt(
            ServerPlayer player,
            Entity entity,
            double maxDistance
    ) {
        if (player.distanceToSqr(entity) > maxDistance * maxDistance) {
            return false;
        }

        Vec3 eyePosition = player.getEyePosition();
        Vec3 viewDirection = player.getViewVector(1.0F).normalize();

        Vec3 targetPosition = entity.getBoundingBox().getCenter();
        Vec3 toTarget = targetPosition
                .subtract(eyePosition)
                .normalize();

        return viewDirection.dot(toTarget) >= 0.95;
    }
}