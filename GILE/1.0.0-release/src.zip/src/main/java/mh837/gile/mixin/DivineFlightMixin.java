package mh837.gile.mixin;

import mh837.gile.GileModItems;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Player.class)
public class DivineFlightMixin {

    @Inject(
            method = "tick",
            at = @At("TAIL")
    )
    private void gilemod$phanesFlightTick(
            CallbackInfo ci
    ) {

        Player player =
                (Player) (Object) this;

        /*
         * Never interfere with Creative or Spectator.
         */
        if (player.isCreative()
                || player.isSpectator()) {
            return;
        }

        boolean holdingPhanes =
                player.getMainHandItem().is(
                        GileModItems.PHANES_BLADE
                )
                        || player.getOffhandItem().is(
                        GileModItems.PHANES_BLADE
                );

        if (holdingPhanes) {
            enableFlight(player);
        } else {
            disableFlight(player);
        }
    }

    private static void enableFlight(
            Player player
    ) {

        if (!player.getAbilities().mayfly) {

            player.getAbilities().mayfly = true;

            syncAbilities(player);
        }
    }

    private static void disableFlight(
            Player player
    ) {

        boolean changed = false;

        /*
         * Remove Phanes' flight permission.
         */
        if (player.getAbilities().mayfly) {

            player.getAbilities().mayfly = false;

            changed = true;
        }

        /*
         * If the player was actually flying when Phanes
         * disappeared, force them back to normal movement.
         */
        if (player.getAbilities().flying) {

            player.getAbilities().flying = false;

            changed = true;
        }

        if (changed) {
            syncAbilities(player);
        }
    }

    private static void syncAbilities(
            Player player
    ) {

        if (player instanceof ServerPlayer serverPlayer) {

            serverPlayer.connection.send(
                    new ClientboundPlayerAbilitiesPacket(
                            serverPlayer.getAbilities()
                    )
            );
        }
    }
}