package mh837.gile.item.tool;

import mh837.gile.GileModEffects;
import mh837.gile.GileModEnchantments;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public class EnlargerItem extends Item {

    /*
     * Base range of the Enlarger.
     */
    private static final double BASE_RANGE = 20.0;

    /*
     * Every Range enchantment level adds 16 blocks.
     *
     * Range I   = 28 blocks
     * Range II  = 36 blocks
     * Range III = 44 blocks
     * Range IV  = 52 blocks
     */
    private static final double RANGE_PER_LEVEL = 8.0;

    public EnlargerItem(Properties properties) {
        super(properties);
    }

    private void processEnlargeTarget(
            LivingEntity target,
            Level level,
            Player user,
            ItemStack stack,
            boolean isSelf
    ) {
        Holder<MobEffect> shrink = GileModEffects.SHRINK;
        Holder<MobEffect> enlarge = GileModEffects.ENLARGE;

        boolean isCountering = target.hasEffect(shrink);

        if (!level.isClientSide()) {

            if (isCountering) {
                // COUNTER LOGIC

                MobEffectInstance currentEffect =
                        target.getEffect(shrink);

                int remainingTicks =
                        currentEffect != null
                                ? currentEffect.getDuration()
                                : 0;

                target.removeEffect(shrink);

                if (remainingTicks > 6000) {
                    target.addEffect(
                            new MobEffectInstance(
                                    shrink,
                                    remainingTicks - 6000,
                                    3,
                                    true,
                                    true
                            )
                    );
                }

                if (level instanceof ServerLevel serverLevel) {
                    serverLevel.sendParticles(
                            ParticleTypes.CLOUD,
                            target.getX(),
                            target.getY(0.5),
                            target.getZ(),
                            20,
                            0.3,
                            0.5,
                            0.3,
                            0.1
                    );
                }

            } else {

                int finalDuration = 6000;

                if (target.hasEffect(enlarge)) {
                    MobEffectInstance currentEffect =
                            target.getEffect(enlarge);

                    if (currentEffect != null) {
                        finalDuration += currentEffect.getDuration();
                    }
                }

                target.addEffect(
                        new MobEffectInstance(
                                enlarge,
                                finalDuration,
                                3,
                                true,
                                true
                        )
                );

                if (level instanceof ServerLevel serverLevel) {
                    serverLevel.sendParticles(
                            ParticleTypes.HAPPY_VILLAGER,
                            target.getX(),
                            target.getY(0.5),
                            target.getZ(),
                            20,
                            0.3,
                            0.5,
                            0.3,
                            0.1
                    );
                }

                if (user instanceof ServerPlayer serverPlayer) {
                    GileModTriggers.USE_ENLARGER.trigger(serverPlayer);
                }

            }

            if (level instanceof ServerLevel serverLevel) {

                ServerPlayer serverPlayer =
                        user instanceof ServerPlayer sp
                                ? sp
                                : null;

                stack.hurtAndBreak(
                        1,
                        serverLevel,
                        serverPlayer,
                        item -> user.onEquippedItemBroken(
                                item,
                                EquipmentSlot.MAINHAND
                        )
                );
            }
        }

        // Sounds

        if (isCountering) {

            SoundEvent cancelSound =
                    isSelf
                            ? SoundEvents.BEACON_DEACTIVATE
                            : SoundEvents.DISPENSER_FAIL;

            level.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    cancelSound,
                    SoundSource.PLAYERS,
                    1.0F,
                    1.0F
            );

        } else {

            level.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.ILLUSIONER_CAST_SPELL,
                    SoundSource.PLAYERS,
                    1.0F,
                    2.0F
            );
        }
    }

    @Override
    public InteractionResult use(
            Level level,
            Player user,
            InteractionHand hand
    ) {
        ItemStack stack = user.getItemInHand(hand);

        if (user instanceof ServerPlayer serverPlayer) {
            GileModTriggers.USE_ENLARGER.trigger(serverPlayer);
        }

        // =========================================================
        // SELF-INTERACTION MODE
        // Shift + Right Click
        // =========================================================

        if (user.isShiftKeyDown()) {

            // Smart toggle cancel

            if (user.getXRot() >= 80.0F
                    && user.hasEffect(GileModEffects.ENLARGE)) {

                if (!level.isClientSide()) {

                    user.removeEffect(
                            GileModEffects.ENLARGE
                    );

                    if (level instanceof ServerLevel serverLevel) {
                        serverLevel.sendParticles(
                                ParticleTypes.CLOUD,
                                user.getX(),
                                user.getY(0.5),
                                user.getZ(),
                                20,
                                0.3,
                                0.5,
                                0.3,
                                0.1
                        );
                    }
                }

                level.playSound(
                        null,
                        user.getX(),
                        user.getY(),
                        user.getZ(),
                        SoundEvents.BEACON_DEACTIVATE,
                        SoundSource.PLAYERS,
                        1.0F,
                        1.0F
                );

                user.getCooldowns().addCooldown(
                        stack,
                        20
                );

                return InteractionResult.SUCCESS;
            }

            // Apply or counter self

            processEnlargeTarget(
                    user,
                    level,
                    user,
                    stack,
                    true
            );

            user.getCooldowns().addCooldown(
                    stack,
                    40
            );

            return InteractionResult.SUCCESS;
        }

        // =========================================================
        // RAYCAST MODE
        // =========================================================

        /*
         * IMPORTANT:
         *
         * The Enlarger has its own range system.
         *
         * It does NOT rely on entity_interaction_range.
         */
        int rangeLevel = getRangeLevel(level, stack);

        double maxDistance =
                BASE_RANGE
                        + (rangeLevel * RANGE_PER_LEVEL);

        Vec3 startPos = user.getEyePosition();

        Vec3 lookDir =
                user.getViewVector(1.0F);

        Vec3 endPos =
                startPos.add(
                        lookDir.scale(maxDistance)
                );

        /*
         * Search box must cover the entire ray.
         */
        AABB searchBox =
                user.getBoundingBox()
                        .expandTowards(
                                lookDir.scale(maxDistance)
                        )
                        .inflate(
                                1.0,
                                1.0,
                                1.0
                        );

        EntityHitResult hitResult =
                ProjectileUtil.getEntityHitResult(
                        user,
                        startPos,
                        endPos,
                        searchBox,
                        entity ->
                                entity instanceof LivingEntity
                                        && !entity.isSpectator(),
                        maxDistance * maxDistance
                );

        // =========================================================
        // PROXIMITY CANCEL
        // =========================================================

        if (hitResult != null
                && hitResult.getEntity()
                instanceof LivingEntity target) {

            double distance =
                    startPos.distanceTo(
                            hitResult.getLocation()
                    );

            if (distance <= 3.0
                    && target.hasEffect(
                    GileModEffects.ENLARGE
            )) {

                if (!level.isClientSide()) {

                    target.removeEffect(
                            GileModEffects.ENLARGE
                    );

                    if (level instanceof ServerLevel serverLevel) {
                        serverLevel.sendParticles(
                                ParticleTypes.CLOUD,
                                target.getX(),
                                target.getY(0.5),
                                target.getZ(),
                                20,
                                0.3,
                                0.5,
                                0.3,
                                0.1
                        );
                    }
                }

                level.playSound(
                        null,
                        user.getX(),
                        user.getY(),
                        user.getZ(),
                        SoundEvents.DISPENSER_FAIL,
                        SoundSource.PLAYERS,
                        1.0F,
                        1.0F
                );

                user.getCooldowns().addCooldown(
                        stack,
                        20
                );

                return InteractionResult.SUCCESS;
            }
        }

        // =========================================================
        // RAY PARTICLES
        // =========================================================

        Vec3 traceEnd =
                hitResult != null
                        ? hitResult.getLocation()
                        : endPos;

        if (!level.isClientSide()
                && level instanceof ServerLevel serverLevel) {

            double distance =
                    startPos.distanceTo(traceEnd);

            int particleCount =
                    Math.max(
                            1,
                            (int) (distance * 2)
                    );

            /*
             * Prevent division by zero for extremely short rays.
             */
            for (int i = 0; i <= particleCount; i++) {

                double delta =
                        (double) i / particleCount;

                Vec3 particlePos =
                        startPos.lerp(
                                traceEnd,
                                delta
                        );

                serverLevel.sendParticles(
                        ParticleTypes.HAPPY_VILLAGER,
                        particlePos.x,
                        particlePos.y - 0.2,
                        particlePos.z,
                        1,
                        0.0,
                        0.0,
                        0.0,
                        0.0
                );
            }
        }

        // =========================================================
        // NORMAL ENLARGE HIT
        // =========================================================

        if (hitResult != null
                && hitResult.getEntity()
                instanceof LivingEntity target) {

            processEnlargeTarget(
                    target,
                    level,
                    user,
                    stack,
                    false
            );

            user.getCooldowns().addCooldown(
                    stack,
                    40
            );

            return InteractionResult.SUCCESS;
        }

        // =========================================================
        // MISSED TARGET
        // =========================================================

        level.playSound(
                null,
                user.getX(),
                user.getY(),
                user.getZ(),
                SoundEvents.DISPENSER_FAIL,
                SoundSource.PLAYERS,
                1.0F,
                1.5F
        );

        user.getCooldowns().addCooldown(
                stack,
                40
        );

        return InteractionResult.PASS;
    }

    /**
     * Reads the Range enchantment level from the item.
     */
    private int getRangeLevel(
            Level level,
            ItemStack stack
    ) {
        Holder<Enchantment> rangeEnchantment =
                level.registryAccess()
                        .lookupOrThrow(
                                Registries.ENCHANTMENT
                        )
                        .getOrThrow(
                                GileModEnchantments.RANGE
                        );

        return EnchantmentHelper.getItemEnchantmentLevel(
                rangeEnchantment,
                stack
        );
    }
}