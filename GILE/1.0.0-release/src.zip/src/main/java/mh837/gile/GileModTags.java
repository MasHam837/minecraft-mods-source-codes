package mh837.gile;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

public class GileModTags {

    public static class Items {

        public static final TagKey<Item> ELEMENTAL_WEAPON = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "elemental_weapon"));
        public static final TagKey<Item> LEGENDARY_WEAPON = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "legendary_weapon"));
        public static final TagKey<Item> PRIMORDIAL_WEAPON = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "primordial_weapon"));

        public static final TagKey<Item> WISH_INPUT = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "wish_input"));
        public static final TagKey<Item> SIGIL_INPUT = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "sigil_input"));

        public static final TagKey<Item> ENDERITE_TOOL_MATERIALS = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "enderite_tool_materials"));
        public static final TagKey<Item> ENDERITE_MINING_TOOLS = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "enderite_mining_tools"));

    }

    public static class Blocks {

        public static final TagKey<Block> INCORRECT_FOR_ENDERITE_TOOL = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "incorrect_for_enderite_tool"));

        public static final TagKey<Block> GLOWING_CHORUS_SUPPORT = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_support"));

    }

}
