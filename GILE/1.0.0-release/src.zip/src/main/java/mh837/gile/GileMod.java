package mh837.gile;

import mh837.gile.advancement.GileModEncounterHelper;
import mh837.gile.advancement.GileModTriggers;
import mh837.gile.entity.RuinGuardEntity;
import mh837.gile.item.tool.FluttererEvents;
import mh837.gile.item.weapon.elemental.ElementalWeaponItems;
import mh837.gile.recipe.GileModRecipeSerializers;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GileMod implements ModInitializer {
	public static final String MOD_ID = "gilemod";

	@Override
	public void onInitialize() {
		// Only run mod logic that exists for all players
		GileModItems.initialize();
		FluttererEvents.initialize();
		GileModDataComponents.initialize();
		GileModCreativeTabs.initialize();
		GileModBlocks.initialize();
		GileModBlocksLogic.initialize();
		GileModBlockEntities.initialize();
		GileModEntities.initialize();
		GileModWorldgen.initialize();
		GileModEffects.initialize();
		GileModAbilities.initialize();
		GileModSounds.initialize();
		GileModParticleTypes.initialize();
		GileModVillagerProfessions.initialize();
		GileModRecipeSerializers.initialize();
		GileModTriggers.initialize();

		// Datapack mode helper
		ResourceManagerHelper.registerBuiltinResourcePack(Identifier.fromNamespaceAndPath(MOD_ID, "lunar_favor_mode"),
				FabricLoader.getInstance().getModContainer(MOD_ID).orElseThrow(), ResourcePackActivationType.NORMAL);

		// Mavuika instant cooking handling
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			if (!world.isClientSide() && hand == InteractionHand.MAIN_HAND
					&& player.getMainHandItem().getItem() instanceof ElementalWeaponItems.ThousandBlazingSuns
					&& entity instanceof LivingEntity target) {target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), 100));}
			return InteractionResult.PASS;});

		// Ruin Guard Spawning from Armor Stand handling
		ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			if (!(entity instanceof ArmorStand armorStand)) {return;}
			if (!armorStand.hasCustomName()) {return;}
			if (!"gilemod:ruin_guard_spawn".equals(armorStand.getCustomName().getString())) {return;}
			RuinGuardEntity ruinGuard = GileModEntities.RUIN_GUARD.create(armorStand.level(), EntitySpawnReason.STRUCTURE);
			if (ruinGuard == null) {return;}
			ruinGuard.setPos(armorStand.getX(), armorStand.getY(), armorStand.getZ());
			ruinGuard.setYRot(armorStand.getYRot());
			ruinGuard.setYHeadRot(armorStand.getYRot());
			ruinGuard.yBodyRot = armorStand.getYRot();
			armorStand.level().addFreshEntity(ruinGuard);
			armorStand.discard();});

		// Advancement Encounter helper handling
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				GileModEncounterHelper.checkEncounters(player);
				GileModWorldgen.checkDiscoveries(player);}});
	}
}