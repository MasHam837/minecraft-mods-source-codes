package mh837.gile.mixin;

import mh837.gile.item.weapon.elemental.ElementalWeaponItems;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(net.minecraft.world.level.block.PowderSnowBlock.class)
public class PowderSnowWalkerMixin {

    @Inject(
            method = "canEntityWalkOnPowderSnow",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void gilemod$hiemalMandateWalkOnPowderSnow(
            Entity entity,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (entity instanceof Player player) {
            boolean hasHiemalMandate =
                    player.getMainHandItem().getItem() instanceof ElementalWeaponItems.HiemalMandate
                            || player.getOffhandItem().getItem() instanceof ElementalWeaponItems.HiemalMandate;

            if (hasHiemalMandate) {
                cir.setReturnValue(true);
            }
        }
    }
}