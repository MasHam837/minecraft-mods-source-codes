package mh837.gile.item.weapon.fate;

import mh837.gile.GileModItems;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemUseAnimation;

import java.util.function.Predicate;

public class FateBow extends BowItem {

    public FateBow(Properties properties) {
        super(properties);
    }

    @Override
    public Predicate<ItemStack> getAllSupportedProjectiles() {
        // Allows the Fate Bow to shoot standard vanilla arrows OR your custom Fate Arrow
        return stack -> stack.is(ItemTags.ARROWS) || stack.is(GileModItems.FATE_ARROW);
    }

    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {return ItemUseAnimation.BOW;}

}