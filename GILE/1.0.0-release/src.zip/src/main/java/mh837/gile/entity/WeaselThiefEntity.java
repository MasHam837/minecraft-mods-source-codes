package mh837.gile.entity;

import mh837.gile.GileModItems;
import mh837.gile.GileModSounds;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.Bees;
import net.minecraft.world.item.component.Fireworks;
import net.minecraft.world.item.component.TypedEntityData;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.entity.BeehiveBlockEntity;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class WeaselThiefEntity extends AbstractVillager {

    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(WeaselThiefEntity.class, EntityDataSerializers.INT);
    private int dropCooldown = 0;

    public WeaselThiefEntity(EntityType<? extends WeaselThiefEntity> entityType, Level level) {
        super(entityType, level);
    }

    public static AttributeSupplier.Builder createWeaselAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)
                .add(Attributes.MOVEMENT_SPEED, 0.4);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        // Flee from players within 16 blocks, runs at 1.2x speed near, 1.5x speed far
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Player.class, 16.0F, 1.2, 1.5));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(VARIANT, 0);
    }

    public WeaselVariant getVariant() {
        return WeaselVariant.byId(this.entityData.get(VARIANT));
    }

    public void setVariant(WeaselVariant variant) {
        this.entityData.set(VARIANT, variant.getId());
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        int looting = 0;
        if (source.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEnchant = registry.get(Enchantments.LOOTING);
            if (lootingEnchant.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(
                        lootingEnchant.get(),
                        attacker.getMainHandItem()
                );
            }
        }
        int dropCount = 1 + this.random.nextInt(10 + looting);
        this.spawnAtLocation(level, new ItemStack(GileModItems.PRIMOGEM, dropCount));
    }

    private int lifeTimeTicks = 0;
    private static final int MAX_LIFE_TIME = 48000; // 2 in-game days (24,000 * 2)

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide()) {
            this.lifeTimeTicks++;

            // Despawn after 2 in-game days, ignoring EVERYTHING (even nametags)
            if (this.lifeTimeTicks >= MAX_LIFE_TIME) {
                this.discard(); // Deletes the entity quietly without dropping items
            }
        }
    }

    // 1. Force the game to ignore nametags when checking if it can despawn
    @Override
    public boolean requiresCustomPersistence() {
        return false;
    }

    // 2. ALSO allow it to despawn instantly if the player just runs 128+ blocks away
    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        // Frees up the 10-mob CREATURE cap dynamically!
        return !this.hasCustomName() && !this.isLeashed();
    }

    @Override
    public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason spawnReason) {
        // Bypasses vanilla light-level and grass-block requirements.
        // It will now rely entirely on the SpawnPlacements we set up earlier!
        return true;
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {
        return 0;
    }

    @Override
    public void aiStep() {
        super.aiStep();

        if (!this.level().isClientSide() && this.isAlive()) {
            // Check if moving fast (fleeing)
            if (this.getDeltaMovement().horizontalDistanceSqr() > 0.01) {
                Player closest = this.level().getNearestPlayer(this, 16.0);
                if (closest != null) {
                    if (this.dropCooldown <= 0) {
                        this.spawnAtLocation((ServerLevel) this.level(), new ItemStack(GileModItems.MORA, 1));
                        this.dropCooldown = 60 + this.random.nextInt(100);
                    }
                }
            }
            if (this.dropCooldown > 0) {
                this.dropCooldown--;
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (this.isAlive() && this.getTradingPlayer() == null && !this.isBaby()) {
            if (!this.level().isClientSide()) {
                this.setTradingPlayer(player);
                this.openTradingScreen(player, this.getDisplayName(), 1);
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected void updateTrades(ServerLevel level) {
        MerchantOffers offers = new MerchantOffers();
        WeaselVariant variant = this.getVariant();

        // 1. Define Trade Limits based on Rarity
        int maxUses = variant == WeaselVariant.AMATEUR ? 3 : (variant == WeaselVariant.HOARDER ? 3 : 3);
        int xp = variant == WeaselVariant.AMATEUR ? 5 : (variant == WeaselVariant.HOARDER ? 5 : 5);

        // 2. Load Modded Items (Sigils & Currency)
        Item mora = getCustomItem("mora");
        Item pyro = getCustomItem("pyro_sigil");
        Item geo = getCustomItem("geo_sigil");
        Item dendro = getCustomItem("dendro_sigil");
        Item electro = getCustomItem("electro_sigil");
        Item hydro = getCustomItem("hydro_sigil");
        Item anemo = getCustomItem("anemo_sigil");
        Item cryo = getCustomItem("cryo_sigil");
        Item luna = getCustomItem("luna_sigil");

        // --- TRADE 1: MORA CONVERTER ---
        int moraCost = switch (variant) {
            case HOARDER -> 2;
            case GOLDEN -> 1;
            default -> 4;
        };

        Item[] allSigils = {pyro, geo, dendro, electro, hydro, anemo, cryo, luna};
        Item randomSigil = allSigils[this.random.nextInt(allSigils.length)];

        offers.add(createTrade(mora, moraCost, randomSigil, 1, maxUses, xp));

        // Let's roll a random index (0, 1, or 2) for each of the 8 elements
        int rAir = this.random.nextInt(3);
        int rEarth = this.random.nextInt(3);
        int rElectro = this.random.nextInt(3);
        int rNature = this.random.nextInt(3);
        int rWater = this.random.nextInt(3);
        int rFire = this.random.nextInt(3);
        int rFrost = this.random.nextInt(3);
        int rMoon = this.random.nextInt(3);

        // --- TRADE 2: AIR ---
        switch (variant) {
            case AMATEUR -> offers.add(rAir == 0 ? createTrade(anemo, 2, Items.PHANTOM_MEMBRANE, 4, maxUses, xp) : rAir == 1 ? createTrade(anemo, 1, Items.EGG, 2, maxUses, xp) : createTrade(anemo, 4, createDuration3Rocket(8), maxUses, xp));
            case HOARDER -> offers.add(rAir == 0 ? createTrade(anemo, 8, Items.BREEZE_ROD, 2, maxUses, xp) : rAir == 1 ? createTrade(anemo, 15, Items.DRAGON_BREATH, 8, maxUses, xp) : createTrade(anemo, 9, Items.COBWEB, 3, maxUses, xp));
            case GOLDEN -> offers.add(rAir == 0 ? createTrade(anemo, 30, Items.HEAVY_CORE, 1, maxUses, xp) : rAir == 1 ? createTrade(anemo, 40, Items.ELYTRA, 1, maxUses, xp) : createTrade(anemo, 64, getCustomItem("daybreak_chronicles"), 1, maxUses, xp));
        }

        // --- TRADE 3: EARTH ---
        switch (variant) {
            case AMATEUR -> offers.add(rEarth == 0 ? createTrade(geo, 1, Items.SAND, 16, maxUses, xp) : rEarth == 1 ? createTrade(geo, 2, Items.GRASS_BLOCK, 4, maxUses, xp) : createTrade(geo, 4, Items.STONE, 32, maxUses, xp));
            case HOARDER -> offers.add(rEarth == 0 ? createTrade(geo, 8, Items.POINTED_DRIPSTONE, 4, maxUses, xp) : rEarth == 1 ? createTrade(geo, 4, Items.AMETHYST_CLUSTER, 2, maxUses, xp) : createTrade(geo, 9, getCustomItem("pearlescent_material"), 1, maxUses, xp));
            case GOLDEN -> offers.add(rEarth == 0 ? createTrade(geo, 32, Items.DIAMOND_BLOCK, 1, maxUses, xp) : rEarth == 1 ? createTrade(geo, 16, Items.DEEPSLATE_EMERALD_ORE, 4, maxUses, xp) : createTrade(geo, 64, getCustomItem("vortex_vanquisher"), 1, maxUses, xp));
        }

        // --- TRADE 4: ELECTRO ---
        switch (variant) {
            case AMATEUR -> offers.add(rElectro == 0 ? createTrade(electro, 1, Items.REDSTONE, 16, maxUses, xp) : rElectro == 1 ? createTrade(electro, 3, Items.REPEATER, 9, maxUses, xp) : createTrade(electro, 5, Items.COMPARATOR, 6, maxUses, xp));
            case HOARDER -> offers.add(rElectro == 0 ? createTrade(electro, 4, Items.TNT, 2, maxUses, xp) : rElectro == 1 ? createTrade(electro, 6, Items.GLOWSTONE, 6, maxUses, xp) : createTrade(electro, 8, Items.OXIDIZED_COPPER, 4, maxUses, xp));
            case GOLDEN -> offers.add(rElectro == 0 ? createTrade(electro, 16, Items.REDSTONE_BLOCK, 8, maxUses, xp) : rElectro == 1 ? createTrade(electro, 32, createThunderTrident(), maxUses, xp) : createTrade(electro, 64, getCustomItem("engulfing_lightning"), 1, maxUses, xp));
        }

        // --- TRADE 5: NATURE ---
        switch (variant) {
            case AMATEUR -> offers.add(rNature == 0 ? createTrade(dendro, 1, Items.MOSS_BLOCK, 16, maxUses, xp) : rNature == 1 ? createTrade(dendro, 4, Items.LILY_PAD, 8, maxUses, xp) : createTrade(dendro, 3, Items.SPORE_BLOSSOM, 1, maxUses, xp));
            case HOARDER -> offers.add(rNature == 0 ? createTrade(dendro, 5, Items.SUGAR_CANE, 12, maxUses, xp) : rNature == 1 ? createTrade(dendro, 6, Items.BAMBOO, 4, maxUses, xp) : createTrade(dendro, 8, Items.COCOA_BEANS, 2, maxUses, xp));
            case GOLDEN -> offers.add(rNature == 0 ? createTrade(dendro, 15, createBeeNestWithBee().getItem(), 1, maxUses, xp) : rNature == 1 ? createTrade(dendro, 20, Items.SNIFFER_EGG, 1, maxUses, xp) : createTrade(dendro, 64, getCustomItem("thousand_floating_dreams"), 1, maxUses, xp));
        }

        // --- TRADE 6: WATER ---
        switch (variant) {
            case AMATEUR -> offers.add(rWater == 0 ? createTrade(hydro, 2, Items.PRISMARINE_CRYSTALS, 5, maxUses, xp) : rWater == 1 ? createTrade(hydro, 1, Items.SEA_PICKLE, 8, maxUses, xp) : createTrade(hydro, 1, Items.DRIED_KELP_BLOCK, 4, maxUses, xp));
            case HOARDER -> offers.add(rWater == 0 ? createTrade(hydro, 12, Items.NAUTILUS_SHELL, 2, maxUses, xp) : rWater == 1 ? createTrade(hydro, 10, Items.AXOLOTL_BUCKET, 1, maxUses, xp) : createTrade(hydro, 8, Items.SPONGE, 4, maxUses, xp));
            case GOLDEN -> offers.add(rWater == 0 ? createTrade(hydro, 25, Items.HEART_OF_THE_SEA, 1, maxUses, xp) : rWater == 1 ? createTrade(hydro, 32, createRiptideTrident(), maxUses, xp) : createTrade(hydro, 64, getCustomItem("splendor_of_tranquil_waters"), 1, maxUses, xp));
        }

        // --- TRADE 7: FIRE ---
        switch (variant) {
            case AMATEUR -> offers.add(rFire == 0 ? createTrade(pyro, 2, Items.MAGMA_BLOCK, 16, maxUses, xp) : rFire == 1 ? createTrade(pyro, 3, Items.LAVA_BUCKET, 1, maxUses, xp) : createTrade(pyro, 2, Items.FIRE_CHARGE, 8, maxUses, xp));
            case HOARDER -> offers.add(rFire == 0 ? createTrade(pyro, 16, Items.OBSIDIAN, 1, maxUses, xp) : rFire == 1 ? createTrade(pyro, 8, Items.BLAZE_ROD, 2, maxUses, xp) : createTrade(pyro, 4, Items.GHAST_TEAR, 2, maxUses, xp));
            case GOLDEN -> offers.add(rFire == 0 ? createTrade(pyro, 30, Items.WITHER_SKELETON_SKULL, 1, maxUses, xp) : rFire == 1 ? createTrade(pyro, 25, Items.NETHERITE_SCRAP, 1, maxUses, xp) : createTrade(pyro, 64, getCustomItem("thousand_blazing_suns"), 1, maxUses, xp));
        }

        // --- TRADE 8: FROST ---
        switch (variant) {
            case AMATEUR -> offers.add(rFrost == 0 ? createTrade(cryo, 2, Items.POWDER_SNOW_BUCKET, 1, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 8, Items.SNOW_BLOCK, 1, maxUses, xp) : createTrade(cryo, 1, Items.ICE, 16, maxUses, xp));
            case HOARDER -> offers.add(rFrost == 0 ? createTrade(cryo, 8, Items.PACKED_ICE, 32, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 18, createFrostWalkerBook(), maxUses, xp) : createTrade(cryo, 9, Items.SCULK_SENSOR, 16, maxUses, xp));
            case GOLDEN -> offers.add(rFrost == 0 ? createTrade(cryo, 20, Items.BLUE_ICE, 64, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 36, createEpicPickaxe(), maxUses, xp) : createTrade(cryo, 64, getCustomItem("hiemal_mandate"), 1, maxUses, xp));
        }

        // --- TRADE 9: MOON ---
        switch (variant) {
            case AMATEUR -> offers.add(rMoon == 0 ? createTrade(luna, 1, getCustomItem("end_grass_block"), 2, maxUses, xp) : rMoon == 1 ? createTrade(luna, 1, Items.END_STONE, 16, maxUses, xp) : createTrade(luna, 4, getCustomItem("ghostly_sapling"), 1, maxUses, xp));
            case HOARDER -> offers.add(rMoon == 0 ? createTrade(luna, 6, Items.ENDER_PEARL, 4, maxUses, xp) : rMoon == 1 ? createTrade(luna, 8, Items.SHULKER_SHELL, 2, maxUses, xp) : createTrade(luna, 16, getCustomItem("heart_of_emergency"), 1, maxUses, xp));
            case GOLDEN -> offers.add(rMoon == 0 ? createTrade(luna, 20, Items.END_CRYSTAL, 2, maxUses, xp) : rMoon == 1 ? createTrade(luna, 24, getCustomItem("warp_clock"), 1, maxUses, xp) : createTrade(luna, 64, getCustomItem("nocturnes_curtain_call"), 1, maxUses, xp));
        }
        this.offers = offers;
    }

    // ==========================================
    // TRADE CREATION HELPERS
    // ==========================================

    private ItemEnchantments createEnchantments(
            HolderLookup.RegistryLookup<Enchantment> registry,
            Object... enchantmentLevels
    ) {
        ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);

        for (int i = 0; i < enchantmentLevels.length; i += 2) {
            var enchantment = (net.minecraft.resources.ResourceKey<Enchantment>) enchantmentLevels[i];
            int level = (int) enchantmentLevels[i + 1];

            mutable.set(
                    registry.getOrThrow(enchantment),
                    level
            );
        }

        return mutable.toImmutable();
    }

    private Item getCustomItem(String id) {
        return BuiltInRegistries.ITEM
                .getValue(Identifier.fromNamespaceAndPath("gilemod", id));
    }

    private MerchantOffer createTrade(Item cost, int costCount, Item reward, int rewardCount, int maxUses, int xp) {
        return new MerchantOffer(new ItemCost(cost, costCount), new ItemStack(reward, rewardCount), maxUses, xp, 0.0f);}

    private MerchantOffer createTrade(Item cost, int costCount, ItemStack rewardStack, int maxUses, int xp) {
        return new MerchantOffer(new ItemCost(cost, costCount), rewardStack, maxUses, xp, 0.0f);}

    private ItemStack createDuration3Rocket(int count) {
        ItemStack stack = new ItemStack(Items.FIREWORK_ROCKET, count);
        stack.set(DataComponents.FIREWORKS, new Fireworks(3, List.of()));
        return stack;
    }

    private ItemStack createFrostWalkerBook() {ItemStack stack = new ItemStack(Items.ENCHANTED_BOOK);
        var enchantmentRegistry = this.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
        mutable.set(enchantmentRegistry.getOrThrow(Enchantments.FROST_WALKER), 2);
        stack.set(DataComponents.STORED_ENCHANTMENTS, mutable.toImmutable());return stack;}

    private ItemStack createEpicPickaxe() {ItemStack stack = new ItemStack(Items.DIAMOND_PICKAXE);
        var enchantmentRegistry = this.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        stack.set(DataComponents.ENCHANTMENTS, createEnchantments(enchantmentRegistry,
                Enchantments.SILK_TOUCH, 1, Enchantments.EFFICIENCY, 3));return stack;}

    private ItemStack createRiptideTrident() {ItemStack stack = new ItemStack(Items.TRIDENT);
        var enchantmentRegistry = this.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        stack.set(DataComponents.ENCHANTMENTS, createEnchantments(enchantmentRegistry,
                        Enchantments.RIPTIDE, 1));return stack;}

    private ItemStack createThunderTrident() {ItemStack stack = new ItemStack(Items.TRIDENT);
        var enchantmentRegistry = this.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        stack.set(DataComponents.ENCHANTMENTS, createEnchantments(enchantmentRegistry,
                Enchantments.CHANNELING, 1, Enchantments.LOYALTY, 2));return stack;}

    private ItemStack createBeeNestWithBee() {ItemStack stack = new ItemStack(Items.BEE_NEST);
        TypedEntityData<EntityType<?>> beeData = TypedEntityData.of(EntityType.BEE, new CompoundTag());
        BeehiveBlockEntity.Occupant bee = new BeehiveBlockEntity.Occupant(beeData, 0, 600);
        stack.set(DataComponents.BEES, new Bees(List.of(bee)));return stack;}

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, EntitySpawnReason spawnReason, @Nullable SpawnGroupData spawnData) {
        // Roll for rarity: 10% Golden, 30% Hoarder, 60% Amateur
        int roll = this.random.nextInt(100);
        if (roll < 10) {
            this.setVariant(WeaselVariant.GOLDEN);
        } else if (roll < 40) {
            this.setVariant(WeaselVariant.HOARDER);
        } else {
            this.setVariant(WeaselVariant.AMATEUR);
        }
        return super.finalizeSpawn(level, difficulty, spawnReason, spawnData);
    }

    @Override
    public void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("WeaselVariant", this.getVariant().getId());
    }

    @Override
    public void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.setVariant(WeaselVariant.byId(input.getIntOr("WeaselVariant", 0)));
    }

    @Override
    protected void rewardTradeXp(MerchantOffer offer) {
        if (!this.level().isClientSide()) {

            if (this.getTradingPlayer() instanceof ServerPlayer player) {
                GileModTriggers.TRADE_WEASEL_THIEF.trigger(player);
            }

            int xp = 3 + this.random.nextInt(4);
            this.level().addFreshEntity(new ExperienceOrb(this.level(), this.getX(), this.getY() + 0.5D, this.getZ(), xp));
        }
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob entity) {
        return null; // They don't breed
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return GileModSounds.WEASEL_THIEF_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.FOX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.FOX_DEATH;
    }
}