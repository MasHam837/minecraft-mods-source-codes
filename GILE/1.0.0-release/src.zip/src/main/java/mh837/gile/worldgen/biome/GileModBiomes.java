package mh837.gile.worldgen.biome;

import mh837.gile.GileModEntities;
import mh837.gile.GileModWorldgen;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.data.worldgen.placement.EndPlacements;
import net.minecraft.data.worldgen.placement.VegetationPlacements;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public class GileModBiomes {

    public static void bootstrap(BootstrapContext<Biome> context) {
        context.register(GileModWorldgen.END_THRESHOLD, createEndThreshold(context));
    }

    private static Biome createEndThreshold(BootstrapContext<Biome> context) {
        HolderGetter<PlacedFeature> placedFeatures = context.lookup(Registries.PLACED_FEATURE);

        // 1. Mob Spawns
        MobSpawnSettings.Builder spawnBuilder = new MobSpawnSettings.Builder();
        spawnBuilder.addSpawn(MobCategory.MONSTER, 10, new MobSpawnSettings.SpawnerData(EntityType.ENDERMAN, 1, 2));
        spawnBuilder.addSpawn(MobCategory.AMBIENT, 20, new MobSpawnSettings.SpawnerData(GileModEntities.GLITTER, 1, 4));

        // 2. Biome Features
        BiomeGenerationSettings.Builder generationBuilder = new BiomeGenerationSettings.Builder(placedFeatures, context.lookup(Registries.CONFIGURED_CARVER));
        generationBuilder.addFeature(GenerationStep.Decoration.VEGETAL_DECORATION, placedFeatures.getOrThrow(EndPlacements.CHORUS_PLANT));
        generationBuilder.addFeature(GenerationStep.Decoration.VEGETAL_DECORATION, placedFeatures.getOrThrow(VegetationPlacements.PATCH_GRASS_NORMAL));
        generationBuilder.addFeature(GenerationStep.Decoration.VEGETAL_DECORATION, placedFeatures.getOrThrow(VegetationPlacements.PATCH_TALL_GRASS));
        generationBuilder.addFeature(GenerationStep.Decoration.VEGETAL_DECORATION, placedFeatures.getOrThrow(VegetationPlacements.PATCH_LEAF_LITTER));

        // 3. Biome Construction
        return new Biome.BiomeBuilder()
                .hasPrecipitation(false).temperature(0.3f).downfall(0.0f)
                .setAttribute(EnvironmentAttributes.FOG_COLOR, 0x6845e3)
                .setAttribute(EnvironmentAttributes.WATER_FOG_COLOR, 0x3d619d)
                .setAttribute(EnvironmentAttributes.SKY_COLOR, 0x6845e3)
                .specialEffects(new BiomeSpecialEffects.Builder()
                        .waterColor(0x3d619d)
                        .foliageColorOverride(0x698bbe)
                        .dryFoliageColorOverride(0xc0d8ff)
                        .grassColorOverride(0x624fc3)
                        .build())
                .mobSpawnSettings(spawnBuilder.build())
                .generationSettings(generationBuilder.build())
                .build();
    }
}