package mh837.gile.mixin;

import com.mojang.datafixers.util.Pair;
import mh837.gile.GileModWorldgen;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.biome.OverworldBiomeBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;

@Mixin(OverworldBiomeBuilder.class)
public class OverworldBiomeBuilderMixin {

    @Inject(method = "addBiomes", at = @At("TAIL"))
    private void gile$addEndThresholdBiome(
            Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> biomes,
            CallbackInfo ci
    ) {
        biomes.accept(Pair.of(
                Climate.parameters(
                        Climate.Parameter.span(-0.45F, 0.20F),     // temperature: cold -> cool
                        Climate.Parameter.span(-1.0F, -0.35F),     // humidity: very dry
                        Climate.Parameter.span(-0.11F, 0.75F),     // continentalness
                        Climate.Parameter.span(-0.78F, -0.375F),   // erosion
                        Climate.Parameter.point(0.0F),        // depth
                        Climate.Parameter.span(-0.6F, 0.6F),       // weirdness
                        0.0F                                       // offset
                ),
                GileModWorldgen.END_THRESHOLD
        ));
    }
}