package mh837.gile.item;

import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;

public final class GileModItemHelper {

    private GileModItemHelper() {
    }

    public static ItemStack enchantedBook(
            Holder<Enchantment> enchantment,
            int level
    ) {
        return EnchantmentHelper.createBook(
                new EnchantmentInstance(enchantment, level)
        );
    }
}