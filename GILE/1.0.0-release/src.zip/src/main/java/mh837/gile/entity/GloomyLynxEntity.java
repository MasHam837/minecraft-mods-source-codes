package mh837.gile.entity;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.feline.CatSoundVariants;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import org.jetbrains.annotations.Nullable;

public class GloomyLynxEntity extends Animal implements Leashable {

    private static final EntityDataAccessor<Boolean> ANGRY = SynchedEntityData.defineId(GloomyLynxEntity.class, EntityDataSerializers.BOOLEAN);

    public GloomyLynxEntity(EntityType<? extends Animal> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new LeapAtTargetGoal(this, 0.4F) {
            @Override public boolean canUse() {return !GloomyLynxEntity.this.isBaby() && super.canUse();}
            @Override public boolean canContinueToUse() {return !GloomyLynxEntity.this.isBaby() && super.canContinueToUse();}});
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true) {
            @Override public boolean canUse() {return !GloomyLynxEntity.this.isBaby() && super.canUse();}
            @Override public boolean canContinueToUse() {return !GloomyLynxEntity.this.isBaby() && super.canContinueToUse();}});
        this.goalSelector.addGoal(3, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(4, new TemptGoal(this, 1.1, Ingredient.of(GileModItems.COOKED_PHASMA), false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        // Hunting logic: Actively target ghosts!
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true) {
            @Override public boolean canUse() {return !GloomyLynxEntity.this.isBaby() && super.canUse();}
            @Override public boolean canContinueToUse() {return !GloomyLynxEntity.this.isBaby() && super.canContinueToUse();}});
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, LuminousEntity.class, true) {
            @Override public boolean canUse() {return !GloomyLynxEntity.this.isBaby() && super.canUse();}
            @Override public boolean canContinueToUse() {return !GloomyLynxEntity.this.isBaby() && super.canContinueToUse();}});
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, HoveringGhostEntity.class, true) {
            @Override public boolean canUse() {return !GloomyLynxEntity.this.isBaby() && super.canUse();}
            @Override public boolean canContinueToUse() {return !GloomyLynxEntity.this.isBaby() && super.canContinueToUse();}});
    }

    public static AttributeSupplier.Builder createLynxAttributes() {
        return Animal.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 24.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 7.0)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.TEMPT_RANGE, 10.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(ANGRY, false);
    }

    public boolean isAngry() {
        return this.entityData.get(ANGRY);
    }

    public void setAngry(boolean angry) {
        this.entityData.set(ANGRY, angry);
    }

    @Override
    protected void customServerAiStep(ServerLevel level) {
        // Automatically become angry if it has a target it is actively hunting
        this.setAngry(this.getTarget() != null);
        super.customServerAiStep(level);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(GileModItems.COOKED_PHASMA);
    }

    @Override
    public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        // Forces the game to accept this spawn location even in absolute darkness
        // without needing vanilla Grass Blocks.
        return 10.0F;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);
        int looting = 0;
        if (damageSource.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEnchant = registry.get(Enchantments.LOOTING);
            if (lootingEnchant.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(
                        lootingEnchant.get(),
                        attacker.getMainHandItem()
                );
            }
        }

        int dropCount = 1 + this.random.nextInt(3 + looting);
        this.spawnAtLocation(level, new ItemStack(this.isOnFire() ? GileModItems.COOKED_PHASMA : GileModItems.PHASMA, dropCount));
        this.spawnAtLocation(level, new ItemStack(GileModBlocks.GLOOMY_FLOWER.asItem(), this.random.nextInt(2)));
    }

    @Override
    public boolean requiresCustomPersistence() {
        return super.requiresCustomPersistence();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return !this.hasCustomName();
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob entity) {
        return GileModEntities.GLOOMY_LYNX.create(level, EntitySpawnReason.BREEDING);
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return this.isAngry()
                ? SoundEvents.CAT_SOUNDS
                .get(CatSoundVariants.SoundSet.CLASSIC)
                .adultSounds()
                .hissSound()
                .value()
                : SoundEvents.FOX_AMBIENT;
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return this.random.nextInt(3) + 1;}

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.OCELOT_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.OCELOT_DEATH;
    }
}