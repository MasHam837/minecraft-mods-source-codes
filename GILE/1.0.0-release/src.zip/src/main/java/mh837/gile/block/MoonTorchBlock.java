package mh837.gile.block;

import mh837.gile.GileModParticleTypes;
import net.minecraft.world.level.block.TorchBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class MoonTorchBlock extends TorchBlock {
    public MoonTorchBlock(BlockBehaviour.Properties properties) {
        // Pass your custom END_FLAME particle straight to the super constructor.
        // TorchBlock will automatically handle the standard ambient torch flame spawning for you!
        super(GileModParticleTypes.END_FLAME, properties);
    }
}