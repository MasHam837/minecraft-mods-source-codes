package mh837.gile.item.tool;

import mh837.gile.GileModEnchantments;
import mh837.gile.GileModItems;

import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class FluttererUtil {

    private FluttererUtil() {
    }

    private static final Map<UUID, Boolean> PREVIOUS_GROUND_STATES = new HashMap<>();

    public static void updateGroundState(ServerPlayer player) {
        PREVIOUS_GROUND_STATES.put(
                player.getUUID(),
                player.onGround()
        );
    }

    private static boolean wasOnGround(ServerPlayer player) {
        return PREVIOUS_GROUND_STATES.getOrDefault(
                player.getUUID(),
                player.onGround()
        );
    }

    public static boolean isActive(Player player) {
        ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);

        if (chest.isEmpty()) {
            return false;
        }

        if (chest.is(GileModItems.FLUTTERER)) {
            return true;
        }

        Holder<net.minecraft.world.item.enchantment.Enchantment> enchantment =
                player.level()
                        .registryAccess()
                        .lookupOrThrow(Registries.ENCHANTMENT)
                        .getOrThrow(GileModEnchantments.FLUTTERING);

        return EnchantmentHelper.getItemEnchantmentLevel(
                enchantment,
                chest
        ) > 0;
    }

    public static boolean isFalling(Player player) {
        return !player.onGround()
                && player.getDeltaMovement().y < -0.01D;
    }

    private static final int AIR_JUMP_COOLDOWN = 5;

    private static final Map<UUID, Long> AIR_JUMP_COOLDOWNS = new HashMap<>();

    public static boolean canAirJump(ServerPlayer player) {
        long gameTime = player.level().getGameTime();

        long cooldownUntil = AIR_JUMP_COOLDOWNS.getOrDefault(
                player.getUUID(),
                0L
        );

        return gameTime >= cooldownUntil;
    }

    public static void setAirJumpCooldown(ServerPlayer player) {
        AIR_JUMP_COOLDOWNS.put(
                player.getUUID(),
                player.level().getGameTime() + AIR_JUMP_COOLDOWN
        );
    }

    public static boolean airJump(ServerPlayer player) {
        if (!isActive(player)) {
            return false;
        }

        if (player.onGround()) {
            return false;
        }

        if (wasOnGround(player)) {
            return false;
        }

        if (!canAirJump(player)) {
            return false;
        }

        setAirJumpCooldown(player);

        GileModTriggers.USE_FLUTTERER.trigger(player);

        player.addEffect(
                new MobEffectInstance(
                        MobEffects.LEVITATION,
                        5,
                        14,
                        false,
                        false,
                        false
                )
        );

        player.resetFallDistance();

        damageFlutterer(player);

        return true;
    }

    public static void applySlowFalling(ServerPlayer player) {
        if (!isActive(player) || !isFalling(player)) {
            return;
        }

        MobEffectInstance current =
                player.getEffect(MobEffects.SLOW_FALLING);

        if (current == null || current.getDuration() <= 5) {
            player.addEffect(
                    new MobEffectInstance(
                            MobEffects.SLOW_FALLING,
                            5,
                            0,
                            false,
                            false,
                            false
                    )
            );
        }
    }

    private static void damageFlutterer(ServerPlayer player) {
        ItemStack chest =
                player.getItemBySlot(EquipmentSlot.CHEST);

        if (chest.isEmpty()) {
            return;
        }

        if (chest.is(GileModItems.FLUTTERER)
                || hasFlutteringEnchantment(player, chest)) {

            chest.hurtAndBreak(
                    1,
                    player,
                    EquipmentSlot.CHEST
            );
        }
    }

    private static boolean hasFlutteringEnchantment(
            ServerPlayer player,
            ItemStack chest
    ) {
        Holder<net.minecraft.world.item.enchantment.Enchantment> enchantment =
                player.level()
                        .registryAccess()
                        .lookupOrThrow(Registries.ENCHANTMENT)
                        .getOrThrow(GileModEnchantments.FLUTTERING);

        return EnchantmentHelper.getItemEnchantmentLevel(
                enchantment,
                chest
        ) > 0;
    }
}