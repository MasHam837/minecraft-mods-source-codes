package mh837.gile.block.entity;

public enum WishRarity {

    NONE(0), COMMON(1), RARE(2), LEGENDARY(3);

    private final int id;

    WishRarity(int id) {this.id = id;}

    public int getId() {return this.id;}

    public static WishRarity fromId(int id) {for (WishRarity rarity : values()) {if (rarity.id == id) {return rarity;}}return NONE;}

}