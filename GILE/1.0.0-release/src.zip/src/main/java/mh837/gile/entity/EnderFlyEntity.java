package mh837.gile.entity;

import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import mh837.gile.entity.projectile.EnderFlyStingEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;

public class EnderFlyEntity extends PathfinderMob implements FlyingAnimal {

    private static final int ATTACK_COOLDOWN = 60;
    private int attackCooldown = 0;
    private static final int STING_INTERVAL = 8;
    private int stingIndex = -1;
    private int stingTimer = 0;
    private Player currentTarget;

    public EnderFlyEntity(
            EntityType<? extends PathfinderMob> entityType,
            Level level
    ) {
        super(entityType, level);
        this.moveControl = new FlyingMoveControl(this, 10, true);
        this.setNoGravity(true);
    }

    public static AttributeSupplier.Builder createFlyAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 15.0D)
                .add(Attributes.FLYING_SPEED, 0.4D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);

        int looting = 0;
        if (damageSource.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEntry = registry.get(Enchantments.LOOTING);
            if (lootingEntry.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(lootingEntry.get(), attacker.getMainHandItem());
            }
        }

        int minDrops = Math.min(3, looting);
        int maxDrops = Math.min(4, 2 + looting);
        int dropCount = minDrops + this.random.nextInt((maxDrops - minDrops) + 1);

        if (dropCount > 0) {
            this.spawnAtLocation(level, new ItemStack(GileModItems.PHASMA, dropCount));
            this.spawnAtLocation(level, new ItemStack(this.isOnFire() ? GileModItems.COOKED_PHASMA : GileModItems.PHASMA, dropCount));
            this.spawnAtLocation(level, new ItemStack(GileModItems.DUST, Math.max(dropCount - 1, 0)));
        }
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(5, new RandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        // Use standard constructor to avoid mapping/lambda mismatch errors;
        // creative/spectator safety filters are handled dynamically in tick()
        this.targetSelector.addGoal(
                1,
                new NearestAttackableTargetGoal<>(
                        this,
                        Player.class,
                        true
                )
        );
    }

    @Override
    public void tick() {
        super.tick();

        if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }

        if (this.level().isClientSide()) {
            return;
        }

        Player player = this.level().getNearestPlayer(this, 16.0D);

        if (this.stingIndex >= 0) {
            if (this.currentTarget == null
                    || !this.currentTarget.isAlive()
                    || this.currentTarget.isSpectator()
                    || this.currentTarget.getAbilities().invulnerable
                    || !this.hasLineOfSight(this.currentTarget)) {

                this.stingIndex = -1;
                this.currentTarget = null;
                this.attackCooldown = ATTACK_COOLDOWN;
                return;
            }

            // Continuously force the entity to look right at the player while firing stings
            this.getLookControl().setLookAt(this.currentTarget, 30.0F, 30.0F);

            if (this.stingTimer > 0) {
                this.stingTimer--;
                return;
            }

            fireStingAtIndex(this.currentTarget, this.stingIndex);

            this.stingIndex++;

            if (this.stingIndex >= 4) {
                this.stingIndex = -1;
                this.currentTarget = null;
                this.attackCooldown = ATTACK_COOLDOWN;
            } else {
                this.stingTimer = STING_INTERVAL;
            }

            return;
        }

        if (player != null
                && player.isAlive()
                && !player.isSpectator()
                && !player.getAbilities().invulnerable
                && this.hasLineOfSight(player)
                && this.distanceToSqr(player) <= 16.0D * 16.0D
                && this.attackCooldown <= 0) {

            this.currentTarget = player;
            this.stingIndex = 0;
            this.stingTimer = 0;

            // Look at player immediately upon lock-on
            this.getLookControl().setLookAt(player, 30.0F, 30.0F);
        }
    }

    private void fireSting(
            ServerLevel level,
            double localX,
            double localY,
            double localZ,
            double dx,
            double dy,
            double dz
    ) {
        float yaw = this.getYRot() * ((float) Math.PI / 180.0F);
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);

        double worldX = this.getX() + localX * cos - localZ * sin;
        double worldY = this.getY() + this.getBbHeight() * 0.5D + localY;
        double worldZ = this.getZ() + localX * sin + localZ * cos;

        EnderFlyStingEntity sting = new EnderFlyStingEntity(
                GileModEntities.ENDER_FLY_STING,
                level,
                this
        );

        sting.setPos(worldX, worldY, worldZ);
        sting.shoot(dx, dy, dz, 1.6F, 0.0F);

        level.addFreshEntity(sting);
    }

    @Override
    public boolean isFlying() {
        return !this.onGround();
    }

    @Override
    public boolean causeFallDamage(
            double fallDistance,
            float damageMultiplier,
            DamageSource source
    ) {
        return false;
    }

    private void fireStingAtIndex(Player target, int index) {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }

        double dx = target.getX() - this.getX();
        double dy = target.getEyeY() - (this.getY() + this.getBbHeight() * 0.5D);
        double dz = target.getZ() - this.getZ();
        double length = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (length < 0.001D) {
            return;
        }
        dx /= length;
        dy /= length;
        dz /= length;

        switch (index) {
            case 0 -> fireSting(serverLevel, -0.22D, 0.16D, -0.20D, dx, dy, dz);
            case 1 -> fireSting(serverLevel, 0.22D, 0.16D, -0.20D, dx, dy, dz);
            case 2 -> fireSting(serverLevel, -0.22D, -0.16D, -0.20D, dx, dy, dz);
            case 3 -> fireSting(serverLevel, 0.22D, -0.16D, -0.20D, dx, dy, dz);
        }
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return 5;}

}