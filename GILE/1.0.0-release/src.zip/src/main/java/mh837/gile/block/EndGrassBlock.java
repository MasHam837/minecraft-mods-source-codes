package mh837.gile.block;

import mh837.gile.GileModBlocks; // Make sure it points to your block registry class
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public class EndGrassBlock extends Block implements BonemealableBlock {

    public EndGrassBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        BlockPos abovePos = pos.above();BlockState aboveState = level.getBlockState(abovePos);
        if (!aboveState.isAir() && aboveState.isRedstoneConductor(level, abovePos)) {
            level.setBlock(pos, Blocks.END_STONE.defaultBlockState(), 3);}}

    // BONE MEAL LOGIC
    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state) {return level.getBlockState(pos.above()).isAir();}

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        BlockPos above = pos.above();

        for (int i = 0; i < 48; ++i) {
            BlockPos target = above;

            // Vanilla random walk
            for (int j = 0; j < i / 16; ++j) {
                target = target.offset(
                        random.nextInt(3) - 1,
                        (random.nextInt(3) - 1) * random.nextInt(3) / 2,
                        random.nextInt(3) - 1
                );

                if (!level.getBlockState(target.below()).is(this)
                        || level.getBlockState(target).isCollisionShapeFullBlock(level, target)) {
                }
            }

            BlockPos ground = target.below();

            // Spread End Grass
            if (level.getBlockState(ground).is(Blocks.END_STONE)
                    && level.getBlockState(target).isAir()) {

                level.setBlock(ground, defaultBlockState(), 3);

                float chance = random.nextFloat();

                if (chance < 0.12F) {
                    level.setBlock(target, GileModBlocks.TALL_END_GRASS.defaultBlockState(), 3);
                } else if (chance < 0.45F) {
                    level.setBlock(target, GileModBlocks.END_GRASS.defaultBlockState(), 3);}}

            // Vegetation on existing End Grass
            else if (level.getBlockState(ground).is(this)
                    && level.getBlockState(target).isAir()) {

                float chance = random.nextFloat();

                if (chance < 0.06F) {
                    level.setBlock(target, GileModBlocks.TALL_END_GRASS.defaultBlockState(), 3);
                } else if (chance < 0.22F) {
                    level.setBlock(target, GileModBlocks.END_GRASS.defaultBlockState(), 3);
                }
            }
        }
        level.levelEvent(1505, pos.above(), 0);
    }
}