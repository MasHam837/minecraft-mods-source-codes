package mh837.gile.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record FluttererJumpPayload() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<FluttererJumpPayload> TYPE = new CustomPacketPayload.Type<>(
            Identifier.fromNamespaceAndPath("gilemod", "flutterer_jump"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FluttererJumpPayload> CODEC = StreamCodec.unit(new FluttererJumpPayload());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() { return TYPE; }
}