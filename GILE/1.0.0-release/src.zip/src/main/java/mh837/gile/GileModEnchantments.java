package mh837.gile;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.enchantment.Enchantment;

public class GileModEnchantments {

    public static final ResourceKey<Enchantment> FLUTTERING = ResourceKey.create(Registries.ENCHANTMENT,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "fluttering"));

    public static final ResourceKey<Enchantment> RANGE = ResourceKey.create(Registries.ENCHANTMENT,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "range"));

    public static void initialize() {
        // Enchantments are data-driven in modern Minecraft.
    }
}