package mh837.gile.item.weapon;

import net.minecraft.world.item.Item;

public class CatalystItem extends Item {

    public CatalystItem(Properties properties) {
        super(properties);
    }
}