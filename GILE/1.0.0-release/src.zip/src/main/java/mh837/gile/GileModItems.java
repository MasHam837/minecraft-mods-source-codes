package mh837.gile;

import mh837.gile.item.FateArrowItem;
import mh837.gile.item.FateUpgradeSmithingTemplateItem;
import mh837.gile.item.GlowingChorusFruitItem;
import mh837.gile.item.tool.*;
import mh837.gile.item.weapon.NuclearCannonItem;
import mh837.gile.item.weapon.elemental.ElementalWeaponItems;
import mh837.gile.item.weapon.fate.FateBow;
import mh837.gile.item.weapon.fate.FateSword;
import mh837.gile.item.weapon.legendary.*;
import mh837.gile.item.weapon.primordial.PhanesBlade;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Unit;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.Repairable;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.item.equipment.Equippable;
import net.minecraft.world.level.Level;

import java.util.function.Function;

public class GileModItems {

    public static <T extends Item> T registerItem(String name, Function<Item.Properties, T> itemFactory, Item.Properties properties) {
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
        T item = itemFactory.apply(properties.setId(itemKey));
        return Registry.register(BuiltInRegistries.ITEM, itemKey, item);
    }

    public static Item registerSignItem(String name, Function<Item.Properties, Item> factory, Item.Properties baseProperties) {
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, itemKey, factory.apply(baseProperties.setId(itemKey)));
    }

    // === SIMPLE ITEMS ===
    public static final Item MORA = registerItem("mora", Item::new, new Item.Properties());
    public static final Item ANEMO_SIGIL = registerItem("anemo_sigil", Item::new, new Item.Properties());
    public static final Item GEO_SIGIL = registerItem("geo_sigil", Item::new, new Item.Properties());
    public static final Item ELECTRO_SIGIL = registerItem("electro_sigil", Item::new, new Item.Properties());
    public static final Item DENDRO_SIGIL = registerItem("dendro_sigil", Item::new, new Item.Properties());
    public static final Item HYDRO_SIGIL = registerItem("hydro_sigil", Item::new, new Item.Properties());
    public static final Item PYRO_SIGIL = registerItem("pyro_sigil", Item::new, new Item.Properties());
    public static final Item CRYO_SIGIL = registerItem("cryo_sigil", Item::new, new Item.Properties());
    public static final Item LUNA_SIGIL = registerItem("luna_sigil", Item::new, new Item.Properties());
    public static final Item SIGILS_ANIMATION = registerItem("sigils_animation", Item::new, new Item.Properties());

    public static final Item PRIMOGEM = registerItem("primogem", Item::new, new Item.Properties());
    public static final Item WISH_INGOT = registerItem("wish_ingot", Item::new, new Item.Properties()
                            .delayedHolderComponent(DataComponents.PROVIDES_TRIM_MATERIAL, GileModTrimMaterials.WISH_INGOT));
    public static final Item WISH_NUGGET = registerItem("wish_nugget", Item::new, new Item.Properties());
    public static final Item CRYSTAL = registerItem("crystal", Item::new, new Item.Properties());

    public static final Item MOTH_WING = registerItem("moth_wing", Item::new, new Item.Properties());
    public static final Item VOID_SLIMEBALL = registerItem("void_slimeball", Item::new, new Item.Properties());
    public static final Item CHRONO_GEAR = registerItem("chrono_gear", Item::new, new Item.Properties());
    public static final Item STAR_FRAGMENT = registerItem("star_fragment", Item::new, new Item.Properties());
    public static final Item JERBOAS_TAIL = registerItem("jerboas_tail", Item::new, new Item.Properties());

    public static final Item STAR_DUST = registerItem("star_dust", Item::new, new Item.Properties());
    public static final Item STAR_SHINE = registerItem("star_shine", Item::new, new Item.Properties());
    public static final Item PEARLESCENT_MATERIAL = registerItem("pearlescent_material", Item::new, new Item.Properties());
    public static final Item GENESIS_CRYSTAL = registerItem("genesis_crystal", Item::new, new Item.Properties());
    public static final Item DUST = registerItem("dust", Item::new, new Item.Properties());
    public static final Item COGWORK_CORE = registerItem("cogwork_core", Item::new, new Item.Properties());

    public static final Item ENDERITE_SHARD = registerItem("enderite_shard", Item::new, new Item.Properties());
    public static final Item ENDERITE_INGOT = registerItem("enderite_ingot", Item::new, new Item.Properties()
                            .delayedHolderComponent(DataComponents.PROVIDES_TRIM_MATERIAL, GileModTrimMaterials.ENDERITE_INGOT));

    // --- FOOD ITEMS ---
    public static final Item JELLY = registerItem("jelly", Item::new, new Item.Properties()
            .food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3f).build()));
    public static final Item JAM = registerItem("jam", Item::new, new Item.Properties()
            .food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.4f).build()));
    public static final Item PHASMA = registerItem("phasma", Item::new, new Item.Properties()
            .food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.4f).build()));
    public static final Item COOKED_PHASMA = registerItem("cooked_phasma", Item::new, new Item.Properties()
            .food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.5f).build()));
    public static final Item OFFERING = registerItem("offering", props -> new Item(props) {
                @Override
                public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity user) {
                    if (!level.isClientSide()) {user.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 1200, 0));}
                    ItemStack result = super.finishUsingItem(stack, level, user);
                    if (user instanceof Player player && !player.getAbilities().instabuild) {return new ItemStack(Items.BOWL);}return result;}},
            new Item.Properties().stacksTo(1).food(new FoodProperties.Builder().nutrition(8).saturationModifier(1.2f).alwaysEdible().build()));
    public static final Item GLOWING_CHORUS_FRUIT = registerItem("glowing_chorus_fruit", GlowingChorusFruitItem::new,
            new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.3f).alwaysEdible().build()));
    public static final Item GLOWING_POPPED_CHORUS_FRUIT = registerItem("glowing_popped_chorus_fruit", Item::new, new Item.Properties());

    // --- TOOLS, WEAPONS & EQUIPMENT ---
    public static final Item SHRINKER = registerItem("shrinker", ShrinkerItem::new, new Item.Properties().durability(191));
    public static final Item ENLARGER = registerItem("enlarger", EnlargerItem::new, new Item.Properties().durability(191));
    public static final Item JELLY_ON_A_STICK = registerItem("jelly_on_a_stick", JellyOnAStickItem::new, new Item.Properties().durability(25));
    public static final Item HEART_OF_EMERGENCY = registerItem("heart_of_emergency", HeartOfEmergencyItem::new, new Item.Properties().stacksTo(1));
    public static final Item WARP_CLOCK = registerItem("warp_clock", WarpClockItem::new, new Item.Properties().stacksTo(16));
    public static final Item GRAPPLING_HOOK = registerItem("grappling_hook", GrapplingHookItem::new, new Item.Properties()
                    .stacksTo(1).durability(282).component(DataComponents.REPAIRABLE, new Repairable(
                    HolderSet.direct(GileModItems.WISH_INGOT.asItem().builtInRegistryHolder()))));
    public static final Item END_COMPASS = registerItem("end_compass", EndCompassItem::new, new Item.Properties().stacksTo(16));
    public static final Item NUCLEAR_CANNON = registerItem("nuclear_cannon", NuclearCannonItem::new, new Item.Properties().stacksTo(1).durability(40));

    public static final ResourceKey<EquipmentAsset> FLUTTERER_ASSET = ResourceKey.create(EquipmentAssets.ROOT_ID,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "flutterer"));
    public static final Item FLUTTERER = registerItem("flutterer", FluttererItem::new, new Item.Properties()
            .stacksTo(1).durability(324).component(DataComponents.EQUIPPABLE, Equippable.builder(EquipmentSlot.CHEST)
                    .setSwappable(true).setDamageOnHurt(true).setAsset(FLUTTERER_ASSET).build())
                    .component(DataComponents.REPAIRABLE, new Repairable(HolderSet.direct(GileModItems.MOTH_WING.builtInRegistryHolder()))));

    public static final Item FATE_UPGRADE_SMITHING_TEMPLATE = registerItem("fate_upgrade_smithing_template", FateUpgradeSmithingTemplateItem::new, new Item.Properties());
    public static final Item FATE_SWORD = registerItem("fate_sword", FateSword::new, new Item.Properties().sword(GileModMaterials.FATE_SWORD_MATERIAL, 0.0f, -2.4f));
    public static final Item FATE_BOW = registerItem("fate_bow", FateBow::new, new Item.Properties().durability(1536));
    public static final Item FATE_ARROW = registerItem("fate_arrow", FateArrowItem::new, new Item.Properties());

    public static final Item ENDERITE_PICKAXE = registerItem("enderite_pickaxe", Item::new, new Item.Properties().pickaxe(
            GileModMaterials.ENDERITE_TOOLS, 1.0F, -2.8F).fireResistant());
    public static final Item ENDERITE_AXE = registerItem("enderite_axe", properties -> new AxeItem(
            GileModMaterials.ENDERITE_TOOLS, 5.0F, -3.0F, properties), new Item.Properties().fireResistant());
    public static final Item ENDERITE_SHOVEL = registerItem("enderite_shovel", properties -> new ShovelItem(
            GileModMaterials.ENDERITE_TOOLS, 1.0F, -3.0F, properties), new Item.Properties().fireResistant());
    public static final Item ENDERITE_HOE = registerItem("enderite_hoe", properties -> new HoeItem(
            GileModMaterials.ENDERITE_TOOLS, -5.0F, 0.0F, properties), new Item.Properties().fireResistant());
    public static final Item ENDERITE_SWORD = registerItem("enderite_sword", Item::new, new Item.Properties().sword(
            GileModMaterials.ENDERITE_TOOLS, 3.0F, -2.4F).fireResistant());
    public static final Item ENDERITE_SPEAR = registerItem("enderite_spear", Item::new, new Item.Properties()
            .spear(GileModMaterials.ENDERITE_TOOLS, 1.10f, 1.22f, 0.35f, 2.5f,
                    9.0f, 5.5f, 5.0f, 8.75f, 6.0f).fireResistant());

    public static final Item ENDERITE_HELMET = registerItem("enderite_helmet", Item::new,
            new Item.Properties().humanoidArmor(GileModMaterials.ENDERITE_ARMOR, ArmorType.HELMET).fireResistant());
    public static final Item ENDERITE_CHESTPLATE = registerItem("enderite_chestplate", Item::new,
            new Item.Properties().humanoidArmor(GileModMaterials.ENDERITE_ARMOR, ArmorType.CHESTPLATE).fireResistant());
    public static final Item ENDERITE_LEGGINGS = registerItem("enderite_leggings", Item::new,
            new Item.Properties().humanoidArmor(GileModMaterials.ENDERITE_ARMOR, ArmorType.LEGGINGS).fireResistant());
    public static final Item ENDERITE_BOOTS = registerItem("enderite_boots", Item::new,
            new Item.Properties().humanoidArmor(GileModMaterials.ENDERITE_ARMOR, ArmorType.BOOTS).fireResistant());

    // --- SIGN AND BLOCK ITEMS ---
    public static final Item GHOSTLY_SIGN_ITEM = registerSignItem("ghostly_sign",
            props -> new SignItem(GileModBlocks.GHOSTLY_SIGN, GileModBlocks.GHOSTLY_WALL_SIGN, props), new Item.Properties().stacksTo(16));
    public static final Item GHOSTLY_HANGING_SIGN_ITEM = registerSignItem("ghostly_hanging_sign",
            props -> new HangingSignItem(GileModBlocks.GHOSTLY_HANGING_SIGN, GileModBlocks.GHOSTLY_WALL_HANGING_SIGN, props), new Item.Properties().stacksTo(16));
    public static final Item INVERTED_OAK_SIGN_ITEM = registerSignItem("inverted_oak_sign",
            props -> new SignItem(GileModBlocks.INVERTED_OAK_SIGN, GileModBlocks.INVERTED_OAK_WALL_SIGN, props), new Item.Properties().stacksTo(16));
    public static final Item INVERTED_OAK_HANGING_SIGN_ITEM = registerSignItem("inverted_oak_hanging_sign",
            props -> new HangingSignItem(GileModBlocks.INVERTED_OAK_HANGING_SIGN, GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN, props), new Item.Properties().stacksTo(16));

    private static final ResourceKey<Item> MOON_TORCH_ITEM_KEY = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "moon_torch"));
    public static final Item MOON_TORCH_ITEM = Registry.register(BuiltInRegistries.ITEM, MOON_TORCH_ITEM_KEY,
            new StandingAndWallBlockItem(GileModBlocks.MOON_TORCH, GileModBlocks.MOON_WALL_TORCH, Direction.DOWN, new Item.Properties().setId(MOON_TORCH_ITEM_KEY)));

    // --- ELEMENTAL / LEGENDARY / PRIMORDIAL WEAPONS ---
    public static final Item DAYBREAK_CHRONICLES = registerItem("daybreak_chronicles", ElementalWeaponItems.DaybreakChronicles::new, new Item.Properties().stacksTo(1)
            .attributes(ElementalWeaponItems.DaybreakChronicles.ElementalWeaponAttributes.createBow())
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item VORTEX_VANQUISHER = registerItem("vortex_vanquisher", ElementalWeaponItems.VortexVanquisher::new,
            new Item.Properties().stacksTo(1).spear(GileModMaterials.ELEMENTAL_WEAPONS, 1.20F,
                            1.35F, 0.65F, 2.25F, 8.5F,
                            4.75F, 5.0F, 8.0F, 4.8F)
                    .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item ENGULFING_LIGHTNING = registerItem("engulfing_lightning", ElementalWeaponItems.EngulfingLightning::new,
            new Item.Properties().stacksTo(1).spear(GileModMaterials.ELEMENTAL_WEAPONS, 0.90F,
                            1.05F, 0.50F, 2.25F, 7.5F,
                            4.75F, 4.5F, 8.0F, 4.2F)
                    .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item THOUSAND_FLOATING_DREAMS = registerItem("thousand_floating_dreams", ElementalWeaponItems.ThousandFloatingDreams::new, new Item.Properties().stacksTo(1)
            .attributes(ElementalWeaponItems.DaybreakChronicles.ElementalWeaponAttributes.create(7.0D, -2.2D))
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item SPLENDOR_OF_TRANQUIL_WATERS = registerItem("splendor_of_tranquil_waters", ElementalWeaponItems.SplendorOfTranquilWaters::new, new Item.Properties().stacksTo(1)
            .sword(GileModMaterials.ELEMENTAL_WEAPONS, 0.0F, -2.4F)
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item THOUSAND_BLAZING_SUNS = registerItem("thousand_blazing_suns", ElementalWeaponItems.ThousandBlazingSuns::new, new Item.Properties().stacksTo(1)
            .sword(GileModMaterials.ELEMENTAL_WEAPONS, 0.0F, -2.4F)
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item HIEMAL_MANDATE = registerItem("hiemal_mandate", ElementalWeaponItems.HiemalMandate::new, new Item.Properties().stacksTo(1)
            .sword(GileModMaterials.ELEMENTAL_WEAPONS, 0.0F, -2.4F)
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item NOCTURNES_CURTAIN_CALL = registerItem("nocturnes_curtain_call", ElementalWeaponItems.NocturnesCurtainCall::new, new Item.Properties().stacksTo(1)
            .attributes(ElementalWeaponItems.DaybreakChronicles.ElementalWeaponAttributes.create(7.0D, -2.3D))
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));

    public static final Item TOME_OF_NABERIUS = registerItem("tome_of_naberius", LegendaryWeaponItems.TomeOfNaberius::new, new Item.Properties().stacksTo(1)
            .attributes(LegendaryWeaponItems.LegendaryWeaponAttributes.create(11.0D, 0.0D))
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item PALM_OF_ASMODAY = registerItem("palm_of_asmoday", LegendaryWeaponItems.PalmOfAsmoday::new, new Item.Properties().stacksTo(1)
            .attributes(LegendaryWeaponItems.LegendaryWeaponAttributes.create(11.0D, 0.0D))
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item HOURGLASS_OF_ISTAROTH = registerItem("hourglass_of_istaroth", LegendaryWeaponItems.HourglassOfIstaroth::new, new Item.Properties().stacksTo(1)
            .attributes(LegendaryWeaponItems.LegendaryWeaponAttributes.create(11.0D, 0.0D))
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));
    public static final Item SCYTHE_OF_RONOVA = registerItem("scythe_of_ronova", LegendaryWeaponItems.ScytheOfRonova::new,
            new Item.Properties().stacksTo(1).attributes(LegendaryWeaponItems.LegendaryWeaponAttributes.create(0.0D, 0.0D))
                    .spear(GileModMaterials.LEGENDARY_WEAPONS, 1.10f, 1.22f, 0.35f, 2.5f,
                            9.0f, 5.5f, 5.0f, 8.75f, 6.0f)
                    .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));

    public static final Item PHANES_BLADE = registerItem("phanes_blade", PhanesBlade::new, new Item.Properties()
            .sword(GileModMaterials.PRIMORDIAL_WEAPONS, 7.0F, -2.4F)
            .component(GileModDataComponents.WEAPON_LEVEL, 1).component(DataComponents.UNBREAKABLE, Unit.INSTANCE));

    public static void initialize() {

        System.out.println("Successfully registered 26.1 Mod Items for " + GileMod.MOD_ID);

    }
}
