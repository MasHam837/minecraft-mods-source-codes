package mh837.gile;

import mh837.gile.item.GileModItemHelper;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public class GileModCreativeTabs {

    public static final CreativeModeTab GILE_TAB =
            CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
                    .title(Component.translatable("itemgroup.gilemod.gile"))
                    .icon(() -> new ItemStack(GileModItems.PRIMOGEM))
                    .displayItems((parameters, output) -> {
                        // I CURRENCY
                        output.accept(GileModItems.MORA); output.accept(GileModItems.ANEMO_SIGIL); output.accept(GileModItems.GEO_SIGIL);
                        output.accept(GileModItems.ELECTRO_SIGIL); output.accept(GileModItems.DENDRO_SIGIL); output.accept(GileModItems.HYDRO_SIGIL);
                        output.accept(GileModItems.PYRO_SIGIL); output.accept(GileModItems.CRYO_SIGIL); output.accept(GileModItems.LUNA_SIGIL);
                        // II PHANES & ELEMENTAL WEAPONS
                        output.accept(GileModItems.PHANES_BLADE);
                        output.accept(GileModItems.DAYBREAK_CHRONICLES); output.accept(GileModItems.VORTEX_VANQUISHER);
                        output.accept(GileModItems.ENGULFING_LIGHTNING); output.accept(GileModItems.THOUSAND_FLOATING_DREAMS);
                        output.accept(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS); output.accept(GileModItems.THOUSAND_BLAZING_SUNS);
                        output.accept(GileModItems.HIEMAL_MANDATE); output.accept(GileModItems.NOCTURNES_CURTAIN_CALL);
                        // III LEGENDARY WEAPONS & ORES
                        output.accept(GileModItems.TOME_OF_NABERIUS); output.accept(GileModItems.PALM_OF_ASMODAY);
                        output.accept(GileModItems.HOURGLASS_OF_ISTAROTH); output.accept(GileModItems.SCYTHE_OF_RONOVA);
                        output.accept(GileModBlocks.PRIMOGEM_ORE); output.accept(GileModBlocks.DEEPSLATE_PRIMOGEM_ORE);
                        output.accept(GileModBlocks.END_PRIMOGEM_ORE); output.accept(GileModBlocks.ENDERITE_ORE);
                        output.accept(GileModBlocks.ENDERITE_BLOCK);
                        // IV MOON SAND/STONE
                        output.accept(GileModBlocks.WISH);
                        output.accept(GileModBlocks.PEARLESCENT_BLOCK); output.accept(GileModBlocks.PEARLESCENT_STAIRS);
                        output.accept(GileModBlocks.PEARLESCENT_SLAB); output.accept(GileModBlocks.PEARLESCENT_WALL);
                        output.accept(GileModBlocks.PEARLESCENT_BRICKS); output.accept(GileModBlocks.PEARLESCENT_BRICKS_STAIRS);
                        output.accept(GileModBlocks.PEARLESCENT_BRICKS_SLAB); output.accept(GileModBlocks.PEARLESCENT_BRICKS_WALL);
                        // V MOON SANDSTONE & WISH/PEARLESCENT BLOCK SET
                        output.accept(GileModBlocks.MOON_SAND);
                        output.accept(GileModBlocks.MOON_SANDSTONE); output.accept(GileModBlocks.MOON_SANDSTONE_STAIRS);
                        output.accept(GileModBlocks.MOON_SANDSTONE_SLAB); output.accept(GileModBlocks.MOON_SANDSTONE_WALL);
                        output.accept(GileModBlocks.MOON_CHISELED_SANDSTONE); output.accept(GileModBlocks.MOON_SMOOTH_SANDSTONE);
                        output.accept(GileModBlocks.MOON_SMOOTH_SANDSTONE_STAIRS); output.accept(GileModBlocks.MOON_SMOOTH_SANDSTONE_SLAB);
                        // VI OTHER NOT FLAT BLOCKS
                        output.accept(GileModBlocks.MOON_CUT_SANDSTONE); output.accept(GileModBlocks.MOON_CUT_SANDSTONE_SLAB);
                        output.accept(GileModBlocks.GLOWING_CHORUS_FLOWER);
                        output.accept(GileModBlocks.FLUO_BLOCK); output.accept(GileModBlocks.FLUO_PILLAR);
                        output.accept(GileModBlocks.FLUO_STAIRS); output.accept(GileModBlocks.FLUO_SLAB);
                        output.accept(GileModBlocks.GLITTER_BLOCK); output.accept(GileModBlocks.GLITTER_CARPET);
                        // VII GHOSTLY WOOD 1st row
                        output.accept(GileModBlocks.GHOSTLY_LOG);
                        output.accept(GileModBlocks.GHOSTLY_WOOD); output.accept(GileModBlocks.STRIPPED_GHOSTLY_LOG);
                        output.accept(GileModBlocks.STRIPPED_GHOSTLY_WOOD); output.accept(GileModBlocks.GHOSTLY_PLANKS);
                        output.accept(GileModBlocks.GHOSTLY_STAIRS); output.accept(GileModBlocks.GHOSTLY_SLAB);
                        output.accept(GileModBlocks.GHOSTLY_FENCE); output.accept(GileModBlocks.GHOSTLY_FENCE_GATE);
                        // VIII GHOSTLY WOOD 2nd row
                        output.accept(GileModBlocks.GHOSTLY_DOOR);
                        output.accept(GileModBlocks.GHOSTLY_TRAPDOOR); output.accept(GileModBlocks.GHOSTLY_PRESSURE_PLATE);
                        output.accept(GileModBlocks.GHOSTLY_BUTTON); output.accept(GileModBlocks.GHOSTLY_SIGN);
                        output.accept(GileModBlocks.GHOSTLY_HANGING_SIGN); output.accept(GileModBlocks.GHOSTLY_SHELF);
                        output.accept(GileModBlocks.GHOSTLY_LEAVES); output.accept(GileModBlocks.GHOSTLY_SAPLING);
                        // IX INVERTED OAK WOOD 1st row
                        output.accept(GileModBlocks.INVERTED_OAK_LOG);
                        output.accept(GileModBlocks.INVERTED_OAK_WOOD); output.accept(GileModBlocks.STRIPPED_INVERTED_OAK_LOG);
                        output.accept(GileModBlocks.STRIPPED_INVERTED_OAK_WOOD); output.accept(GileModBlocks.INVERTED_OAK_PLANKS);
                        output.accept(GileModBlocks.INVERTED_OAK_STAIRS); output.accept(GileModBlocks.INVERTED_OAK_SLAB);
                        output.accept(GileModBlocks.INVERTED_OAK_FENCE); output.accept(GileModBlocks.INVERTED_OAK_FENCE_GATE);
                        // X INVERTED OAK WOOD 2nd row
                        output.accept(GileModBlocks.INVERTED_OAK_DOOR);
                        output.accept(GileModBlocks.INVERTED_OAK_TRAPDOOR); output.accept(GileModBlocks.INVERTED_OAK_PRESSURE_PLATE);
                        output.accept(GileModBlocks.INVERTED_OAK_BUTTON); output.accept(GileModBlocks.INVERTED_OAK_SIGN);
                        output.accept(GileModBlocks.INVERTED_OAK_HANGING_SIGN); output.accept(GileModBlocks.INVERTED_OAK_SHELF);
                        output.accept(GileModBlocks.INVERTED_OAK_LEAVES); output.accept(GileModBlocks.INVERTED_OAK_SAPLING);
                        // XI MISC & FLAT BLOCKS/PLANTS
                        output.accept(GileModBlocks.WISH_TABLE); output.accept(GileModBlocks.END_GRASS_BLOCK); output.accept(GileModBlocks.END_CLOUD);
                        output.accept(GileModBlocks.STAR); output.accept(GileModBlocks.TALL_END_GRASS); output.accept(GileModBlocks.END_GRASS);
                        output.accept(GileModBlocks.DRY_FLOWER); output.accept(GileModBlocks.GLOOMY_FLOWER); output.accept(GileModBlocks.MOON_FLOWER);
                        // XII LIGHT BLOCKS & FIRST MATERIALS
                        output.accept(GileModItems.MOON_TORCH_ITEM);
                        output.accept(GileModBlocks.MOON_LANTERN); output.accept(GileModBlocks.PEARLESCENT_CHAIN);
                        output.accept(GileModBlocks.MOON_CAMPFIRE); output.accept(GileModBlocks.JAR_OF_GLITTERS);
                        output.accept(GileModItems.CHRONO_GEAR); output.accept(GileModItems.CRYSTAL);
                        output.accept(GileModItems.WISH_INGOT); output.accept(GileModItems.WISH_NUGGET);
                        // XIII MATERIALS & ORES
                        output.accept(GileModItems.DUST); output.accept(GileModItems.GENESIS_CRYSTAL);
                        output.accept(GileModItems.PEARLESCENT_MATERIAL); output.accept(GileModItems.PRIMOGEM);
                        output.accept(GileModItems.STAR_FRAGMENT); output.accept(GileModItems.STAR_DUST); output.accept(GileModItems.STAR_SHINE);
                        output.accept(GileModItems.ENDERITE_INGOT); output.accept(GileModItems.ENDERITE_SHARD);
                        // XIV TOOLS
                        output.accept(GileModItems.END_COMPASS); output.accept(GileModItems.FLUTTERER); output.accept(GileModItems.GRAPPLING_HOOK);
                        output.accept(GileModItems.HEART_OF_EMERGENCY); output.accept(GileModItems.JELLY_ON_A_STICK);
                        output.accept(GileModItems.NUCLEAR_CANNON); output.accept(GileModItems.WARP_CLOCK);
                        output.accept(GileModItems.SHRINKER); output.accept(GileModItems.ENLARGER);
                        // XV FATE COLLECTION & ENDERITE ARMOR
                        output.accept(GileModItems.FATE_SWORD); output.accept(GileModItems.FATE_BOW);
                        output.accept(GileModItems.FATE_ARROW); output.accept(GileModItems.FATE_UPGRADE_SMITHING_TEMPLATE);
                        output.accept(GileModItems.ENDERITE_HELMET); output.accept(GileModItems.ENDERITE_CHESTPLATE);
                        output.accept(GileModItems.ENDERITE_LEGGINGS); output.accept(GileModItems.ENDERITE_BOOTS);
                        output.accept(GileModItems.ENDERITE_SPEAR);
                        // XVI ENDERITE TOOLS
                        output.accept(GileModItems.ENDERITE_SWORD);
                        output.accept(GileModItems.ENDERITE_SHOVEL); output.accept(GileModItems.ENDERITE_PICKAXE);
                        output.accept(GileModItems.ENDERITE_AXE); output.accept(GileModItems.ENDERITE_HOE);
                        output.accept(GileModItems.COGWORK_CORE); output.accept(GileModItems.GLOWING_CHORUS_FRUIT);
                        output.accept(GileModItems.GLOWING_POPPED_CHORUS_FRUIT); output.accept(GileModItems.JAM);
                        // XVII FOOD/DROPS & FIRST SPAWN EGGS
                        output.accept(GileModItems.JELLY); output.accept(GileModItems.JERBOAS_TAIL);
                        output.accept(GileModItems.MOTH_WING); output.accept(GileModItems.OFFERING);
                        output.accept(GileModItems.PHASMA);  output.accept(GileModItems.COOKED_PHASMA); output.accept(GileModItems.VOID_SLIMEBALL);
                        output.accept(GileModEntities.ENDER_FLY_SPAWN_EGG); output.accept(GileModEntities.GLITTER_SPAWN_EGG);
                        // XVIII SPAWN EGGS
                        output.accept(GileModEntities.GLOOMY_LYNX_SPAWN_EGG); output.accept(GileModEntities.HOVERING_GHOST_SPAWN_EGG);
                        output.accept(GileModEntities.JERBOA_SPAWN_EGG); output.accept(GileModEntities.LUMINOUS_SPAWN_EGG);
                        output.accept(GileModEntities.MOTH_SPAWN_EGG); output.accept(GileModEntities.RUIN_GUARD_SPAWN_EGG);
                        output.accept(GileModEntities.SALON_MEMBER_SPAWN_EGG); output.accept(GileModEntities.VOID_SLIME_SPAWN_EGG);
                        output.accept(GileModEntities.WEASEL_THIEF_SPAWN_EGG);
                        // XIX ENCHANTMENT BOOKS
                        output.accept(GileModItemHelper.enchantedBook(parameters.holders().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(GileModEnchantments.FLUTTERING), 1));
                        output.accept(GileModItemHelper.enchantedBook(parameters.holders().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(GileModEnchantments.RANGE), 1));
                        output.accept(GileModItemHelper.enchantedBook(parameters.holders().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(GileModEnchantments.RANGE), 2));
                        output.accept(GileModItemHelper.enchantedBook(parameters.holders().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(GileModEnchantments.RANGE), 3));
                        output.accept(GileModItemHelper.enchantedBook(parameters.holders().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(GileModEnchantments.RANGE), 4));

                    }).build();


    public static void initialize() {

        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "gile"), GILE_TAB);

    }
}