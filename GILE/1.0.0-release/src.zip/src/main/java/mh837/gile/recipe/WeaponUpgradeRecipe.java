package mh837.gile.recipe;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mh837.gile.item.weapon.WeaponLevel;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;
import mh837.gile.item.weapon.WeaponDamage;

public final class WeaponUpgradeRecipe extends CustomRecipe {

    public enum Mode {
        DUPLICATE,
        ADDITIVE
    }

    /*
     * Default recipe mode.
     *
     * DUPLICATE:
     * 1 + 1 = 2
     * 2 + 2 = 3
     * 3 + 3 = 4
     * 4 + 4 = 5
     */
    public static final WeaponUpgradeRecipe INSTANCE =
            new WeaponUpgradeRecipe(Mode.DUPLICATE);

    /*
     * JSON:
     *
     * {
     *   "type": "gilemod:weapon_upgrade",
     *   "mode": "duplicate"
     * }
     *
     * or:
     *
     * {
     *   "type": "gilemod:weapon_upgrade",
     *   "mode": "additive"
     * }
     */
    public static final MapCodec<WeaponUpgradeRecipe> CODEC =
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    com.mojang.serialization.Codec.STRING
                            .optionalFieldOf("mode", "duplicate")
                            .xmap(
                                    WeaponUpgradeRecipe::parseMode,
                                    WeaponUpgradeRecipe::modeName
                            )
                            .forGetter(recipe -> recipe.mode)
            ).apply(instance, WeaponUpgradeRecipe::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, WeaponUpgradeRecipe> STREAM_CODEC =
            StreamCodec.of(
                    (buf, recipe) -> buf.writeEnum(recipe.mode),
                    buf -> new WeaponUpgradeRecipe(buf.readEnum(Mode.class))
            );

    public static final RecipeSerializer<WeaponUpgradeRecipe> SERIALIZER =
            new RecipeSerializer<>(CODEC, STREAM_CODEC);

    private final Mode mode;

    public WeaponUpgradeRecipe(Mode mode) {
        super();
        this.mode = mode;
    }

    private static Mode parseMode(String mode) {
        return switch (mode.toLowerCase()) {
            case "additive" -> Mode.ADDITIVE;
            case "duplicate" -> Mode.DUPLICATE;
            default -> throw new IllegalArgumentException(
                    "Unknown weapon upgrade mode: " + mode
            );
        };
    }

    private static String modeName(Mode mode) {
        return switch (mode) {
            case ADDITIVE -> "additive";
            case DUPLICATE -> "duplicate";
        };
    }

    public Mode getMode() {
        return mode;
    }

    // =========================================================
    // MATCHES
    // =========================================================

    @Override
    public boolean matches(CraftingInput input, Level level) {
        ItemStack first = ItemStack.EMPTY;
        ItemStack second = ItemStack.EMPTY;

        for (int slot = 0; slot < input.size(); slot++) {

            ItemStack stack = input.getItem(slot);

            if (stack.isEmpty()) {
                continue;
            }

            if (first.isEmpty()) {
                first = stack;
            } else if (second.isEmpty()) {
                second = stack;
            } else {
                // More than two items.
                return false;
            }
        }

        // Exactly two items are required.
        if (first.isEmpty() || second.isEmpty()) {
            return false;
        }

        // Both must be your weapons.
        if (!WeaponLevel.isWeapon(first)
                || !WeaponLevel.isWeapon(second)) {
            return false;
        }

        // Must be the exact same weapon.
        if (first.getItem() != second.getItem()) {
            return false;
        }

        int firstLevel = WeaponLevel.get(first);
        int secondLevel = WeaponLevel.get(second);

        // =====================================================
        // DUPLICATE MODE
        // =====================================================

        if (mode == Mode.DUPLICATE) {

            /*
             * 1 + 1 = 2
             * 2 + 2 = 3
             * 3 + 3 = 4
             * 4 + 4 = 5
             */

            if (firstLevel != secondLevel) {
                return false;
            }

            return firstLevel < WeaponLevel.MAX_LEVEL;
        }

        // =====================================================
        // ADDITIVE MODE
        // =====================================================

        if (mode == Mode.ADDITIVE) {

            /*
             * 1 + 1 = 2
             * 2 + 1 = 3
             * 3 + 1 = 4
             * 4 + 1 = 5
             *
             * Also:
             *
             * 2 + 3 = 5
             * 3 + 2 = 5
             *
             * The two levels are added together.
             */

            return firstLevel + secondLevel <= WeaponLevel.MAX_LEVEL;
        }

        return false;
    }

    // =========================================================
    // ASSEMBLE
    // =========================================================

    @Override
    public ItemStack assemble(CraftingInput input) {

        ItemStack first = ItemStack.EMPTY;
        ItemStack second = ItemStack.EMPTY;

        for (int slot = 0; slot < input.size(); slot++) {

            ItemStack stack = input.getItem(slot);

            if (stack.isEmpty()) {
                continue;
            }

            if (first.isEmpty()) {
                first = stack;
            } else if (second.isEmpty()) {
                second = stack;
            } else {
                return ItemStack.EMPTY;
            }
        }

        if (first.isEmpty() || second.isEmpty()) {
            return ItemStack.EMPTY;
        }

        // Both must be valid weapons.
        if (!WeaponLevel.isWeapon(first)
                || !WeaponLevel.isWeapon(second)) {
            return ItemStack.EMPTY;
        }

        // Must be exactly the same weapon.
        if (first.getItem() != second.getItem()) {
            return ItemStack.EMPTY;
        }

        int firstLevel = WeaponLevel.get(first);
        int secondLevel = WeaponLevel.get(second);

        int resultLevel;

        // =====================================================
        // DUPLICATE MODE
        // =====================================================

        if (mode == Mode.DUPLICATE) {

            /*
             * 1 + 1 = 2
             * 2 + 2 = 3
             * 3 + 3 = 4
             * 4 + 4 = 5
             */

            if (firstLevel != secondLevel) {
                return ItemStack.EMPTY;
            }

            if (firstLevel >= WeaponLevel.MAX_LEVEL) {
                return ItemStack.EMPTY;
            }

            resultLevel = firstLevel + 1;
        }

        // =====================================================
        // ADDITIVE MODE
        // =====================================================

        else if (mode == Mode.ADDITIVE) {

            /*
             * 1 + 1 = 2
             * 2 + 1 = 3
             * 3 + 1 = 4
             * 4 + 1 = 5
             *
             * 2 + 3 = 5
             *
             * Since MAX_LEVEL is 5, anything above 5
             * is simply rejected in matches().
             */

            resultLevel = firstLevel + secondLevel;

            if (resultLevel > WeaponLevel.MAX_LEVEL) {
                return ItemStack.EMPTY;
            }

            /*
             * Don't allow two level-5 weapons to craft.
             */
            if (resultLevel <= firstLevel
                    && resultLevel <= secondLevel) {
                return ItemStack.EMPTY;
            }
        }

        else {
            return ItemStack.EMPTY;
        }

        // =====================================================
        // CREATE RESULT
        // =====================================================

        /*
         * IMPORTANT:
         *
         * Do NOT create:
         *
         * new ItemStack(first.getItem(), 1)
         *
         * because that can lose important components.
         *
         * Instead, copy the actual weapon stack.
         *
         * This preserves:
         *
         * - sword components
         * - spear components
         * - attributes
         * - weapon data
         * - UNBREAKABLE
         * - enchantments
         * - any other components
         *
         * Then change ONLY the weapon level.
         */
        ItemStack result = first.copyWithCount(1);

        WeaponLevel.set(result, resultLevel);
        WeaponDamage.update(result);

        return result;
    }

    // =========================================================
    // SERIALIZER
    // =========================================================

    @Override
    public RecipeSerializer<? extends WeaponUpgradeRecipe> getSerializer() {
        return SERIALIZER;
    }
}