package mh837.gile.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record DivineAbilityPayload() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<DivineAbilityPayload> TYPE =
            new CustomPacketPayload.Type<>(
                    Identifier.fromNamespaceAndPath(
                            "gilemod",
                            "divine_ability"
                    )
            );

    public static final StreamCodec<RegistryFriendlyByteBuf, DivineAbilityPayload> CODEC =
            StreamCodec.unit(new DivineAbilityPayload());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}