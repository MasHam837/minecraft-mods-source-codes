package mh837.gile.item;

import mh837.gile.GileModDataComponents;
import mh837.gile.block.entity.GlitterJarBlockEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

public class GlitterJarItem extends BlockItem {

    public GlitterJarItem(
            Block block,
            Properties properties
    ) {
        super(
                block,
                properties.component(
                        GileModDataComponents.GLITTER_COUNT,
                        GlitterJarBlockEntity.DEFAULT_GLITTERS
                ).stacksTo(16)
        );
    }

    public static int getGlitterCount(ItemStack stack) {
        return stack.getOrDefault(
                GileModDataComponents.GLITTER_COUNT,
                GlitterJarBlockEntity.DEFAULT_GLITTERS
        );
    }

    public static void setGlitterCount(
            ItemStack stack,
            int count
    ) {
        stack.set(
                GileModDataComponents.GLITTER_COUNT,
                Math.clamp(
                        count,
                        GlitterJarBlockEntity.DEFAULT_GLITTERS,
                        GlitterJarBlockEntity.MAX_GLITTERS
                )
        );
    }
}