package mh837.gile.item.weapon.primordial;

import mh837.gile.GileModParticleTypes;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class DivineOblivion {

    private DivineOblivion() {
    }

    private static final int COOLDOWN = 240;
    private static final int DURATION = 120;
    private static final double RADIUS = 14.0D;

    private static final Map<UUID, DivineDomain> ACTIVE =
            new HashMap<>();

    private record DivineDomain(
            ServerLevel level,
            ServerPlayer player,
            long endTime
    ) {
    }

    public static boolean activate(
            ServerLevel level,
            ServerPlayer player,
            ItemStack stack
    ) {

        if (player.getCooldowns().isOnCooldown(stack)) {

            int remainingTicks =
                    Math.max(
                            1,
                            Math.round(
                                    player.getCooldowns()
                                            .getCooldownPercent(
                                                    stack,
                                                    0.0F
                                            )
                                            * COOLDOWN
                            )
                    );

            int seconds =
                    Math.max(
                            1,
                            (remainingTicks + 19) / 20
                    );

            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.translatable(
                            "message.gilemod.divine_ability_cooldown",
                            seconds
                    ),
                    true
            );

            return false;
        }

        ACTIVE.put(
                player.getUUID(),
                new DivineDomain(
                        level,
                        player,
                        level.getGameTime() + DURATION
                )
        );

        /*
         * ========================================================
         * DIVINE ACTIVATION
         * ========================================================
         */

        player.sendSystemMessage(
                net.minecraft.network.chat.Component.translatable(
                        "message.gilemod.divine_ability_activated"
                ),
                true
        );

        GileModTriggers.ABILITY_DIVINE.trigger(player);

        player.getCooldowns().addCooldown(
                stack,
                COOLDOWN
        );

        /*
         * ========================================================
         * INITIAL PRIMORDIAL IMPACT
         * ========================================================
         */

        spawnInitialImpact(
                level,
                player
        );

        level.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.BEACON_ACTIVATE,
                SoundSource.PLAYERS,
                1.6F,
                0.35F
        );

        level.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.END_PORTAL_SPAWN,
                SoundSource.PLAYERS,
                1.0F,
                0.55F
        );

        return true;
    }

    public static void tick(ServerLevel level) {

        var iterator =
                ACTIVE.entrySet().iterator();

        while (iterator.hasNext()) {

            var entry =
                    iterator.next();

            DivineDomain domain =
                    entry.getValue();

            if (domain.level() != level) {
                continue;
            }

            ServerPlayer player =
                    domain.player();

            if (!player.isAlive()
                    || level.getGameTime() >= domain.endTime()) {

                if (player.isAlive()) {

                    spawnFinalImpact(
                            level,
                            player
                    );

                    level.playSound(
                            null,
                            player.getX(),
                            player.getY(),
                            player.getZ(),
                            SoundEvents.PLAYER_LEVELUP,
                            SoundSource.PLAYERS,
                            1.2F,
                            0.35F
                    );
                }

                iterator.remove();
                continue;
            }

            long age =
                    level.getGameTime()
                            - (domain.endTime() - DURATION);

            /*
             * ====================================================
             * PHANES CONSTELLATION
             *
             * Four primordial points orbit the player.
             * Their motion is deliberately smooth and celestial.
             * ====================================================
             */

            if (age % 2L == 0L) {

                double rotation =
                        age * 0.075D;

                for (int i = 0; i < 4; i++) {

                    double angle =
                            rotation
                                    + Math.PI * 2.0D * i / 4.0D;

                    double radius =
                            1.45D
                                    + Math.sin(age * 0.045D)
                                    * 0.30D;

                    double x =
                            player.getX()
                                    + Math.cos(angle)
                                    * radius;

                    double z =
                            player.getZ()
                                    + Math.sin(angle)
                                    * radius;

                    double y =
                            player.getY()
                                    + 1.0D
                                    + Math.sin(
                                    angle * 1.5D
                                            + age * 0.035D
                            ) * 0.75D;

                    level.sendParticles(
                            GileModParticleTypes.PHANES,
                            x,
                            y,
                            z,
                            1,
                            0.0D,
                            0.0D,
                            0.0D,
                            0.0D
                    );
                }
            }

            /*
             * ====================================================
             * PRIMORDIAL COLUMN
             *
             * Unlike Genesis, this is not a "healing light".
             * It is a vertical manifestation of Phanes itself.
             * ====================================================
             */

            if (age % 6L == 0L) {

                level.sendParticles(
                        GileModParticleTypes.PHANES,
                        player.getX(),
                        player.getY() + 3.0D,
                        player.getZ(),
                        6,
                        0.45D,
                        2.2D,
                        0.45D,
                        0.015D
                );

                level.sendParticles(
                        ParticleTypes.REVERSE_PORTAL,
                        player.getX(),
                        player.getY() + 2.0D,
                        player.getZ(),
                        8,
                        0.65D,
                        1.8D,
                        0.65D,
                        0.01D
                );
            }

            /*
             * ====================================================
             * ROTATING PRIMORDIAL RINGS
             *
             * Three tilted rings instead of Genesis' flat Life
             * rings. These form a celestial Phanes symbol.
             * ====================================================
             */

            if (age % 4L == 0L) {

                double rotation =
                        age * 0.035D;

                for (int ring = 0; ring < 3; ring++) {

                    double radius =
                            2.5D + ring * 3.4D;

                    double tilt =
                            0.25D
                                    + ring * 0.20D;

                    spawnRotatingRing(
                            level,
                            player,
                            radius,
                            rotation
                                    + ring * Math.PI / 3.0D,
                            tilt
                    );
                }
            }

            /*
             * ====================================================
             * VOID DRIFT
             *
             * Reverse portal particles continuously appear around
             * the domain, giving Oblivion its cosmic atmosphere.
             * ====================================================
             */

            if (age % 5L == 0L) {

                double angle =
                        age * 0.19D;

                for (int i = 0; i < 3; i++) {

                    double a =
                            angle
                                    + i * Math.PI * 2.0D / 3.0D;

                    double radius =
                            4.0D
                                    + Math.sin(
                                    age * 0.06D + i
                            ) * 1.5D;

                    double x =
                            player.getX()
                                    + Math.cos(a)
                                    * radius;

                    double y =
                            player.getY()
                                    + 1.0D
                                    + Math.sin(
                                    age * 0.08D + i
                            ) * 1.4D;

                    double z =
                            player.getZ()
                                    + Math.sin(a)
                                    * radius;

                    level.sendParticles(
                            ParticleTypes.REVERSE_PORTAL,
                            x,
                            y,
                            z,
                            3,
                            0.15D,
                            0.35D,
                            0.15D,
                            0.01D
                    );
                }
            }

            /*
             * ====================================================
             * PHANES PULSES
             *
             * Rare, very visible bursts prevent the ability from
             * becoming visually static during its 6-second state.
             * ====================================================
             */

            if (age % 30L == 0L) {

                level.sendParticles(
                        GileModParticleTypes.PHANES,
                        player.getX(),
                        player.getY() + 1.0D,
                        player.getZ(),
                        35,
                        2.0D,
                        1.0D,
                        2.0D,
                        0.025D
                );

                level.sendParticles(
                        ParticleTypes.REVERSE_PORTAL,
                        player.getX(),
                        player.getY() + 1.0D,
                        player.getZ(),
                        25,
                        2.5D,
                        1.2D,
                        2.5D,
                        0.015D
                );
            }
        }
    }

    private static void spawnInitialImpact(
            ServerLevel level,
            ServerPlayer player
    ) {

        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();

        /*
         * ========================================================
         * PRIMORDIAL CORE
         * ========================================================
         */

        level.sendParticles(
                GileModParticleTypes.PHANES,
                x,
                y + 1.0D,
                z,
                220,
                2.8D,
                1.8D,
                2.8D,
                0.045D
        );

        /*
         * ========================================================
         * VOID COLLAPSE
         * ========================================================
         */

        level.sendParticles(
                ParticleTypes.REVERSE_PORTAL,
                x,
                y + 1.0D,
                z,
                140,
                3.0D,
                1.7D,
                3.0D,
                0.035D
        );

        /*
         * ========================================================
         * PRIMORDIAL FLASH
         * ========================================================
         */

        level.sendParticles(
                ColorParticleOption.create(
                        ParticleTypes.FLASH,
                        1.0F,
                        1.0F,
                        1.0F
                ),
                x,
                y + 1.0D,
                z,
                1,
                0.0D,
                0.0D,
                0.0D,
                0.0D
        );

        /*
         * ========================================================
         * THREE CELESTIAL RINGS
         * ========================================================
         */

        for (int ring = 0; ring < 3; ring++) {

            spawnRotatingRing(
                    level,
                    player,
                    2.5D + ring * 3.5D,
                    ring * Math.PI / 3.0D,
                    0.30D + ring * 0.20D
            );
        }
    }

    private static void spawnRotatingRing(
            ServerLevel level,
            ServerPlayer player,
            double radius,
            double rotation,
            double tilt
    ) {

        double x0 = player.getX();
        double y0 = player.getY() + 0.12D;
        double z0 = player.getZ();

        for (int i = 0; i < 72; i++) {

            double angle =
                    Math.PI * 2.0D * i / 72.0D
                            + rotation;

            double localX =
                    Math.cos(angle) * radius;

            double localZ =
                    Math.sin(angle) * radius;

            /*
             * Tilt the ring around its local axis.
             */

            double tiltedY =
                    Math.sin(angle)
                            * radius
                            * Math.sin(tilt);

            double horizontal =
                    Math.cos(tilt);

            double finalX =
                    x0
                            + localX
                            * horizontal;

            double finalY =
                    y0
                            + tiltedY;

            double finalZ =
                    z0
                            + localZ;

            level.sendParticles(
                    GileModParticleTypes.PHANES,
                    finalX,
                    finalY,
                    finalZ,
                    1,
                    0.0D,
                    0.0D,
                    0.0D,
                    0.0D
            );
        }
    }

    private static void spawnFinalImpact(
            ServerLevel level,
            ServerPlayer player
    ) {

        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();

        /*
         * ========================================================
         * FINAL PHANES EXPLOSION
         * ========================================================
         */

        level.sendParticles(
                GileModParticleTypes.PHANES,
                x,
                y + 1.0D,
                z,
                350,
                RADIUS,
                2.5D,
                RADIUS,
                0.055D
        );

        /*
         * ========================================================
         * FINAL VOID COLLAPSE
         * ========================================================
         */

        level.sendParticles(
                ParticleTypes.REVERSE_PORTAL,
                x,
                y + 1.0D,
                z,
                220,
                RADIUS * 0.9D,
                2.2D,
                RADIUS * 0.9D,
                0.045D
        );

        /*
         * ========================================================
         * FINAL FLASH
         * ========================================================
         */

        level.sendParticles(
                ColorParticleOption.create(
                        ParticleTypes.FLASH,
                        1.0F,
                        1.0F,
                        1.0F
                ),
                x,
                y + 1.0D,
                z,
                1,
                0.0D,
                0.0D,
                0.0D,
                0.0D
        );

        /*
         * ========================================================
         * THREE FINAL CELESTIAL RINGS
         * ========================================================
         */

        spawnRotatingRing(
                level,
                player,
                RADIUS,
                0.0D,
                0.35D
        );

        spawnRotatingRing(
                level,
                player,
                RADIUS * 0.75D,
                Math.PI / 3.0D,
                0.55D
        );

        spawnRotatingRing(
                level,
                player,
                RADIUS * 0.50D,
                Math.PI / 1.5D,
                0.75D
        );

        level.playSound(
                null,
                x,
                y,
                z,
                SoundEvents.BEACON_POWER_SELECT,
                SoundSource.PLAYERS,
                1.8F,
                0.30F
        );

        level.playSound(
                null,
                x,
                y,
                z,
                SoundEvents.END_PORTAL_SPAWN,
                SoundSource.PLAYERS,
                1.2F,
                0.45F
        );
    }
}