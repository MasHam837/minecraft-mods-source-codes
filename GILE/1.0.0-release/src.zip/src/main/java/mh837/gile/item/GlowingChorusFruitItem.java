package mh837.gile.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class GlowingChorusFruitItem extends Item {

    public GlowingChorusFruitItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(
            ItemStack stack,
            Level level,
            LivingEntity user
    ) {
        ItemStack result = super.finishUsingItem(stack, level, user);

        if (!level.isClientSide() && user instanceof Player player) {
            ServerLevel serverLevel = (ServerLevel) level;

            /*
             * Apply Glowing for 10 seconds.
             */
            player.addEffect(
                    new MobEffectInstance(
                            MobEffects.GLOWING,
                            200,
                            0
                    )
            );

            /*
             * Glow particles around the eater.
             */
            serverLevel.sendParticles(
                    ParticleTypes.GLOW,
                    player.getX(),
                    player.getY() + 1.0D,
                    player.getZ(),
                    20,
                    0.4D,
                    0.6D,
                    0.4D,
                    0.02D
            );

            /*
             * Find a safe teleport position within an 8-block
             * horizontal radius.
             *
             * IMPORTANT:
             *
             * We do NOT require the player to already be on the
             * ground.
             *
             * This means the fruit can save a player while falling,
             * just like a vanilla Chorus Fruit MLG.
             */
            Vec3 teleportTarget = findTeleportTarget(
                    serverLevel,
                    player
            );

            if (teleportTarget != null) {
                player.teleportTo(
                        teleportTarget.x,
                        teleportTarget.y,
                        teleportTarget.z
                );
            }
        }

        return result;
    }

    private static Vec3 findTeleportTarget(
            ServerLevel level,
            Player player
    ) {
        Vec3 playerPos = player.position();

        BlockPos center = BlockPos.containing(playerPos);

        /*
         * Search the complete 8-block horizontal radius.
         *
         * We search from nearest to farthest so that a nearby
         * safe landing position is preferred.
         */
        int radius = 8;

        BlockPos bestPos = null;
        double bestDistance = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {

                /*
                 * Horizontal distance check.
                 */
                double horizontalDistanceSq =
                        dx * dx + dz * dz;

                if (horizontalDistanceSq > radius * radius) {
                    continue;
                }

                /*
                 * Search vertically around the player's current
                 * height.
                 *
                 * This is important for MLG situations:
                 * the support block can be considerably below
                 * the player's current position.
                 */
                for (int dy = -16; dy <= 16; dy++) {

                    BlockPos supportPos =
                            center.offset(dx, dy, dz);

                    /*
                     * The block underneath must provide a full
                     * collision surface.
                     */
                    if (!level.getBlockState(supportPos)
                            .isCollisionShapeFullBlock(
                                    level,
                                    supportPos
                            )) {
                        continue;
                    }

                    /*
                     * The player's 2-block-tall space must be clear.
                     */
                    BlockPos feetPos = supportPos.above();
                    BlockPos headPos = supportPos.above(2);

                    if (!level.getBlockState(feetPos).isAir()) {
                        continue;
                    }

                    if (!level.getBlockState(headPos).isAir()) {
                        continue;
                    }

                    /*
                     * Make sure the landing position is actually
                     * within the requested horizontal radius.
                     */
                    double targetX = supportPos.getX() + 0.5D;
                    double targetZ = supportPos.getZ() + 0.5D;

                    double actualDx =
                            targetX - playerPos.x;

                    double actualDz =
                            targetZ - playerPos.z;

                    double actualDistanceSq =
                            actualDx * actualDx
                                    + actualDz * actualDz;

                    if (actualDistanceSq > 64.0D) {
                        continue;
                    }

                    /*
                     * Prefer the closest valid landing position.
                     */
                    if (actualDistanceSq < bestDistance) {
                        bestDistance = actualDistanceSq;
                        bestPos = feetPos;
                    }
                }
            }
        }

        if (bestPos == null) {
            return null;
        }

        /*
         * Spawn the player centered on the block.
         */
        return new Vec3(
                bestPos.getX() + 0.5D,
                bestPos.getY(),
                bestPos.getZ() + 0.5D
        );
    }
}