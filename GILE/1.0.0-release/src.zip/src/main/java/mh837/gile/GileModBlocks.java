package mh837.gile;

import java.util.Optional;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import mh837.gile.block.*;
import mh837.gile.block.entity.signs.*;
import mh837.gile.item.GlitterJarItem;
import net.fabricmc.fabric.api.object.builder.v1.block.type.BlockSetTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.block.type.WoodTypeBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.BlockFamily;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ColorRGBA;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.function.BiFunction;
import java.util.function.Function;

public class GileModBlocks {

    public static <T extends Block> T registerBlockOnly(String name, Function<BlockBehaviour.Properties, T> blockFactory, BlockBehaviour.Properties properties) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
        T block = blockFactory.apply(properties.setId(blockKey));
        return Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
    }

    public static <T extends Block> T registerBlockAndItem(String name, Function<BlockBehaviour.Properties, T> blockFactory, BlockBehaviour.Properties blockProperties) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
        T block = blockFactory.apply(blockProperties.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
        BlockItem blockItem = new BlockItem(block, new Item.Properties().setId(itemKey));
        Registry.register(BuiltInRegistries.ITEM, itemKey, blockItem);
        return block;
    }

    public static <T extends Block> T registerBlockAndCustomItem(String name, Function<BlockBehaviour.Properties, T> blockFactory, BlockBehaviour.Properties blockProperties,
            BiFunction<T, Item.Properties, BlockItem> itemFactory) {
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
        T block = blockFactory.apply(blockProperties.setId(blockKey)); Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
        BlockItem blockItem = itemFactory.apply(block, new Item.Properties().setId(itemKey)); Registry.register(BuiltInRegistries.ITEM, itemKey, blockItem); return block;
    }

    private static BlockBehaviour.Properties copySignProperties(
            Block source,
            String lootTablePath,
            MapColor color
    ) {
        return BlockBehaviour.Properties.ofFullCopy(source)
                .mapColor(color)
                .overrideLootTable(Optional.of(
                        ResourceKey.create(
                                Registries.LOOT_TABLE,
                                Identifier.fromNamespaceAndPath(
                                        GileMod.MOD_ID,
                                        "blocks/" + lootTablePath
                                )
                        )
                ));
    }

    // PRIMOGEM/PEARLESCENT/ENDERITE:
    public static final Block PRIMOGEM_ORE = registerBlockAndItem("primogem_ore",
                    props -> new DropExperienceBlock(UniformInt.of(2, 6), props), BlockBehaviour.Properties.of()
                            .requiresCorrectToolForDrops().strength(3.0f, 3.0f).mapColor(MapColor.STONE));
    public static final Block DEEPSLATE_PRIMOGEM_ORE = registerBlockAndItem("deepslate_primogem_ore",
            props -> new DropExperienceBlock(UniformInt.of(2, 6), props), BlockBehaviour.Properties.of()
                    .requiresCorrectToolForDrops().strength(3.5f, 3.5f).mapColor(MapColor.DEEPSLATE));
    public static final Block END_PRIMOGEM_ORE = registerBlockAndItem("end_primogem_ore",
            props -> new DropExperienceBlock(UniformInt.of(2, 6), props), BlockBehaviour.Properties.of()
                    .requiresCorrectToolForDrops().strength(4.0f, 4.0f).mapColor(MapColor.SAND));
    public static final Block WISH = registerBlockAndItem("wish",
            props -> new Block(props), BlockBehaviour.Properties.of()
                    .strength(2.0f, 2.0f).sound(SoundType.AMETHYST).mapColor(MapColor.COLOR_LIGHT_GRAY));

    public static final Block WISH_TABLE = registerBlockAndItem("wish_table",
            props -> new WishTableBlock(props), BlockBehaviour.Properties.of().noOcclusion()
                    .strength(2.0f, 2.0f).sound(SoundType.AMETHYST).mapColor(MapColor.COLOR_PINK));

    public static final Block PEARLESCENT_BLOCK = registerBlockAndItem("pearlescent_block",
            props -> new Block(props), BlockBehaviour.Properties.of()
                    .requiresCorrectToolForDrops().strength(2.0f, 2.0f).sound(SoundType.COPPER_BULB).mapColor(MapColor.COLOR_PINK));
    public static final Block PEARLESCENT_STAIRS = registerBlockAndItem("pearlescent_stairs",
            props -> new StairBlock(PEARLESCENT_BLOCK.defaultBlockState(), props), BlockBehaviour.Properties.ofFullCopy(PEARLESCENT_BLOCK));
    public static final Block PEARLESCENT_SLAB = registerBlockAndItem("pearlescent_slab",
            props -> new SlabBlock(props), BlockBehaviour.Properties.ofFullCopy(PEARLESCENT_BLOCK));
    public static final Block PEARLESCENT_WALL = registerBlockAndItem("pearlescent_wall",
            props -> new WallBlock(props), BlockBehaviour.Properties.ofFullCopy(PEARLESCENT_BLOCK));
    public static final Block PEARLESCENT_BRICKS = registerBlockAndItem("pearlescent_bricks",
            props -> new Block(props), BlockBehaviour.Properties.ofFullCopy(PEARLESCENT_BLOCK));
    public static final Block PEARLESCENT_BRICKS_STAIRS = registerBlockAndItem("pearlescent_bricks_stairs",
            props -> new StairBlock(PEARLESCENT_BRICKS.defaultBlockState(), props), BlockBehaviour.Properties.ofFullCopy(PEARLESCENT_BRICKS));
    public static final Block PEARLESCENT_BRICKS_SLAB = registerBlockAndItem("pearlescent_bricks_slab",
            props -> new SlabBlock(props), BlockBehaviour.Properties.ofFullCopy(PEARLESCENT_BLOCK));
    public static final Block PEARLESCENT_BRICKS_WALL = registerBlockAndItem("pearlescent_bricks_wall",
            props -> new WallBlock(props), BlockBehaviour.Properties.ofFullCopy(PEARLESCENT_BLOCK));

    public static final Block ENDERITE_ORE = registerBlockAndItem("enderite_ore",
            props -> new EnderiteBlocks(props), BlockBehaviour.Properties.of()
                    .requiresCorrectToolForDrops().strength(20.0f, 3.0f).mapColor(MapColor.SAND));
    public static final Block ENDERITE_BLOCK = registerBlockAndItem("enderite_block",
            props -> new EnderiteBlocks(props), BlockBehaviour.Properties.of()
                    .requiresCorrectToolForDrops().strength(50.0f, 1200.0f).mapColor(MapColor.TERRACOTTA_LIGHT_BLUE));

    // GHOSTLY WOOD
    public static final BlockSetType GHOSTLY_SET_TYPE = BlockSetTypeBuilder.copyOf(BlockSetType.OAK)
            .register(Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly"));
    public static final WoodType GHOSTLY_WOOD_TYPE = WoodTypeBuilder.copyOf(WoodType.OAK)
            .register(Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly"), GHOSTLY_SET_TYPE);

    public static final Block GHOSTLY_LOG = registerBlockAndItem("ghostly_log", RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG)
                    .mapColor(state -> {return state.getValue(RotatedPillarBlock.AXIS) == Direction.Axis.Y ? MapColor.COLOR_MAGENTA : MapColor.COLOR_LIGHT_GRAY;}));
    public static final Block STRIPPED_GHOSTLY_LOG = registerBlockAndItem("stripped_ghostly_log",
            RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.STRIPPED_OAK_LOG).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_WOOD = registerBlockAndItem("ghostly_wood",
            RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_WOOD).mapColor(MapColor.COLOR_LIGHT_GRAY));
    public static final Block STRIPPED_GHOSTLY_WOOD = registerBlockAndItem("stripped_ghostly_wood",
            RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.STRIPPED_OAK_WOOD).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_PLANKS = registerBlockAndItem("ghostly_planks",
            Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_PLANKS).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_STAIRS = registerBlockAndItem("ghostly_stairs",
            props -> new StairBlock(GHOSTLY_PLANKS.defaultBlockState(), props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_STAIRS).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_SLAB = registerBlockAndItem("ghostly_slab",
            SlabBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SLAB).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_FENCE = registerBlockAndItem("ghostly_fence",
            FenceBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_FENCE).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_FENCE_GATE = registerBlockAndItem("ghostly_fence_gate",
            props -> new FenceGateBlock(GHOSTLY_WOOD_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_FENCE_GATE).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_DOOR = registerBlockAndItem("ghostly_door",
            props -> new DoorBlock(GHOSTLY_SET_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_DOOR).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_TRAPDOOR = registerBlockAndItem("ghostly_trapdoor",
            props -> new TrapDoorBlock(GHOSTLY_SET_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_TRAPDOOR).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_PRESSURE_PLATE = registerBlockAndItem("ghostly_pressure_plate",
            props -> new PressurePlateBlock(GHOSTLY_SET_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_PRESSURE_PLATE).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_BUTTON = registerBlockAndItem("ghostly_button",
            props -> new ButtonBlock(GHOSTLY_SET_TYPE, 30, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_BUTTON).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_SHELF = registerBlockAndItem("ghostly_shelf",
            GhostlyShelfBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SHELF).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_LEAVES = registerBlockAndItem("ghostly_leaves",
            props -> new TintedParticleLeavesBlock(0.02F, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).mapColor(MapColor.COLOR_PINK));

    // INVERTED OAK WOOD
    public static final BlockSetType INVERTED_OAK_SET_TYPE = BlockSetTypeBuilder.copyOf(BlockSetType.OAK)
            .register(Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "inverted_oak"));
    public static final WoodType INVERTED_OAK_WOOD_TYPE = WoodTypeBuilder.copyOf(WoodType.OAK)
            .register(Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "inverted_oak"), INVERTED_OAK_SET_TYPE);

    public static final Block INVERTED_OAK_LOG = registerBlockAndItem("inverted_oak_log", RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LOG)
                    .mapColor(state -> {return state.getValue(RotatedPillarBlock.AXIS) == Direction.Axis.Y ? MapColor.COLOR_BLUE : MapColor.COLOR_LIGHT_BLUE;}));
    public static final Block STRIPPED_INVERTED_OAK_LOG = registerBlockAndItem("stripped_inverted_oak_log",
            RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.STRIPPED_OAK_LOG).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_WOOD = registerBlockAndItem("inverted_oak_wood",
            RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_WOOD).mapColor(MapColor.COLOR_LIGHT_BLUE));
    public static final Block STRIPPED_INVERTED_OAK_WOOD = registerBlockAndItem("stripped_inverted_oak_wood",
            RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.STRIPPED_OAK_WOOD).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_PLANKS = registerBlockAndItem("inverted_oak_planks",
            Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_PLANKS).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_STAIRS = registerBlockAndItem("inverted_oak_stairs",
            props -> new StairBlock(INVERTED_OAK_PLANKS.defaultBlockState(), props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_STAIRS).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_SLAB = registerBlockAndItem("inverted_oak_slab",
            SlabBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SLAB).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_FENCE = registerBlockAndItem("inverted_oak_fence",
            FenceBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_FENCE).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_FENCE_GATE = registerBlockAndItem("inverted_oak_fence_gate",
            props -> new FenceGateBlock(INVERTED_OAK_WOOD_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_FENCE_GATE).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_DOOR = registerBlockAndItem("inverted_oak_door",
            props -> new DoorBlock(INVERTED_OAK_SET_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_DOOR).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_TRAPDOOR = registerBlockAndItem("inverted_oak_trapdoor",
            props -> new TrapDoorBlock(INVERTED_OAK_SET_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_TRAPDOOR).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_PRESSURE_PLATE = registerBlockAndItem("inverted_oak_pressure_plate",
            props -> new PressurePlateBlock(INVERTED_OAK_SET_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_PRESSURE_PLATE).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_BUTTON = registerBlockAndItem("inverted_oak_button",
            props -> new ButtonBlock(INVERTED_OAK_SET_TYPE, 30, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_BUTTON).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_SHELF = registerBlockAndItem("inverted_oak_shelf",
            InvertedOakShelfBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SHELF).mapColor(MapColor.COLOR_BLUE));

    public static final Block INVERTED_OAK_LEAVES = registerBlockAndItem("inverted_oak_leaves",
            props -> new TintedParticleLeavesBlock(0.02F, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_LEAVES).mapColor(MapColor.CLAY));

    // SIGN BLOCKS & FAMILY
    public static final Block GHOSTLY_SIGN = registerBlockOnly("ghostly_sign",
            props -> new GhostlyStandingSignBlock(GHOSTLY_WOOD_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.BIRCH_SIGN).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_WALL_SIGN =
            registerBlockOnly("ghostly_wall_sign",
                    props -> new GhostlyWallSignBlock(GHOSTLY_WOOD_TYPE, props),
                    copySignProperties(
                            Blocks.BIRCH_WALL_SIGN,
                            "ghostly_sign",
                            MapColor.COLOR_MAGENTA
                    ));
    public static final Block GHOSTLY_HANGING_SIGN = registerBlockOnly("ghostly_hanging_sign",
            props -> new GhostlyCeilingHangingSignBlock(GHOSTLY_WOOD_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.BIRCH_HANGING_SIGN).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block GHOSTLY_WALL_HANGING_SIGN =
            registerBlockOnly("ghostly_wall_hanging_sign",
                    props -> new GhostlyWallHangingSignBlock(GHOSTLY_WOOD_TYPE, props),
                    copySignProperties(
                            Blocks.BIRCH_WALL_HANGING_SIGN,
                            "ghostly_hanging_sign",
                            MapColor.COLOR_MAGENTA
                    ));

    public static final BlockFamily GHOSTLY_FAMILY = new BlockFamily.Builder(GHOSTLY_PLANKS)
            .button(GHOSTLY_BUTTON).fence(GHOSTLY_FENCE).fenceGate(GHOSTLY_FENCE_GATE).pressurePlate(GHOSTLY_PRESSURE_PLATE)
            .slab(GHOSTLY_SLAB).stairs(GHOSTLY_STAIRS).door(GHOSTLY_DOOR).trapdoor(GHOSTLY_TRAPDOOR)
            .recipeGroupPrefix("wood").recipeUnlockedBy("has_planks").getFamily();

    public static final Block INVERTED_OAK_SIGN = registerBlockOnly("inverted_oak_sign",
            props -> new InvertedOakStandingSignBlock(INVERTED_OAK_WOOD_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SIGN).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_WALL_SIGN =
            registerBlockOnly("inverted_oak_wall_sign",
                    props -> new InvertedOakWallSignBlock(INVERTED_OAK_WOOD_TYPE, props),
                    copySignProperties(
                            Blocks.OAK_WALL_SIGN,
                            "inverted_oak_sign",
                            MapColor.COLOR_BLUE
                    ));
    public static final Block INVERTED_OAK_HANGING_SIGN = registerBlockOnly("inverted_oak_hanging_sign",
            props -> new InvertedOakCeilingHangingSignBlock(INVERTED_OAK_WOOD_TYPE, props), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_HANGING_SIGN).mapColor(MapColor.COLOR_BLUE));
    public static final Block INVERTED_OAK_WALL_HANGING_SIGN =
            registerBlockOnly("inverted_oak_wall_hanging_sign",
                    props -> new InvertedOakWallHangingSignBlock(INVERTED_OAK_WOOD_TYPE, props),
                    copySignProperties(
                            Blocks.OAK_WALL_HANGING_SIGN,
                            "inverted_oak_hanging_sign",
                            MapColor.COLOR_BLUE
                    ));

    public static final BlockFamily INVERTED_OAK_FAMILY = new BlockFamily.Builder(INVERTED_OAK_PLANKS)
            .button(INVERTED_OAK_BUTTON).fence(INVERTED_OAK_FENCE).fenceGate(INVERTED_OAK_FENCE_GATE).pressurePlate(INVERTED_OAK_PRESSURE_PLATE)
            .slab(INVERTED_OAK_SLAB).stairs(INVERTED_OAK_STAIRS).door(INVERTED_OAK_DOOR).trapdoor(INVERTED_OAK_TRAPDOOR)
            .recipeGroupPrefix("wood").recipeUnlockedBy("has_planks").getFamily();

    // SAPLINGS & GLOWING CHORUS FAMILY
    public static final Block GHOSTLY_SAPLING = registerBlockAndItem("ghostly_sapling", properties -> new GhostlySaplingBlock(
            GileModWorldgen.GHOSTLY_SAPLING_GENERATOR, properties), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SAPLING).mapColor(MapColor.COLOR_PINK));
    public static final Block POTTED_GHOSTLY_SAPLING = registerBlockOnly("potted_ghostly_sapling", props -> new FlowerPotBlock(
            GHOSTLY_SAPLING, props), BlockBehaviour.Properties.ofFullCopy(Blocks.POTTED_OAK_SAPLING).noOcclusion().pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_PINK));
    public static final Block INVERTED_OAK_SAPLING = registerBlockAndItem("inverted_oak_sapling", properties -> new SaplingBlock(
            GileModWorldgen.INVERTED_OAK_SAPLING_GENERATOR, properties), BlockBehaviour.Properties.ofFullCopy(Blocks.OAK_SAPLING).mapColor(MapColor.COLOR_MAGENTA));
    public static final Block POTTED_INVERTED_OAK_SAPLING = registerBlockOnly("potted_inverted_oak_sapling", props -> new FlowerPotBlock(
            INVERTED_OAK_SAPLING, props), BlockBehaviour.Properties.ofFullCopy(Blocks.POTTED_OAK_SAPLING).noOcclusion().pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_MAGENTA));

    public static final Block GLOWING_CHORUS_PLANT = registerBlockAndItem("glowing_chorus_plant", GlowingChorusPlantBlock::new,
            BlockBehaviour.Properties.ofFullCopy(Blocks.CHORUS_PLANT).lightLevel(state -> 8).mapColor(MapColor.COLOR_YELLOW));
    public static final Block GLOWING_CHORUS_FLOWER = registerBlockAndItem("glowing_chorus_flower", props -> new GlowingChorusFlowerBlock(
            (GlowingChorusPlantBlock) GLOWING_CHORUS_PLANT, props), BlockBehaviour.Properties.ofFullCopy(Blocks.CHORUS_FLOWER).lightLevel(state -> 12).mapColor(MapColor.COLOR_YELLOW));

    public static final Block FLUO_BLOCK = registerBlockAndItem("fluo_block", Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.PURPUR_BLOCK)
                    .lightLevel(state -> 4).randomTicks().mapColor(MapColor.COLOR_YELLOW));
    public static final Block FLUO_STAIRS = registerBlockAndItem("fluo_stairs",
            props -> new StairBlock(FLUO_BLOCK.defaultBlockState(), props), BlockBehaviour.Properties.ofFullCopy(Blocks.PURPUR_STAIRS)
                    .lightLevel(state -> 4).mapColor(MapColor.COLOR_YELLOW));
    public static final Block FLUO_SLAB = registerBlockAndItem("fluo_slab",
            props -> new SlabBlock(props), BlockBehaviour.Properties.ofFullCopy(Blocks.PURPUR_SLAB)
                    .lightLevel(state -> 4).mapColor(MapColor.COLOR_YELLOW));
    public static final Block FLUO_PILLAR = registerBlockAndItem("fluo_pillar", RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.PURPUR_PILLAR)
                    .lightLevel(state -> 4).randomTicks().mapColor(MapColor.COLOR_YELLOW));

    // MOON SAND & SANDSTONE FAMILY
    public static final Block MOON_SAND = registerBlockAndItem("moon_sand", props -> new ColoredFallingBlock(new ColorRGBA(0xFFD2DCB8), props),
            BlockBehaviour.Properties.of().requiresCorrectToolForDrops().strength(1.2f, 1.2f).sound(SoundType.SAND).mapColor(MapColor.CLAY));

    public static final Block MOON_SANDSTONE = registerBlockAndItem("moon_sandstone",
            Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.SANDSTONE).requiresCorrectToolForDrops().mapColor(MapColor.CLAY));
    public static final Block MOON_SANDSTONE_STAIRS = registerBlockAndItem("moon_sandstone_stairs",
            props -> new StairBlock(MOON_SANDSTONE.defaultBlockState(), props), BlockBehaviour.Properties.ofFullCopy(MOON_SANDSTONE));
    public static final Block MOON_SANDSTONE_SLAB = registerBlockAndItem("moon_sandstone_slab",
            SlabBlock::new, BlockBehaviour.Properties.ofFullCopy(MOON_SANDSTONE));
    public static final Block MOON_SANDSTONE_WALL = registerBlockAndItem("moon_sandstone_wall",
            WallBlock::new, BlockBehaviour.Properties.ofFullCopy(MOON_SANDSTONE));
    public static final Block MOON_CHISELED_SANDSTONE = registerBlockAndItem("moon_chiseled_sandstone",
            Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.CHISELED_SANDSTONE).requiresCorrectToolForDrops().mapColor(MapColor.CLAY));
    public static final Block MOON_SMOOTH_SANDSTONE = registerBlockAndItem("moon_smooth_sandstone",
            Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.SMOOTH_SANDSTONE).requiresCorrectToolForDrops().mapColor(MapColor.CLAY));
    public static final Block MOON_SMOOTH_SANDSTONE_STAIRS = registerBlockAndItem("moon_smooth_sandstone_stairs",
            props -> new StairBlock(MOON_SMOOTH_SANDSTONE.defaultBlockState(), props), BlockBehaviour.Properties.ofFullCopy(MOON_SMOOTH_SANDSTONE));
    public static final Block MOON_SMOOTH_SANDSTONE_SLAB = registerBlockAndItem("moon_smooth_sandstone_slab",
            SlabBlock::new, BlockBehaviour.Properties.ofFullCopy(MOON_SMOOTH_SANDSTONE));
    public static final Block MOON_CUT_SANDSTONE = registerBlockAndItem("moon_cut_sandstone",
            Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.CUT_SANDSTONE).requiresCorrectToolForDrops().mapColor(MapColor.CLAY));
    public static final Block MOON_CUT_SANDSTONE_SLAB = registerBlockAndItem("moon_cut_sandstone_slab",
            SlabBlock::new, BlockBehaviour.Properties.ofFullCopy(MOON_CUT_SANDSTONE));

    // PLANTS & DECORATIONS
    public static final Block MOON_FLOWER = registerBlockAndItem("moon_flower", props -> new GileModFlowerBlocks(MobEffects.LEVITATION, 7, props),
            BlockBehaviour.Properties.of().noCollision().instabreak().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_LIGHT_BLUE));
    public static final Block POTTED_MOON_FLOWER = registerBlockOnly("potted_moon_flower", props -> new FlowerPotBlock(
            MOON_FLOWER, props), BlockBehaviour.Properties.ofFullCopy(Blocks.POTTED_DANDELION).noOcclusion().pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_BLUE));
    public static final Block GLOOMY_FLOWER = registerBlockAndItem("gloomy_flower", props -> new GileModFlowerBlocks(MobEffects.DARKNESS, 8, props),
            BlockBehaviour.Properties.of().noCollision().instabreak().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_CYAN));
    public static final Block POTTED_GLOOMY_FLOWER = registerBlockOnly("potted_gloomy_flower", props -> new FlowerPotBlock(
            GLOOMY_FLOWER, props), BlockBehaviour.Properties.ofFullCopy(Blocks.POTTED_DANDELION).noOcclusion().pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_CYAN));
    public static final Block DRY_FLOWER = registerBlockAndItem("dry_flower", props -> new GileModFlowerBlocks(MobEffects.WITHER, 6, props),
            BlockBehaviour.Properties.of().noCollision().instabreak().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY).mapColor(MapColor.TERRACOTTA_GREEN));
    public static final Block POTTED_DRY_FLOWER = registerBlockOnly("potted_dry_flower", props -> new FlowerPotBlock(
            DRY_FLOWER, props), BlockBehaviour.Properties.ofFullCopy(Blocks.POTTED_DANDELION).noCollision().pushReaction(PushReaction.DESTROY).mapColor(MapColor.TERRACOTTA_GREEN));

    public static final Block END_GRASS = registerBlockAndItem("end_grass", EndGrass::new, BlockBehaviour.Properties.of()
                    .noCollision().instabreak().sound(SoundType.GRASS).noOcclusion().pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_PURPLE));
    public static final Block TALL_END_GRASS = registerBlockAndItem("tall_end_grass", TallEndGrass::new, BlockBehaviour.Properties.of()
                    .noCollision().instabreak().sound(SoundType.GRASS).noOcclusion().pushReaction(PushReaction.DESTROY).mapColor(MapColor.COLOR_PURPLE));

    public static final Block GLITTER_BLOCK = registerBlockAndItem("glitter_block",
            Block::new, BlockBehaviour.Properties.of().mapColor(MapColor.NONE).sound(SoundType.WOOL).instabreak());
    public static final Block GLITTER_CARPET = registerBlockAndItem("glitter_carpet",
            CarpetBlock::new, BlockBehaviour.Properties.of().mapColor(MapColor.NONE).sound(SoundType.WOOL).pushReaction(PushReaction.DESTROY).instabreak());
    public static final Block JAR_OF_GLITTERS = registerBlockAndCustomItem("jar_of_glitters",
            GlitterJarBlock::new, BlockBehaviour.Properties.of().mapColor(MapColor.NONE).sound(SoundType.GLASS).strength(0.3F).noOcclusion()
                    .lightLevel(state -> state.getValue(GlitterJarBlock.GLITTERS) * 2 + 1 ), GlitterJarItem::new);

    // MISCELLANEOUS
    public static final Block PEARLESCENT_CHAIN = registerBlockAndItem("pearlescent_chain",
            ChainBlock::new, BlockBehaviour.Properties.of().requiresCorrectToolForDrops().strength(5.0f).sound(SoundType.CHAIN).noOcclusion().mapColor(MapColor.NONE));

    public static final Block END_GRASS_BLOCK = registerBlockAndItem("end_grass_block",
            EndGrassBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.END_STONE).randomTicks().mapColor(MapColor.COLOR_PURPLE));

    public static final Block END_CLOUD = registerBlockAndItem("end_cloud",
            props -> new Block(props) {
                @Override
                protected void entityInside(BlockState state, Level level, BlockPos pos, Entity entity, InsideBlockEffectApplier effectApplier, boolean isPrecise) {
                    entity.makeStuckInBlock(state, new Vec3(0.8, 0.6, 0.8));}
                @Override
                public boolean skipRendering(BlockState state, BlockState adjacentBlockState, Direction direction) {
                    return adjacentBlockState.is(this) || super.skipRendering(state, adjacentBlockState, direction);}},
            BlockBehaviour.Properties.of().noCollision().instabreak().sound(SoundType.POWDER_SNOW).pushReaction(PushReaction.DESTROY).mapColor(MapColor.TERRACOTTA_LIGHT_BLUE)
                    .isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false).noOcclusion());

    public static final Block STAR = registerBlockAndItem("star", props -> new Block(props) {
                @Override
                public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
                    return Block.box(4, 4, 4, 12, 12, 12);}
                @Override
                public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
                    return Block.box(4, 4, 4, 12, 12, 12);}},
            BlockBehaviour.Properties.of().strength(0.5f, 0.5f).lightLevel(state -> 15)
                    .noOcclusion().sound(SoundType.AMETHYST).mapColor(MapColor.GOLD));

    public static final Block MOON_TORCH = registerBlockOnly("moon_torch",
            MoonTorchBlock::new, BlockBehaviour.Properties.of().noCollision().instabreak()
                    .lightLevel(state -> 10).sound(SoundType.WOOD).pushReaction(PushReaction.DESTROY).mapColor(MapColor.NONE));
    public static final Block MOON_WALL_TORCH = registerBlockOnly("moon_wall_torch",
            MoonWallTorchBlock::new, BlockBehaviour.Properties.of().noCollision().instabreak()
                    .lightLevel(state -> 10).sound(SoundType.WOOD).pushReaction(PushReaction.DESTROY).mapColor(MapColor.NONE));
    public static final Block MOON_LANTERN = registerBlockAndItem("moon_lantern",
            LanternBlock::new, BlockBehaviour.Properties.of().requiresCorrectToolForDrops().lightLevel(state -> 10).strength(3.5f)
                    .noOcclusion().pushReaction(PushReaction.DESTROY).isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false).mapColor(MapColor.COLOR_PINK));
    public static final Block MOON_CAMPFIRE = registerBlockAndItem("moon_campfire",
            props -> new MoonCampfireBlock(true, 2, props), BlockBehaviour.Properties.ofFullCopy(Blocks.CAMPFIRE).mapColor(MapColor.COLOR_BROWN));
    public static final Block MOON_FIRE = registerBlockOnly("moon_fire",
            MoonFireBlock::new, BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_MAGENTA).replaceable().noCollision()
                    .instabreak().lightLevel(state -> 12).sound(SoundType.WOOL).pushReaction(PushReaction.DESTROY));

    public static void initialize() {

        System.out.println("Successfully registered 26.1 Mod Blocks for " + GileMod.MOD_ID);

    }
}