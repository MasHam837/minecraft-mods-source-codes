package mh837.gile.block.entity.slots;

import mh837.gile.GileModTags;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class WishInputSlot extends Slot {

    public WishInputSlot(
            Container container,
            int slot,
            int x,
            int y
    ) {
        super(container, slot, x, y);
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return stack.is(GileModTags.Items.WISH_INPUT);
    }
}
