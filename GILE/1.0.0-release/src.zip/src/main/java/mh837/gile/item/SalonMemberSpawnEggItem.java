package mh837.gile.item;

import mh837.gile.entity.SalonMemberEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.stats.Stats;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.component.TypedEntityData;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Spawner;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext.Fluid;

import java.util.Objects;
import java.util.Optional;

public class SalonMemberSpawnEggItem extends SpawnEggItem {

    public SalonMemberSpawnEggItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();

        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack itemStack = context.getItemInHand();
        BlockPos pos = context.getClickedPos();
        Direction clickedFace = context.getClickedFace();
        BlockState blockState = level.getBlockState(pos);

        BlockEntity blockEntity = level.getBlockEntity(pos);

        // Preserve vanilla behavior for spawners.
        if (blockEntity instanceof Spawner spawner) {
            EntityType<?> type = getType(itemStack);

            if (type == null) {
                return InteractionResult.FAIL;
            }

            if (!serverLevel.isSpawnerBlockEnabled()) {
                Player player = context.getPlayer();

                if (player instanceof ServerPlayer serverPlayer) {
                    serverPlayer.sendSystemMessage(
                            Component.translatable("advMode.notEnabled.spawner")
                    );
                }

                return InteractionResult.FAIL;
            }

            spawner.setEntityId(type, level.getRandom());
            level.sendBlockUpdated(pos, blockState, blockState, 3);
            level.gameEvent(context.getPlayer(), GameEvent.BLOCK_CHANGE, pos);

            itemStack.shrink(1);

            return InteractionResult.SUCCESS;
        }

        BlockPos spawnPos;

        if (blockState.getCollisionShape(level, pos).isEmpty()) {
            spawnPos = pos;
        } else {
            spawnPos = pos.relative(clickedFace);
        }

        boolean tryMoveDown = true;
        boolean movedUp =
                !Objects.equals(pos, spawnPos)
                        && clickedFace == Direction.UP;

        return spawnSalonMember(
                context.getPlayer(),
                itemStack,
                serverLevel,
                spawnPos,
                tryMoveDown,
                movedUp
        );
    }

    private static InteractionResult spawnSalonMember(
            Player user,
            ItemStack itemStack,
            ServerLevel level,
            BlockPos spawnPos,
            boolean tryMoveDown,
            boolean movedUp
    ) {
        EntityType<?> type = getType(itemStack);

        if (type == null) {
            return InteractionResult.FAIL;
        }

        if (!type.isAllowedInPeaceful()
                && level.getDifficulty() == Difficulty.PEACEFUL) {
            return InteractionResult.FAIL;
        }

        if (type != mh837.gile.GileModEntities.SALON_MEMBER) {
            return InteractionResult.FAIL;
        }

        SalonMemberEntity member =
                (SalonMemberEntity) type.create(
                        level,
                        EntitySpawnReason.SPAWN_ITEM_USE
                );

        if (member == null) {
            return InteractionResult.FAIL;
        }

        // Apply the normal ENTITY_DATA from the spawn egg.
        member.applyComponentsFromItemStack(itemStack);

        // ONLY the spawn egg chooses the member.
        // Nothing here sets owner, lifetime, nickname, etc.
        member.setMemberIndex(level.getRandom().nextInt(3));

        double x = spawnPos.getX() + 0.5D;
        double y = spawnPos.getY();
        double z = spawnPos.getZ() + 0.5D;

        member.snapTo(
                x,
                y,
                z,
                level.getRandom().nextFloat() * 360.0F,
                0.0F
        );

        level.addFreshEntityWithPassengers(member);

        itemStack.consume(1, user);

        level.gameEvent(
                user,
                GameEvent.ENTITY_PLACE,
                spawnPos
        );

        return InteractionResult.SUCCESS;
    }

    @Override
    public InteractionResult use(
            Level level,
            Player player,
            InteractionHand hand
    ) {
        ItemStack itemStack = player.getItemInHand(hand);

        BlockHitResult hitResult =
                getPlayerPOVHitResult(
                        level,
                        player,
                        Fluid.SOURCE_ONLY
                );

        if (hitResult.getType() != Type.BLOCK) {
            return InteractionResult.PASS;
        }

        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        BlockPos pos = hitResult.getBlockPos();

        if (!(level.getBlockState(pos).getBlock() instanceof LiquidBlock)) {
            return InteractionResult.PASS;
        }

        if (!level.mayInteract(player, pos)
                || !player.mayUseItemAt(
                pos,
                hitResult.getDirection(),
                itemStack
        )) {
            return InteractionResult.FAIL;
        }

        InteractionResult result =
                spawnSalonMember(
                        player,
                        itemStack,
                        serverLevel,
                        pos,
                        false,
                        false
                );

        if (result == InteractionResult.SUCCESS) {
            player.awardStat(
                    Stats.ITEM_USED.get(this)
            );
        }

        return result;
    }

    public boolean shouldPrintOpWarning(
            ItemStack stack,
            Player player
    ) {
        if (player != null
                && player.permissions()
                .hasPermission(Permissions.COMMANDS_GAMEMASTER)) {

            TypedEntityData<EntityType<?>> entityData =
                    stack.get(DataComponents.ENTITY_DATA);

            if (entityData != null) {
                return entityData.type().onlyOpCanSetNbt();
            }
        }

        return false;
    }

    public static boolean spawnsEntity(
            ItemStack itemStack,
            EntityType<?> type
    ) {
        return Objects.equals(
                getType(itemStack),
                type
        );
    }

    public static Optional<Holder<Item>> byId(
            EntityType<?> type
    ) {
        return BuiltInRegistries.ITEM
                .componentLookup()
                .findMatching(
                        DataComponents.ENTITY_DATA,
                        component -> component.type() == type
                )
                .findAny();
    }
}