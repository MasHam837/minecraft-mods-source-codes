package mh837.gile.worldgen.biome;

import com.mojang.serialization.Codec;
import mh837.gile.GileModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;

public class EndThresholdSurfaceFeature extends Feature<SimpleBlockConfiguration> {

    private static final float END_STONE_BLOB_CHANCE = 0.05F;
    private static final float MOON_SAND_BLOB_CHANCE = 0.025F;

    public EndThresholdSurfaceFeature(Codec<SimpleBlockConfiguration> codec) {super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<SimpleBlockConfiguration> context) {WorldGenLevel level = context.level();
        BlockPos origin = context.origin();RandomSource random = context.random();
        boolean placed = false;
        if (random.nextFloat() < END_STONE_BLOB_CHANCE) {placed |= generateEndStoneBlob(level, origin, random);}
        if (random.nextFloat() < MOON_SAND_BLOB_CHANCE) {placed |= generateMoonSandBlob(level, origin, random);} return placed;
    }

    private boolean generateEndStoneBlob( WorldGenLevel level, BlockPos origin, RandomSource random) {
        int radiusX = Mth.nextInt(random, 3, 5);
        int radiusZ = Mth.nextInt(random, 3, 5);
        boolean placed = false;
        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                double normalizedX = (double) dx / radiusX; double normalizedZ = (double) dz / radiusZ;
                double distance = normalizedX * normalizedX + normalizedZ * normalizedZ;
                double noise = Math.sin((origin.getX() + dx) * 0.7D) * 0.12D + Math.cos((origin.getZ() + dz) * 0.55D) * 0.12D;
                if (distance + noise > 1.0D) {continue;} if (distance > 0.65D && random.nextFloat() < 0.25F) {continue;}
                int x = origin.getX() + dx; int z = origin.getZ() + dz; int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos groundPos = new BlockPos(x, y - 1, z); BlockPos topPos = groundPos.above();
                if (!isValidSurfaceBlock(level, groundPos)) {continue;}
                level.setBlock(groundPos, Blocks.END_STONE.defaultBlockState(), Block.UPDATE_ALL); }} return placed;
    }

    private boolean generateMoonSandBlob(WorldGenLevel level, BlockPos origin, RandomSource random) {
        int radiusX = Mth.nextInt(random, 1, 2);
        int radiusZ = Mth.nextInt(random, 1, 2);
        boolean placed = false;
        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                double normalizedX = (double) dx / radiusX;
                double normalizedZ = (double) dz / radiusZ;
                double distance = normalizedX * normalizedX + normalizedZ * normalizedZ;
                double noise = Math.sin((origin.getX() + dx) * 0.7D) * 0.12D + Math.cos((origin.getZ() + dz) * 0.55D) * 0.12D;
                if (distance + noise > 1.0D) {continue;}
                if (distance > 0.65D && random.nextFloat() < 0.25F) {continue;}
                int x = origin.getX() + dx; int z = origin.getZ() + dz; int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos groundPos = new BlockPos(x, y - 1, z); BlockPos topPos = groundPos.above();
                if (!isValidSurfaceBlock(level, groundPos)) {continue;}
                level.setBlock(groundPos, GileModBlocks.MOON_SAND.defaultBlockState(), Block.UPDATE_ALL); placed = true;}} return placed;
    }

    private boolean isValidSurfaceBlock(WorldGenLevel level, BlockPos pos) {var state = level.getBlockState(pos);
        return state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.DIRT) || state.is(Blocks.COARSE_DIRT) || state.is(Blocks.PODZOL)
                || state.is(Blocks.MOSS_BLOCK) || state.is(Blocks.STONE) || state.is(Blocks.SAND) || state.is(Blocks.GRAVEL);
    }

}