package mh837.gile.item.tool;

import net.minecraft.world.item.Item;

public class FluttererItem extends Item {

    public FluttererItem(Properties properties) {
        super(properties);
    }
}