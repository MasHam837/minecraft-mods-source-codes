package mh837.gile.item.weapon;

import mh837.gile.GileModDataComponents;
import mh837.gile.GileModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.function.Consumer;

public final class WeaponLevel {

    public static final int MIN_LEVEL = 1;
    public static final int MAX_LEVEL = 5;

    private WeaponLevel() {
    }

    /**
     * Returns the weapon's current level.
     *
     * Weapons without the component are treated as level 1.
     */
    public static int get(ItemStack stack) {
        int level = stack.getOrDefault(
                GileModDataComponents.WEAPON_LEVEL,
                MIN_LEVEL
        );

        return Math.clamp(
                level,
                MIN_LEVEL,
                MAX_LEVEL
        );
    }

    /**
     * Sets the weapon level.
     */
    public static void set(ItemStack stack, int level) {
        int clampedLevel = Math.clamp(
                level,
                MIN_LEVEL,
                MAX_LEVEL
        );

        stack.set(
                GileModDataComponents.WEAPON_LEVEL,
                clampedLevel
        );
    }

    /**
     * Returns true if this stack is one of your upgradeable weapons.
     */
    public static boolean isWeapon(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }

        Item item = stack.getItem();

        return item == GileModItems.DAYBREAK_CHRONICLES
                || item == GileModItems.VORTEX_VANQUISHER
                || item == GileModItems.ENGULFING_LIGHTNING
                || item == GileModItems.THOUSAND_FLOATING_DREAMS
                || item == GileModItems.SPLENDOR_OF_TRANQUIL_WATERS
                || item == GileModItems.THOUSAND_BLAZING_SUNS
                || item == GileModItems.HIEMAL_MANDATE
                || item == GileModItems.NOCTURNES_CURTAIN_CALL;
    }

    /**
     * Adds the weapon level to the tooltip.
     */
    public static void appendLevelTooltip(
            ItemStack stack,
            Consumer<Component> builder
    ) {
        if (!isWeapon(stack)) {
            return;
        }

        builder.accept(
                Component.translatable(
                        "tooltip.gilemod.weapon_level",
                        get(stack)
                ).withStyle(ChatFormatting.GRAY)
        );
    }
}