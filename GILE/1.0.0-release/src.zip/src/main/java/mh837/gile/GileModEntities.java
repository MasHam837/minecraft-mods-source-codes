package mh837.gile;

import mh837.gile.advancement.GileModEncounterHelper;
import mh837.gile.advancement.GileModTriggers;
import mh837.gile.entity.*;
import mh837.gile.entity.projectile.EnderFlyStingEntity;
import mh837.gile.entity.projectile.FateArrowEntity;
import mh837.gile.entity.projectile.RocketEntity;
import mh837.gile.entity.projectile.VentiArrowEntity;
import mh837.gile.item.SalonMemberSpawnEggItem;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.component.TypedEntityData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

public class GileModEntities {

    private static ResourceKey<EntityType<?>> createEntityKey(String name) {
        return ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
    }

    private static ResourceKey<Item> createSpawnEggKey(String name) {
        return ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name));
    }

    private static void checkGileModEncounters(ServerPlayer player) {
        if (player.tickCount % 10 != 0) return;
        ServerLevel level = player.level();
        boolean inEnd = level.dimension().equals(Level.END);
        AABB searchBox = player.getBoundingBox().inflate(5.0);
        if (inEnd) {
            for (HoveringGhostEntity hoveringGhost : level.getEntitiesOfClass(HoveringGhostEntity.class, searchBox)) {
                if (GileModEncounterHelper.isLookingAt(player, hoveringGhost, 5.0)) {GileModTriggers.ENCOUNTER_HOVERING_GHOST.trigger(player);return;}}
            for (GloomyLynxEntity lynx : level.getEntitiesOfClass(GloomyLynxEntity.class, searchBox)) {
                if (GileModEncounterHelper.isLookingAt(player, lynx, 5.0)) {GileModTriggers.ENCOUNTER_GLOOMY_LYNX.trigger(player);return;}}
            for (JerboaEntity jerboa : level.getEntitiesOfClass(JerboaEntity.class, searchBox)) {
                if (GileModEncounterHelper.isLookingAt(player, jerboa, 5.0)) {GileModTriggers.ENCOUNTER_JERBOA.trigger(player);break;}}
            for (EnderFlyEntity enderFly : level.getEntitiesOfClass(EnderFlyEntity.class, searchBox)) {
                if (GileModEncounterHelper.isLookingAt(player, enderFly, 5.0)) {GileModTriggers.ENCOUNTER_MOON_MOBS.trigger(player);break;}}
            for (MothEntity moth : level.getEntitiesOfClass(MothEntity.class, searchBox)) {
                if (GileModEncounterHelper.isLookingAt(player, moth, 5.0)) {GileModTriggers.ENCOUNTER_MOON_MOBS.trigger(player);break;}}
            for (VoidSlimeEntity voidSlime : level.getEntitiesOfClass(VoidSlimeEntity.class, searchBox)) {
                if (GileModEncounterHelper.isLookingAt(player, voidSlime, 5.0)) {GileModTriggers.ENCOUNTER_MOON_MOBS.trigger(player);break;}}
        } else {
            for (WeaselThiefEntity thief : level.getEntitiesOfClass(WeaselThiefEntity.class, searchBox)) {
                if (GileModEncounterHelper.isLookingAt(player, thief, 5.0)) {GileModTriggers.ENCOUNTER_WEASEL_THIEF.trigger(player);break;}}
        }
    }

    // === PROJECTILES ===

    // FATE ARROW
    public static final ResourceKey<EntityType<?>> FATE_ARROW_KEY = createEntityKey("fate_arrow");
    public static final EntityType<FateArrowEntity> FATE_ARROW_TYPE = Registry.register(BuiltInRegistries.ENTITY_TYPE, FATE_ARROW_KEY,
            EntityType.Builder.<FateArrowEntity>of(FateArrowEntity::new, MobCategory.MISC).sized(0.5f, 0.5f).build(FATE_ARROW_KEY));

    // VENTI ARROW
    public static final ResourceKey<EntityType<?>> VENTI_ARROW_KEY = createEntityKey("venti_arrow");
    public static final EntityType<VentiArrowEntity> VENTI_ARROW_TYPE = Registry.register(BuiltInRegistries.ENTITY_TYPE, VENTI_ARROW_KEY,
            EntityType.Builder.<VentiArrowEntity>of(VentiArrowEntity::new, MobCategory.MISC).sized(0.5f, 0.5f).build(VENTI_ARROW_KEY));

    // ENDER FLY STING
    public static final ResourceKey<EntityType<?>> ENDER_FLY_STING_KEY = createEntityKey("ender_fly_sting");
    public static final EntityType<EnderFlyStingEntity> ENDER_FLY_STING = Registry.register(BuiltInRegistries.ENTITY_TYPE, ENDER_FLY_STING_KEY,
            EntityType.Builder.of((EntityType<EnderFlyStingEntity> type, Level level) -> new EnderFlyStingEntity(type, level), MobCategory.MISC)
                    .sized(0.15F, 0.15F).clientTrackingRange(4).updateInterval(10).build(ENDER_FLY_STING_KEY));

    // RUIN GUARD RORCKET
    public static final ResourceKey<EntityType<?>> ROCKET_ENTITY_KEY = createEntityKey("rocket_entity");
    public static final EntityType<RocketEntity> ROCKET_ENTITY = Registry.register(BuiltInRegistries.ENTITY_TYPE, ROCKET_ENTITY_KEY,
            EntityType.Builder.<RocketEntity>of(RocketEntity::new, MobCategory.MISC).sized(0.125F, 0.125F).build(ROCKET_ENTITY_KEY));

    // === ENTITIES ===

    // VOID SLIME
    public static final ResourceKey<EntityType<?>> VOID_SLIME_KEY = createEntityKey("void_slime");
    public static final EntityType<VoidSlimeEntity> VOID_SLIME = Registry.register(BuiltInRegistries.ENTITY_TYPE, VOID_SLIME_KEY,
            EntityType.Builder.of(VoidSlimeEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 0.8f).clientTrackingRange(8).updateInterval(2).build(VOID_SLIME_KEY));
    public static final ResourceKey<Item> VOID_SLIME_EGG_KEY = createSpawnEggKey("void_slime_spawn_egg");
    public static final Item VOID_SLIME_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, VOID_SLIME_EGG_KEY,
            new SpawnEggItem(new Item.Properties().setId(VOID_SLIME_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(VOID_SLIME, new CompoundTag()))));

    // MOTH
    public static final ResourceKey<EntityType<?>> MOTH_KEY = createEntityKey("moth");
    public static final EntityType<MothEntity> MOTH = Registry.register(BuiltInRegistries.ENTITY_TYPE, MOTH_KEY,
            EntityType.Builder.of(MothEntity::new, MobCategory.MONSTER)
                    .sized(0.75f, 0.35f).clientTrackingRange(8).updateInterval(2).build(MOTH_KEY));
    public static final ResourceKey<Item> MOTH_EGG_KEY = createSpawnEggKey("moth_spawn_egg");
    public static final Item MOTH_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, MOTH_EGG_KEY,
            new SpawnEggItem(new Item.Properties().setId(MOTH_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(MOTH, new CompoundTag()))));

    // LUMINOUS
    public static final ResourceKey<EntityType<?>> LUMINOUS_KEY = createEntityKey("luminous");
    public static final EntityType<LuminousEntity> LUMINOUS = Registry.register(BuiltInRegistries.ENTITY_TYPE, LUMINOUS_KEY,
            EntityType.Builder.of(LuminousEntity::new, MobCategory.AMBIENT)
                    .sized(0.85f, 0.85f).clientTrackingRange(8).updateInterval(2).build(LUMINOUS_KEY));
    public static final ResourceKey<Item> LUMINOUS_EGG_KEY = createSpawnEggKey("luminous_spawn_egg");
    public static final Item LUMINOUS_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, LUMINOUS_EGG_KEY,
            new SpawnEggItem(new Item.Properties().setId(LUMINOUS_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(LUMINOUS, new CompoundTag()))));

    // HOVERING GHOST
    public static final ResourceKey<EntityType<?>> HOVERING_GHOST_KEY = createEntityKey("hovering_ghost");
    public static final EntityType<HoveringGhostEntity> HOVERING_GHOST = Registry.register(BuiltInRegistries.ENTITY_TYPE, HOVERING_GHOST_KEY,
            EntityType.Builder.of(HoveringGhostEntity::new, MobCategory.AMBIENT)
                    .sized(1.5f, 0.75f).build(HOVERING_GHOST_KEY));
    public static final ResourceKey<Item> HOVERING_GHOST_EGG_KEY = createSpawnEggKey("hovering_ghost_spawn_egg");
    public static final Item HOVERING_GHOST_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, HOVERING_GHOST_EGG_KEY, new SpawnEggItem(
            new Item.Properties().setId(HOVERING_GHOST_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(HOVERING_GHOST, new CompoundTag()))));

    // JERBOA
    public static final ResourceKey<EntityType<?>> JERBOA_KEY = createEntityKey("jerboa");
    public static final EntityType<JerboaEntity> JERBOA = Registry.register(BuiltInRegistries.ENTITY_TYPE, JERBOA_KEY,
            EntityType.Builder.of(JerboaEntity::new, MobCategory.MONSTER)
                    .sized(0.4f, 0.4f).clientTrackingRange(8).updateInterval(2).build(JERBOA_KEY));
    public static final ResourceKey<Item> JERBOA_EGG_KEY = createSpawnEggKey("jerboa_spawn_egg");
    public static final Item JERBOA_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, JERBOA_EGG_KEY, new SpawnEggItem(
            new Item.Properties().setId(JERBOA_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(JERBOA, new CompoundTag()))));

    // GLOOMY LYNX
    public static final ResourceKey<EntityType<?>> GLOOMY_LYNX_KEY = createEntityKey("gloomy_lynx");
    public static final EntityType<GloomyLynxEntity> GLOOMY_LYNX = Registry.register(BuiltInRegistries.ENTITY_TYPE, GLOOMY_LYNX_KEY,
            EntityType.Builder.of(GloomyLynxEntity::new, MobCategory.AMBIENT).sized(0.8f, 1.2f)
                    .clientTrackingRange(8).updateInterval(2).build(GLOOMY_LYNX_KEY));
    public static final ResourceKey<Item> GLOOMY_LYNX_EGG_KEY = createSpawnEggKey("gloomy_lynx_spawn_egg");
    public static final Item GLOOMY_LYNX_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, GLOOMY_LYNX_EGG_KEY, new SpawnEggItem(
            new Item.Properties().setId(GLOOMY_LYNX_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(GLOOMY_LYNX, new CompoundTag()))));

    // WEASEL THIEF
    public static final ResourceKey<EntityType<?>> WEASEL_THIEF_KEY = createEntityKey("weasel_thief");
    public static final EntityType<WeaselThiefEntity> WEASEL_THIEF = Registry.register(BuiltInRegistries.ENTITY_TYPE, WEASEL_THIEF_KEY,
            EntityType.Builder.of(WeaselThiefEntity::new, MobCategory.MONSTER).sized(0.6f, 0.5f).build(WEASEL_THIEF_KEY));
    public static final ResourceKey<Item> WEASEL_THIEF_EGG_KEY = createSpawnEggKey("weasel_thief_spawn_egg");
    public static final Item WEASEL_THIEF_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, WEASEL_THIEF_EGG_KEY,
            new SpawnEggItem(new Item.Properties().setId(WEASEL_THIEF_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(WEASEL_THIEF, new CompoundTag()))));

    // ENDER FLY
    public static final ResourceKey<EntityType<?>> ENDER_FLY_KEY = createEntityKey("ender_fly");
    public static final EntityType<EnderFlyEntity> ENDER_FLY = Registry.register(BuiltInRegistries.ENTITY_TYPE, ENDER_FLY_KEY,
            EntityType.Builder.of(EnderFlyEntity::new, MobCategory.MONSTER).sized(0.75F, 1.0F).clientTrackingRange(8).updateInterval(2).build(ENDER_FLY_KEY));
    public static final ResourceKey<Item> ENDER_FLY_EGG_KEY = createSpawnEggKey("ender_fly_spawn_egg");
    public static final Item ENDER_FLY_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, ENDER_FLY_EGG_KEY,
            new SpawnEggItem(new Item.Properties().setId(ENDER_FLY_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(ENDER_FLY, new CompoundTag()))));

    // GLITTER
    public static final ResourceKey<EntityType<?>> GLITTER_KEY = createEntityKey("glitter");
    public static final EntityType<GlitterEntity> GLITTER = Registry.register( BuiltInRegistries.ENTITY_TYPE, GLITTER_KEY,
            EntityType.Builder.of( GlitterEntity::new, MobCategory.AMBIENT).sized(0.25f, 0.25f) .build(GLITTER_KEY));
    public static final ResourceKey<Item> GLITTER_EGG_KEY = createSpawnEggKey("glitter_spawn_egg");
    public static final Item GLITTER_SPAWN_EGG = Registry.register( BuiltInRegistries.ITEM, GLITTER_EGG_KEY,
            new SpawnEggItem(new Item.Properties().setId(GLITTER_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(GLITTER, new CompoundTag()))));

    // RUIN GUARD
    public static final ResourceKey<EntityType<?>> RUIN_GUARD_KEY = createEntityKey("ruin_guard");
    public static final EntityType<RuinGuardEntity> RUIN_GUARD = Registry.register(BuiltInRegistries.ENTITY_TYPE, RUIN_GUARD_KEY,
            EntityType.Builder.of(RuinGuardEntity::new, MobCategory.MONSTER).sized(3.0F, 4.0F).build(RUIN_GUARD_KEY));
    public static final ResourceKey<Item> RUIN_GUARD_EGG_KEY = createSpawnEggKey("ruin_guard_spawn_egg");
    public static final Item RUIN_GUARD_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, RUIN_GUARD_EGG_KEY,
            new SpawnEggItem(new Item.Properties().setId(RUIN_GUARD_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(RUIN_GUARD, new CompoundTag()))));

    // SALON MEMBERS
    public static final ResourceKey<EntityType<?>> SALON_MEMBER_KEY = createEntityKey("salon_member");
    public static final EntityType<SalonMemberEntity> SALON_MEMBER = Registry.register(BuiltInRegistries.ENTITY_TYPE, SALON_MEMBER_KEY,
            EntityType.Builder.of(SalonMemberEntity::new, MobCategory.CREATURE).sized(0.55F, 0.75F).build(SALON_MEMBER_KEY));
    public static final ResourceKey<Item> SALON_MEMBER_EGG_KEY = createSpawnEggKey("salon_member_spawn_egg");
    public static final Item SALON_MEMBER_SPAWN_EGG = Registry.register(BuiltInRegistries.ITEM, SALON_MEMBER_EGG_KEY,
            new SalonMemberSpawnEggItem(new Item.Properties().setId(SALON_MEMBER_EGG_KEY).component(DataComponents.ENTITY_DATA, TypedEntityData.of(SALON_MEMBER, new CompoundTag()))));

    public static void initialize() {
        System.out.println("Registering Entities for " + GileMod.MOD_ID);

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                checkGileModEncounters(player);
            }
        });

        FabricDefaultAttributeRegistry.register(VOID_SLIME, VoidSlimeEntity.createVoidSlimeAttributes());
        FabricDefaultAttributeRegistry.register(MOTH, MothEntity.createMothAttributes());
        FabricDefaultAttributeRegistry.register(LUMINOUS, LuminousEntity.createLuminousAttributes());
        FabricDefaultAttributeRegistry.register(HOVERING_GHOST, HoveringGhostEntity.createHoveringGhostAttributes());
        FabricDefaultAttributeRegistry.register(JERBOA, JerboaEntity.createJerboaAttributes());
        FabricDefaultAttributeRegistry.register(GLOOMY_LYNX, GloomyLynxEntity.createLynxAttributes());
        FabricDefaultAttributeRegistry.register(WEASEL_THIEF, WeaselThiefEntity.createWeaselAttributes());
        FabricDefaultAttributeRegistry.register(GLITTER, GlitterEntity.createGlitterAttributes());
        FabricDefaultAttributeRegistry.register(SALON_MEMBER, SalonMemberEntity.createSalonMemberAttributes());
        FabricDefaultAttributeRegistry.register(ENDER_FLY, EnderFlyEntity.createFlyAttributes());
        FabricDefaultAttributeRegistry.register(RUIN_GUARD, RuinGuardEntity.createGuardAttributes());

        // === SPAWN PLACEMENTS ===

        // VOID SLIME
        SpawnPlacements.register(
                VOID_SLIME,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> {
                    BlockState below = level.getBlockState(pos.below());
                    return below.is(Blocks.END_STONE) || below.is(GileModBlocks.END_GRASS_BLOCK);
                }
        );

        // MOTH
        SpawnPlacements.register(
                MOTH,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> {
                    BlockState below = level.getBlockState(pos.below());
                    return below.is(Blocks.END_STONE)
                            || below.is(GileModBlocks.MOON_SAND)
                            || below.is(Blocks.GRASS_BLOCK)
                            || below.is(Blocks.MYCELIUM);
                }
        );

        // LUMINOUS
        SpawnPlacements.register(
                LUMINOUS,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> level.getBlockState(pos.below()).is(GileModBlocks.END_GRASS_BLOCK)
        );

        // HOVERING GHOST
        SpawnPlacements.register(
                HOVERING_GHOST,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> level.getBlockState(pos.below()).is(GileModBlocks.END_GRASS_BLOCK)
        );

        // JERBOA
        SpawnPlacements.register(
                JERBOA,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> {
                    BlockState below = level.getBlockState(pos.below());
                    return below.is(GileModBlocks.MOON_SAND)
                            || below.is(Blocks.SAND)
                            || below.is(Blocks.RED_SAND)
                            || below.is(Blocks.COARSE_DIRT);
                }
        );

        // GLOOMY LYNX
        SpawnPlacements.register(
                GLOOMY_LYNX,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> {
                    BlockState below = level.getBlockState(pos.below());
                    return below.is(Blocks.END_STONE) || below.is(GileModBlocks.END_GRASS_BLOCK);
                }
        );

        // WEASEL THIEF
        SpawnPlacements.register(
                WEASEL_THIEF,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> {
                    BlockState below = level.getBlockState(pos.below());
                    return below.is(Blocks.GRASS_BLOCK)
                            || below.is(Blocks.COARSE_DIRT)
                            || below.is(Blocks.MYCELIUM)
                            || below.is(Blocks.MOSS_BLOCK)
                            || below.is(Blocks.SAND)
                            || below.is(Blocks.GRAVEL)
                            || below.is(Blocks.STONE)
                            || below.is(Blocks.DEEPSLATE)
                            || below.is(Blocks.TERRACOTTA)
                            || below.is(Blocks.SNOW)
                            || below.is(Blocks.END_STONE)
                            || below.is(GileModBlocks.MOON_SAND)
                            || below.is(GileModBlocks.END_GRASS_BLOCK);
                }
        );

        // ENDER FLY
        SpawnPlacements.register(
                ENDER_FLY,
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> {
                    // 75% chance to fail the spawn natively, preventing them from overriding Enderman spawns
                    if (random.nextInt(4) != 0) {
                        return false;
                    }
                    BlockState below = level.getBlockState(pos.below());
                    return below.is(Blocks.END_STONE) || below.is(GileModBlocks.END_GRASS_BLOCK);
                }
        );
    }
}