package mh837.gile.item.weapon;

import mh837.gile.GileModItems;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;

public final class WeaponDamage {

    private WeaponDamage() {
    }

    /*
     * Desired TOTAL attack damage:
     *
     * Level 1 = 8
     * Level 2 = 9
     * Level 3 = 10
     * Level 4 = 11
     * Level 5 = 12
     */
    private static final double BASE_DAMAGE = 7.0D;
    private static final double DAMAGE_PER_LEVEL = 1.0D;

    /*
     * Minecraft's player base attack damage is 1.0.
     *
     * Therefore:
     *
     * displayed damage 8 = item modifier +7
     * displayed damage 9 = item modifier +8
     * etc.
     */

    public static double getDamage(ItemStack stack) {
        if (!isElemental(stack)) {
            return 0.0D;
        }

        int level = WeaponLevel.get(stack);

        return BASE_DAMAGE + level * DAMAGE_PER_LEVEL;
    }

    /**
     * Updates the EXISTING attack-damage modifier of an elemental weapon.
     *
     * Important:
     * We do NOT add another attack-damage modifier.
     * We replace whichever attack-damage modifier the registered item
     * already has.
     */
    public static void update(ItemStack stack) {
        if (!isElemental(stack)) {
            return;
        }

        ItemAttributeModifiers original =
                stack.getOrDefault(
                        DataComponents.ATTRIBUTE_MODIFIERS,
                        ItemAttributeModifiers.EMPTY
                );

        double modifierAmount = getDamage(stack) - 1.0D;

        ItemAttributeModifiers.Builder builder =
                ItemAttributeModifiers.builder();

        boolean replacedDamage = false;

        for (ItemAttributeModifiers.Entry entry : original.modifiers()) {

            if (entry.attribute().is(Attributes.ATTACK_DAMAGE)
                    && !replacedDamage) {

                builder.add(
                        entry.attribute(),
                        new AttributeModifier(
                                entry.modifier().id(),
                                modifierAmount,
                                entry.modifier().operation()
                        ),
                        entry.slot(),
                        entry.display()
                );

                replacedDamage = true;

            } else {

                builder.add(
                        entry.attribute(),
                        entry.modifier(),
                        entry.slot(),
                        entry.display()
                );
            }
        }

        if (!replacedDamage) {
            return;
        }

        stack.set(
                DataComponents.ATTRIBUTE_MODIFIERS,
                builder.build()
        );
    }

    private static boolean isElemental(ItemStack stack) {
        return stack.is(GileModItems.DAYBREAK_CHRONICLES)
                || stack.is(GileModItems.VORTEX_VANQUISHER)
                || stack.is(GileModItems.ENGULFING_LIGHTNING)
                || stack.is(GileModItems.THOUSAND_FLOATING_DREAMS)
                || stack.is(GileModItems.SPLENDOR_OF_TRANQUIL_WATERS)
                || stack.is(GileModItems.THOUSAND_BLAZING_SUNS)
                || stack.is(GileModItems.HIEMAL_MANDATE)
                || stack.is(GileModItems.NOCTURNES_CURTAIN_CALL);
    }
}