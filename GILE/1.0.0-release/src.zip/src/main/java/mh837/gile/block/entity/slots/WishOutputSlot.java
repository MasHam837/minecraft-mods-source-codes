package mh837.gile.block.entity.slots;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class WishOutputSlot extends Slot {

    public WishOutputSlot(
            Container container,
            int slot,
            int x,
            int y
    ) {
        super(
                container,
                slot,
                x,
                y
        );
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return false;
    }

    @Override
    public int getMaxStackSize() {
        return 64;
    }

}
