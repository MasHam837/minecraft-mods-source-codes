package mh837.gile.block.entity.signs;

import mh837.gile.GileModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class InvertedOakSignBlockEntity extends SignBlockEntity {

    public InvertedOakSignBlockEntity(BlockPos pos, BlockState state) {
        super(GileModBlockEntities.INVERTED_OAK_SIGN_ENTITY, pos, state);
    }
}