package mh837.gile;

import mh837.gile.advancement.GileModTriggers;
import mh837.gile.worldgen.biome.EndThresholdSurfaceFeature;
import mh837.gile.worldgen.biome.GileModBiomes;
import mh837.gile.worldgen.feature.CloudBlobFeature;
import mh837.gile.worldgen.biome.GhostlyThicketsSurfaceFeature;
import mh837.gile.worldgen.biome.MoonDesertSurfaceFeature;
import mh837.gile.worldgen.feature.GlowingChorusFeature;
import mh837.gile.worldgen.feature.StarFeature;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.TheEndBiomes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.grower.TreeGrower;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.structure.Structure;

import java.util.Optional;

public class GileModWorldgen {

    // ADVANCEMENTS TRIGGERS
    private static boolean isInsideAncientRuins(ServerLevel level, BlockPos pos) {
        Holder<Structure> structure = level.registryAccess().lookupOrThrow(Registries.STRUCTURE).getOrThrow(ANCIENT_RUINS);
        return level.structureManager().getStructureAt(pos, structure.value()).isValid();
    }

    private static boolean isMoonBiome(Holder<Biome> biome) {
        return biome.is(MOON_DESERT) || biome.is(GHOSTLY_THICKETS) || biome.is(Biomes.END_BARRENS)
                || biome.is(Biomes.END_HIGHLANDS) || biome.is(Biomes.END_MIDLANDS) || biome.is(Biomes.SMALL_END_ISLANDS);
    }

    public static void checkDiscoveries(ServerPlayer player) {
        ServerLevel level = player.level(); BlockPos pos = player.blockPosition(); Holder<Biome> biome = level.getBiome(pos);
        if (biome.is(MOON_DESERT)) {GileModTriggers.DISCOVER_MOON_DESERT.trigger(player);}
        if (biome.is(END_THRESHOLD)) {GileModTriggers.DISCOVER_END_THRESHOLD.trigger(player);}
        if (biome.is(GHOSTLY_THICKETS)) {GileModTriggers.DISCOVER_GHOSTLY_THICKETS.trigger(player);}
        if (isMoonBiome(biome)) {GileModTriggers.DISCOVER_MOON.trigger(player);}
        if (isInsideAncientRuins(level, pos)) {GileModTriggers.DISCOVER_ANCIENT_RUINS.trigger(player);}
    }

    // STRUCTURE KEYS
    public static final ResourceKey<Structure> ANCIENT_RUINS = ResourceKey.create(
            Registries.STRUCTURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ancient_ruins"));

    // GHOSTLY THICKETS KEYS
    public static final ResourceKey<Biome> GHOSTLY_THICKETS = ResourceKey.create(
            Registries.BIOME, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly_thickets"));

    public static final ResourceKey<ConfiguredFeature<?, ?>> GHOSTLY_THICKETS_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly_thickets_surface_conf"));
    public static final ResourceKey<PlacedFeature> GHOSTLY_SURFACE_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly_thickets_surface"));

    public static final ResourceKey<ConfiguredFeature<?, ?>> GHOSTLY_TREE_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly_tree"));
    public static final ResourceKey<PlacedFeature> GHOSTLY_TREE_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly_tree"));

    // MOON DESERT KEYS
    public static final ResourceKey<Biome> MOON_DESERT = ResourceKey.create(
            Registries.BIOME, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "moon_desert"));

    public static final ResourceKey<PlacedFeature> MOON_DESERT_SURFACE_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "moon_desert_surface"));
    public static final ResourceKey<ConfiguredFeature<?, ?>> MOON_DESERT_SURFACE_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "moon_desert_surface_conf"));

    public static final ResourceKey<PlacedFeature> DRY_FLOWER_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "dry_flower"));
    public static final ResourceKey<ConfiguredFeature<?, ?>> DRY_FLOWER_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "dry_flower"));

    public static final ResourceKey<ConfiguredFeature<?, ?>> GLOWING_CHORUS_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_conf"));
    public static final ResourceKey<PlacedFeature> GLOWING_CHORUS_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus"));

    public static final ResourceKey<ConfiguredFeature<?, ?>> GLOWING_CHORUS_MOON_DESERT_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_moon_desert_conf"));
    public static final ResourceKey<PlacedFeature> GLOWING_CHORUS_MOON_DESERT_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_moon_desert"));

    // END THRESHOLD KEYS
    public static final ResourceKey<Biome> END_THRESHOLD = ResourceKey.create(
            Registries.BIOME, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_threshold"));

    public static final ResourceKey<PlacedFeature> END_THRESHOLD_SURFACE_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_threshold_surface"));
    public static final ResourceKey<ConfiguredFeature<?, ?>> END_THRESHOLD_SURFACE_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_threshold_surface_conf"));

    public static final ResourceKey<ConfiguredFeature<?, ?>> INVERTED_OAK_TREE_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "inverted_oak_tree"));
    public static final ResourceKey<PlacedFeature> INVERTED_OAK_TREE_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "inverted_oak_tree"));

    public static final ResourceKey<ConfiguredFeature<?, ?>> GLOWING_CHORUS_END_THRESHOLD_CONFIGURED = ResourceKey.create(
            Registries.CONFIGURED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_end_threshold_conf"));
    public static final ResourceKey<PlacedFeature> GLOWING_CHORUS_END_THRESHOLD_PLACED_KEY = ResourceKey.create(
            Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_end_threshold"));

    // CUSTOM FEATURES
    public static final Feature<SimpleBlockConfiguration> GHOSTLY_SURFACE_FEATURE = new GhostlyThicketsSurfaceFeature(SimpleBlockConfiguration.CODEC);
    public static final Feature<SimpleBlockConfiguration> CLOUD_BLOB = new CloudBlobFeature(SimpleBlockConfiguration.CODEC);
    public static final Feature<SimpleBlockConfiguration> STAR_FEATURE = new StarFeature(SimpleBlockConfiguration.CODEC);
    public static final Feature<SimpleBlockConfiguration> MOON_DESERT_SURFACE_FEATURE = new MoonDesertSurfaceFeature(SimpleBlockConfiguration.CODEC);
    public static final Feature<SimpleBlockConfiguration> END_THRESHOLD_SURFACE_FEATURE = new EndThresholdSurfaceFeature(SimpleBlockConfiguration.CODEC);
    public static final Feature<NoneFeatureConfiguration> GLOWING_CHORUS_FEATURE = new GlowingChorusFeature();
    public static final Feature<NoneFeatureConfiguration> GLOWING_CHORUS_MOON_DESERT_FEATURE = new GlowingChorusFeature();
    public static final Feature<NoneFeatureConfiguration> GLOWING_CHORUS_END_THRESHOLD_FEATURE = new GlowingChorusFeature();

    // TREES & SAPLINGS
    public static final TreeGrower GHOSTLY_SAPLING_GENERATOR = new TreeGrower("ghostly_tree",
            Optional.empty(), Optional.of(GHOSTLY_TREE_CONFIGURED), Optional.empty());
    public static final TreeGrower INVERTED_OAK_SAPLING_GENERATOR = new TreeGrower("inverted_oak_tree",
            Optional.empty(), Optional.of(INVERTED_OAK_TREE_CONFIGURED), Optional.empty());

    // REGISTRATION METHOD
    public static void initialize() {

        // 1. Register Custom Code Logic FIRST so JSONs can read them
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ghostly_surface"), GHOSTLY_SURFACE_FEATURE);
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "cloud_blob"), CLOUD_BLOB);
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "star"), STAR_FEATURE);
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "moon_desert_surface"), MOON_DESERT_SURFACE_FEATURE);
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_threshold_surface"), END_THRESHOLD_SURFACE_FEATURE);
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus"), GLOWING_CHORUS_FEATURE);
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_moon_desert"), GLOWING_CHORUS_MOON_DESERT_FEATURE);
        Registry.register(BuiltInRegistries.FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glowing_chorus_end_threshold"), GLOWING_CHORUS_END_THRESHOLD_FEATURE);

        // 2. Register Biomes to End Generation
        TheEndBiomes.addHighlandsBiome(GHOSTLY_THICKETS, 0.3);
        TheEndBiomes.addHighlandsBiome(MOON_DESERT, 1.5);
        // Overworld biome is handeled by a mixin

        // 3. Register Biome Modifications (Features)
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_OVERWORLD), GenerationStep.Decoration.UNDERGROUND_ORES,
                ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "primogem_ore")));
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_END)
                        .and(ctx -> !ctx.getBiomeKey().equals(Biomes.THE_END)), GenerationStep.Decoration.UNDERGROUND_ORES,
                ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_primogem_ore")));
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_END)
                        .and(ctx -> !ctx.getBiomeKey().equals(Biomes.THE_END)), GenerationStep.Decoration.UNDERGROUND_ORES,
                ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "enderite_ore")));

        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_END)
                        .and(ctx -> !ctx.getBiomeKey().equals(Biomes.THE_END)), GenerationStep.Decoration.VEGETAL_DECORATION,
                ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "moon_sand")));

        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_END)
                        .and(ctx -> !ctx.getBiomeKey().equals(Biomes.THE_END))
                        .and(ctx -> !ctx.getBiomeKey().equals(MOON_DESERT))
                        .or(ctx -> ctx.getBiomeKey().equals(END_THRESHOLD)),
                GenerationStep.Decoration.TOP_LAYER_MODIFICATION, ResourceKey.create(Registries.PLACED_FEATURE,
                        Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "moon_flower")));
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_END).and(ctx -> !ctx.getBiomeKey().equals(Biomes.THE_END)),
                GenerationStep.Decoration.VEGETAL_DECORATION, GLOWING_CHORUS_PLACED_KEY);

        // Ghostly Thickets Generation
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GHOSTLY_THICKETS), GenerationStep.Decoration.TOP_LAYER_MODIFICATION, GHOSTLY_SURFACE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GHOSTLY_THICKETS), GenerationStep.Decoration.TOP_LAYER_MODIFICATION, ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_cloud_blob")));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GHOSTLY_THICKETS), GenerationStep.Decoration.TOP_LAYER_MODIFICATION, ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "star")));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GHOSTLY_THICKETS), GenerationStep.Decoration.VEGETAL_DECORATION, ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_grass")));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GHOSTLY_THICKETS), GenerationStep.Decoration.VEGETAL_DECORATION, ResourceKey.create(Registries.PLACED_FEATURE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "tall_end_grass")));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GHOSTLY_THICKETS), GenerationStep.Decoration.VEGETAL_DECORATION, GHOSTLY_TREE_PLACED_KEY);

        // Moon Desert Generation
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MOON_DESERT), GenerationStep.Decoration.TOP_LAYER_MODIFICATION, MOON_DESERT_SURFACE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MOON_DESERT), GenerationStep.Decoration.VEGETAL_DECORATION, DRY_FLOWER_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MOON_DESERT), GenerationStep.Decoration.VEGETAL_DECORATION, GLOWING_CHORUS_MOON_DESERT_PLACED_KEY);

        // End Threshold Generation
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(END_THRESHOLD), GenerationStep.Decoration.TOP_LAYER_MODIFICATION, END_THRESHOLD_SURFACE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(END_THRESHOLD), GenerationStep.Decoration.VEGETAL_DECORATION, INVERTED_OAK_TREE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(END_THRESHOLD), GenerationStep.Decoration.VEGETAL_DECORATION, GLOWING_CHORUS_END_THRESHOLD_PLACED_KEY);

        // 4. Only Register normal Overworld Biomes Modifications

        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.DARK_FOREST),
                MobCategory.CREATURE, GileModEntities.MOTH, 20, 1, 3);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.MUSHROOM_FIELDS),
                MobCategory.CREATURE, GileModEntities.MOTH, 10, 1, 3);

        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.DESERT),
                MobCategory.CREATURE, GileModEntities.JERBOA, 20, 2, 5);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.BADLANDS),
                MobCategory.CREATURE, GileModEntities.JERBOA, 20, 2, 5);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.ERODED_BADLANDS),
                MobCategory.CREATURE, GileModEntities.JERBOA, 20, 2, 5);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.WOODED_BADLANDS),
                MobCategory.CREATURE, GileModEntities.JERBOA, 20, 2, 5);

        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
                MobCategory.CREATURE, GileModEntities.WEASEL_THIEF, 5, 1, 1);

    }
}