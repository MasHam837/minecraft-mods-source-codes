package mh837.gile.entity.projectile;

import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class FateArrowEntity extends AbstractArrow {

    // Default constructor for entity registration & NBT loading
    public FateArrowEntity(EntityType<? extends AbstractArrow> entityType, Level level) {
        super(entityType, level);
        // Removed hardcoded pickup here so NBT loading works cleanly
    }

    // Custom constructor for when the player/entity shoots it
    public FateArrowEntity(Level level, LivingEntity owner, ItemStack pickupStack, @Nullable ItemStack firedFromWeapon) {
        super(GileModEntities.FATE_ARROW_TYPE, owner, level, pickupStack, firedFromWeapon);
        this.setBaseDamage(6.0);

        // FIX: Respect Creative Mode to prevent inventory clutter
        if (owner instanceof Player player && player.getAbilities().instabuild) {
            this.pickup = Pickup.CREATIVE_ONLY;
        } else {
            this.pickup = Pickup.ALLOWED;
        }
    }

    @NotNull
    @Override
    protected ItemStack getPickupItem() {
        return new ItemStack(GileModItems.FATE_ARROW);
    }

    @NotNull
    @Override
    protected ItemStack getDefaultPickupItem() {
        return new ItemStack(GileModItems.FATE_ARROW);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        DamageSource damageSource = this.damageSources().arrow(this, this.getOwner());

        if (result.getEntity() instanceof LivingEntity livingTarget) {
            this.doKnockback(livingTarget, damageSource);
        }

        super.onHitEntity(result);

        if (this.level() instanceof ServerLevel serverLevel) {
            if (result.getEntity() instanceof LivingEntity target) {
                target.addEffect(new MobEffectInstance(
                        MobEffects.LEVITATION, 100, 0, true, true
                ), this.getOwner());

                serverLevel.sendParticles(
                        ParticleTypes.FIREWORK,
                        target.getX(), target.getY() + target.getBbHeight() / 2.0f, target.getZ(),
                        40, 0.5, 0.5, 0.5, 0.1
                );

                serverLevel.playSound(
                        null,
                        target.getX(), target.getY(), target.getZ(),
                        SoundEvents.AMETHYST_BLOCK_BREAK,
                        SoundSource.PLAYERS,
                        1.0f, 1.0f
                );
            }
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!this.level().isClientSide()) {
            this.playSound(SoundEvents.ARROW_HIT, 1.0F, 1.0F);
        }
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide()) {
            // Trail particles while flying
            if (!this.isInGround()) {
                for (int i = 0; i < 3; i++) {
                    double offsetX = (this.random.nextDouble() - 0.5) * 0.5;
                    double offsetY = (this.random.nextDouble() - 0.5) * 0.5;
                    double offsetZ = (this.random.nextDouble() - 0.5) * 0.5;

                    // FIX: Changed 0x800080 to 0xFF800080 (Added FF Alpha Channel)
                    this.level().addParticle(ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, 0xFFFFFFDD),
                            this.getX() + offsetX,
                            this.getY() + offsetY,
                            this.getZ() + offsetZ,
                            0.0, 0.0, 0.0
                    );
                }
            }
            // Particles when stuck in ground
            else if (this.tickCount % 10 == 0) {
                for (int i = 0; i < 2; i++) {
                    double offsetX = (this.random.nextDouble() - 0.5) * 0.5;
                    double offsetZ = (this.random.nextDouble() - 0.5) * 0.5;

                    // FIX: Changed 0x800080 to 0xFF800080 (Added FF Alpha Channel)
                    this.level().addParticle(ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, 0xFFFFFFDD),
                            this.getX() + offsetX,
                            this.getY() + 0.1,
                            this.getZ() + offsetZ,
                            0.0, 0.0, 0.0
                    );
                }
            }
        }
    }

    @Override
    protected float getWaterInertia() {
        return 0.6F;
    }
}