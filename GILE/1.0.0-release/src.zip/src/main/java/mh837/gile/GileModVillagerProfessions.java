package mh837.gile;

import com.google.common.collect.ImmutableSet;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PoiHelper;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.npc.villager.VillagerProfession;
import net.minecraft.world.item.trading.TradeSet;

public final class GileModVillagerProfessions {

    public static final ResourceKey<PoiType> WISHER_POI_KEY = ResourceKey.create(Registries.POINT_OF_INTEREST_TYPE, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "wisher"));

    public static final PoiType WISHER_POI = PoiHelper.register(Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "wisher"), 1, 1, GileModBlocks.WISH_TABLE);

    public static final ResourceKey<TradeSet> WISHER_LEVEL_1 = tradeSetKey("wisher/level_1");
    public static final ResourceKey<TradeSet> WISHER_LEVEL_2 = tradeSetKey("wisher/level_2");
    public static final ResourceKey<TradeSet> WISHER_LEVEL_3 = tradeSetKey("wisher/level_3");
    public static final ResourceKey<TradeSet> WISHER_LEVEL_4 = tradeSetKey("wisher/level_4");
    public static final ResourceKey<TradeSet> WISHER_LEVEL_5 = tradeSetKey("wisher/level_5");

    private static ResourceKey<TradeSet> tradeSetKey(String path) {return ResourceKey.create(Registries.TRADE_SET, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, path));}

    public static final ResourceKey<VillagerProfession> WISHER_KEY = ResourceKey.create(Registries.VILLAGER_PROFESSION, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "wisher"));

    public static final VillagerProfession WISHER = Registry.register(BuiltInRegistries.VILLAGER_PROFESSION, WISHER_KEY,
            new VillagerProfession(Component.translatable("entity." + GileMod.MOD_ID + ".villager.wisher"),
                    holder -> holder.is(WISHER_POI_KEY), holder -> holder.is(WISHER_POI_KEY),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_ARMORER, Int2ObjectMap.ofEntries(
                                    Int2ObjectMap.entry(1, WISHER_LEVEL_1), Int2ObjectMap.entry(2, WISHER_LEVEL_2),
                                    Int2ObjectMap.entry(3, WISHER_LEVEL_3),
                                    Int2ObjectMap.entry(4, WISHER_LEVEL_4),
                                    Int2ObjectMap.entry(5, WISHER_LEVEL_5))));

    public static void initialize() {
    }

    private GileModVillagerProfessions() {
    }
}