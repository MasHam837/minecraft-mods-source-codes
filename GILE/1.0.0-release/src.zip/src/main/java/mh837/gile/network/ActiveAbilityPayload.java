package mh837.gile.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record ActiveAbilityPayload() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<ActiveAbilityPayload> TYPE = new CustomPacketPayload.Type<>(
            Identifier.fromNamespaceAndPath("gilemod", "active_ability"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ActiveAbilityPayload> CODEC = StreamCodec.unit(new ActiveAbilityPayload());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}