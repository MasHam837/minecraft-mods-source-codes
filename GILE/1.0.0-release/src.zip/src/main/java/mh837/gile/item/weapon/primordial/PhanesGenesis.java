package mh837.gile.item.weapon.primordial;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

public final class PhanesGenesis {

    private PhanesGenesis() {
    }

    private static final int COOLDOWN = 240;
    private static final double RADIUS = 12.0D;

    public static boolean activate(
            ServerLevel level,
            ServerPlayer player,
            ItemStack stack
    ) {

        if (player.getCooldowns().isOnCooldown(stack)) {

            int remainingTicks =
                    Math.max(
                            1,
                            Math.round(
                                    player.getCooldowns()
                                            .getCooldownPercent(
                                                    stack,
                                                    0.0F
                                            )
                                            * COOLDOWN
                            )
                    );

            int seconds =
                    Math.max(
                            1,
                            (remainingTicks + 19) / 20
                    );

            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.translatable(
                            "message.gilemod.phanes_ability_cooldown",
                            seconds
                    ),
                    true
            );

            return false;
        }

        AABB area =
                player.getBoundingBox()
                        .inflate(RADIUS);

        for (LivingEntity entity :
                level.getEntitiesOfClass(
                        LivingEntity.class,
                        area,
                        target ->
                                target.isAlive()
                                        && !target.isSpectator()
                )) {

            /*
             * ====================================================
             * LIFE — HOSTILE CREATURES
             * ====================================================
             */

            if (entity instanceof Monster) {

                entity.hurtServer(
                        level,
                        level.damageSources().generic(),
                        entity.getHealth() + 1000.0F
                );

                continue;
            }

            /*
             * ====================================================
             * LIFE — ALL OTHER LIVING ENTITIES
             * ====================================================
             */

            entity.setHealth(
                    entity.getMaxHealth()
            );

            entity.removeEffect(MobEffects.POISON);
            entity.removeEffect(MobEffects.WITHER);
            entity.removeEffect(MobEffects.HUNGER);
            entity.removeEffect(MobEffects.WEAKNESS);
            entity.removeEffect(MobEffects.SLOWNESS);
            entity.removeEffect(MobEffects.MINING_FATIGUE);

            entity.addEffect(
                    new net.minecraft.world.effect.MobEffectInstance(
                            MobEffects.REGENERATION,
                            100,
                            1,
                            false,
                            false,
                            true
                    )
            );
        }

        spawnGenesis(
                level,
                player
        );

        level.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.BEACON_POWER_SELECT,
                SoundSource.PLAYERS,
                1.5F,
                0.55F
        );

        level.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.PLAYER_LEVELUP,
                SoundSource.PLAYERS,
                1.0F,
                0.65F
        );

        player.getCooldowns().addCooldown(
                stack,
                COOLDOWN
        );

        player.sendSystemMessage(
                net.minecraft.network.chat.Component.translatable(
                        "message.gilemod.phanes_ability_activated"
                ),
                true
        );

        return true;
    }

    private static void spawnGenesis(
            ServerLevel level,
            ServerPlayer player
    ) {

        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();

        /*
         * ========================================================
         * LIFE BURST
         * ========================================================
         */

        level.sendParticles(
                ParticleTypes.HEART,
                x,
                y + 1.0D,
                z,
                55,
                RADIUS * 0.65D,
                1.0D,
                RADIUS * 0.65D,
                0.025D
        );

        /*
         * ========================================================
         * HEALING LIGHT
         * ========================================================
         */

        level.sendParticles(
                ParticleTypes.HAPPY_VILLAGER,
                x,
                y + 1.0D,
                z,
                80,
                RADIUS * 0.75D,
                1.4D,
                RADIUS * 0.75D,
                0.02D
        );

        /*
         * ========================================================
         * RISING LIFE ENERGY
         * ========================================================
         */

        level.sendParticles(
                ParticleTypes.END_ROD,
                x,
                y + 0.2D,
                z,
                65,
                RADIUS * 0.7D,
                0.25D,
                RADIUS * 0.7D,
                0.02D
        );

        /*
         * ========================================================
         * LIFE RINGS
         * ========================================================
         */

        for (int ring = 0; ring < 3; ring++) {

            double radius =
                    3.0D + ring * 4.0D;

            for (int i = 0; i < 48; i++) {

                double angle =
                        Math.PI * 2.0D * i / 48.0D;

                level.sendParticles(
                        ParticleTypes.HAPPY_VILLAGER,
                        x + Math.cos(angle) * radius,
                        y + 0.08D + ring * 0.15D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.0D,
                        0.0D,
                        0.0D,
                        0.0D
                );
            }
        }
    }
}