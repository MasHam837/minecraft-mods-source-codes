package mh837.gile.block.entity;

import mh837.gile.GileModBlockEntities;
import mh837.gile.block.GlitterJarBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public class GlitterJarBlockEntity extends BlockEntity {

    public static final int DEFAULT_GLITTERS = 1;
    public static final int MAX_GLITTERS = 4;

    private int glitterCount = DEFAULT_GLITTERS;

    public GlitterJarBlockEntity(BlockPos pos, BlockState state) {
        super(GileModBlockEntities.GLITTER_JAR_ENTITY, pos, state);

        // Keep the BE synchronized with the actual block state.
        this.glitterCount =
                state.getValue(GlitterJarBlock.GLITTERS);
    }

    public int getGlitterCount() {
        return glitterCount;
    }

    public void setGlitterCount(int count) {
        count = Math.clamp(
                count,
                DEFAULT_GLITTERS,
                MAX_GLITTERS
        );

        glitterCount = count;
        setChanged();

        if (level == null || level.isClientSide()) {
            return;
        }

        BlockState oldState = getBlockState();

        BlockState newState = oldState.setValue(
                GlitterJarBlock.GLITTERS,
                count
        );

        if (oldState != newState) {
            level.setBlock(
                    worldPosition,
                    newState,
                    3
            );
        }
    }

    public boolean addGlitter() {
        if (glitterCount >= MAX_GLITTERS) {
            return false;
        }

        setGlitterCount(glitterCount + 1);
        return true;
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);

        output.putInt(
                "GlitterCount",
                glitterCount
        );
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);

        glitterCount = Math.clamp(
                input.getIntOr(
                        "GlitterCount",
                        DEFAULT_GLITTERS
                ),
                DEFAULT_GLITTERS,
                MAX_GLITTERS
        );
    }
}