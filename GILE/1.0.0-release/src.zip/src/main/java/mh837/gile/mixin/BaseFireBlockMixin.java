package mh837.gile.mixin;

import mh837.gile.GileModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BaseFireBlock.class)
public class BaseFireBlockMixin {
    @Inject(method = "getState", at = @At("HEAD"), cancellable = true)
    private static void redirectGetState(BlockGetter level, BlockPos pos, CallbackInfoReturnable<BlockState> cir) {
        BlockPos below = pos.below();
        if (level.getBlockState(below).is(GileModBlocks.MOON_SAND)) {
            cir.setReturnValue(GileModBlocks.MOON_FIRE.defaultBlockState());
        }
    }
}