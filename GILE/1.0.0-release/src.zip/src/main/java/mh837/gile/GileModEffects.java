package mh837.gile;

import mh837.gile.effect.EnlargeStatusEffect;
import mh837.gile.effect.ShrinkStatusEffect;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;

public class GileModEffects {

    public static final Holder<MobEffect> SHRINK = register("shrink", new ShrinkStatusEffect());
    public static final Holder<MobEffect> ENLARGE = register("enlarge", new EnlargeStatusEffect());

    private static Holder<MobEffect> register(String name, MobEffect effect) {
        return Registry.registerForHolder(
                BuiltInRegistries.MOB_EFFECT,
                Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name),
                effect
        );
    }

    public static void initialize() {
        // Triggers class loading and registration
    }
}