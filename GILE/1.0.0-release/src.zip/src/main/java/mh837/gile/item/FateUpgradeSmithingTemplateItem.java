package mh837.gile.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SmithingTemplateItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;

import java.util.List;
import java.util.function.Consumer;

public class FateUpgradeSmithingTemplateItem extends SmithingTemplateItem {

    public FateUpgradeSmithingTemplateItem(Item.Properties properties) {
        super(
                Component.empty(),
                Component.empty(),
                Component.translatable("trim_pattern.gilemod.fate_upgrade").withStyle(ChatFormatting.GRAY),
                Component.empty(),
                List.of(),
                List.of(),
                properties
        );
    }

    @Override
    public void appendHoverText(
            ItemStack stack,
            Item.TooltipContext context,
            TooltipDisplay display,
            Consumer<Component> builder,
            TooltipFlag tooltipFlag
    ) {
        builder.accept(Component.translatable("trim_pattern.gilemod.fate_upgrade").withStyle(ChatFormatting.GRAY));
        builder.accept(Component.empty());
        builder.accept(Component.translatable("item.minecraft.smithing_template.applies_to").withStyle(ChatFormatting.GRAY));
        builder.accept(Component.translatable("smithing_template.gilemod.fate_upgrade.applies_to").withStyle(ChatFormatting.BLUE));
        builder.accept(Component.translatable("item.minecraft.smithing_template.ingredients").withStyle(ChatFormatting.GRAY));
        builder.accept(Component.translatable("smithing_template.gilemod.fate_upgrade.ingredients").withStyle(ChatFormatting.BLUE));
    }
}