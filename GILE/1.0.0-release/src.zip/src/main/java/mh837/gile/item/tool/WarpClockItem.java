package mh837.gile.item.tool;

import mh837.gile.GileModItems;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;

import java.util.Set;
import java.util.function.Consumer;

public class WarpClockItem extends Item {

    public WarpClockItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        Player player = context.getPlayer();
        ItemStack stack = context.getItemInHand();

        if (player == null) {
            return InteractionResult.PASS;
        }

        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }

        /*
         * SHIFT + RIGHT CLICK:
         * Unlink the Warp Clock.
         */
        if (player.isCrouching()) {
            if (stack.has(DataComponents.CUSTOM_DATA)) {
                stack.remove(DataComponents.CUSTOM_DATA);
                stack.remove(DataComponents.ENCHANTMENT_GLINT_OVERRIDE);

                level.playSound(
                        null,
                        player.getX(),
                        player.getY(),
                        player.getZ(),
                        SoundEvents.RESPAWN_ANCHOR_DEPLETE,
                        SoundSource.PLAYERS,
                        0.7F,
                        1.3F
                );

                ((ServerLevel) level).sendParticles(
                        ParticleTypes.SMOKE,
                        player.getX(),
                        player.getY() + 1.0,
                        player.getZ(),
                        15,
                        0.2,
                        0.2,
                        0.2,
                        0.03
                );

                player.sendSystemMessage(
                        Component.translatable(
                                        "message.gilemod.warp_clock.unlinked"
                                )
                                .withStyle(ChatFormatting.GOLD)
                );

                return InteractionResult.SUCCESS;
            }
        }

        /*
         * Only signs can be linked.
         */
        BlockEntity blockEntity = level.getBlockEntity(pos);

        if (!(blockEntity instanceof SignBlockEntity sign)) {
            return this.use(level, player, context.getHand());
        }

        /*
         * Determine which side of the sign the player is looking at.
         */
        boolean isFront = sign.isFacingFrontText(player);

        SignText signText = isFront
                ? sign.getFrontText()
                : sign.getBackText();

        CompoundTag tag = new CompoundTag();

        /*
         * Teleport position is the block directly above the sign.
         */
        BlockPos teleportPos = pos.above();

        tag.putInt("X", teleportPos.getX());
        tag.putInt("Y", teleportPos.getY());
        tag.putInt("Z", teleportPos.getZ());

        tag.putString(
                "Dimension",
                level.dimension().identifier().toString()
        );

        /*
         * ---------------------------------------------------------
         * SIGN TEXT COLOR
         *
         * Vanilla SignText stores the sign text color as a DyeColor.
         *
         * Normal/undyed signs also use BLACK internally.
         *
         * For the Warp Clock tooltip we intentionally treat BLACK
         * as the normal Minecraft tooltip gray instead of forcing
         * the tooltip text to actual RGB black.
         *
         * Other dye colors are preserved exactly.
         * ---------------------------------------------------------
         */
        DyeColor signColor = signText.getColor();

        int signColorRGB = signColor.getTextColor();

        tag.putInt("ColorRGB", signColorRGB);

        /*
         * Remember whether this sign side is glowing.
         *
         * This is stored separately because glowing is a property
         * of SignText, just like the color.
         */
        tag.putBoolean(
                "Glowing",
                signText.hasGlowingText()
        );

        /*
         * Store the color per line as well for compatibility with
         * older Warp Clock data.
         */
        for (int line = 0; line < 4; line++) {
            tag.putInt(
                    "ColorRGB" + line,
                    signColorRGB
            );
        }

        /*
         * Vanilla signs use centered text by default.
         *
         * Normal SignText does not expose a separate per-line
         * alignment property, so we preserve CENTER here.
         */
        for (int line = 0; line < 4; line++) {
            tag.putString(
                    "Alignment" + line,
                    "CENTER"
            );
        }

        boolean hasText = false;
        String firstLine = "Warp Point";

        /*
         * Save the four visible lines.
         */
        for (int line = 0; line < 4; line++) {
            Component lineText =
                    signText.getMessage(line, false);

            String text =
                    lineText.getString().trim();

            tag.putString(
                    "Line" + line,
                    text
            );

            if (!text.isEmpty()) {
                if (!hasText) {
                    firstLine = text;
                }

                hasText = true;
            }
        }

        tag.putBoolean(
                "HasLines",
                hasText
        );

        tag.putString(
                "Name",
                firstLine
        );

        stack.set(
                DataComponents.CUSTOM_DATA,
                CustomData.of(tag)
        );

        stack.set(
                DataComponents.ENCHANTMENT_GLINT_OVERRIDE,
                true
        );

        level.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ENCHANTMENT_TABLE_USE,
                SoundSource.PLAYERS,
                1.0F,
                1.0F
        );

        ((ServerLevel) level).sendParticles(
                ParticleTypes.GLOW,
                pos.getX() + 0.5,
                pos.getY() + 0.5,
                pos.getZ() + 0.5,
                30,
                0.3,
                0.3,
                0.3,
                0.05
        );

        player.sendSystemMessage(
                Component.translatable(
                        "message.gilemod.warp_clock.linked"
                ).withStyle(ChatFormatting.GREEN)
        );

        return InteractionResult.SUCCESS;
    }

    @Override
    public InteractionResult use(
            Level level,
            Player player,
            InteractionHand hand
    ) {
        ItemStack stack =
                player.getItemInHand(hand);

        if (player instanceof ServerPlayer serverPlayer) {
            GileModTriggers.USE_WARP_CLOCK.trigger(
                    serverPlayer
            );
        }

        CustomData customData =
                stack.get(DataComponents.CUSTOM_DATA);

        if (customData == null ||
                !customData.copyTag().contains("X")) {

            if (!level.isClientSide()) {
                player.sendSystemMessage(
                        Component.translatable(
                                        "message.gilemod.warp_clock.click_sign"
                                )
                                .withStyle(ChatFormatting.GREEN)
                );
            }

            return InteractionResult.FAIL;
        }

        CompoundTag tag =
                customData.copyTag();

        String dimensionId =
                tag.getString("Dimension").orElse("");

        if (!level.dimension()
                .identifier()
                .toString()
                .equals(dimensionId)) {

            if (!level.isClientSide()) {
                player.sendSystemMessage(
                        Component.translatable(
                                        "message.gilemod.warp_clock.wrong_dimension"
                                )
                                .withStyle(ChatFormatting.RED)
                );
            }

            return InteractionResult.FAIL;
        }

        /*
         * Consume Chrono Gear unless the player is in Creative.
         */
        if (!player.isCreative()) {
            boolean hasChronoGear = false;

            for (int i = 0;
                 i < player.getInventory().getContainerSize();
                 i++) {

                ItemStack inventoryStack =
                        player.getInventory().getItem(i);

                if (inventoryStack.is(
                        GileModItems.CHRONO_GEAR
                )) {
                    hasChronoGear = true;

                    if (!level.isClientSide()) {
                        inventoryStack.shrink(1);
                    }

                    break;
                }
            }

            if (!hasChronoGear) {
                if (!level.isClientSide()) {
                    player.sendSystemMessage(
                            Component.translatable(
                                            "message.gilemod.warp_clock.no_chrono_gear"
                                    )
                                    .withStyle(ChatFormatting.RED)
                    );
                }

                return InteractionResult.FAIL;
            }
        }

        /*
         * Perform teleportation.
         */
        if (!level.isClientSide()) {

            BlockPos targetPos =
                    new BlockPos(
                            tag.getIntOr("X", 0),
                            tag.getIntOr("Y", 0),
                            tag.getIntOr("Z", 0)
                    );

            BlockEntity be =
                    level.getBlockEntity(
                            targetPos.below()
                    );

            if (!(be instanceof SignBlockEntity)) {
                player.sendSystemMessage(
                        Component.translatable(
                                        "message.gilemod.warp_clock.missing_sign"
                                )
                                .withStyle(ChatFormatting.RED)
                );

                level.playSound(
                        null,
                        player.getX(),
                        player.getY(),
                        player.getZ(),
                        SoundEvents.WITHER_BREAK_BLOCK,
                        SoundSource.PLAYERS,
                        0.5F,
                        1.5F
                );

                return InteractionResult.FAIL;
            }

            if (player instanceof ServerPlayer serverPlayer &&
                    level instanceof ServerLevel serverLevel) {

                serverPlayer.teleportTo(
                        serverLevel,
                        targetPos.getX() + 0.5,
                        targetPos.getY(),
                        targetPos.getZ() + 0.5,
                        Set.of(),
                        player.getYRot(),
                        player.getXRot(),
                        false
                );

                serverLevel.sendParticles(
                        ParticleTypes.PORTAL,
                        targetPos.getX() + 0.5,
                        targetPos.getY() + 0.5,
                        targetPos.getZ() + 0.5,
                        40,
                        0.5,
                        0.5,
                        0.5,
                        0.2
                );
            }

            level.playSound(
                    null,
                    targetPos,
                    SoundEvents.ENDERMAN_TELEPORT,
                    SoundSource.PLAYERS,
                    1.0F,
                    1.0F
            );
        }

        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(
            ItemStack stack,
            TooltipContext context,
            TooltipDisplay display,
            Consumer<Component> builder,
            TooltipFlag tooltipFlag
    ) {
        CustomData customData =
                stack.get(DataComponents.CUSTOM_DATA);

        if (customData == null ||
                !customData.copyTag().contains("X")) {

            builder.accept(
                    Component.translatable(
                                    "tooltip.gilemod.warp_clock.unlinked"
                            )
                            .withStyle(
                                    ChatFormatting.GRAY
                            )
            );

            return;
        }

        CompoundTag tag =
                customData.copyTag();

        int x =
                tag.getIntOr("X", 0);

        int y =
                tag.getIntOr("Y", 0);

        int z =
                tag.getIntOr("Z", 0);

        /*
         * Coordinates.
         */
        builder.accept(
                Component.translatable(
                                "tooltip.gilemod.warp_clock.coordinates"
                        )
                        .withStyle(
                                ChatFormatting.GRAY
                        )
                        .append(
                                Component.literal(
                                                x + ", " +
                                                        y + ", " +
                                                        z
                                        )
                                        .withStyle(
                                                ChatFormatting.AQUA
                                        )
                        )
        );

        /*
         * Was the sign text glowing?
         */
        boolean glowing =
                tag.getBooleanOr(
                        "Glowing",
                        false
                );

        boolean hasLines =
                tag.getBooleanOr(
                        "HasLines",
                        false
                );

        if (hasLines) {

            /*
             * Find the first and last non-empty line.
             */
            int firstFilledLine = -1;
            int lastFilledLine = -1;

            for (int line = 0;
                 line < 4;
                 line++) {

                String text =
                        tag.getStringOr(
                                "Line" + line,
                                ""
                        );

                if (!text.isEmpty()) {

                    if (firstFilledLine == -1) {
                        firstFilledLine = line;
                    }

                    lastFilledLine = line;
                }
            }

            if (firstFilledLine != -1) {

                for (int line = firstFilledLine;
                     line <= lastFilledLine;
                     line++) {

                    String text =
                            tag.getStringOr(
                                    "Line" + line,
                                    ""
                            );

                    /*
                     * Preserve blank lines between the first and
                     * last populated lines.
                     */
                    if (text.isEmpty()) {
                        builder.accept(
                                Component.literal(" ")
                        );

                        continue;
                    }

                    MutableComponent warpText =
                            Component.literal(text);

                    /*
                     * -------------------------------------------------
                     * SIGN COLOR
                     *
                     * BLACK is intentionally rendered using the
                     * normal tooltip gray.
                     *
                     * Other dye colors retain the exact RGB color
                     * from the sign.
                     * -------------------------------------------------
                     */
                    String colorKey =
                            "ColorRGB" + line;

                    int color;

                    if (tag.contains(colorKey)) {
                        color =
                                tag.getIntOr(
                                        colorKey,
                                        0x000000
                                );
                    } else {
                        color =
                                tag.getIntOr(
                                        "ColorRGB",
                                        0x000000
                                );
                    }

                    /*
                     * Only override Minecraft's normal tooltip color
                     * when the sign actually has a non-black dye color.
                     *
                     * This makes normal/black sign text readable as
                     * the usual tooltip gray.
                     */
                    if (color != 0x000000) {
                        warpText.setStyle(
                                warpText
                                        .getStyle()
                                        .withColor(color)
                        );
                    }

                    /*
                     * Glowing sign text becomes bold in the tooltip.
                     */
                    if (glowing) {
                        warpText.setStyle(
                                warpText
                                        .getStyle()
                                        .withBold(true)
                        );
                    }

                    /*
                     * -------------------------------------------------
                     * CENTERING
                     *
                     * Vanilla sign text is centered horizontally.
                     *
                     * The tooltip API has no horizontal alignment
                     * property, so leading spaces are used to
                     * approximate the sign's visual centering.
                     * -------------------------------------------------
                     */
                    String centeredText =
                            centerTooltipLine(text);

                    MutableComponent centered =
                            Component.literal(
                                    centeredText
                            );

                    centered.setStyle(
                            warpText.getStyle()
                    );

                    builder.accept(centered);
                }
            }

        } else {

            /*
             * Compatibility with the old single-name format.
             */
            String name =
                    tag.getStringOr(
                            "Name",
                            "Unknown"
                    );

            if (!name.isBlank() &&
                    !name.equals("Warp Point")) {

                MutableComponent warpText =
                        Component.literal(name);

                /*
                 * Exact saved sign color.
                 *
                 * Black/default remains the normal tooltip gray.
                 */
                int color =
                        tag.getIntOr(
                                "ColorRGB",
                                0x000000
                        );

                if (color != 0x000000) {
                    warpText.setStyle(
                            warpText
                                    .getStyle()
                                    .withColor(color)
                    );
                }

                /*
                 * Preserve glowing state for old single-name data too.
                 */
                if (glowing) {
                    warpText.setStyle(
                            warpText
                                    .getStyle()
                                    .withBold(true)
                    );
                }

                builder.accept(
                        Component.translatable(
                                        "tooltip.gilemod.warp_clock.linked_warp"
                                )
                                .withStyle(
                                        ChatFormatting.GRAY
                                )
                                .append(warpText)
                );
            }
        }

        /*
         * Chrono Gear consumption information.
         */
        builder.accept(
                Component.translatable(
                                "tooltip.gilemod.warp_clock.consumes"
                        )
                        .withStyle(
                                ChatFormatting.GRAY
                        )
                        .append(
                                Component.translatable(
                                                "item.gilemod.chrono_gear"
                                        )
                                        .withStyle(
                                                ChatFormatting.LIGHT_PURPLE
                                        )
                        )
        );
    }

    /**
     * Adds enough leading spacing to make the line appear centered
     * rather than flush against the left side of the tooltip.
     *
     * Minecraft's normal tooltip Component API has no horizontal
     * alignment property, so this intentionally remains independent
     * of client-only Font/Minecraft classes.
     */
    private static String centerTooltipLine(String text) {

        int length =
                text.codePointCount(
                        0,
                        text.length()
                );

        int spaces;

        if (length <= 4) {
            spaces = 10;
        } else if (length <= 8) {
            spaces = 7;
        } else if (length <= 12) {
            spaces = 5;
        } else if (length <= 16) {
            spaces = 3;
        } else {
            spaces = 1;
        }

        return " ".repeat(spaces) + text;
    }
}