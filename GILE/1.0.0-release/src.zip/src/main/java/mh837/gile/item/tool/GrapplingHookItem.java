package mh837.gile.item.tool;

import mh837.gile.GileModDataComponents;
import mh837.gile.GileModEnchantments;

import mh837.gile.GileModParticleTypes;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class GrapplingHookItem extends Item {

    private static final double BASE_GRAPPLE_RANGE = 32.0;
    private static final double GRAPPLE_RANGE_PER_LEVEL = 16.0;
    private static final int MAX_GRAPPLE_TICKS = 300;
    private static final int COOLDOWN_TICKS = 20;
    private static final double ARRIVAL_DISTANCE = 2.2;
    private static final double PULL_SPEED = 0.85;
    private static final double VERTICAL_PULL_BONUS = 0.10;

    private static class GrappleState {

        final Vec3 target;
        final UUID grappleId;
        int ticksActive;

        GrappleState(Vec3 target, UUID grappleId) {
            this.target = target;
            this.grappleId = grappleId;
            this.ticksActive = 0;
        }
    }

    private final Map<UUID, GrappleState> activeHooks = new ConcurrentHashMap<>();

    public GrapplingHookItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (player instanceof ServerPlayer serverPlayer) {
            GileModTriggers.USE_GRAPPLING_HOOK.trigger(serverPlayer);
        }

        if (player.isShiftKeyDown()) {
            if (!level.isClientSide()) {
                if (cancelGrapple(player)) {
                    playCancelSound(level, player);
                    return InteractionResult.SUCCESS;
                }
            } return InteractionResult.PASS;
        }
        if (activeHooks.containsKey(player.getUUID())) {return InteractionResult.PASS;}
        UUID grappleId = getOrCreateGrappleId(stack);
        if (player.getCooldowns().isOnCooldown(stack)) {return InteractionResult.PASS;}
        int rangeLevel = getRangeLevel(level, stack);
        double maxDistance = BASE_GRAPPLE_RANGE + (rangeLevel * GRAPPLE_RANGE_PER_LEVEL);
        Vec3 eyePosition = player.getEyePosition();
        Vec3 lookVector = player.getViewVector(1.0F);
        Vec3 traceEnd = eyePosition.add(lookVector.scale(maxDistance));
        BlockHitResult hitResult = level.clip(new ClipContext(eyePosition, traceEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (hitResult.getType() != HitResult.Type.BLOCK) {
            if (!level.isClientSide()) {level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 0.5F, 0.8F);
            } return InteractionResult.PASS;
        }
        Vec3 hookPoint = hitResult.getLocation();
        if (!level.isClientSide()) {
            stack.set(GileModDataComponents.GRAPPLE_ACTIVE, true);
            player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
            activeHooks.put(player.getUUID(), new GrappleState(hookPoint, grappleId));
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.WIND_CHARGE_THROW, SoundSource.PLAYERS, 1.0F, 1.5F);
            if (player instanceof ServerPlayer serverPlayer) {
                EquipmentSlot equipmentSlot = hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND;
                stack.hurtAndBreak(1, serverPlayer, equipmentSlot);
            }
        } return InteractionResult.SUCCESS;
    }

    @Override
    public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
        if (!(entity instanceof ServerPlayer player)) {return;}
        GrappleState state = activeHooks.get(player.getUUID());
        if (state == null) {return;}
        UUID thisHookId = stack.get(GileModDataComponents.GRAPPLE_ID);
        if (!state.grappleId.equals(thisHookId)) {return;}
        if (player.isShiftKeyDown()) {
            if (cancelGrapple(player)) {
                playCancelSound(level, player);
            } return;
        }
        ItemStack heldHook = findHeldHook(player, state.grappleId);
        if (heldHook.isEmpty()) {cancelGrapple(player); return;}
        state.ticksActive++;
        if (state.ticksActive > MAX_GRAPPLE_TICKS) {cancelGrapple(player); return;}
        Vec3 currentPosition = player.position();
        if (currentPosition.distanceTo(state.target) <= ARRIVAL_DISTANCE) {cancelGrapple(player); return;}
        if (state.ticksActive > 5 && player.onGround()) {cancelGrapple(player); return;}
        spawnRopeParticle(level, player.getEyePosition(), state.target, state.ticksActive);
        Vec3 pullDirection = state.target.subtract(currentPosition);
        if (pullDirection.lengthSqr() < 0.000001) {cancelGrapple(player);return;}
        Vec3 velocity = pullDirection.normalize().scale(PULL_SPEED);
        player.setDeltaMovement(velocity.x, velocity.y + VERTICAL_PULL_BONUS, velocity.z);
        player.hurtMarked = true; player.fallDistance = 0.0F;
    }

    private UUID getOrCreateGrappleId(ItemStack stack) { UUID id = stack.get(GileModDataComponents.GRAPPLE_ID);
        if (id == null) {id = UUID.randomUUID(); stack.set(GileModDataComponents.GRAPPLE_ID, id);}return id;
    }

    private ItemStack findHeldHook(Player player, UUID grappleId) {
        ItemStack mainHand = player.getMainHandItem();
        UUID mainId = mainHand.get(GileModDataComponents.GRAPPLE_ID);
        if (grappleId.equals(mainId)) {return mainHand;}
        ItemStack offHand = player.getOffhandItem();
        UUID offId = offHand.get(GileModDataComponents.GRAPPLE_ID);
        if (grappleId.equals(offId)) {return offHand;}
        return ItemStack.EMPTY;
    }

    private int getRangeLevel(Level level, ItemStack stack) {
        Holder<Enchantment> rangeEnchantment = level.registryAccess()
                .lookupOrThrow(Registries.ENCHANTMENT)
                        .getOrThrow(GileModEnchantments.RANGE);
        return EnchantmentHelper.getItemEnchantmentLevel(rangeEnchantment, stack);
    }

    private boolean cancelGrapple(Player player) {
        GrappleState state = activeHooks.remove(player.getUUID());
        if (state == null) {return false;}
        ItemStack hook = findHeldHook(player, state.grappleId);
        if (!hook.isEmpty()) {hook.remove(GileModDataComponents.GRAPPLE_ACTIVE);}
        return true;
    }

    private void playCancelSound(Level level, Player player) {
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 0.8F, 1.2F);
    }

    private void spawnRopeParticle(ServerLevel level, Vec3 start, Vec3 end, int tick) {
        double distance = start.distanceTo(end);
        if (distance < 0.001) {return;}
        double particleSpeed = 0.35;
        double distanceAlongRope = (tick * particleSpeed) % distance;
        double progress = distanceAlongRope / distance;
        double x = start.x + (end.x - start.x) * progress;
        double y = start.y + (end.y - start.y) * progress;
        double z = start.z + (end.z - start.z) * progress;
        level.sendParticles(GileModParticleTypes.ROPE, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
    }

}