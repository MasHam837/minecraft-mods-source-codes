package mh837.gile.entity;

import mh837.gile.GileModItems;
import mh837.gile.GileModParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class GlitterEntity extends PathfinderMob {

    private int particleTimer;

    public GlitterEntity(
            EntityType<? extends GlitterEntity> type,
            Level level
    ) {
        super(type, level);

        this.moveControl = new FlyingMoveControl(
                this,
                20,
                true
        );

        this.setNoGravity(true);

        this.particleTimer = 0;
    }

    public static AttributeSupplier.Builder createGlitterAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 2.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.20D)
                .add(Attributes.FLYING_SPEED, 0.25D);
    }

    @Override
    protected void registerGoals() {
        /*
         * Simple butterfly-like random flying.
         */
        this.goalSelector.addGoal(
                1,
                new WaterAvoidingRandomFlyingGoal(
                        this,
                        1.0D
                )
        );
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new FlyingPathNavigation(
                this,
                level
        );
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);
        int dropCount = this.random.nextInt(2);
        if (dropCount > 0) {this.spawnAtLocation(level, new ItemStack(GileModItems.DUST, dropCount));
        }
    }

    @Override
    public void tick() {
        super.tick();

        /*
         * Particle spawning is client-side.
         */
        if (this.level().isClientSide()) {

            this.particleTimer++;

            /*
             * One glitter particle every 10 ticks.
             */
            if (this.particleTimer >= 10) {this.particleTimer = 0;
                this.level().addParticle(GileModParticleTypes.GLITTER, this.getX(), this.getY(), this.getZ(), 0.0D, 0.0D, 0.0D
                );
            }

            /*
             * Gentle floating/bobbing.
             */
            double bob =
                    Math.sin(this.tickCount * 0.15D)
                            * 0.0025D;

            this.setDeltaMovement(
                    this.getDeltaMovement().add(
                            0.0D,
                            bob,
                            0.0D
                    )
            );
        }
    }

    @Override
    protected void playStepSound(
            net.minecraft.core.BlockPos pos,
            net.minecraft.world.level.block.state.BlockState state
    ) {
        // Silent butterfly.
    }

    @Override
    public boolean isSilent() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, net.minecraft.world.level.block.state.BlockState state, net.minecraft.core.BlockPos pos) {}

    @Override
    public boolean causeFallDamage(double fallDistance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return 0;}

}