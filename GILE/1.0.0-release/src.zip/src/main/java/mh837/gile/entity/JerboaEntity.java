package mh837.gile.entity;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.List;

public class JerboaEntity extends Animal implements Leashable {

    private static final EntityDataAccessor<Boolean> HIDING = SynchedEntityData.defineId(JerboaEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DESERT_VARIANT = SynchedEntityData.defineId(JerboaEntity.class, EntityDataSerializers.BOOLEAN);

    public JerboaEntity(EntityType<? extends Animal> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        return 10.0F;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.5));
        this.goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Monster.class, 8.0F, 1.2, 1.5));
        new AvoidEntityGoal<>(this, Player.class, 8.0F, 1.1, 1.4, player -> !isHoldingDryFlower((Player) player));
        this.goalSelector.addGoal(4, new HideGoal(this));
        this.goalSelector.addGoal(5, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(6, new TemptGoal(this, 1.1, Ingredient.of(GileModBlocks.DRY_FLOWER.asItem()), false));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 6.0f));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    public static AttributeSupplier.Builder createJerboaAttributes() {
        return Animal.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.FOLLOW_RANGE, 16.0)
                .add(Attributes.TEMPT_RANGE, 10.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(HIDING, false);
        builder.define(DESERT_VARIANT, false); // Register the desert variant tracker
    }

    public boolean isHiding() {
        return this.entityData.get(HIDING);
    }

    public void setHiding(boolean hiding) {
        this.entityData.set(HIDING, hiding);
    }

    public boolean isDesertVariant() {
        return this.entityData.get(DESERT_VARIANT);
    }

    public void setDesertVariant(boolean variant) {
        this.entityData.set(DESERT_VARIANT, variant);
    }

    // Save and load the variant so it persists when chunks unload
    @Override
    public void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putBoolean("DesertVariant", this.isDesertVariant());
    }

    @Override
    public void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.setDesertVariant(input.getBooleanOr("DesertVariant", false));
    }

    // Check the biome when the Jerboa naturally spawns
    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, EntitySpawnReason spawnReason, @Nullable SpawnGroupData spawnData) {
        if (level.getBiome(this.blockPosition()).is(BiomeTags.IS_OVERWORLD)) {
            this.setDesertVariant(true);
        }
        return super.finalizeSpawn(level, difficulty, spawnReason, spawnData);
    }

    // Complete Invincibility while hiding
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float damage) {
        if (this.isHiding()) {
            return false;
        }
        return super.hurtServer(level, source, damage);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(GileModBlocks.DRY_FLOWER.asItem());
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide() || !this.isAlive()) {
            return;
        }

        boolean afraid = false;
        AABB searchBox = this.getBoundingBox().inflate(8.0);

        List<Entity> hostiles = this.level().getEntities(this, searchBox, entity -> entity instanceof Enemy);
        if (!hostiles.isEmpty()) {
            afraid = true;
        }

        boolean playersNearby = this.level().players().stream()
                .anyMatch(player -> player.distanceToSqr(this) < 100 && !isHoldingDryFlower(player));
        if (playersNearby) {
            afraid = true;
        }

        BlockState below = this.level().getBlockState(this.blockPosition().below());
        boolean canHide = below.is(GileModBlocks.MOON_SAND) || below.is(Blocks.SAND) || below.is(Blocks.RED_SAND);

        boolean shouldHide = afraid && canHide;

        // Run 2x faster if scared and cannot hide
        if (afraid && !canHide) {
            this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.64); // 2x normal speed
        } else {
            this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.32); // normal speed
        }

        if (shouldHide != this.isHiding()) {

            boolean wasHiding = this.isHiding();

            this.setHiding(shouldHide);
            this.level().broadcastEntityEvent(
                    this,
                    (byte) (shouldHide ? 10 : 11)
            );

            // Jerboa just emerged because a player is holding a dry flower.
            if (wasHiding && !shouldHide) {

                this.level().players().stream()
                        .filter(player -> player.distanceToSqr(this) < 100)
                        .filter(this::isHoldingDryFlower)
                        .forEach(player -> {
                            if (player instanceof ServerPlayer serverPlayer) {
                                GileModTriggers.MAKE_JERBOA_EMERGE.trigger(serverPlayer);
                            }
                        });
            }
        }

        if (this.isHiding()) {
            this.getNavigation().stop();
        }

    }

    private boolean isHoldingDryFlower(Player player) {
        return player.getMainHandItem().is(GileModBlocks.DRY_FLOWER.asItem()) || player.getOffhandItem().is(GileModBlocks.DRY_FLOWER.asItem());
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 10 || id == 11) {
            BlockState state = this.level().getBlockState(this.blockPosition().below());
            for (int i = 0; i < 12; ++i) {
                double offsetX = (this.random.nextDouble() - 0.5) * this.getBbWidth() * 1.5;
                double offsetZ = (this.random.nextDouble() - 0.5) * this.getBbWidth() * 1.5;
                this.level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, state),
                        this.getX() + offsetX, this.getY() + 0.1, this.getZ() + offsetZ, 0.0, 0.15, 0.0);
            }
        } else {
            super.handleEntityEvent(id);
        }
    }

    @Override
    public void travel(Vec3 movementInput) {
        if (this.isHiding()) {
            super.travel(Vec3.ZERO);
        } else {
            super.travel(movementInput);
        }
    }

    @Override
    public boolean isPushable() {
        return !this.isHiding();
    }

    @Override
    public void doPush(Entity entity) {
        if (!this.isHiding()) {
            super.doPush(entity);
        }
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);

        int looting = 0;
        if (damageSource.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEnchant = registry.get(Enchantments.LOOTING);
            if (lootingEnchant.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(
                        lootingEnchant.get(),
                        attacker.getMainHandItem()
                );
            }
        }

        float[] chances = {0.25f, 0.33f, 0.40f, 0.50f};
        int index = Math.min(looting, chances.length - 1);
        if (this.random.nextFloat() < chances[index]) {
            this.spawnAtLocation(level, new ItemStack(GileModItems.JERBOAS_TAIL, 1));
        }

        int hideCount = this.random.nextInt(2 + looting);
        if (hideCount > 0) {
            this.spawnAtLocation(level, new ItemStack(Items.RABBIT_HIDE, hideCount));
        }
    }

    @Override
    public boolean requiresCustomPersistence() {
        return super.requiresCustomPersistence();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        // Frees up the 10-mob CREATURE cap dynamically!
        return !this.hasCustomName() && !this.isLeashed();
    }

    @Override
    public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason spawnReason) {
        // Bypasses vanilla light-level and grass-block requirements.
        // It will now rely entirely on the SpawnPlacements we set up earlier!
        return true;
    }

    @Nullable
    @Override
    public JerboaEntity getBreedOffspring(ServerLevel level, AgeableMob entity) {
        JerboaEntity baby = GileModEntities.JERBOA.create(level, EntitySpawnReason.BREEDING);
        if (baby != null && entity instanceof JerboaEntity parent) {
            // Baby inherits variant from parents
            baby.setDesertVariant(this.random.nextBoolean() ? this.isDesertVariant() : parent.isDesertVariant());
        }
        return baby;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return this.isHiding() ? null : SoundEvents.RABBIT_AMBIENT;
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RABBIT_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RABBIT_DEATH;
    }

    static class HideGoal extends Goal {
        private final JerboaEntity jerboa;

        public HideGoal(JerboaEntity jerboa) {
            this.jerboa = jerboa;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return this.jerboa.isHiding();
        }

        @Override
        public void start() {
            this.jerboa.getNavigation().stop();
        }

        @Override
        public void tick() {
            this.jerboa.getNavigation().stop();
        }
    }

    private static boolean isLookingAt(Player player, Entity target) {
        Vec3 eye = player.getEyePosition();
        Vec3 direction = player.getViewVector(1.0F).normalize();

        Vec3 toTarget = target.getBoundingBox()
                .getCenter()
                .subtract(eye)
                .normalize();

        return direction.dot(toTarget) > 0.95;
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return this.random.nextInt(3) + 1;}

}