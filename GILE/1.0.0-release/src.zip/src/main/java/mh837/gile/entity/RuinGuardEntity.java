package mh837.gile.entity;

import mh837.gile.GileModItems;
import mh837.gile.GileModParticleTypes;
import mh837.gile.GileModSounds;
import mh837.gile.advancement.GileModTriggers;
import mh837.gile.entity.projectile.RocketEntity;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class RuinGuardEntity extends PathfinderMob {
    private static final byte MELEE = 1, RANGE = 2, ROTATION = 3;
    private static final int MELEE_LEN = 160, RANGE_LEN = 120, ROTATION_LEN = 80;

    private int attackTicks;
    private byte attackType;
    private int walkSoundTick = 0;
    private boolean wasOnGround = true;

    public final AnimationState walkAnimationState = new AnimationState();
    public final AnimationState attackMeleeAnimationState = new AnimationState();
    public final AnimationState attackRangeAnimationState = new AnimationState();
    public final AnimationState attackRotationAnimationState = new AnimationState();

    // Sound constants
    private static final SoundEvent WALK_SOUND = SoundEvents.IRON_GOLEM_STEP;
    private static final SoundEvent MELEE_HIT_SOUND = GileModSounds.RUIN_GUARD_HIT;
    private static final SoundEvent MELEE_SWING_SOUND = SoundEvents.PLAYER_ATTACK_CRIT;
    private static final SoundEvent RANGE_SHOOT_SOUND = SoundEvents.FIREWORK_ROCKET_LAUNCH;
    private static final SoundEvent ROTATION_SOUND = GileModSounds.RUIN_GUARD_ROTATION;
    private static final SoundEvent ROTATION_GEAR_SOUND = SoundEvents.IRON_STEP;
    private static final SoundEvent JUMP_SOUND = SoundEvents.BREEZE_JUMP;
    private static final SoundEvent LAND_SOUND = SoundEvents.BREEZE_LAND;
    private static final Holder.Reference<SoundEvent> DEATH_EXPLOSION_SOUND = SoundEvents.GENERIC_EXPLODE;
    private static final SoundEvent DEATH_METAL_SOUND = SoundEvents.ANVIL_BREAK;
    private static final SoundEvent HURT_METAL_SOUND = SoundEvents.IRON_GOLEM_HURT;

    public RuinGuardEntity(EntityType<? extends PathfinderMob> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createGuardAttributes() {
        return createMobAttributes()
                .add(Attributes.MAX_HEALTH, 400)
                .add(Attributes.ATTACK_DAMAGE, 15)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1)
                .add(Attributes.ARMOR, 10)
                .add(Attributes.ARMOR_TOUGHNESS, 4)
                .add(Attributes.SCALE, 0.75);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false; // Never despawns due to distance
    }

    @Override
    public void tick() {
        super.tick();

        if (level().isClientSide()) {
            boolean attacking = attackMeleeAnimationState.isStarted() || attackRangeAnimationState.isStarted() || attackRotationAnimationState.isStarted();
            walkAnimationState.animateWhen(!attacking && getTarget() == null, tickCount);
            return;
        }

        // Check if target is dead or null, cancel attack if so
        LivingEntity target = getTarget();
        if (attackTicks > 0 && (target == null || !target.isAlive())) {
            // Cancel the current attack
            attackTicks = 0;
            attackType = 0;
            level().broadcastEntityEvent(this, (byte) 67); // Stop animation
            getNavigation().stop(); // Stop moving
            return;
        }

        // Walking sounds
        if (walkAnimationState.isStarted() && !isInWater() && onGround()) {
            if (++walkSoundTick >= 25) { // Play every ~1.25 seconds
                walkSoundTick = 0;
                playSound(WALK_SOUND, 0.6F, 0.7F + random.nextFloat() * 0.3F);

                // Optional: play mechanical whirring sound occasionally
                if (random.nextFloat() < 0.15F) {
                    playSound(SoundEvents.BELL_BLOCK, 0.3F, 0.8F + random.nextFloat() * 0.4F);
                }
            }
        } else {
            walkSoundTick = 0;
        }

        // Landing sound
        if (!wasOnGround && onGround()) {
            playSound(LAND_SOUND, 1.2F, 0.8F + random.nextFloat() * 0.2F);
            playSound(DEATH_METAL_SOUND, 0.8F, 0.6F + random.nextFloat() * 0.3F);
        }
        wasOnGround = onGround();

        if (attackTicks <= 0) return;
        int t = attackTicks--;

        switch (attackType) {
            case MELEE -> {
                if (t == 85) { // Halfway through animation
                    playSound(MELEE_SWING_SOUND, 1.0F, 0.5F + random.nextFloat() * 0.3F);
                }
                if (t == 55 || t == 75 || t == 90 || t == 100 || t == 130) {
                    meleeHit();
                    playSound(MELEE_HIT_SOUND, 1.5F, 0.6F + random.nextFloat() * 0.4F);
                    // Mechanical impact variation
                    if (random.nextFloat() < 0.3F) {
                        playSound(DEATH_METAL_SOUND, 0.5F, 0.7F + random.nextFloat() * 0.6F);
                    }
                }
                if (t == 55 || t == 75 || t == 90 || t == 100 || t == 130) spawnHitParticles(GileModParticleTypes.GUARD_SWEEP);
                if (t == 80) {
                    leap();
                    playSound(JUMP_SOUND, 1.0F, 0.7F + random.nextFloat() * 0.4F);
                    playSound(DEATH_METAL_SOUND, 0.6F, 0.5F + random.nextFloat() * 0.3F);
                }
            }
            case RANGE -> {
                if (t == 30) {
                    fireSixRockets();
                    playSound(RANGE_SHOOT_SOUND, 2.0F, 0.8F + random.nextFloat() * 0.4F);
                    // Additional mechanical charging sound
                    playSound(SoundEvents.COPPER_BULB_TURN_OFF, 1.0F, 0.5F + random.nextFloat() * 0.3F);
                    // Play whoop sound variations for each rocket
                    for (int i = 0; i < 3; i++) {
                        if (random.nextFloat() < 0.4F) {
                            playSound(RANGE_SHOOT_SOUND, 0.8F, 1.2F + random.nextFloat() * 0.3F);
                        }
                    }
                }
            }
            case ROTATION -> {
                // Continuous gear sounds during rotation
                if (t % 5 == 0) {
                    playSound(ROTATION_GEAR_SOUND, 0.4F + random.nextFloat() * 0.3F, 0.6F + random.nextFloat() * 0.6F);
                }
                if (t == 50) { // Mid-rotation
                    playSound(ROTATION_SOUND, 1.5F, 0.5F + random.nextFloat() * 0.4F);
                    playSound(ROTATION_GEAR_SOUND, 1.0F, 0.3F + random.nextFloat() * 0.5F);
                }
                if (t == 10 || t == 30 || t == 50 || t == 70) {
                    rotationHit();
                    playSound(MELEE_HIT_SOUND, 1.2F, 0.8F + random.nextFloat() * 0.4F);
                    playSound(ROTATION_GEAR_SOUND, 0.8F, 0.2F + random.nextFloat() * 0.3F);
                }
                if (t == 10 || t == 30 || t == 50 || t == 70) spawnHitParticles(GileModParticleTypes.GUARD_SWEEP);
            }
        }

        if (attackTicks == 0) {
            attackType = 0;
            level().broadcastEntityEvent(this, (byte) 67);
            // Play cooldown sound
            playSound(ROTATION_GEAR_SOUND, 0.3F, 1.5F + random.nextFloat() * 0.3F);
        }
    }

    private boolean startAttack(byte type, int duration) {
        if (attackTicks > 0) return false;
        attackType = type;
        attackTicks = duration;
        level().broadcastEntityEvent(this, (byte) (63 + type));

        // Play attack startup sounds
        switch (type) {
            case MELEE -> playSound(SoundEvents.PISTON_EXTEND, 0.8F, 0.6F + random.nextFloat() * 0.4F);
            case RANGE -> playSound(SoundEvents.RESPAWN_ANCHOR_CHARGE, 1.0F, 0.5F + random.nextFloat() * 0.3F);
            case ROTATION -> {
                playSound(ROTATION_SOUND, 1.2F, 0.3F + random.nextFloat() * 0.3F);
                playSound(ROTATION_GEAR_SOUND, 0.6F, 0.1F + random.nextFloat() * 0.2F);
            }
        }
        return true;
    }

    @Override
    public void handleEntityEvent(byte id) {
        super.handleEntityEvent(id);
        switch (id) {
            case 64 -> attackMeleeAnimationState.start(tickCount);
            case 65 -> attackRangeAnimationState.start(tickCount);
            case 66 -> attackRotationAnimationState.start(tickCount);
            case 67 -> {
                attackMeleeAnimationState.stop();
                attackRangeAnimationState.stop();
                attackRotationAnimationState.stop();
            }
        }
    }

    private void spawnHitParticles(ParticleOptions particle) {
        if (!(level() instanceof ServerLevel sl)) return;
        Vec3 c = position().add(0, getBbHeight() * 0.5D, 0);
        sl.sendParticles(particle, c.x, c.y, c.z, 12, 1.0D, 0.4D, 1.0D, 0.05D);
    }

    private void faceTarget(LivingEntity target) {
        double dx = target.getX() - getX(), dz = target.getZ() - getZ();
        if (dx * dx + dz * dz < 0.0001) return;
        setYRot((float) (Math.atan2(dz, dx) * 180 / Math.PI) - 90);
        yBodyRot = yHeadRot = getYRot();
    }

    private void meleeHit() {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        faceTarget(target);

        Vec3 center = position().add(0, getBbHeight() * 0.45D, 0).add(getLookAngle().scale(2.0D));
        AABB box = new AABB(center, center).inflate(2.0D, 1.5D, 2.0D);

        for (LivingEntity victim : level().getEntitiesOfClass(LivingEntity.class, box, e -> e != this && e.isAlive())) {
            Vec3 to = victim.position().add(0, victim.getBbHeight() * 0.5D, 0).subtract(position());
            if (to.horizontalDistanceSqr() > 25.0D || getLookAngle().dot(to.normalize()) < 0.25D) continue;

            victim.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE));
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.CRIT, victim.getX(), victim.getY() + victim.getBbHeight() * 0.5D, victim.getZ(), 15, .4D, .4D, .4D, .1D);
            }
        }
    }

    private void leap() {
        LivingEntity target = getTarget();
        if (target == null) return;
        Vec3 d = new Vec3(target.getX() - getX(), 0, target.getZ() - getZ());
        if (d.lengthSqr() < 0.001D) return;

        d = d.normalize();
        lookAt(target, 360.0F, 360.0F);
        setDeltaMovement(d.x * 0.65D, 0.65D, d.z * 0.65D);
    }

    private void fireSixRockets() {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        Vec3 targetPos = target.position().add(0, target.getBbHeight() * 0.5D, 0);

        double[][] spots = {
                {-1.35D, 3.2D, -1.65D}, {-1.35D, 4.0D, -1.65D}, {-1.35D, 4.8D, -1.65D},
                { 1.35D, 3.2D, -1.65D}, { 1.35D, 4.0D, -1.65D}, { 1.35D, 4.8D, -1.65D}
        };

        float yaw = getYRot() * Mth.DEG_TO_RAD;
        double cos = Math.cos(yaw), sin = Math.sin(yaw);

        for (double[] s : spots) {
            Vec3 pos = new Vec3(getX() + s[0] * cos - s[2] * sin, getY() + s[1], getZ() + s[0] * sin + s[2] * cos);
            RocketEntity rocket = new RocketEntity(level(), this);
            rocket.setPos(pos);
            rocket.setDeltaMovement(targetPos.subtract(pos).normalize().scale(1.5D));
            level().addFreshEntity(rocket);
        }
    }

    private void rotationHit() {
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;

        for (LivingEntity victim : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(4.5, 1.5, 4.5), e -> e != this && e.isAlive())) {
            victim.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.67F);
            Vec3 knock = victim.position().subtract(position()).normalize().scale(0.8D);
            victim.push(knock.x, 0.35D, knock.z);

            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(GileModParticleTypes.GUARD_SWEEP, victim.getX(), victim.getY() + 1, victim.getZ(), 1, 0, 0, 0, 0);
            }
        }
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new RuinGuardAttackGoal());
        goalSelector.addGoal(2, new RuinGuardWanderGoal());
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, true));
    }

    private class RuinGuardWanderGoal extends Goal {
        private int cooldown;

        @Override public boolean canUse() { return getTarget() == null && attackTicks <= 0; }
        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public void start() { chooseDestination(); }

        @Override
        public void tick() {
            if (--cooldown <= 0 || getNavigation().isDone()) chooseDestination();
        }

        private void chooseDestination() {
            double angle = random.nextDouble() * Math.PI * 2, distance = 5.0D + random.nextDouble() * 7.0D;
            getNavigation().moveTo(getX() + Math.cos(angle) * distance, getY(), getZ() + Math.sin(angle) * distance, 0.35D);
            cooldown = 20 + random.nextInt(20);
        }

        @Override public void stop() { getNavigation().stop(); }
    }

    private class RuinGuardAttackGoal extends Goal {
        @Override
        public boolean canUse() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive(); // Check target is still alive
        }

        @Override
        public void tick() {
            LivingEntity t = getTarget();
            if (t == null || !t.isAlive()) {
                // Target is dead, stop everything
                if (attackTicks > 0) {
                    attackTicks = 0;
                    attackType = 0;
                    level().broadcastEntityEvent(RuinGuardEntity.this, (byte) 67);
                }
                getNavigation().stop();
                return;
            }

            getLookControl().setLookAt(t);

            if (attackType == ROTATION) { getNavigation().moveTo(t, 0.8D); return; }
            if (attackTicks > 0) { getNavigation().stop(); return; }

            double d = distanceToSqr(t);
            if (d <= 25.0D) { startAttack(MELEE, MELEE_LEN); return; }
            if (d <= 100.0D) {
                boolean rot = random.nextInt(4) == 0;
                startAttack(rot ? ROTATION : RANGE, rot ? ROTATION_LEN : RANGE_LEN);
                return;
            }
            getNavigation().moveTo(t, 0.8D);
        }

        @Override
        public void stop() {
            getNavigation().stop();
            // Also cancel attack if goal stops
            if (attackTicks > 0) {
                attackTicks = 0;
                attackType = 0;
                level().broadcastEntityEvent(RuinGuardEntity.this, (byte) 67);
            }
        }
    }

    private void triggerDefeatAdvancement(
            ServerLevel level,
            DamageSource source
    ) {
        Entity attacker = source.getEntity();

        if (attacker instanceof ServerPlayer serverPlayer) {
            GileModTriggers.DEFEAT_RUIN_GUARD.trigger(serverPlayer);
            return;
        }

        if (attacker instanceof Wolf wolf
                && wolf.getOwner() instanceof ServerPlayer serverPlayer) {
            GileModTriggers.DEFEAT_RUIN_GUARD.trigger(serverPlayer);
        }

        if (attacker instanceof SalonMemberEntity salonMember
                && salonMember.getOwner() instanceof ServerPlayer serverPlayer) {
            GileModTriggers.DEFEAT_RUIN_GUARD.trigger(serverPlayer);
        }

    }

    @Override
    public void die(DamageSource source) {
        if (!level().isClientSide() && level() instanceof ServerLevel sl) {

            triggerDefeatAdvancement(sl, source);

            Vec3 c = position().add(0, getBbHeight() * 0.5D, 0);

            // Death explosion
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 3, .8D, .8D, .8D, 0);
            sl.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 25, 1.8D, 1.5D, 1.8D, .15D);
            sl.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, c.x, c.y, c.z, 35, 1.2D, 1.0D, 1.2D, .08D);
            sl.sendParticles(ParticleTypes.CRIT, c.x, c.y, c.z, 60, 1.5D, 1.2D, 1.5D, .35D);

            // Death sounds - explosion + metal falling
            sl.playSound(null, getX(), getY(), getZ(), DEATH_EXPLOSION_SOUND, SoundSource.HOSTILE, 2.5F, 0.65F);
            sl.playSound(null, getX(), getY(), getZ(), DEATH_METAL_SOUND, SoundSource.HOSTILE, 2.0F, 1.2F + random.nextFloat() * 0.4F);

            // Additional metal falling sounds
            for (int i = 0; i < 3; i++) {
                sl.playSound(null,
                        getX() + (random.nextDouble() - 0.5) * 3,
                        getY() + random.nextDouble() * 2,
                        getZ() + (random.nextDouble() - 0.5) * 3,
                        DEATH_METAL_SOUND,
                        SoundSource.HOSTILE,
                        0.8F + random.nextFloat() * 0.6F,
                        0.4F + random.nextFloat() * 0.6F
                );
            }
        }
        super.die(source);
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        boolean result = super.hurtServer(level, source, amount);
        if (result) {
            // Play metal impact sound when damaged
            playSound(HURT_METAL_SOUND, 1.2F, 0.6F + random.nextFloat() * 0.6F);
        }
        return result;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {

        super.dropCustomDeathLoot(level, source, recentlyHit);
        int looting = 0;

        if (source.getEntity() instanceof LivingEntity attacker) {
            var entry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(Enchantments.LOOTING);
            if (entry.isPresent()) looting = EnchantmentHelper.getItemEnchantmentLevel(entry.get(), attacker.getMainHandItem());
        }

        int extra = (looting * 10) / 3, min = 10 + extra, max = 20 + extra;
        int count = min + random.nextInt(max - min + 1);

        if (count > 0) spawnAtLocation(level, new ItemStack(GileModItems.PRIMOGEM, count));
        spawnAtLocation(level, new ItemStack(GileModItems.COGWORK_CORE, 1));
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return 20;}

}