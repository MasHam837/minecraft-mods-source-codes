package mh837.gile.entity;

import mh837.gile.GileModItems;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.LookControl;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

public class VoidSlimeEntity extends Monster {
    private static final EntityDataAccessor<Integer> SLIME_SIZE = SynchedEntityData.defineId(VoidSlimeEntity.class, EntityDataSerializers.INT);
    public float targetStretch;
    public float stretch;
    public float lastStretch;
    public float oSquish;
    public float squish;
    private boolean onGroundLastTick;

    public VoidSlimeEntity(EntityType<? extends Monster> entityType, Level level) {
        super(entityType, level);
        this.onGroundLastTick = false;
        this.moveControl = new MoveControl(this);
        this.lookControl = new LookControl(this);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new VoidSlimeAttackGoal(this));
        this.goalSelector.addGoal(3, new VoidSlimeFaceTargetGoal(this));
        this.goalSelector.addGoal(4, new VoidSlimeRandomLookGoal(this));
        this.goalSelector.addGoal(5, new VoidSlimeMoveGoal(this));

        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public static AttributeSupplier.Builder createVoidSlimeAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 4.0)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.GRAVITY, 0.04);
    }

    @Override
    public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason spawnReason) {
        // Allows them to spawn naturally bypassing swamp/slime-chunk restrictions
        return true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SLIME_SIZE, 1);
    }

    public void setSize(int size, boolean heal) {
        this.entityData.set(SLIME_SIZE, size);
        this.reapplyPosition();
        this.refreshDimensions();
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(10.0);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.3 + 0.1 * size);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(4.0);
        if (heal) {
            this.setHealth(this.getMaxHealth());
        }
    }

    public int getSize() {
        return this.entityData.get(SLIME_SIZE);
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("Size", this.getSize() - 1);
        output.putBoolean("wasOnGround", this.onGroundLastTick);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        this.setSize(input.getIntOr("Size", 0) + 1, false);
        super.readAdditionalSaveData(input);
        this.onGroundLastTick = input.getBooleanOr("wasOnGround", false);
    }

    @Override
    public void tick() {
        if (this.getTarget() != null) {
            this.lookAtEntity(this.getTarget(), 30.0F, 30.0F);
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.getYRot();
        }

        this.stretch += (this.targetStretch - this.stretch) * 0.5F;
        this.lastStretch = this.stretch;
        super.tick();

        if (this.onGround() && !this.onGroundLastTick) {
            this.targetStretch = -0.5F;
            if (this.level().isClientSide()) {
                for (int i = 0; i < 8; i++) {
                    this.level().addParticle(
                            new DustParticleOptions(0x38295C, 1.0F),
                            this.getX() + (this.random.nextDouble() - 0.5) * 0.8,
                            this.getY() + 0.1,
                            this.getZ() + (this.random.nextDouble() - 0.5) * 0.8,
                            (this.random.nextDouble() - 0.5) * 0.1,
                            0.05,
                            (this.random.nextDouble() - 0.5) * 0.1);
                }
            }
        } else if (!this.onGround() && this.onGroundLastTick) {
            this.targetStretch = 1.0F;
        }

        this.onGroundLastTick = this.onGround();
        if (this.onGround()) {
            this.targetStretch *= 0.6F;
        }

        if (this.level().isClientSide() && this.onGround() && this.random.nextInt(2) == 0) {
            for (int i = 0; i < 3; i++) {
                this.level().addParticle(
                        new DustParticleOptions(0x38295C, 1.0F),
                        this.getRandomX(0.5),
                        this.getRandomY(),
                        this.getRandomZ(0.5),
                        (this.random.nextDouble() - 0.5) * 0.02,
                        0.01,
                        (this.random.nextDouble() - 0.5) * 0.02);
            }
        }
    }

    @Override
    public void playerTouch(Player player) {
        double distance = this.distanceToSqr(player);
        double hitboxRange = 1.5;

        if (distance <= hitboxRange * hitboxRange && this.isAlive() && !player.isCreative() && player.isAlive()) {
            player.hurt(this.damageSources().mobAttack(this),
                    (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE));
            this.pushPlayerAway(player);
        }
    }

    private void pushPlayerAway(Player player) {
        double dX = player.getX() - this.getX();
        double dZ = player.getZ() - this.getZ();
        double distance = Math.max(Math.sqrt(dX * dX + dZ * dZ), 0.001);
        double pushStrength = 0.5;

        player.setDeltaMovement(player.getDeltaMovement().add(dX / distance * pushStrength, 0.15, dZ / distance * pushStrength));
    }

    public void lookAtEntity(Entity targetEntity, float maxYawChange, float maxPitchChange) {
        double dX = targetEntity.getX() - this.getX();
        double dZ = targetEntity.getZ() - this.getZ();
        double dY;

        if (targetEntity instanceof LivingEntity livingEntity) {
            dY = livingEntity.getEyeY() - this.getEyeY();
        } else {
            dY = (targetEntity.getBoundingBox().minY + targetEntity.getBoundingBox().maxY) / 2.0 - this.getEyeY();
        }

        double distance = Math.sqrt(dX * dX + dZ * dZ);
        float targetYaw = (float)(Math.atan2(dZ, dX) * 57.2957763671875) - 90.0F;
        float targetPitch = (float)(-(Math.atan2(dY, distance) * 57.2957763671875));

        this.setXRot(this.changeAngle(this.getXRot(), targetPitch, maxPitchChange));
        this.setYRot(this.changeAngle(this.getYRot(), targetYaw, maxYawChange));
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SLIME_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.4F;
    }

    @Override
    public float getVoicePitch() {
        return 1.0F;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);

        int looting = 0;
        if (damageSource.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEntry = registry.get(Enchantments.LOOTING);
            if (lootingEntry.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(lootingEntry.get(), attacker.getMainHandItem());
            }
        }

        // nextInt(2 + looting) returns a number between 0 and (1 + looting) inclusive
        int dropCount = this.random.nextInt(2 + looting);

        if (dropCount > 0) {
            this.spawnAtLocation(level, new ItemStack(GileModItems.VOID_SLIMEBALL, dropCount));
        }
    }

    @Override
    public boolean requiresCustomPersistence() {
        return super.requiresCustomPersistence();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return !this.hasCustomName();
    }

    static class VoidSlimeMoveGoal extends Goal {
        private final VoidSlimeEntity slime;

        public VoidSlimeMoveGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return this.slime.getTarget() != null && this.slime.onGround();
        }

        @Override
        public void tick() {
            LivingEntity target = this.slime.getTarget();
            if (target != null) {
                this.slime.lookAtEntity(target, 30.0F, 30.0F);
                this.slime.yBodyRot = this.slime.getYRot();
                this.slime.yHeadRot = this.slime.getYRot();
            }
        }
    }

    static class VoidSlimeFaceTargetGoal extends Goal {
        private final VoidSlimeEntity slime;

        public VoidSlimeFaceTargetGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setFlags(EnumSet.of(Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return this.slime.getTarget() != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.slime.getTarget() != null && this.slime.getTarget().isAlive();
        }

        @Override
        public void tick() {
            LivingEntity target = this.slime.getTarget();
            if (target != null) {
                this.slime.lookAtEntity(target, 30.0F, 30.0F);
                this.slime.yBodyRot = this.slime.getYRot();
                this.slime.yHeadRot = this.slime.getYRot();
            }
        }
    }

    static class VoidSlimeAttackGoal extends Goal {
        private final VoidSlimeEntity slime;
        private int timer;

        public VoidSlimeAttackGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
            this.timer = this.slime.getRandom().nextInt(20);
        }

        @Override
        public boolean canUse() {
            return this.slime.getTarget() != null;
        }

        @Override
        public void tick() {
            LivingEntity target = this.slime.getTarget();
            if (target != null && this.slime.onGround()) {
                if (--this.timer <= 0) {
                    this.timer = 15 + this.slime.getRandom().nextInt(15);

                    if (this.slime.level().isClientSide()) {
                        for (int i = 0; i < 5; i++) {
                            this.slime.level().addParticle(
                                    new DustParticleOptions(0x38295C, 1.0F),
                                    this.slime.getX() + (this.slime.random.nextDouble() - 0.5) * 0.5,
                                    this.slime.getY() + 0.1,
                                    this.slime.getZ() + (this.slime.random.nextDouble() - 0.5) * 0.5,
                                    (this.slime.random.nextDouble() - 0.5) * 0.2,
                                    0.1,
                                    (this.slime.random.nextDouble() - 0.5) * 0.2);
                        }
                    }

                    double dX = target.getX() - this.slime.getX();
                    double dZ = target.getZ() - this.slime.getZ();
                    double distance = Math.sqrt(dX * dX + dZ * dZ);

                    if (distance > 0.01) {
                        Vec3 velocity = this.slime.getDeltaMovement();
                        double jumpStrength = Math.min(distance, 0.8) * 0.5;
                        this.slime.setDeltaMovement(
                                velocity.x + (dX / distance) * jumpStrength,
                                0.4,
                                velocity.z + (dZ / distance) * jumpStrength);
                        this.slime.markHurt();
                    }

                    this.slime.lookAtEntity(target, 30.0F, 30.0F);
                    this.slime.yBodyRot = this.slime.getYRot();
                    this.slime.yHeadRot = this.slime.getYRot();
                }
            }
        }
    }

    static class VoidSlimeRandomLookGoal extends Goal {
        private final VoidSlimeEntity slime;
        private float targetYaw;
        private int timer;
        private int jumpTimer;

        public VoidSlimeRandomLookGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setFlags(EnumSet.of(Goal.Flag.LOOK, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return this.slime.getTarget() == null && this.slime.onGround();
        }

        @Override
        public boolean canContinueToUse() {
            return this.slime.getTarget() == null;
        }

        @Override
        public void start() {
            this.timer = this.slime.getRandom().nextInt(40);
            this.jumpTimer = 20 + this.slime.getRandom().nextInt(60);
            if (this.slime.getRandom().nextInt(3) == 0) {
                this.targetYaw = this.slime.getYRot() + (this.slime.getRandom().nextFloat() - 0.5F) * 180.0F;
            }
        }

        @Override
        public void tick() {
            if (--this.timer <= 0) {
                this.timer = 30 + this.slime.getRandom().nextInt(70);
                this.targetYaw = this.slime.getRandom().nextFloat() * 360.0F;
            }

            this.slime.setYRot(this.slime.changeAngle(this.slime.getYRot(), this.targetYaw, 10.0F));
            this.slime.yBodyRot = this.slime.getYRot();
            this.slime.yHeadRot = this.slime.getYRot();

            if (--this.jumpTimer <= 0 && this.slime.onGround()) {
                this.jumpTimer = 40 + this.slime.getRandom().nextInt(120);
                float yaw = this.slime.getYRot() * ((float)Math.PI / 180F);
                double jumpStrength = 0.2 + this.slime.getRandom().nextDouble() * 0.2;
                double dX = -Math.sin(yaw) * jumpStrength;
                double dZ = Math.cos(yaw) * jumpStrength;
                this.slime.setDeltaMovement(dX, 0.2 + this.slime.getRandom().nextDouble() * 0.2, dZ);
                this.slime.markHurt();
            }
        }
    }

    public float changeAngle(float from, float to, float max) {
        float f = Mth.wrapDegrees(to - from);
        if (f > max) {
            f = max;
        }
        if (f < -max) {
            f = -max;
        }
        return from + f;
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {
        return 2;
    }

}