package mh837.gile.item.weapon.primordial;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.gamerules.GameRules;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class PhanesTimeUtility {

    private PhanesTimeUtility() {}

    private static final int ACCELERATED_RANDOM_TICK_SPEED = 100;
    private static final int DEFAULT_RANDOM_TICK_SPEED = 3;
    private static final int COOLDOWN = 120;
    private static final Map<UUID, Long> COOLDOWNS =
            new HashMap<>();

    public static boolean activate(
            ServerLevel level,
            ServerPlayer player,
            ItemStack stack
    ) {

        long now = level.getGameTime();
        long cooldownEnd =
                COOLDOWNS.getOrDefault(
                        player.getUUID(),
                        0L
                );

        if (now < cooldownEnd) {

            long remainingTicks =
                    cooldownEnd - now;

            long remainingSeconds =
                    Math.max(
                            1L,
                            (remainingTicks + 19L) / 20L
                    );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.phanes_utility_cooldown",
                            remainingSeconds
                    ),
                    true
            );

            return false;
        }

        int currentRandomTickSpeed =
                level.getGameRules().get(
                        GameRules.RANDOM_TICK_SPEED
                );

        if (currentRandomTickSpeed ==
                ACCELERATED_RANDOM_TICK_SPEED) {

            setRandomTickSpeed(
                    level,
                    DEFAULT_RANDOM_TICK_SPEED
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.phanes_utility_deactivated"
                    )
            );

            spawnResetEffect(
                    level,
                    player
            );

        } else {

            setRandomTickSpeed(
                    level,
                    ACCELERATED_RANDOM_TICK_SPEED
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.phanes_utility_activated"
                    )
            );

            spawnAccelerationEffect(
                    level,
                    player
            );
        }

        COOLDOWNS.put(
                player.getUUID(),
                now + COOLDOWN
        );

        player.getCooldowns().addCooldown(
                stack,
                COOLDOWN
        );

        return true;
    }

    private static void setRandomTickSpeed(
            ServerLevel level,
            int speed
    ) {

        level.getGameRules().set(
                GameRules.RANDOM_TICK_SPEED,
                speed,
                level.getServer()
        );
    }

    private static void spawnAccelerationEffect(
            ServerLevel level,
            ServerPlayer player
    ) {

        double x = player.getX();
        double y = player.getY() + 1.0D;
        double z = player.getZ();

        level.sendParticles(
                ParticleTypes.END_ROD,
                x,
                y,
                z,
                35,
                1.5D,
                1.0D,
                1.5D,
                0.04D
        );

        level.sendParticles(
                ParticleTypes.ENCHANT,
                x,
                y,
                z,
                30,
                1.2D,
                0.8D,
                1.2D,
                0.25D
        );

        level.sendParticles(
                ParticleTypes.GLOW,
                x,
                y,
                z,
                15,
                0.6D,
                0.8D,
                0.6D,
                0.02D
        );

        level.playSound(
                null,
                x,
                y,
                z,
                SoundEvents.BEACON_POWER_SELECT,
                SoundSource.PLAYERS,
                1.0F,
                1.65F
        );
    }

    private static void spawnResetEffect(
            ServerLevel level,
            ServerPlayer player
    ) {

        double x = player.getX();
        double y = player.getY() + 1.0D;
        double z = player.getZ();

        level.sendParticles(
                ParticleTypes.END_ROD,
                x,
                y,
                z,
                25,
                1.3D,
                0.8D,
                1.3D,
                0.025D
        );

        level.sendParticles(
                ParticleTypes.GLOW,
                x,
                y,
                z,
                12,
                0.5D,
                0.7D,
                0.5D,
                0.015D
        );

        level.playSound(
                null,
                x,
                y,
                z,
                SoundEvents.BEACON_DEACTIVATE,
                SoundSource.PLAYERS,
                0.9F,
                1.35F
        );
    }
}