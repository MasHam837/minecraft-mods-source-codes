package mh837.gile.worldgen.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;

public class StarFeature extends Feature<SimpleBlockConfiguration> {
    public StarFeature(Codec<SimpleBlockConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<SimpleBlockConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        RandomSource random = context.random();
        SimpleBlockConfiguration config = context.config();

        int heightOffset = random.nextInt(6) + 20;
        BlockPos targetPos = origin.above(heightOffset);

        if (level.isEmptyBlock(targetPos)) {
            level.setBlock(targetPos, config.toPlace().getState(level, random, targetPos), 3);
            return true;
        }

        return false;
    }
}