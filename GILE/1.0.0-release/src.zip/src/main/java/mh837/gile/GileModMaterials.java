package mh837.gile;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;

import java.util.Map;

public class GileModMaterials {

    // === UNBREAKABLE HELPER ===
    private static final TagKey<net.minecraft.world.item.Item> NO_WEAPON_REPAIR = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "no_weapon_repair"));

    // Enderite Tools
    public static final ToolMaterial ENDERITE_TOOLS = new ToolMaterial(GileModTags.Blocks.INCORRECT_FOR_ENDERITE_TOOL,
            2640, 13.0F, 5.0F, 18, GileModTags.Items.ENDERITE_TOOL_MATERIALS);

    // Enderite Armor
    public static final ArmorMaterial ENDERITE_ARMOR = new ArmorMaterial(42, Map.of(
                    ArmorType.HELMET, 4, ArmorType.CHESTPLATE, 9, ArmorType.LEGGINGS, 7, ArmorType.BOOTS, 4),
            18, SoundEvents.ARMOR_EQUIP_NETHERITE, 3.5F, 0.15F, GileModTags.Items.ENDERITE_TOOL_MATERIALS,
            ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "enderite")));

    // Fate Sword
    public static final ToolMaterial FATE_SWORD_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL,
            1201, 1.0f, 6.0f, 15,
            TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("gilemod", "wish_ingot")));

    // Elemental
    public static final ToolMaterial ELEMENTAL_WEAPONS = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL,
            1, 1.0F, 7.0F, 22, NO_WEAPON_REPAIR);

    // Legendary
    public static final ToolMaterial LEGENDARY_WEAPONS = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL,
            1, 1.0F, 11.0F, 22, NO_WEAPON_REPAIR);

    // Primordial
    public static final ToolMaterial PRIMORDIAL_WEAPONS = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL,
            1, 1.0F, 7.0F, 22, NO_WEAPON_REPAIR);

}