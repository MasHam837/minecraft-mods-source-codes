package mh837.gile.worldgen.biome;

import com.mojang.serialization.Codec;
import mh837.gile.GileModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;

public class MoonDesertSurfaceFeature extends Feature<SimpleBlockConfiguration> {

    public MoonDesertSurfaceFeature(Codec<SimpleBlockConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<SimpleBlockConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        boolean placed = false;
        int radius = 6;

        Block moonSand = GileModBlocks.MOON_SAND;
        Block moonSandstone = GileModBlocks.MOON_SANDSTONE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double distSq = dx * dx + dz * dz;
                if (distSq > radius * radius) continue;

                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;

                int topY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos topPos = new BlockPos(x, topY - 1, z);

                if (!level.getBlockState(topPos).is(Blocks.END_STONE)) continue;

                for (int depth = 0; depth < 3; depth++) {
                    BlockPos replacePos = topPos.below(depth);
                    if (level.getBlockState(replacePos).is(Blocks.END_STONE)) {
                        level.setBlock(replacePos, moonSand.defaultBlockState(), 2);
                    }
                }

                BlockPos sandstonePos = topPos.below(3);
                if (level.getBlockState(sandstonePos).is(Blocks.END_STONE)) {
                    level.setBlock(sandstonePos, moonSandstone.defaultBlockState(), 2);
                }
                placed = true;
            }
        }
        return placed;
    }
}