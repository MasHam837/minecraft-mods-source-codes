package mh837.gile.block;

import com.mojang.serialization.MapCodec;
import mh837.gile.GileModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

public class MoonFireBlock extends BaseFireBlock {
    public static final MapCodec<MoonFireBlock> CODEC = simpleCodec(MoonFireBlock::new);

    public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
    public static final BooleanProperty EAST = BlockStateProperties.EAST;
    public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
    public static final BooleanProperty WEST = BlockStateProperties.WEST;
    public static final BooleanProperty UP = BlockStateProperties.UP;

    public MoonFireBlock(BlockBehaviour.Properties properties) {
        super(properties, 2.0F);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(NORTH, false)
                .setValue(EAST, false)
                .setValue(SOUTH, false)
                .setValue(WEST, false)
                .setValue(UP, false));
    }

    @Override
    protected MapCodec<? extends BaseFireBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST, UP);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockPos below = context.getClickedPos().below();
        if (context.getLevel().getBlockState(below).is(GileModBlocks.MOON_SAND)) {
            return this.defaultBlockState();
        }
        return this.updateState(context.getLevel(), context.getClickedPos());
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        if (level.getBlockState(below).is(GileModBlocks.MOON_SAND)) {
            return true;
        }
        BlockState updatedState = this.updateState(level, pos);
        return updatedState.getValue(NORTH) || updatedState.getValue(EAST) ||
                updatedState.getValue(SOUTH) || updatedState.getValue(WEST) ||
                updatedState.getValue(UP);
    }

    @Override
    protected BlockState updateShape(BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos, Direction directionToNeighbour, BlockPos neighbourPos, BlockState neighbourState, RandomSource random) {
        if (!this.canSurvive(state, level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, level, ticks, pos, directionToNeighbour, neighbourPos, neighbourState, random);
    }

    private BlockState updateState(BlockGetter level, BlockPos pos) {
        return this.defaultBlockState()
                .setValue(UP, this.isValidFireBase(level.getBlockState(pos.above())))
                .setValue(NORTH, this.isValidFireBase(level.getBlockState(pos.north())))
                .setValue(SOUTH, this.isValidFireBase(level.getBlockState(pos.south())))
                .setValue(EAST, this.isValidFireBase(level.getBlockState(pos.east())))
                .setValue(WEST, this.isValidFireBase(level.getBlockState(pos.west())));
    }

    private boolean isValidFireBase(BlockState state) {
        return state.is(GileModBlocks.MOON_SAND) || state.ignitedByLava();
    }

    @Override
    protected boolean canBurn(BlockState state) {
        return true;
    }
}