package mh837.gile;

import net.fabricmc.fabric.api.registry.CompostableRegistry;
import net.fabricmc.fabric.api.registry.FuelValueEvents;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;

import static mh837.gile.GileModBlocks.*;
import static mh837.gile.GileModItems.GLOWING_CHORUS_FRUIT;

public class GileModBlocksLogic {

    public static void initialize() {
        // STRIPPABLE
        StrippableBlockRegistry.register(GHOSTLY_LOG, STRIPPED_GHOSTLY_LOG); StrippableBlockRegistry.register(GHOSTLY_WOOD, STRIPPED_GHOSTLY_WOOD);
        StrippableBlockRegistry.register(INVERTED_OAK_LOG, STRIPPED_INVERTED_OAK_LOG); StrippableBlockRegistry.register(INVERTED_OAK_WOOD, STRIPPED_INVERTED_OAK_WOOD);

        // COMPOSTER
        CompostableRegistry.INSTANCE.add(GHOSTLY_LEAVES, 0.3f);
        CompostableRegistry.INSTANCE.add(INVERTED_OAK_LEAVES, 0.3f);
        CompostableRegistry.INSTANCE.add(GHOSTLY_SAPLING, 0.3f);
        CompostableRegistry.INSTANCE.add(INVERTED_OAK_SAPLING, 0.3f);
        CompostableRegistry.INSTANCE.add(TALL_END_GRASS, 0.3f);
        CompostableRegistry.INSTANCE.add(END_GRASS, 0.3f);
        CompostableRegistry.INSTANCE.add(DRY_FLOWER, 0.3f);
        CompostableRegistry.INSTANCE.add(MOON_FLOWER, 0.65f);
        CompostableRegistry.INSTANCE.add(GLOOMY_FLOWER, 0.65f);
        CompostableRegistry.INSTANCE.add(GileModItems.JELLY, 0.65f);

        // FUEL
        FuelValueEvents.BUILD.register((builder, context) -> {
            builder.add(GHOSTLY_LOG, 300); builder.add(INVERTED_OAK_LOG, 300);
            builder.add(STRIPPED_GHOSTLY_LOG, 300); builder.add(STRIPPED_INVERTED_OAK_LOG, 300);
            builder.add(GHOSTLY_WOOD, 300); builder.add(INVERTED_OAK_WOOD, 300);
            builder.add(STRIPPED_GHOSTLY_WOOD, 300); builder.add(STRIPPED_INVERTED_OAK_WOOD, 300);
            builder.add(GHOSTLY_PLANKS, 300); builder.add(INVERTED_OAK_PLANKS, 300);
            builder.add(GHOSTLY_STAIRS, 300); builder.add(INVERTED_OAK_STAIRS, 300);
            builder.add(GHOSTLY_SLAB, 150); builder.add(INVERTED_OAK_SLAB, 150);
            builder.add(GHOSTLY_FENCE, 300); builder.add(INVERTED_OAK_FENCE, 300);
            builder.add(GHOSTLY_FENCE_GATE, 300); builder.add(INVERTED_OAK_FENCE_GATE, 300);
            builder.add(GHOSTLY_DOOR, 200); builder.add(INVERTED_OAK_DOOR, 200);
            builder.add(GHOSTLY_PRESSURE_PLATE, 300); builder.add(INVERTED_OAK_PRESSURE_PLATE, 300);
            builder.add(GHOSTLY_BUTTON, 100); builder.add(INVERTED_OAK_BUTTON, 100);
            builder.add(GHOSTLY_TRAPDOOR, 300); builder.add(INVERTED_OAK_TRAPDOOR, 300);
            builder.add(GHOSTLY_SAPLING, 100); builder.add(INVERTED_OAK_SAPLING, 100);
            builder.add(GHOSTLY_SIGN, 200); builder.add(INVERTED_OAK_SIGN, 200);
            builder.add(GHOSTLY_HANGING_SIGN, 800); builder.add(INVERTED_OAK_HANGING_SIGN, 800);
            builder.add(STAR, 3200);
        });
    }
}