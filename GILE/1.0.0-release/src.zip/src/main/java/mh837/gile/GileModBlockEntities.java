package mh837.gile;

import mh837.gile.block.entity.*;
import mh837.gile.block.entity.signs.GhostlyHangingSignBlockEntity;
import mh837.gile.block.entity.signs.GhostlySignBlockEntity;
import mh837.gile.block.entity.signs.InvertedOakHangingSignBlockEntity;
import mh837.gile.block.entity.signs.InvertedOakSignBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

public class GileModBlockEntities {

    public static <T extends BlockEntity> BlockEntityType<T> register(
            String name, FabricBlockEntityTypeBuilder.Factory<T> factory, Block... blocks
    ) {
        return Registry.register(
                BuiltInRegistries.BLOCK_ENTITY_TYPE,
                Identifier.fromNamespaceAndPath(GileMod.MOD_ID, name),
                FabricBlockEntityTypeBuilder.create(factory, blocks).build()
        );
    }

    // SIGNS
    public static final BlockEntityType<GhostlySignBlockEntity> GHOSTLY_SIGN_ENTITY =
            register("ghostly_sign", GhostlySignBlockEntity::new, GileModBlocks.GHOSTLY_SIGN, GileModBlocks.GHOSTLY_WALL_SIGN);
    public static final BlockEntityType<GhostlyHangingSignBlockEntity> GHOSTLY_HANGING_SIGN_ENTITY =
            register("ghostly_hanging_sign", GhostlyHangingSignBlockEntity::new, GileModBlocks.GHOSTLY_HANGING_SIGN, GileModBlocks.GHOSTLY_WALL_HANGING_SIGN);
    public static final BlockEntityType<InvertedOakSignBlockEntity> INVERTED_OAK_SIGN_ENTITY =
            register("inverted_oak_sign", InvertedOakSignBlockEntity::new, GileModBlocks.INVERTED_OAK_SIGN, GileModBlocks.INVERTED_OAK_WALL_SIGN);
    public static final BlockEntityType<InvertedOakHangingSignBlockEntity> INVERTED_OAK_HANGING_SIGN_ENTITY =
            register("inverted_oak_hanging_sign", InvertedOakHangingSignBlockEntity::new, GileModBlocks.INVERTED_OAK_HANGING_SIGN, GileModBlocks.INVERTED_OAK_WALL_HANGING_SIGN);

    // CAMPFIRE
    public static final BlockEntityType<MoonCampfireBlockEntity> MOON_CAMPFIRE_ENTITY =
            register("moon_campfire", MoonCampfireBlockEntity::new, GileModBlocks.MOON_CAMPFIRE);

    // SHELF
    public static final BlockEntityType<GhostlyShelfBlockEntity> GHOSTLY_SHELF_ENTITY =
            register("ghostly_shelf", GhostlyShelfBlockEntity::new, GileModBlocks.GHOSTLY_SHELF);
    public static final BlockEntityType<InvertedOakShelfBlockEntity> INVERTED_OAK_SHELF_ENTITY =
            register("inverted_oak_shelf", InvertedOakShelfBlockEntity::new, GileModBlocks.INVERTED_OAK_SHELF);

    // WISH TABLE
    public static final MenuType<WishTableScreenHandler> WISH_TABLE_SCREEN_HANDLER =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath("gilemod", "wish_table"),
                    new MenuType<>(WishTableScreenHandler::new, FeatureFlags.DEFAULT_FLAGS));

    public static final BlockEntityType<WishTableBlockEntity> WISH_TABLE_BLOCK_ENTITY =
            register("wish_table", WishTableBlockEntity::new, GileModBlocks.WISH_TABLE);

    // GLITTER JAR
    public static final BlockEntityType<GlitterJarBlockEntity> GLITTER_JAR_ENTITY =
            register("glitter_jar", GlitterJarBlockEntity::new, GileModBlocks.JAR_OF_GLITTERS);

    public static void initialize() {
    }
}