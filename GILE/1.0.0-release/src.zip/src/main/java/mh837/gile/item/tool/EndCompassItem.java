package mh837.gile.item.tool;

import mh837.gile.GileModDataComponents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.biome.Biomes;

import java.util.Set;

public class EndCompassItem extends Item {

    private static final int MIN_COORDINATE = 1000;
    private static final int SEARCH_RADIUS = 128;

    /**
     * Persistent player-data key.
     * Once the player has received the Main End Island warning,
     * they won't be warned again.
     */
    private static final String END_WARNING_KEY =
            "gilemod_end_compass_warning_seen";

    public EndCompassItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {

        ItemStack stack = player.getItemInHand(hand);

        // Client side does not perform the teleport.
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }

        boolean isOverworld = level.dimension().equals(Level.OVERWORLD);
        boolean isEnd = level.dimension().equals(Level.END);

        // Only allow the compass to work in the Overworld or End.
        if (!isOverworld && !isEnd) {

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.end_compass.invalid_dimension"
                    ).withStyle(ChatFormatting.RED)
            );

            return InteractionResult.FAIL;
        }

        if (!(level instanceof ServerLevel currentLevel)) {
            return InteractionResult.FAIL;
        }

        /*
         * Use the player's current X/Z coordinates as the destination
         * coordinates in the other dimension.
         */
        int targetX = (int) Math.floor(player.getX());
        int targetZ = (int) Math.floor(player.getZ());

        ServerLevel destinationLevel;

        if (isOverworld) {
            destinationLevel = currentLevel.getServer().getLevel(Level.END);
        } else {
            destinationLevel = currentLevel.getServer().getLevel(Level.OVERWORLD);
        }

        if (destinationLevel == null) {

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.end_compass.destination_missing"
                    ).withStyle(ChatFormatting.RED)
            );

            return InteractionResult.FAIL;
        }

        /*
         * If the player is far enough from 0,0, use the normal
         * search around their coordinates.
         *
         * Otherwise, search for the closest safe position.
         */
        boolean outsideSafeCenter =
                Math.abs(targetX) >= MIN_COORDINATE
                        || Math.abs(targetZ) >= MIN_COORDINATE;

        BlockPos safePosition;

        if (outsideSafeCenter) {
            safePosition = findSafePosition(
                    destinationLevel,
                    targetX,
                    targetZ
            );
        } else {
            safePosition = findClosestGround(
                    destinationLevel,
                    targetX,
                    targetZ
            );
        }

        // No suitable position was found.
        if (safePosition == null) {

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.end_compass.no_safe_position"
                    ).withStyle(ChatFormatting.RED)
            );

            level.playSound(
                    null,
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    SoundEvents.WITHER_BREAK_BLOCK,
                    SoundSource.PLAYERS,
                    0.5F,
                    1.5F
            );

            return InteractionResult.FAIL;
        }

        if (!(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResult.FAIL;
        }

        /*
         * MAIN END ISLAND WARNING
         *
         * Only warn when travelling from the Overworld into
         * a location whose biome is THE_END.
         *
         * The first click shows the warning and stops here.
         * The second click continues with the teleport.
         */
        if (isOverworld
                && isMainEndIsland(destinationLevel, safePosition)) {

            boolean warningSeen = stack.getOrDefault(
                    GileModDataComponents.END_WARNING_SEEN,
                    false
            );

            if (!warningSeen) {

                stack.set(
                        GileModDataComponents.END_WARNING_SEEN,
                        true
                );

                player.sendSystemMessage(
                        Component.translatable(
                                "message.gilemod.end_compass.main_end_warning"
                        ).withStyle(ChatFormatting.GOLD)
                );

                // Warning sound.
                level.playSound(
                        null,
                        player.getX(),
                        player.getY(),
                        player.getZ(),
                        SoundEvents.BEACON_DEACTIVATE,
                        SoundSource.PLAYERS,
                        0.8F,
                        0.8F
                );

                // Do NOT teleport yet.
                return InteractionResult.SUCCESS;
            }
        }

        /*
         * TELEPORT
         */
        serverPlayer.teleportTo(
                destinationLevel,
                safePosition.getX() + 0.5,
                safePosition.getY(),
                safePosition.getZ() + 0.5,
                Set.of(),
                player.getYRot(),
                player.getXRot(),
                false
        );

        /*
         * Teleport particles.
         */
        destinationLevel.sendParticles(
                ParticleTypes.PORTAL,
                safePosition.getX() + 0.5,
                safePosition.getY() + 0.5,
                safePosition.getZ() + 0.5,
                60,
                0.5,
                0.8,
                0.5,
                0.2
        );

        /*
         * Teleport sound.
         */
        destinationLevel.playSound(
                null,
                safePosition.getX() + 0.5,
                safePosition.getY(),
                safePosition.getZ() + 0.5,
                SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.PLAYERS,
                1.0F,
                1.0F
        );

        return InteractionResult.SUCCESS;
    }

    /**
     * Checks whether the destination is inside the main End biome.
     *
     * The main End island normally uses the THE_END biome,
     * while the outer islands use different End biomes.
     */
    private static boolean isMainEndIsland(
            ServerLevel level,
            BlockPos pos
    ) {
        return level.getBiome(pos).is(Biomes.THE_END);
    }

    /**
     * Searches outward from the target position for a safe location.
     *
     * The search works in a square/ring pattern around the target.
     */
    private static BlockPos findSafePosition(
            ServerLevel level,
            int targetX,
            int targetZ
    ) {

        // Try the exact position first.
        BlockPos exact = findSafePositionInColumn(
                level,
                targetX,
                targetZ
        );

        if (exact != null) {
            return exact;
        }

        // Search outward in rings.
        for (int radius = 1; radius <= SEARCH_RADIUS; radius++) {

            // North and south sides.
            for (int dx = -radius; dx <= radius; dx++) {

                BlockPos result = findSafePositionInColumn(
                        level,
                        targetX + dx,
                        targetZ - radius
                );

                if (result != null) {
                    return result;
                }

                result = findSafePositionInColumn(
                        level,
                        targetX + dx,
                        targetZ + radius
                );

                if (result != null) {
                    return result;
                }
            }

            // West and east sides.
            for (int dz = -radius + 1; dz <= radius - 1; dz++) {

                BlockPos result = findSafePositionInColumn(
                        level,
                        targetX - radius,
                        targetZ + dz
                );

                if (result != null) {
                    return result;
                }

                result = findSafePositionInColumn(
                        level,
                        targetX + radius,
                        targetZ + dz
                );

                if (result != null) {
                    return result;
                }
            }
        }

        return null;
    }

    /**
     * Finds the closest safe ground position around the target.
     *
     * This currently uses the same ring-search algorithm as
     * findSafePosition().
     */
    private static BlockPos findClosestGround(
            ServerLevel level,
            int targetX,
            int targetZ
    ) {

        // Try the exact position first.
        BlockPos exact = findSafePositionInColumn(
                level,
                targetX,
                targetZ
        );

        if (exact != null) {
            return exact;
        }

        // Search outward in rings.
        for (int radius = 1; radius <= SEARCH_RADIUS; radius++) {

            // North and south sides.
            for (int dx = -radius; dx <= radius; dx++) {

                BlockPos result = findSafePositionInColumn(
                        level,
                        targetX + dx,
                        targetZ - radius
                );

                if (result != null) {
                    return result;
                }

                result = findSafePositionInColumn(
                        level,
                        targetX + dx,
                        targetZ + radius
                );

                if (result != null) {
                    return result;
                }
            }

            // West and east sides.
            for (int dz = -radius + 1; dz <= radius - 1; dz++) {

                BlockPos result = findSafePositionInColumn(
                        level,
                        targetX - radius,
                        targetZ + dz
                );

                if (result != null) {
                    return result;
                }

                result = findSafePositionInColumn(
                        level,
                        targetX + radius,
                        targetZ + dz
                );

                if (result != null) {
                    return result;
                }
            }
        }

        return null;
    }

    /**
     * Finds a safe position in a specific X/Z column.
     *
     * Requirements:
     * - Player's feet must be in air.
     * - Player's head must be in air.
     * - Block underneath must have a sturdy top face.
     */
    private static BlockPos findSafePositionInColumn(
            ServerLevel level,
            int x,
            int z
    ) {

        int minY = level.getMinY();
        int maxY = level.getMaxY();

        /*
         * Start near the top and work downward.
         *
         * maxY - 2 guarantees that feet and head remain
         * inside the world height.
         */
        for (int y = maxY - 2; y >= minY + 1; y--) {

            BlockPos feet = new BlockPos(x, y, z);
            BlockPos head = feet.above();
            BlockPos ground = feet.below();

            BlockState feetState = level.getBlockState(feet);
            BlockState headState = level.getBlockState(head);
            BlockState groundState = level.getBlockState(ground);

            // Feet must be empty.
            if (!feetState.isAir()) {
                continue;
            }

            // Head must be empty.
            if (!headState.isAir()) {
                continue;
            }

            // Ground must be solid enough to stand on.
            if (!groundState.isFaceSturdy(
                    level,
                    ground,
                    Direction.UP
            )) {
                continue;
            }

            return feet;
        }

        return null;
    }
}