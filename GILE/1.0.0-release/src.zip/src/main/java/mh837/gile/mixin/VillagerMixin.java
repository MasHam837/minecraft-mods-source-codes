package mh837.gile.mixin;

import mh837.gile.GileModVillagerProfessions;

import mh837.gile.advancement.GileModTriggers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.trading.MerchantOffer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Villager.class)
public abstract class VillagerMixin {

    @Inject(
            method = "rewardTradeXp",
            at = @At("HEAD")
    )
    private void gile$triggerWisherTrade(
            MerchantOffer offer,
            CallbackInfo ci
    ) {
        Villager villager = (Villager) (Object) this;

        if (villager.getVillagerData().profession()
                .is(GileModVillagerProfessions.WISHER_KEY)) {

            if (villager.getTradingPlayer() instanceof ServerPlayer player) {
                GileModTriggers.TRADE_WITH_WISHER.trigger(player);
            }
        }
    }
}