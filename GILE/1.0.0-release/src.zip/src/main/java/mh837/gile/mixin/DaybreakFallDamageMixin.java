package mh837.gile.mixin;

import mh837.gile.item.weapon.elemental.ElementalWeaponItems;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class DaybreakFallDamageMixin {

    @Inject(
            method = "causeFallDamage",
            at = @At("HEAD"),
            cancellable = true
    )
    private void gilemod$cancelDaybreakFallDamage(
            double fallDistance,
            float damageMultiplier,
            DamageSource damageSource,
            CallbackInfoReturnable<Boolean> cir
    ) {
        LivingEntity entity = (LivingEntity) (Object) this;

        ItemStack mainHand = entity.getMainHandItem();
        ItemStack offHand = entity.getOffhandItem();

        if (mainHand.getItem() instanceof ElementalWeaponItems.DaybreakChronicles ||
                offHand.getItem() instanceof ElementalWeaponItems.DaybreakChronicles) {
            cir.setReturnValue(false);
        }
    }
}