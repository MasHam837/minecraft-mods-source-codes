package mh837.gile.item.weapon.elemental;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModEntities;
import mh837.gile.GileModParticleTypes;
import mh837.gile.advancement.GileModTriggers;
import mh837.gile.entity.SalonMemberEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.WeatherData;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

public final class ElementalAbilities { private ElementalAbilities() {}

    // VENTI VORTEX
    public static final class VentiVortex {
        private VentiVortex() {}

        private static final int DURATION = 80; // Reduced from 100
        private static final double RADIUS = 4.5D; // Reduced from 6.0D
        private static final double PULL_STRENGTH = 0.12D; // Reduced from 0.16D
        private static final double MAX_PULL = 0.55D; // Reduced from 0.75D
        private static final double CENTER_Y_OFFSET = 1.0D;
        private static final long COOLDOWN = 12000L;

        private static final Map<UUID, ActiveVortex> ACTIVE = new HashMap<>();
        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();

        static double getRadius() {return RADIUS;}

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis();
            long cooldownEnd = COOLDOWNS.getOrDefault(player.getUUID(), 0L);

            if (now < cooldownEnd) {
                long remaining = (cooldownEnd - now + 999L) / 1000L;

                player.sendSystemMessage(
                        Component.translatable(
                                "message.gilemod.venti_vortex_cooldown",
                                remaining
                        ),
                        true
                );

                return false;
            }

            Vec3 origin = player.getEyePosition();
            Vec3 look = player.getLookAngle();
            Vec3 target = origin.add(look.scale(4.0D));

            BlockPos pos = BlockPos.containing(target);

            if (!(level.getBlockState(pos).isAir()
                    || level.getBlockState(pos.above()).isAir()
                    || level.getBlockState(pos.below()).isAir())) {

                // Fallback
                target = player.position().add(0, 3.0D, 0);
            }

            ACTIVE.remove(player.getUUID());
            ACTIVE.put(
                    player.getUUID(),
                    new ActiveVortex(player.getUUID(), target, DURATION)
            );

            COOLDOWNS.put(
                    player.getUUID(),
                    now + COOLDOWN
            );

            player.getCooldowns().addCooldown(
                    stack,
                    Math.toIntExact(COOLDOWN / 50)
            );

            ElementalEffects.spawnVortexCastEffect(level, player, target);

            GileModTriggers.ABILITY_ANEMO.trigger(player);

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.venti_vortex_activated"
                    ),
                    true
            );

            level.playSound(
                    null,
                    target.x,
                    target.y,
                    target.z,
                    SoundEvents.BREEZE_CHARGE,
                    SoundSource.PLAYERS,
                    1.0F,
                    0.65F
            );

            return true;
        }

        public static void tick(ServerLevel level) {
            Iterator<Map.Entry<UUID, ActiveVortex>> iterator = ACTIVE.entrySet().iterator();
            while (iterator.hasNext()) {
                ActiveVortex vortex = iterator.next().getValue();
                vortex.age++;
                if (vortex.age >= vortex.duration) {
                    ElementalEffects.spawnVortexEndEffect(level, vortex.position);
                    iterator.remove();
                    continue;
                }
                AABB area = new AABB(vortex.position.x - RADIUS, vortex.position.y - 2.0D, vortex.position.z - RADIUS,
                        vortex.position.x + RADIUS, vortex.position.y + 4.0D, vortex.position.z + RADIUS);
                for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area, e -> e.isAlive() && !(e instanceof Player))) {
                    pullEntity(entity, vortex.position);
                }
                ElementalEffects.spawnVortexParticles(level, vortex);
                if (vortex.age % 20 == 0) {
                    float pitch = 0.95F + (float) Math.sin(vortex.age * 0.15D) * 0.08F;
                    level.playSound(null, vortex.position.x, vortex.position.y, vortex.position.z,
                            SoundEvents.BREEZE_CHARGE, SoundSource.AMBIENT, 0.25F, pitch); // Reduced from 0.35F
                }
            }
        }

        private static void pullEntity(LivingEntity entity, Vec3 center) {
            Vec3 entityCenter = entity.position().add(0.0D, entity.getBbHeight() * 0.45D, 0.0D);
            Vec3 vortexCenter = center.add(0.0D, CENTER_Y_OFFSET, 0.0D);
            Vec3 difference = vortexCenter.subtract(entityCenter);
            double distance = difference.length();
            if (distance < 0.35D) {return;}
            double proximity = 1.0D - Math.min(distance / RADIUS, 1.0D);
            double smoothProximity = proximity * proximity * (3.0D - 2.0D * proximity);
            double strength = PULL_STRENGTH + smoothProximity * MAX_PULL;
            Vec3 horizontalDifference = new Vec3(difference.x, 0.0D, difference.z);
            double horizontalDistance = horizontalDifference.length();
            if (horizontalDistance > 0.001D) {
                Vec3 horizontalPull = horizontalDifference.normalize().scale(strength);
                entity.push(horizontalPull.x, 0.0D, horizontalPull.z);
            }
            double verticalPull = Math.clamp(difference.y * 0.08D, -0.04D, 0.10D); // Reduced from 0.12D, -0.06D, 0.16D
            entity.push(0.0D, verticalPull, 0.0D);
            entity.hurtMarked = true;
        }

        static class ActiveVortex {
            private final UUID owner;
            private final Vec3 position;
            private final int duration;
            private int age;
            private ActiveVortex(UUID owner, Vec3 position, int duration) {
                this.owner = owner;
                this.position = position;
                this.duration = duration;
            }
            public Vec3 getPosition() {
                return position;
            }
            public int getAge() {
                return age;
            }
        }
    }

    // ZHONG LI BARRICADE
    public static final class ZhongLiBarricade { private ZhongLiBarricade() {}

        private static final int DURATION = 200;
        private static final int COLLAPSE_START = 180;
        private static final int COLLAPSE_DURATION = 20;
        private static final long COOLDOWN = 12000L;
        private static final double CAST_DISTANCE = 14.0D;
        private static final double MIN_CAST_DISTANCE = 6.0D;
        private static final double STRUCTURE_RADIUS = 5.5D;
        private static final double EFFECT_RADIUS = 6.0D;
        private static final int MAX_PILLAR_HEIGHT = 8;
        private static final int MIN_PILLAR_HEIGHT = 4;
        private static final int CENTER_PILLAR_HEIGHT = 9;
        private static final int SLOW_DURATION = 25;
        private static final int SLOW_AMPLIFIER = 1;
        private static final float BASE_ROCK_CHANCE = 0.22F;
        private static final float CAP_ROCK_CHANCE = 0.30F;
        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
        private static final Map<UUID, ActiveEruption> ACTIVE = new HashMap<>();

        private static BlockState[] getPillarBlocks(BlockState surface) {

            if (surface.is(Blocks.STONE) || surface.is(Blocks.COBBLESTONE) || surface.is(Blocks.GRASS_BLOCK) || surface.is(Blocks.DIRT)
                    || surface.is(Blocks.MYCELIUM) || surface.is(Blocks.COARSE_DIRT) || surface.is(Blocks.GRASS_BLOCK) || surface.is(Blocks.PODZOL)
                    || surface.is(Blocks.DIORITE) || surface.is(Blocks.ANDESITE) || surface.is(Blocks.GRANITE) || surface.is(Blocks.CALCITE)
                    || surface.is(Blocks.GRAVEL) || surface.is(Blocks.DRIPSTONE_BLOCK) || surface.is(Blocks.CLAY) || surface.is(Blocks.MUD))
                return new BlockState[]{Blocks.STONE.defaultBlockState(), Blocks.COBBLESTONE.defaultBlockState()};
            if (surface.is(Blocks.DEEPSLATE) || surface.is(Blocks.COBBLED_DEEPSLATE) || surface.is(Blocks.TUFF))
                return new BlockState[]{Blocks.TUFF.defaultBlockState(), Blocks.COBBLED_DEEPSLATE.defaultBlockState()};

            if (surface.is(Blocks.SAND) || surface.is(Blocks.SANDSTONE))
                return new BlockState[]{Blocks.STONE.defaultBlockState(), Blocks.SANDSTONE.defaultBlockState()};
            if (surface.is(Blocks.RED_SAND) || surface.is(Blocks.RED_SANDSTONE)
                    || surface.is(Blocks.TERRACOTTA) || surface.is(Blocks.ORANGE_TERRACOTTA))
                return new BlockState[]{Blocks.RED_SANDSTONE.defaultBlockState(), Blocks.ORANGE_TERRACOTTA.defaultBlockState()};

            if (surface.is(Blocks.NETHERRACK) || surface.is(Blocks.CRIMSON_NYLIUM) || surface.is(Blocks.WARPED_NYLIUM))
                return new BlockState[]{Blocks.NETHER_GOLD_ORE.defaultBlockState(), Blocks.NETHERRACK.defaultBlockState()};
            if (surface.is(Blocks.SOUL_SOIL))
                return new BlockState[]{Blocks.SOUL_SAND.defaultBlockState(), Blocks.SOUL_SOIL.defaultBlockState()};
            if (surface.is(Blocks.SOUL_SAND))
                return new BlockState[]{Blocks.SOUL_SOIL.defaultBlockState(), Blocks.SOUL_SAND.defaultBlockState()};
            if (surface.is(Blocks.BLACKSTONE))
                return new BlockState[]{Blocks.GILDED_BLACKSTONE.defaultBlockState(), Blocks.BLACKSTONE.defaultBlockState()};
            if (surface.is(Blocks.BASALT))
                return new BlockState[]{Blocks.MAGMA_BLOCK.defaultBlockState(), Blocks.BASALT.defaultBlockState()};

            if (surface.is(Blocks.END_STONE)|| surface.is(GileModBlocks.END_GRASS_BLOCK) || surface.is(GileModBlocks.MOON_SAND))
                return new BlockState[]{GileModBlocks.MOON_SANDSTONE.defaultBlockState(), Blocks.END_STONE.defaultBlockState()};

            return null;
        }

        private static BlockState choosePillarBlock(ServerLevel level, BlockState surface) {
            BlockState[] blocks = getPillarBlocks(surface);
            if (blocks == null) {
                Component.translatable("message.gilemod.zhong_li_barricade_error");
                return null;
            }
            return level.getRandom().nextFloat() < 0.20F ? blocks[0] : blocks[1];
        }

        private static boolean isSupportedSurface(BlockState state) {
            return getPillarBlocks(state) != null;
        }

        private static boolean isPillarBlock(BlockState state) {
            return state.is(Blocks.COBBLESTONE) || state.is(Blocks.STONE) || state.is(Blocks.SNOW)
                    || state.is(Blocks.TUFF) || state.is(Blocks.COBBLED_DEEPSLATE) || state.is(Blocks.SANDSTONE)
                    || state.is(Blocks.RED_SANDSTONE) || state.is(Blocks.ORANGE_TERRACOTTA)
                    || state.is(Blocks.NETHERRACK) || state.is(Blocks.SOUL_SAND)
                    || state.is(Blocks.SOUL_SOIL) || state.is(Blocks.GILDED_BLACKSTONE)
                    || state.is(Blocks.BLACKSTONE) || state.is(Blocks.MAGMA_BLOCK)
                    || state.is(Blocks.BASALT) || state.is(Blocks.END_STONE);
        }

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis();
            long cooldownEnd = COOLDOWNS.getOrDefault(player.getUUID(), 0L);

            if (now < cooldownEnd) {
                long remaining = (cooldownEnd - now + 999L) / 1000L;
                player.sendSystemMessage(Component.translatable("message.gilemod.zhong_li_barricade_cooldown", remaining), true);
                return false;
            }
            Vec3 target = findTargetPosition(level, player);
            if (target == null) {
                // Find the surface block the player was aiming at for the error message
                Vec3 origin = player.getEyePosition();
                Vec3 dir = player.getLookAngle();
                BlockPos pos = BlockPos.containing(origin.add(dir.scale(CAST_DISTANCE)));
                BlockState surface = Blocks.AIR.defaultBlockState();

                for (int i = 0; i < 8; i++) {
                    BlockState state = level.getBlockState(pos);
                    if (!state.isAir() && state.isSolid()) {
                        surface = state;
                        break;
                    }
                    pos = pos.below();
                }
                player.sendSystemMessage(Component.translatable("message.gilemod.zhong_li_barricade_error"), true);
                return false;
            }

            removeExisting(level, player.getUUID());
            ActiveEruption eruption = new ActiveEruption(player.getUUID(), level, target);
            ACTIVE.put(player.getUUID(), eruption);
            COOLDOWNS.put(player.getUUID(), now + COOLDOWN);
            player.getCooldowns().addCooldown(stack, Math.toIntExact(COOLDOWN / 50));
            giveResistance(player);
            ElementalEffects.spawnZhongLiActivationEffect(level, target); GileModTriggers.ABILITY_GEO.trigger(player);
            player.sendSystemMessage(Component.translatable("message.gilemod.zhong_li_barricade_activated"), true);
            spawnCastEffect(level, target);
            playEarthImpact(level, target, 1.0F);

            return true;
        }

        private static void giveResistance(ServerPlayer player) {player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, DURATION + 10,
                RaidenShogunThunder.RESISTANCE_AMPLIFIER, false, true, true));}

        private static Vec3 findTargetPosition(ServerLevel level, ServerPlayer player) {
            Vec3 origin = player.getEyePosition(), dir = player.getLookAngle();

            for (double d = MIN_CAST_DISTANCE; d <= CAST_DISTANCE; d += 0.5D) {
                BlockPos pos = BlockPos.containing(origin.add(dir.scale(d)));
                BlockPos ground = findValidGround(level, pos);
                if (ground != null)
                    return Vec3.atBottomCenterOf(ground);
            }
            return null;
        }

        private static BlockPos findValidGround(ServerLevel level, BlockPos start) {
            for (int i = 0; i < 8; i++) {
                BlockState state = level.getBlockState(start);
                if (!state.isAir() && state.isSolid()) {
                    BlockPos above = start.above();
                    if (level.getBlockState(above).isAir() && isSupportedSurface(state))
                        return above;
                    return null;
                }
                start = start.below();
            }
            return null;
        }

        public static void tick(ServerLevel level) {
            Iterator<Map.Entry<UUID, ActiveEruption>> it = ACTIVE.entrySet().iterator();

            while (it.hasNext()) {
                ActiveEruption e = it.next().getValue();
                if (e.dimension != level.dimension()) continue;

                e.age++;

                if (e.age == 1) eruptOuterPillars(level, e);
                if (e.age == 4) eruptInnerPillars(level, e);
                if (e.age == 7) eruptSecondaryPillars(level, e);
                if (e.age == 10) eruptCenterPillar(level, e);
                if (e.age < COLLAPSE_START) slowNearbyEntities(level, e);
                if (e.age >= 12 && e.age < COLLAPSE_START && e.age % 4 == 0)
                    spawnAmbientDebris(level, e);
                if (e.age >= COLLAPSE_START) collapsePillars(level, e);

                if (e.age >= DURATION) {
                    removeRemainingBlocks(level, e);
                    spawnFinalCollapseEffect(level, e.position);
                    it.remove();
                }
            }
        }

        private static void eruptOuterPillars(ServerLevel level, ActiveEruption e) {
            for (int i = 0; i < 8; i++) {
                double a = Math.PI * 2.0D * i / 8.0D;
                double r = 4.7D;
                BlockPos ground = findGround(level, new BlockPos(
                        Mth.floor(e.position.x + Math.cos(a) * r),
                        Mth.floor(e.position.y),
                        Mth.floor(e.position.z + Math.sin(a) * r)));

                if (ground == null) continue;

                createThinPillar(level, e, ground,
                        MIN_PILLAR_HEIGHT + level.getRandom().nextInt(MAX_PILLAR_HEIGHT - MIN_PILLAR_HEIGHT + 1),
                        false);
                playEarthImpact(level, Vec3.atCenterOf(ground), 0.75F);
            }

            spawnRingDebris(level, e.position, 4.8D, 40);
        }

        private static void eruptInnerPillars(ServerLevel level, ActiveEruption e) {
            for (int i = 0; i < 4; i++) {
                double a = Math.PI * 2.0D * i / 4.0D + Math.PI / 4.0D;
                double r = 2.8D;
                BlockPos ground = findGround(level, new BlockPos(
                        Mth.floor(e.position.x + Math.cos(a) * r),
                        Mth.floor(e.position.y),
                        Mth.floor(e.position.z + Math.sin(a) * r)));

                if (ground == null) continue;

                createThinPillar(level, e, ground, 5 + level.getRandom().nextInt(3), false);
                playEarthImpact(level, Vec3.atCenterOf(ground), 0.9F);
            }

            spawnRingDebris(level, e.position, 2.8D, 25);
        }

        private static void eruptSecondaryPillars(ServerLevel level, ActiveEruption e) {
            for (int i = 0; i < 4; i++) {
                double a = Math.PI * 2.0D * i / 4.0D + Math.PI / 4.0D;
                double r = 4.0D;
                BlockPos ground = findGround(level, new BlockPos(
                        Mth.floor(e.position.x + Math.cos(a) * r),
                        Mth.floor(e.position.y),
                        Mth.floor(e.position.z + Math.sin(a) * r)));

                if (ground == null) continue;

                createThinPillar(level, e, ground, 4 + level.getRandom().nextInt(3), false);
                playEarthImpact(level, Vec3.atCenterOf(ground), 0.7F);
            }

            spawnRingDebris(level, e.position, 4.0D, 30);
        }

        private static void eruptCenterPillar(ServerLevel level, ActiveEruption e) {
            BlockPos ground = findGround(level, BlockPos.containing(e.position));

            if (ground != null) {
                createThinPillar(level, e, ground, CENTER_PILLAR_HEIGHT, true);
                playEarthImpact(level, Vec3.atCenterOf(ground), 1.35F);
            }

            level.sendParticles(ParticleTypes.CLOUD,
                    e.position.x, e.position.y + 1.0D, e.position.z,
                    45, 1.5D, 0.6D, 1.5D, 0.08D);

            level.sendParticles(ParticleTypes.SMALL_GUST,
                    e.position.x, e.position.y + 1.0D, e.position.z,
                    85, 2.0D, 1.5D, 2.0D, 0.22D);

            level.sendParticles(ParticleTypes.CRIT,
                    e.position.x, e.position.y + 1.0D, e.position.z,
                    35, 1.2D, 0.8D, 1.2D, 0.12D);

            level.playSound(null, e.position.x, e.position.y, e.position.z,
                    SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 0.65F, 0.8F);
        }

        private static void createThinPillar(ServerLevel level, ActiveEruption e,
                                             BlockPos ground, int height, boolean center) {
            BlockState surface = level.getBlockState(ground.below());
            if (getPillarBlocks(surface) == null) return;

            int driftX = level.getRandom().nextInt(3) - 1;
            int driftZ = level.getRandom().nextInt(3) - 1;

            for (int y = 0; y < height; y++) {
                int ox = y >= height * 0.65D ? driftX : 0;
                int oz = y >= height * 0.65D ? driftZ : 0;
                BlockPos pos = ground.above(y).offset(ox, 0, oz);

                placePillarBlock(level, e, pos, surface);

                if (y == 0 && level.getRandom().nextFloat() < BASE_ROCK_CHANCE) {
                    placePillarBlock(level, e,
                            pos.offset(level.getRandom().nextBoolean() ? 1 : -1,
                                    0,
                                    level.getRandom().nextBoolean() ? 1 : 0),
                            surface);
                }

                if (level.getRandom().nextFloat() < 0.10F) {
                    placePillarBlock(level, e,
                            pos.offset(level.getRandom().nextBoolean() ? 1 : -1, 0, 0),
                            surface);
                }
            }

            BlockPos top = ground.above(height);

            if (level.getRandom().nextFloat() < CAP_ROCK_CHANCE)
                placePillarBlock(level, e, top.offset(driftX, 0, driftZ), surface);

            if (center && level.getRandom().nextFloat() < 0.65F)
                placePillarBlock(level, e, top.offset(driftX, 1, driftZ), surface);

            spawnPillarDebris(level, ground, surface);
        }

        private static void placePillarBlock(ServerLevel level, ActiveEruption e, BlockPos pos, BlockState surface) {
            if (!level.getBlockState(pos).isAir()) return;

            BlockState state = choosePillarBlock(level, surface);
            if (state == null) return;

            e.blocks.put(pos.immutable(), state);
            e.blockAges.put(pos.immutable(), e.age);

            level.setBlock(pos, state, 3);
            e.highestY = Math.max(e.highestY, pos.getY());

            double x = pos.getX() + 0.5D;
            double y = pos.getY() + 0.5D;
            double z = pos.getZ() + 0.5D;

            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state),
                    x, y, z, 6, 0.25D, 0.30D, 0.25D, 0.12D);

            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, surface),
                    x, pos.getY() + 0.15D, z, 4, 0.30D, 0.10D, 0.30D, 0.08D);

            level.sendParticles(ParticleTypes.CLOUD,
                    x, pos.getY() + 0.15D, z, 4,
                    0.25D, 0.12D, 0.25D, 0.035D);

            level.sendParticles(ParticleTypes.CRIT,
                    x, y, z, 2, 0.15D, 0.20D, 0.15D, 0.06D);
        }

        private static BlockPos findGround(ServerLevel level, BlockPos start) {
            BlockPos pos = start;

            for (int i = 0; i < 12; i++) {
                BlockState state = level.getBlockState(pos);

                if (!state.isAir() && state.isSolid()) {
                    BlockPos above = pos.above();
                    if (level.getBlockState(above).isAir())
                        return above;
                    break;
                }

                pos = pos.below();
            }

            pos = start;

            for (int i = 0; i < 12; i++) {
                BlockState state = level.getBlockState(pos);

                if (!state.isAir() && state.isSolid() &&
                        level.getBlockState(pos.above()).isAir())
                    return pos.above();

                pos = pos.above();
            }

            return null;
        }

        private static void slowNearbyEntities(ServerLevel level, ActiveEruption e) {
            Vec3 c = e.position;

            AABB area = new AABB(
                    c.x - EFFECT_RADIUS, c.y - 2.0D, c.z - EFFECT_RADIUS,
                    c.x + EFFECT_RADIUS, c.y + 12.0D, c.z + EFFECT_RADIUS);

            for (LivingEntity entity :
                    level.getEntitiesOfClass(LivingEntity.class, area, LivingEntity::isAlive)) {

                double dx = entity.getX() - c.x;
                double dz = entity.getZ() - c.z;

                if (dx * dx + dz * dz > EFFECT_RADIUS * EFFECT_RADIUS) continue;
                if (entity.getY() < c.y - 2.0D || entity.getY() > c.y + 12.0D) continue;

                entity.addEffect(new MobEffectInstance(
                        MobEffects.SLOWNESS,
                        SLOW_DURATION,
                        SLOW_AMPLIFIER,
                        false, true, true));
            }
        }

        private static void spawnPillarDebris(ServerLevel level, BlockPos ground,
                                              BlockState surface) {
            double x = ground.getX() + 0.5D;
            double y = ground.getY() + 0.1D;
            double z = ground.getZ() + 0.5D;

            level.sendParticles(ParticleTypes.CLOUD,
                    x, y, z, 7, 0.45D, 0.12D, 0.45D, 0.035D);

            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, surface),
                    x, y + 0.15D, z, 6,
                    0.35D, 0.18D, 0.35D, 0.08D);

            level.sendParticles(ParticleTypes.CRIT,
                    x, y + 0.2D, z, 4,
                    0.25D, 0.20D, 0.25D, 0.07D);
        }

        private static void spawnRingDebris(ServerLevel level, Vec3 center,
                                            double radius, int amount) {
            level.sendParticles(ParticleTypes.CLOUD,
                    center.x, center.y + 0.15D, center.z,
                    amount, radius, 0.18D, radius, 0.07D);

            level.sendParticles(ParticleTypes.SMALL_GUST,
                    center.x, center.y + 0.2D, center.z,
                    amount / 2, radius, 0.25D, radius, 0.14D);

            level.sendParticles(ParticleTypes.CRIT,
                    center.x, center.y + 0.25D, center.z,
                    amount / 3, radius, 0.25D, radius, 0.10D);
        }

        private static void spawnAmbientDebris(ServerLevel level, ActiveEruption e) {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            double radius = 1.5D + level.getRandom().nextDouble() * 4.0D;
            double x = e.position.x + Math.cos(angle) * radius;
            double z = e.position.z + Math.sin(angle) * radius;

            BlockState[] blocks = getPillarBlocks(
                    level.getBlockState(BlockPos.containing(x, e.position.y, z)));

            level.sendParticles(ParticleTypes.CLOUD,
                    x, e.position.y + 0.3D, z,
                    3, 0.20D, 0.12D, 0.20D, 0.025D);

            if (blocks != null) {
                level.sendParticles(new BlockParticleOption(
                                ParticleTypes.BLOCK, blocks[1]),
                        x, e.position.y + 0.4D, z,
                        3, 0.18D, 0.18D, 0.18D, 0.08D);
            }
        }

        private static void playEarthImpact(ServerLevel level, Vec3 position,
                                            float volume) {
            level.playSound(null, position.x, position.y, position.z,
                    SoundEvents.STONE_BREAK, SoundSource.BLOCKS,
                    volume, 0.55F + level.getRandom().nextFloat() * 0.30F);

            level.playSound(null, position.x, position.y, position.z,
                    SoundEvents.ROOTED_DIRT_BREAK, SoundSource.BLOCKS,
                    volume * 0.75F, 0.65F + level.getRandom().nextFloat() * 0.25F);

            if (level.getRandom().nextFloat() < 0.60F)
                level.playSound(null, position.x, position.y, position.z,
                        SoundEvents.STONE_BREAK, SoundSource.BLOCKS,
                        volume * 0.60F,
                        0.75F + level.getRandom().nextFloat() * 0.35F);
        }

        private static void spawnCastEffect(ServerLevel level, Vec3 center) {
            for (int i = 0; i < 48; i++) {
                double a = Math.PI * 2.0D * i / 48.0D;
                double r = 1.0D + (i / 48.0D) * 2.5D;

                level.sendParticles(
                        new BlockParticleOption(
                                ParticleTypes.BLOCK,
                                Blocks.DIRT.defaultBlockState()),
                        center.x + Math.cos(a) * r,
                        center.y + 0.06D,
                        center.z + Math.sin(a) * r,
                        1, 0.04D, 0.025D, 0.04D, 0.06D);
            }

            level.sendParticles(ParticleTypes.CLOUD,
                    center.x, center.y + 0.15D, center.z,
                    25, 1.0D, 0.15D, 1.0D, 0.05D);

            level.sendParticles(ParticleTypes.GUST,
                    center.x, center.y + 0.35D, center.z,
                    8, 0.8D, 0.4D, 0.8D, 0.08D);
        }

        private static void collapsePillars(ServerLevel level, ActiveEruption e) {
            int age = e.age - COLLAPSE_START;
            double progress = age / (double) COLLAPSE_DURATION;
            double threshold = e.highestY - progress * (e.highestY - e.groundY);

            List<BlockPos> remove = new ArrayList<>();
            for (BlockPos pos : e.blocks.keySet())
                if (pos.getY() >= threshold) remove.add(pos);

            for (BlockPos pos : remove) {
                BlockState spawned = e.blocks.get(pos);
                BlockState current = level.getBlockState(pos);

                if (current.equals(spawned)) {
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, current),
                            pos.getX() + .5D, pos.getY() + .5D, pos.getZ() + .5D,
                            3, .2D, .2D, .2D, .1D);
                    level.removeBlock(pos, false);
                }

                e.blocks.remove(pos);
                e.blockAges.remove(pos);
            }

            if (age % 2 == 0)
                for (int i = 0, n = 2 + level.getRandom().nextInt(4); i < n; i++) {
                    double a = level.getRandom().nextDouble() * Math.PI * 2D;
                    double r = level.getRandom().nextDouble() * STRUCTURE_RADIUS;
                    playEarthImpact(level, new Vec3(
                            e.position.x + Math.cos(a) * r,
                            e.groundY + level.getRandom().nextDouble() *
                                    Math.max(1D, e.highestY - e.groundY),
                            e.position.z + Math.sin(a) * r), .35F);
                }

            double r = 1D + progress * 3.5D;
            level.sendParticles(ParticleTypes.CLOUD, e.position.x, e.groundY + .5D, e.position.z,
                    8 + age * 2, r, .3D, r, .06D);

            if (age >= 15)
                level.sendParticles(ParticleTypes.SMALL_GUST, e.position.x, e.groundY + .7D,
                        e.position.z, 15, 3.5D, .8D, 3.5D, .16D);
        }

        private static void spawnFinalCollapseEffect(ServerLevel level, Vec3 center) {
            level.sendParticles(ParticleTypes.CLOUD,
                    center.x, center.y + 0.5D, center.z,
                    60, 3.5D, 0.8D, 3.5D, 0.10D);

            level.sendParticles(
                    new BlockParticleOption(
                            ParticleTypes.BLOCK,
                            Blocks.COBBLESTONE.defaultBlockState()),
                    center.x, center.y + 0.5D, center.z,
                    25, 2.5D, 0.5D, 2.5D, 0.16D);

            level.sendParticles(ParticleTypes.SMALL_GUST,
                    center.x, center.y + 0.6D, center.z,
                    70, 3.5D, 1.0D, 3.5D, 0.20D);

            level.sendParticles(ParticleTypes.CRIT,
                    center.x, center.y + 0.7D, center.z,
                    30, 3.0D, 0.7D, 3.0D, 0.14D);

            level.playSound(null, center.x, center.y, center.z,
                    SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS,
                    0.75F, 0.65F);

            level.playSound(null, center.x, center.y, center.z,
                    SoundEvents.STONE_BREAK, SoundSource.BLOCKS,
                    1.3F, 0.45F);

            level.playSound(null, center.x, center.y, center.z,
                    SoundEvents.ROOTED_DIRT_BREAK, SoundSource.BLOCKS,
                    1.1F, 0.55F);
        }

        private static void removeRemainingBlocks(ServerLevel level, ActiveEruption e) {
            for (BlockPos pos : new ArrayList<>(e.blocks.keySet())) {
                BlockState current = level.getBlockState(pos);
                if (isPillarBlock(current)) {
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, current),
                            pos.getX() + .5D, pos.getY() + .5D, pos.getZ() + .5D,
                            2, .15D, .15D, .15D, .05D);
                    level.removeBlock(pos, false);
                }
            }
            e.blocks.clear();
            e.blockAges.clear();
        }

        private static void removeExisting(ServerLevel level, UUID uuid) {
            ActiveEruption old = ACTIVE.remove(uuid);
            if (old != null)
                removeRemainingBlocks(level, old);
        }

        private static class ActiveEruption {
            private final UUID owner;
            private final ResourceKey<Level> dimension;
            private final Vec3 position;
            private final int groundY;
            private int highestY;
            private final Map<BlockPos, BlockState> blocks = new HashMap<>();
            private final Map<BlockPos, Integer> blockAges = new HashMap<>();
            private int age;

            private ActiveEruption(UUID owner, ServerLevel level, Vec3 position) {
                this.owner = owner;
                this.dimension = level.dimension();
                this.position = position;
                this.groundY = Mth.floor(position.y);
                this.highestY = groundY;
            }
        }
    }

    // RAIDEN THUNDER
    public static final class RaidenShogunThunder {
        private RaidenShogunThunder() {}

        private static final long COOLDOWN = 12000L;
        private static final double CAST_DISTANCE = 20D;
        private static final float THUNDER_DAMAGE = 14F;
        private static final double THUNDER_RADIUS = 4.5D;
        private static final int RESISTANCE_AMPLIFIER = 3;
        private static final int RESISTANCE_DURATION = 80;
        private static final int ABILITY_LIGHTNING_COUNT = 12;
        private static final double ABILITY_LIGHTNING_RADIUS = 4D;
        private static final int BACK_RING_DURATION = 100;
        private static final double BACK_RING_DISTANCE = 1.25D;
        private static final double BACK_RING_RADIUS = 1.35D;
        private static final int THUNDER_WEATHER_DURATION = 600; // 30 seconds (600 ticks)
        private static long THUNDER_WEATHER_END = -1L;
        private static boolean isThunderWeatherActive = false;

        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
        private static final Map<UUID, Integer> HIT_COUNTERS = new HashMap<>();
        private static final Map<UUID, Integer> BACK_RINGS = new HashMap<>();

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis();
            long cooldownEnd = COOLDOWNS.getOrDefault(player.getUUID(), 0L);
            if (now < cooldownEnd) {
                long remaining = (cooldownEnd - now + 999L) / 1000L;
                player.sendSystemMessage(
                        Component.translatable("message.gilemod.raiden_thunder_cooldown", remaining),
                        true);
                return false;
            }

            Vec3 target = findTargetPosition(level, player);

            COOLDOWNS.put(player.getUUID(), now + COOLDOWN);
            player.getCooldowns().addCooldown(stack, Math.toIntExact(COOLDOWN / 50));

            player.addEffect(new MobEffectInstance(
                    MobEffects.RESISTANCE,
                    RESISTANCE_DURATION,
                    RESISTANCE_AMPLIFIER,
                    false, false, true));

            // Set thunder weather for 30 seconds (600 ticks)
            level.getServer().setWeatherParameters(0, THUNDER_WEATHER_DURATION, true, true);
            THUNDER_WEATHER_END = level.getGameTime() + THUNDER_WEATHER_DURATION;
            isThunderWeatherActive = true;

            summonHugeThunder(level, player, target); GileModTriggers.ABILITY_ELECTRO.trigger(player);
            player.sendSystemMessage(Component.translatable("message.gilemod.raiden_thunder_activated"), true);
            startBackRing(player);
            return true;
        }

        private static Vec3 findTargetPosition(ServerLevel level, ServerPlayer player) {
            Vec3 eye = player.getEyePosition(), look = player.getLookAngle();
            EntityHitResult hit = findLivingEntity(level, player, eye, look);

            if (hit != null) {
                Entity e = hit.getEntity();
                return new Vec3(e.getX(), e.getY(), e.getZ());
            }

            Vec3 end = eye.add(look.scale(CAST_DISTANCE));
            HitResult result = level.clip(new ClipContext(
                    eye, end,
                    ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE,
                    player));

            return result.getType() != HitResult.Type.MISS
                    ? result.getLocation()
                    : eye.add(look.scale(10D));
        }

        private static EntityHitResult findLivingEntity(
                ServerLevel level, ServerPlayer player,
                Vec3 origin, Vec3 direction) {

            Vec3 end = origin.add(direction.scale(CAST_DISTANCE));
            AABB box = player.getBoundingBox()
                    .expandTowards(direction.scale(CAST_DISTANCE))
                    .inflate(1.5D);

            LivingEntity closest = null;
            double distance = Double.MAX_VALUE;

            for (LivingEntity entity : level.getEntitiesOfClass(
                    LivingEntity.class, box,
                    e -> e.isAlive() && e != player && !e.isSpectator())) {

                Optional<Vec3> hit = entity.getBoundingBox()
                        .inflate(0.3D)
                        .clip(origin, end);

                if (hit.isPresent()) {
                    double d = origin.distanceToSqr(hit.get());
                    if (d < distance) {
                        distance = d;
                        closest = entity;
                    }
                }
            }

            return closest == null ? null :
                    new EntityHitResult(closest, closest.position());
        }

        private static void summonHugeThunder(
                ServerLevel level, ServerPlayer caster, Vec3 target) {

            for (int i = 0; i < 100; i++) {
                double a = level.getRandom().nextDouble() * Math.PI * 2D;
                double r = level.getRandom().nextDouble() * THUNDER_RADIUS;
                double x = target.x + Math.cos(a) * r;
                double z = target.z + Math.sin(a) * r;
                double y = target.y + 3D + level.getRandom().nextDouble() * 10D;

                level.sendParticles(
                        ParticleTypes.ELECTRIC_SPARK,
                        x, y, z, 2,
                        0.1D, 0.3D, 0.1D, 0.25D);
            }

            for (int i = 0; i < ABILITY_LIGHTNING_COUNT; i++)
                spawnAbilityLightning(level, target);

            spawnLightningColumn(level, target);
            spawnThunderRing(level, target, 1.5D, 36);
            spawnThunderRing(level, target, 3D, 48);
            spawnThunderRing(level, target, 4.5D, 64);

            level.sendParticles(
                    ParticleTypes.ELECTRIC_SPARK,
                    target.x, target.y + 1D, target.z,
                    220, 3.5D, 3D, 3.5D, 0.35D);

            level.sendParticles(
                    ParticleTypes.END_ROD,
                    target.x, target.y + 1.5D, target.z,
                    110, 2.5D, 2.5D, 2.5D, 0.18D);

            level.sendParticles(
                    ParticleTypes.CLOUD,
                    target.x, target.y + 0.2D, target.z,
                    80, 3.5D, 0.2D, 3.5D, 0.1D);

            damageNearbyEnemies(level, caster, target);

            level.playSound(null, target.x, target.y, target.z,
                    SoundEvents.LIGHTNING_BOLT_THUNDER,
                    SoundSource.WEATHER, 8F, 0.65F);

            level.playSound(null, target.x, target.y, target.z,
                    SoundEvents.LIGHTNING_BOLT_IMPACT,
                    SoundSource.WEATHER, 5F, 0.75F);

            level.playSound(null, target.x, target.y, target.z,
                    SoundEvents.GENERIC_EXPLODE,
                    SoundSource.HOSTILE, 1F, 1.15F);
        }

        private static void spawnAbilityLightning(
                ServerLevel level, Vec3 target) {

            double a = level.getRandom().nextDouble() * Math.PI * 2D;
            double r = level.getRandom().nextDouble() * ABILITY_LIGHTNING_RADIUS;

            spawnLightning(
                    level,
                    target.x + Math.cos(a) * r,
                    target.y,
                    target.z + Math.sin(a) * r,
                    null);
        }

        private static void spawnLightning(
                ServerLevel level,
                double x,
                double y,
                double z,
                LivingEntity attacker) {

            LightningBolt bolt = new LightningBolt(EntityType.LIGHTNING_BOLT, level);
            bolt.setPos(x, y, z);

            if (attacker instanceof ServerPlayer player)
                bolt.setCause(player);

            level.addFreshEntity(bolt);

            Vec3 pos = new Vec3(x, y, z);
            ElementalEffects.spawnRaidenLightningImpact(level, pos);

            level.sendParticles(
                    ParticleTypes.ELECTRIC_SPARK,
                    x, y + 0.5D, z,
                    80, 0.7D, 0.8D, 0.7D, 0.3D);

            level.playSound(
                    null, x, y, z,
                    SoundEvents.LIGHTNING_BOLT_IMPACT,
                    SoundSource.WEATHER, 3F, 1.05F);

            level.playSound(
                    null, x, y, z,
                    SoundEvents.LIGHTNING_BOLT_THUNDER,
                    SoundSource.WEATHER, 2.5F, 0.9F);
        }

        private static void spawnLightningColumn(
                ServerLevel level, Vec3 target) {

            for (int y = 0; y < 18; y++) {
                double progress = y / 18D;
                double radius = 0.15D + progress * 0.7D;
                double angle = y * 1.9D;
                double x = target.x + Math.cos(angle) * radius;
                double z = target.z + Math.sin(angle) * radius;

                level.sendParticles(
                        ParticleTypes.ELECTRIC_SPARK,
                        x, target.y + y, z,
                        10, 0.15D, 0.35D, 0.15D, 0.3D);
            }

            for (int branch = 0; branch < 12; branch++) {
                double angle = level.getRandom().nextDouble() * Math.PI * 2D;
                double length = 1.5D + level.getRandom().nextDouble() * 3.5D;
                double startY = target.y + 2D +
                        level.getRandom().nextDouble() * 8D;

                for (int step = 0; step < 8; step++) {
                    double progress = step / 8D;
                    double distance = length * progress;
                    double x = target.x + Math.cos(angle) * distance;
                    double z = target.z + Math.sin(angle) * distance;
                    double y = startY - progress * 2.5D +
                            Math.sin(step * 2.7D + branch) * 0.35D;

                    level.sendParticles(
                            ParticleTypes.ELECTRIC_SPARK,
                            x, y, z,
                            4, 0.12D, 0.12D, 0.12D, 0.3D);
                }
            }
        }

        private static void spawnThunderRing(
                ServerLevel level, Vec3 center,
                double radius, int points) {

            for (int i = 0; i < points; i++) {
                double a = Math.PI * 2D * i / points;
                double x = center.x + Math.cos(a) * radius;
                double z = center.z + Math.sin(a) * radius;
                double height = 0.5D +
                        level.getRandom().nextDouble() * 2D;

                level.sendParticles(
                        ParticleTypes.ELECTRIC_SPARK,
                        x, center.y + 0.15D, z,
                        5, 0.08D, height, 0.08D, 0.22D);

                if (i % 4 == 0)
                    level.sendParticles(
                            ParticleTypes.END_ROD,
                            x, center.y + 0.4D, z,
                            2, 0.04D, 0.4D, 0.04D, 0.2D);
            }
        }

        private static void damageNearbyEnemies(
                ServerLevel level, ServerPlayer caster, Vec3 center) {

            AABB area = new AABB(
                    center.x - THUNDER_RADIUS,
                    center.y - 2D,
                    center.z - THUNDER_RADIUS,
                    center.x + THUNDER_RADIUS,
                    center.y + 8D,
                    center.z + THUNDER_RADIUS);

            for (LivingEntity entity : level.getEntitiesOfClass(
                    LivingEntity.class, area,
                    e -> e.isAlive() &&
                            e != caster &&
                            !(e instanceof ServerPlayer))) {

                if (entity.position().distanceTo(center) <= THUNDER_RADIUS) {
                    entity.hurt(
                            level.damageSources().lightningBolt(),
                            THUNDER_DAMAGE);

                    entity.addEffect(new MobEffectInstance(
                            MobEffects.SLOWNESS,
                            30, 1, false, true, true));
                }
            }
        }

        private static void startBackRing(LivingEntity entity) {
            if (entity != null && entity.isAlive())
                BACK_RINGS.put(entity.getUUID(), BACK_RING_DURATION);
        }

        private static final DustParticleOptions purple = new DustParticleOptions(0x9900CC, 1.0f);

        private static void tickBackRings(ServerLevel level) {
            Iterator<Map.Entry<UUID, Integer>> it =
                    BACK_RINGS.entrySet().iterator();

            while (it.hasNext()) {
                Map.Entry<UUID, Integer> entry = it.next();
                Entity entity = level.getEntity(entry.getKey());
                int remaining = entry.getValue();

                if (!(entity instanceof LivingEntity living) ||
                        !living.isAlive() || remaining <= 0) {
                    it.remove();
                    continue;
                }

                entry.setValue(remaining - 1);

                Vec3 pos = living.position().add(
                        0, living.getBbHeight() * 0.55D, 0);

                Vec3 forward = living.getLookAngle();

                if (forward.horizontalDistanceSqr() < 0.0001D)
                    forward = new Vec3(0, 0, 1);

                forward = new Vec3(
                        forward.x, 0, forward.z).normalize();

                Vec3 right = new Vec3(
                        -forward.z, 0, forward.x).normalize();

                Vec3 center = pos.subtract(
                        forward.scale(BACK_RING_DISTANCE));

                for (int i = 0; i < 24; i++) {
                    double a = Math.PI * 2D * i / 24D;

                    Vec3 p = center
                            .add(right.scale(
                                    Math.cos(a) * BACK_RING_RADIUS))
                            .add(0,
                                    Math.sin(a) * BACK_RING_RADIUS,
                                    0);

                    level.sendParticles(
                            purple,
                            p.x, p.y, p.z,
                            2, 0.025D, 0.025D, 0.025D, 0.05D);
                }

                double a = level.getGameTime() * 1.2D;

                Vec3 p = center
                        .add(right.scale(
                                Math.cos(a) * BACK_RING_RADIUS))
                        .add(0,
                                Math.sin(a) * BACK_RING_RADIUS,
                                0);

                level.sendParticles(
                        purple,
                        p.x, p.y, p.z,
                        12, 0.08D, 0.08D, 0.08D, 0.15D);
            }
        }

        private static void tickThunderWeather(ServerLevel level) {
            // Check if thunder weather is active and time is up
            if (THUNDER_WEATHER_END >= 0 && level.getGameTime() >= THUNDER_WEATHER_END) {
                // Set weather to clear
                level.getServer().setWeatherParameters(0, 0, false, false);
                THUNDER_WEATHER_END = -1L;
                isThunderWeatherActive = false;

                // Send a message to all players that the storm has cleared
                level.players().forEach(player ->
                        player.sendSystemMessage(
                                Component.translatable("message.gilemod.raiden_thunder_end")
                        )
                );
            }
        }

        public static void tick(ServerLevel level) {
            tickThunderWeather(level);
            tickBackRings(level);

            Iterator<Map.Entry<UUID, Integer>> it =
                    HIT_COUNTERS.entrySet().iterator();

            while (it.hasNext()) {
                UUID id = it.next().getKey();
                Entity entity = level.getEntity(id);

                if (!(entity instanceof LivingEntity living) ||
                        !living.isAlive())
                    it.remove();
            }
        }
    }

    // NAHIDA SOWING
    public static final class NahidaSowing { private NahidaSowing() {}

        private static final int DOMAIN_DURATION = 200;
        private static final long COOLDOWN = 12000L;
        private static final double AOE_RADIUS = 9.0D;
        private static final double AOE_HEIGHT = 6.0D;

        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
        private static final Map<UUID, ActiveDomain> ACTIVE = new HashMap<>();

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis();
            long cooldownEnd = COOLDOWNS.getOrDefault(player.getUUID(), 0L);

            if (now < cooldownEnd) {
                long remaining = (cooldownEnd - now + 999L) / 1000L;
                player.sendSystemMessage(
                        Component.translatable(
                                "message.gilemod.nahida_sowing_cooldown", remaining), true);
                return false;
            }

            Vec3 center = findTargetPosition(level, player);
            removeExisting(player.getUUID());

            ActiveDomain domain = new ActiveDomain(player.getUUID(), center);
            ACTIVE.put(player.getUUID(), domain);

            COOLDOWNS.put(player.getUUID(), now + COOLDOWN);
            player.getCooldowns().addCooldown(stack, Math.toIntExact(COOLDOWN / 50));

            poisonNearby(level, player, center);
            spawnDomainEffect(level, center); GileModTriggers.ABILITY_DENDRO.trigger(player);
            player.sendSystemMessage(Component.translatable("message.gilemod.nahida_sowing_activated"), true);

            level.playSound(null, center.x, center.y, center.z,
                    SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS,
                    1.0F, 0.65F);

            return true;
        }

        private static Vec3 findTargetPosition(ServerLevel level, ServerPlayer player) {
            Vec3 origin = player.getEyePosition();
            Vec3 direction = player.getLookAngle();

            for (double distance = 2.0D; distance <= 14.0D; distance += 0.5D) {
                Vec3 point = origin.add(direction.scale(distance));
                BlockPos pos = BlockPos.containing(point);

                if (!level.getBlockState(pos.below()).isAir()
                        && level.getBlockState(pos.below()).isSolid()) {
                    return new Vec3(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
                }
            }

            return origin.add(direction.scale(8.0D));
        }

        private static void poisonNearby(ServerLevel level, ServerPlayer player, Vec3 center) {
            AABB area = new AABB(
                    center.x - AOE_RADIUS, center.y - AOE_HEIGHT, center.z - AOE_RADIUS,
                    center.x + AOE_RADIUS, center.y + AOE_HEIGHT, center.z + AOE_RADIUS);

            for (LivingEntity entity : level.getEntitiesOfClass(
                    LivingEntity.class, area,
                    e -> e.isAlive()
                            && e != player
                            && !(e instanceof ServerPlayer)
                            && e.distanceToSqr(center) <= AOE_RADIUS * AOE_RADIUS)) {

                entity.addEffect(new MobEffectInstance(
                        MobEffects.POISON,
                        100,       // 5 seconds
                        1,         // Poison II
                        false,
                        true,
                        true));
            }
        }

        public static void tick(ServerLevel level) {
            Iterator<Map.Entry<UUID, ActiveDomain>> iterator = ACTIVE.entrySet().iterator();

            while (iterator.hasNext()) {
                ActiveDomain domain = iterator.next().getValue();
                domain.age++;

                ServerPlayer owner = level.getServer().getPlayerList().getPlayer(domain.owner);

                if (owner != null) {
                    owner.removeEffect(MobEffects.POISON);
                    owner.removeEffect(MobEffects.WITHER);
                }

                if (domain.age >= 10
                        && domain.age < DOMAIN_DURATION
                        && domain.age % 5 == 0) {
                    spawnAmbientDomainEffect(level, domain);
                }

                if (domain.age >= DOMAIN_DURATION) {
                    spawnDomainEndEffect(level, domain.center);
                    iterator.remove();
                }
            }
        }

        private static void removeExisting(UUID owner) {
            ACTIVE.remove(owner);
        }

        private static void spawnDomainEffect(ServerLevel level, Vec3 center) {
            for (int i = 0; i < 96; i++) {
                double angle = Math.PI * 2.0D * i / 96.0D;
                double x = center.x + Math.cos(angle) * AOE_RADIUS;
                double z = center.z + Math.sin(angle) * AOE_RADIUS;

                level.sendParticles(
                        ParticleTypes.HAPPY_VILLAGER,
                        x, center.y + 0.08D, z,
                        1, 0.03D, 0.03D, 0.03D, 0.01D);
            }

            level.sendParticles(
                    ParticleTypes.COMPOSTER,
                    center.x, center.y + 0.5D, center.z,
                    50, 3.5D, 0.5D, 3.5D, 0.08D);

            level.sendParticles(
                    ParticleTypes.END_ROD,
                    center.x, center.y + 1.0D, center.z,
                    20, 2.5D, 1.5D, 2.5D, 0.08D);

            for (int i = 0; i < 12; i++) {
                double angle = Math.PI * 2.0D * i / 12.0D;
                double radius = 5.5D;

                level.sendParticles(
                        GileModParticleTypes.DENDRO,
                        center.x + Math.cos(angle) * radius,
                        center.y + 0.7D,
                        center.z + Math.sin(angle) * radius,
                        2, 0.08D, 0.3D, 0.08D, 0.02D);
            }
        }

        private static void spawnAmbientDomainEffect(
                ServerLevel level, ActiveDomain domain) {

            double rotation = domain.age * 0.08D;

            for (int i = 0; i < 8; i++) {
                double angle = rotation + Math.PI * 2.0D * i / 8.0D;
                double x = domain.center.x + Math.cos(angle) * AOE_RADIUS;
                double z = domain.center.z + Math.sin(angle) * AOE_RADIUS;
                double y = domain.center.y
                        + 0.4D
                        + Math.sin(domain.age * 0.1D + i) * 0.4D;

                level.sendParticles(
                        ParticleTypes.END_ROD,
                        x, y, z,
                        1, 0.02D, 0.08D, 0.02D, 0.01D);
            }

            if (domain.age % 20 == 0) {
                level.sendParticles(
                        ParticleTypes.COMPOSTER,
                        domain.center.x,
                        domain.center.y + 0.4D,
                        domain.center.z,
                        12, 2.5D, 0.25D, 2.5D, 0.03D);
            }
        }

        private static void spawnDomainEndEffect(
                ServerLevel level, Vec3 center) {

            level.sendParticles(
                    ParticleTypes.END_ROD,
                    center.x, center.y + 0.5D, center.z,
                    60, AOE_RADIUS, 1.0D, AOE_RADIUS, -0.08D);

            level.sendParticles(
                    ParticleTypes.COMPOSTER,
                    center.x, center.y + 0.5D, center.z,
                    50, AOE_RADIUS, 0.5D, AOE_RADIUS, -0.05D);

            level.playSound(
                    null,
                    center.x, center.y, center.z,
                    SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS,
                    0.8F, 1.8F);
        }

        private static class ActiveDomain {
            private final UUID owner;
            private final Vec3 center;
            private int age;

            private ActiveDomain(UUID owner, Vec3 center) {
                this.owner = owner;
                this.center = center;
            }
        }
    }

    // FURINA SALON MEMBERS
    public static final class FurinaSalonMembers { private FurinaSalonMembers() {}

        private static final int DURATION = 240;
        private static final long COOLDOWN = 12000L;
        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
        private static final Map<UUID, List<SalonMemberEntity>> ACTIVE = new HashMap<>();

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis();
            long cooldownEnd = COOLDOWNS.getOrDefault(player.getUUID(), 0L);
            if (now < cooldownEnd) {
                long remaining = (cooldownEnd - now + 999L) / 1000L;
                player.sendSystemMessage(
                        Component.translatable("message.gilemod.furina_salon_members_cooldown", remaining), true);
                return false;
            }

            removeMembers(player);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BUBBLE_POP, SoundSource.PLAYERS, 1.0F, 0.65F);
            List<SalonMemberEntity> members = new ArrayList<>();

            for (int i = 0; i < 3; i++) {
                SalonMemberEntity member = new SalonMemberEntity(GileModEntities.SALON_MEMBER, level);
                double angle = Math.PI * 2.0D * i / 3.0D;
                double radius = 2.2D;
                member.setPos(player.getX() + Math.cos(angle) * radius, player.getY(), player.getZ() + Math.sin(angle) * radius);
                member.setYRot(player.getYRot());
                member.setXRot(0.0F);
                member.setOwner(player);
                member.setLifetime(DURATION);
                member.setMemberIndex(i); // 0 = Usher, 1 = Surintendant, 2 = Mademoiselle

                // Set custom name based on model type
                Component customName;
                float scaleValue;
                switch (i) {
                    case SalonMemberEntity.MODEL_USHER -> {
                        scaleValue = 1.0f;
                        customName = Component.translatable("entity.gilemod.salon_member_1");
                    }
                    case SalonMemberEntity.MODEL_CHEVALMARIN -> {
                        scaleValue = 0.75f;
                        customName = Component.translatable("entity.gilemod.salon_member_2");
                    }
                    case SalonMemberEntity.MODEL_CRABALETTA -> {
                        scaleValue = 1.25f;
                        customName = Component.translatable("entity.gilemod.salon_member_3");
                    }
                    default -> {
                        scaleValue = 1.0f;
                        customName = Component.translatable("entity.gilemod.salon_member_1");
                    }
                }

                member.setCustomName(customName);
                member.setCustomNameVisible(true);

                var scaleAttribute = member.getAttribute(Attributes.SCALE);
                if (scaleAttribute != null) {
                    scaleAttribute.setBaseValue(scaleValue);
                }

                level.addFreshEntity(member);
                members.add(member);
            }

            ACTIVE.put(player.getUUID(), members);
            COOLDOWNS.put(player.getUUID(), now + COOLDOWN);
            player.getCooldowns().addCooldown(stack, Math.toIntExact(COOLDOWN / 50));
            ElementalEffects.spawnFurinaSummonEffect(level, player); GileModTriggers.ABILITY_HYDRO.trigger(player);
            player.sendSystemMessage(Component.translatable("message.gilemod.furina_salon_members_activated"), true);
            return true;
        }

        public static void tick(ServerLevel level) {
            Iterator<Map.Entry<UUID, List<SalonMemberEntity>>> iterator = ACTIVE.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<UUID, List<SalonMemberEntity>> entry = iterator.next();
                ServerPlayer player = level.getServer().getPlayerList().getPlayer(entry.getKey());

                if (player == null || !player.isAlive()) {
                    for (SalonMemberEntity member : entry.getValue()) {
                        if (member.isAlive()) member.discard();
                    }
                    iterator.remove();
                    continue;
                }

                entry.getValue().removeIf(member -> !member.isAlive());
                if (entry.getValue().isEmpty()) {
                    iterator.remove();
                    continue;
                }

                if (level.getGameTime() % 4L == 0L) {
                    ElementalEffects.spawnFurinaSalonParticles(level, player, entry.getValue());
                }
            }
        }

        public static void removeMembers(ServerPlayer player) {
            List<SalonMemberEntity> members = ACTIVE.remove(player.getUUID());
            if (members != null) {
                for (SalonMemberEntity member : members) {
                    if (member.isAlive()) {
                        member.level().playSound(
                                null,
                                member.getX(),
                                member.getY(),
                                member.getZ(),
                                SoundEvents.GENERIC_SPLASH,
                                SoundSource.HOSTILE,
                                1.0F,
                                1.0F
                        );

                        member.discard();
                    }
                }
            }
        }
    }

    // MAVUIKA RAGE
    public static final class MavuikaRage {
        private MavuikaRage() {}

        private static final int DURATION = 240;
        private static final long COOLDOWN = 12000L;
        private static final int RING_COUNT = 3;
        private static final double ORBIT_RADIUS = 2.0D;
        private static final double RING_HEIGHT = 1.2D;
        private static final double ATTACK_RANGE = 8.0D;
        private static final int ATTACK_INTERVAL = 25;
        private static final float DAMAGE = 7.0F;
        private static final int FIRE_DURATION = 60;
        private static final int FIRE_RADIUS = 4; // Radius for setting blocks on fire
        private static final int FIRE_INTERVAL = 20; // How often to set fire (every 20 ticks = 1 second)
        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
        private static final Map<UUID, RingFormation> ACTIVE = new HashMap<>();

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis(), end = COOLDOWNS.getOrDefault(player.getUUID(), 0L);
            if (now < end) {
                long remaining = (end - now + 999L) / 1000L;
                player.sendSystemMessage(Component.translatable("message.gilemod.mavuika_rage_cooldown", remaining), true);
                return false;
            }

            ACTIVE.remove(player.getUUID());
            ACTIVE.put(player.getUUID(), new RingFormation());

            // Apply ability effects
            player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 10, 1, false, false, true));
            player.addEffect(new MobEffectInstance(MobEffects.SPEED, Math.toIntExact(COOLDOWN / 50), 1, false, false, true));
            player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, Math.toIntExact(COOLDOWN / 50), 0, false, false, true));

            // Initial fire burst on activation
            setFireAroundPlayer(level, player, FIRE_RADIUS);

            ElementalEffects.spawnMavuikaActivationEffect(level, player); GileModTriggers.ABILITY_PYRO.trigger(player);
            player.sendSystemMessage(Component.translatable("message.gilemod.mavuika_rage_activated"), true);
            COOLDOWNS.put(player.getUUID(), now + COOLDOWN);
            player.getCooldowns().addCooldown(stack, Math.toIntExact(COOLDOWN / 50));
            return true;
        }

        public static void tick(ServerLevel level) {
            Iterator<Map.Entry<UUID, RingFormation>> it = ACTIVE.entrySet().iterator();

            while (it.hasNext()) {
                Map.Entry<UUID, RingFormation> e = it.next();
                RingFormation f = e.getValue();
                f.age++;

                ServerPlayer player = level.getServer().getPlayerList().getPlayer(e.getKey());
                if (player == null || !player.isAlive()) {
                    it.remove();
                    continue;
                }

                updateRings(level, player, f);

                // Keep STRENGTH during the ability
                player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 10, 1, false, false, true));

                // Set fire around player periodically
                if (f.age % FIRE_INTERVAL == 0) {
                    setFireAroundPlayer(level, player, FIRE_RADIUS);
                }

                if (f.age >= 10 && f.age % ATTACK_INTERVAL == 0) attackNearbyEnemies(level, player);
                if (f.age >= DURATION) {
                    // Final fire burst on end
                    setFireAroundPlayer(level, player, FIRE_RADIUS + 2);
                    spawnEndEffect(level, player);
                    it.remove();
                }
            }
        }

        /**
         * Sets fire to blocks around the player.
         */
        private static void setFireAroundPlayer(ServerLevel level, ServerPlayer player, int radius) {
            BlockPos center = player.blockPosition();
            int placed = 0;
            int maxFire = 20; // Maximum fire blocks to place per tick

            for (int x = -radius; x <= radius && placed < maxFire; x++) {
                for (int z = -radius; z <= radius && placed < maxFire; z++) {
                    for (int y = -1; y <= 2 && placed < maxFire; y++) {
                        BlockPos pos = center.offset(x, y, z);

                        double distance = Math.sqrt(x * x + y * y + z * z);
                        if (distance > radius) continue;

                        if (level.isEmptyBlock(pos) && level.getBlockState(pos.below()).isSolid()) {
                            float chance = 1.0F - (float)(distance / (radius + 1));
                            if (level.getRandom().nextFloat() < chance * 0.6F) {
                                if (level.getBlockState(pos).canBeReplaced()) {
                                    level.setBlock(pos, Blocks.FIRE.defaultBlockState(), 3);
                                    placed++;
                                }
                            }
                        }
                    }
                }
            }
        }

        private static void updateRings(ServerLevel level, ServerPlayer player, RingFormation f) {
            double rotation = f.age * 0.075D;

            for (int ring = 0; ring < RING_COUNT; ring++) {
                double angle = rotation + ring * Math.PI * 2.0D / RING_COUNT;
                double x = player.getX() + Math.cos(angle) * ORBIT_RADIUS;
                double y = player.getY() + RING_HEIGHT + Math.sin(rotation * 1.5D + ring) * 0.15D;
                double z = player.getZ() + Math.sin(angle) * ORBIT_RADIUS;
                spawnRingParticles(level, x, y, z, ring);
            }
        }

        private static void spawnRingParticles(ServerLevel level, double x, double y, double z, int ring) {
            for (int i = 0; i < 14; i++) {
                double a = Math.PI * 2.0D * i / 14.0D, r = 0.55D + ring * 0.03D;
                level.sendParticles(ParticleTypes.FLAME, x + Math.cos(a) * r, y, z + Math.sin(a) * r,
                        1, 0.025D, 0.025D, 0.025D, 0.015D);
            }
            level.sendParticles(ParticleTypes.LAVA, x, y, z, 1, 0.18D, 0.18D, 0.18D, 0.015D);
            if (ring == 0) level.sendParticles(ParticleTypes.SMOKE, x, y, z, 1, 0.12D, 0.12D, 0.12D, 0.015D);
        }

        private static void attackNearbyEnemies(ServerLevel level, ServerPlayer player) {
            AABB area = new AABB(
                    player.getX() - ATTACK_RANGE, player.getY() - 4, player.getZ() - ATTACK_RANGE,
                    player.getX() + ATTACK_RANGE, player.getY() + 6, player.getZ() + ATTACK_RANGE
            );

            LivingEntity[] targets = level.getEntitiesOfClass(LivingEntity.class, area,
                            e -> e.isAlive() && e != player && !(e instanceof Player))
                    .stream()
                    .sorted((a, b) -> Double.compare(a.distanceToSqr(player), b.distanceToSqr(player)))
                    .limit(RING_COUNT)
                    .toArray(LivingEntity[]::new);

            for (int i = 0; i < targets.length; i++) attackTarget(level, player, targets[i]);
        }

        private static void attackTarget(ServerLevel level, ServerPlayer player, LivingEntity target) {
            if (!target.isAlive()) return;

            target.hurt(player.damageSources().mobAttack(player), DAMAGE);
            target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), FIRE_DURATION));
            ElementalEffects.spawnMavuikaAttackEffect(level, player, target);

            level.playSound(null, target.getX(), target.getY(), target.getZ(),
                    SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS,
                    0.8F, 0.8F + level.getRandom().nextFloat() * 0.25F);

            // Also set fire to blocks around the target on hit
            setFireAroundPlayer(level, player, 2);
        }

        private static void spawnEndEffect(ServerLevel level, ServerPlayer player) {
            level.sendParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 1, player.getZ(),
                    50, 2.2D, 0.8D, 2.2D, 0.08D);
            level.sendParticles(ParticleTypes.SMOKE, player.getX(), player.getY() + 1, player.getZ(),
                    20, 1.5D, 0.5D, 1.5D, 0.05D);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 1.0F, 0.65F);
        }

        private static class RingFormation {
            private int age;
        }
    }

    // TSARITSA BLIZZARD
    public static final class TsaritsasBlizzard { private TsaritsasBlizzard() {}

        private static final int DURATION = 160;
        private static final int COLLAPSE_START = 145;
        private static final long COOLDOWN = 12000L;
        private static final double CAST_DISTANCE = 14.0D;
        private static final double BLIZZARD_RADIUS = 7.0D;
        private static final int IMMOBILIZE_DURATION = 12;
        private static final float DAMAGE = 3.0F;

        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
        private static final Map<UUID, Blizzard> ACTIVE = new HashMap<>();

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis();
            long cooldownEnd = COOLDOWNS.getOrDefault(player.getUUID(), 0L);

            if (now < cooldownEnd) {
                long remaining = (cooldownEnd - now + 999L) / 1000L;
                player.sendSystemMessage(Component.translatable("message.gilemod.tsaritsas_blizzard_cooldown", remaining), true);
                return false;
            }

            Vec3 target = findTargetPosition(level, player);
            ACTIVE.remove(player.getUUID());
            ACTIVE.put(player.getUUID(), new Blizzard(player.getUUID(), target));

            COOLDOWNS.put(player.getUUID(), now + COOLDOWN);
            player.getCooldowns().addCooldown(stack, Math.toIntExact(COOLDOWN / 50));

            // Initial freezing impact
            spawnInitialBurst(level, target); GileModTriggers.ABILITY_CRYO.trigger(player);
            player.sendSystemMessage(Component.translatable("message.gilemod.tsaritsas_blizzard_activated"), true);
            level.playSound(null, target.x, target.y, target.z, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.5F, 0.45F);

            return true;
        }

        private static Vec3 findTargetPosition(ServerLevel level, ServerPlayer player) {
            Vec3 origin = player.getEyePosition();
            Vec3 direction = player.getLookAngle();

            for (double distance = 2.0D; distance <= CAST_DISTANCE; distance += 0.5D) {
                Vec3 point = origin.add(direction.scale(distance));
                BlockPos pos = BlockPos.containing(point);
                BlockPos below = pos.below();

                if (!level.getBlockState(below).isAir() && level.getBlockState(below).isSolid()) {
                    return new Vec3(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
                }
            }

            Vec3 fallback = origin.add(direction.scale(6.0D));
            BlockPos pos = BlockPos.containing(fallback);
            return new Vec3(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
        }

        public static void tick(ServerLevel level) {
            Iterator<Map.Entry<UUID, Blizzard>> iterator = ACTIVE.entrySet().iterator();

            while (iterator.hasNext()) {
                Blizzard blizzard = iterator.next().getValue();
                blizzard.age++;

                // Active Blizzard phase
                if (blizzard.age < COLLAPSE_START) {
                    maintainBlizzard(level, blizzard);
                    immobilizeEnemies(level, blizzard);

                    if (blizzard.age % 12 == 0) {
                        attackEnemies(level, blizzard);
                    }
                }

                // Collapse phase
                if (blizzard.age >= COLLAPSE_START) {
                    collapseBlizzard(level, blizzard);
                }

                // End phase
                if (blizzard.age >= DURATION) {
                    spawnFinalBurst(level, blizzard.position);
                    iterator.remove();
                }
            }
        }

        private static void maintainBlizzard(ServerLevel level, Blizzard blizzard) {
            double rotation = blizzard.age * 0.18D;

            // Rotating spiral arms
            for (int arm = 0; arm < 5; arm++) {
                double armAngle = rotation + arm * (Math.PI * 2.0D / 5.0D);

                for (int layer = 0; layer < 7; layer++) {
                    double progress = layer / 7.0D;
                    double radius = 1.0D + progress * BLIZZARD_RADIUS;
                    double angle = armAngle + progress * 2.4D;

                    double x = blizzard.position.x + Math.cos(angle) * radius;
                    double z = blizzard.position.z + Math.sin(angle) * radius;
                    double y = blizzard.position.y + 0.3D + progress * 4.0D;

                    level.sendParticles(ParticleTypes.SNOWFLAKE, x, y, z, 2, 0.15D, 0.15D, 0.15D, 0.03D);
                }
            }

            // Dense outer snow wall
            for (int i = 0; i < 18; i++) {
                double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
                double radius = BLIZZARD_RADIUS + level.getRandom().nextDouble() * 1.0D;

                double x = blizzard.position.x + Math.cos(angle) * radius;
                double z = blizzard.position.z + Math.sin(angle) * radius;

                level.sendParticles(ParticleTypes.SNOWFLAKE, x, blizzard.position.y + level.getRandom().nextDouble() * 5.0D, z, 2, 0.2D, 0.3D, 0.2D, 0.03D);
            }

            // Occasional snow cloud
            if (blizzard.age % 5 == 0) {
                level.sendParticles(ParticleTypes.CLOUD, blizzard.position.x, blizzard.position.y + 1.5D, blizzard.position.z, 12, BLIZZARD_RADIUS * 0.55D, 1.5D, BLIZZARD_RADIUS * 0.55D, 0.025D);
            }
        }

        private static void immobilizeEnemies(ServerLevel level, Blizzard blizzard) {
            AABB area = new AABB(
                    blizzard.position.x - BLIZZARD_RADIUS, blizzard.position.y - 2.0D, blizzard.position.z - BLIZZARD_RADIUS,
                    blizzard.position.x + BLIZZARD_RADIUS, blizzard.position.y + 7.0D, blizzard.position.z + BLIZZARD_RADIUS
            );

            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area, e -> e.isAlive() && !e.getUUID().equals(blizzard.owner) && !(e instanceof ServerPlayer))) {
                // Slowness 255 effectively freezes enemy movement
                entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, IMMOBILIZE_DURATION, 255, false, true, true));
                entity.setDeltaMovement(entity.getDeltaMovement().multiply(0.0D, 1.0D, 0.0D));
            }
        }

        private static void attackEnemies(ServerLevel level, Blizzard blizzard) {
            AABB area = new AABB(
                    blizzard.position.x - BLIZZARD_RADIUS, blizzard.position.y - 2.0D, blizzard.position.z - BLIZZARD_RADIUS,
                    blizzard.position.x + BLIZZARD_RADIUS, blizzard.position.y + 7.0D, blizzard.position.z + BLIZZARD_RADIUS
            );

            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area, e -> e.isAlive() && !e.getUUID().equals(blizzard.owner) && !(e instanceof ServerPlayer))) {
                spawnIceLance(level, blizzard.position, target.position());
                ElementalEffects.spawnTsaritsaAttackEffect(level, null, target);
                target.hurt(level.damageSources().freeze(), DAMAGE);
            }

            level.playSound(null, blizzard.position.x, blizzard.position.y, blizzard.position.z, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 0.45F, 1.5F);
        }

        private static void spawnIceLance(ServerLevel level, Vec3 start, Vec3 target) {
            Vec3 direction = target.subtract(start);
            double distance = direction.length();
            if (distance <= 0.1D) return;

            direction = direction.normalize();
            int points = Math.max(4, (int) (distance * 3.0D));

            for (int i = 0; i < points; i++) {
                double progress = i / (double) points;
                Vec3 point = start.add(direction.scale(distance * progress));

                level.sendParticles(ParticleTypes.SNOWFLAKE, point.x, point.y + 1.0D, point.z, 2, 0.08D, 0.08D, 0.08D, 0.02D);
            }

            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState()), target.x, target.y + 0.8D, target.z, 8, 0.25D, 0.4D, 0.25D, 0.08D);
        }

        private static void collapseBlizzard(ServerLevel level, Blizzard blizzard) {
            int age = blizzard.age - COLLAPSE_START;
            double progress = age / 15.0D;
            double radius = BLIZZARD_RADIUS * Math.max(0.05D, 1.0D - progress);

            // Storm contracts toward center
            for (int i = 0; i < 60; i++) {
                double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
                double r = level.getRandom().nextDouble() * radius;

                double x = blizzard.position.x + Math.cos(angle) * r;
                double z = blizzard.position.z + Math.sin(angle) * r;
                double y = blizzard.position.y + level.getRandom().nextDouble() * 5.0D;

                level.sendParticles(ParticleTypes.SNOWFLAKE, x, y, z, 2, 0.1D, 0.1D, 0.1D, 0.03D);
            }

            level.sendParticles(ParticleTypes.CLOUD, blizzard.position.x, blizzard.position.y + 1.0D, blizzard.position.z, 20, radius, 0.8D, radius, 0.04D);
        }

        private static void spawnInitialBurst(ServerLevel level, Vec3 center) {
            level.sendParticles(ParticleTypes.SNOWFLAKE, center.x, center.y + 1.0D, center.z, 120, 3.5D, 2.0D, 3.5D, 0.08D);
            level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.5D, center.z, 40, 2.0D, 0.5D, 2.0D, 0.06D);
            level.playSound(null, center.x, center.y, center.z, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.5F, 0.5F);
        }

        private static void spawnFinalBurst(ServerLevel level, Vec3 center) {
            level.sendParticles(ParticleTypes.SNOWFLAKE, center.x, center.y + 1.0D, center.z, 180, 1.0D, 2.5D, 1.0D, 0.12D);
            level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 1.0D, center.z, 80, 2.0D, 1.0D, 2.0D, 0.08D);

            AABB area = new AABB(
                    center.x - BLIZZARD_RADIUS, center.y - 2.0D, center.z - BLIZZARD_RADIUS,
                    center.x + BLIZZARD_RADIUS, center.y + 7.0D, center.z + BLIZZARD_RADIUS
            );

            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area)) {
                entity.hurt(level.damageSources().freeze(), 6.0F);
            }

            level.playSound(null, center.x, center.y, center.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.0F, 1.7F);
            level.playSound(null, center.x, center.y, center.z, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.5F, 0.45F);
        }

        private static class Blizzard {
            private final UUID owner;
            private final Vec3 position;
            private int age;

            private Blizzard(UUID owner, Vec3 position) {
                this.owner = owner;
                this.position = position;
                this.age = 0;
            }
        }
    }

    // COLIMBINA LUNAR DOMAIN
    public static final class LunarDomain { private LunarDomain() {}

        private static final int DURATION = 160;
        private static final long COOLDOWN = 12000L;
        private static final double CAST_DISTANCE = 14.0D;
        private static final double DOMAIN_RADIUS = 7.0D;
        private static final int LEVITATION_AMPLIFIER = 5;
        private static final int EFFECT_DURATION = 10;

        private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
        private static final Map<UUID, ActiveDomain> ACTIVE = new HashMap<>();

        public static boolean tryActivate(ServerLevel level, ServerPlayer player) {
            ItemStack stack = player.getMainHandItem();

            long now = System.currentTimeMillis(); long cooldownEnd = COOLDOWNS.getOrDefault(player.getUUID(), 0L);

            if (now < cooldownEnd) {long remaining = (cooldownEnd - now + 999L) / 1000L; player.sendSystemMessage(
                    Component.translatable("message.gilemod.lunar_domain_cooldown", remaining), true);
                return false;}
            Vec3 direction = player.getLookAngle();
            Vec3 center = player.getEyePosition()
                    .add(direction.scale(Math.min(CAST_DISTANCE, 8.0D)));
            center = new Vec3(center.x, player.getY(), center.z);

            ACTIVE.put(player.getUUID(), new ActiveDomain(player.getUUID(), center));

            COOLDOWNS.put(player.getUUID(), now + COOLDOWN);
            player.getCooldowns().addCooldown(stack, Math.toIntExact(COOLDOWN / 50));

            ElementalEffects.spawnLunarDomainOpening(level, player, center); GileModTriggers.ABILITY_LUNA.trigger(player);
            player.sendSystemMessage(Component.translatable("message.gilemod.lunar_domain_activated"), true);

            level.playSound(null, center.x, center.y, center.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2F, 0.55F);
            return true;
        }

        public static void tick(ServerLevel level) {Iterator<Map.Entry<UUID, ActiveDomain>> iterator = ACTIVE.entrySet().iterator();
            while (iterator.hasNext()) { ActiveDomain domain = iterator.next().getValue(); domain.age++;
                if (domain.age <= DURATION) imprisonEnemies(level, domain);
                if (domain.age < DURATION && domain.age % 2 == 0) ElementalEffects.spawnLunarDomainParticles(
                        level, domain.position, domain.age, DOMAIN_RADIUS);
                if (domain.age >= DURATION) {ElementalEffects.spawnLunarDomainCollapse(level, domain.position, DOMAIN_RADIUS);iterator.remove();}}
        }

        private static void imprisonEnemies(ServerLevel level, ActiveDomain domain) {
            AABB area = new AABB(domain.position.x - DOMAIN_RADIUS, domain.position.y - 3.0D, domain.position.z - DOMAIN_RADIUS,
                    domain.position.x + DOMAIN_RADIUS, domain.position.y + 10.0D, domain.position.z + DOMAIN_RADIUS);
            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area,
                    e -> e.isAlive() && !e.getUUID().equals(domain.owner))) {
                entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, EFFECT_DURATION, LEVITATION_AMPLIFIER,
                        false, true, true));
                entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, EFFECT_DURATION, 10,
                        false, false, false)); Vec3 velocity = entity.getDeltaMovement();
                entity.setDeltaMovement(velocity.x * 0.15D, Math.max(velocity.y, 0.075D), velocity.z * 0.15D);
                double dx = entity.getX() - domain.position.x; double dz = entity.getZ() - domain.position.z;
                double distance = Math.sqrt(dx * dx + dz * dz); if (distance > DOMAIN_RADIUS) {
                    double scale = (DOMAIN_RADIUS - 0.45D) / distance; entity.teleportTo(
                            domain.position.x + dx * scale,  entity.getY(),  domain.position.z + dz * scale);}}
        }

        private static final class ActiveDomain { private final UUID owner; private final Vec3 position; private int age;
            private ActiveDomain(UUID owner, Vec3 position) {this.owner = owner;this.position = position;}
        }

    }

}