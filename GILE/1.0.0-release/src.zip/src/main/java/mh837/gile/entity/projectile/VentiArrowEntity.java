package mh837.gile.entity.projectile;

import mh837.gile.GileModEntities;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class VentiArrowEntity extends AbstractArrow {

    /*
     * ============================================================
     * PARTICLES
     * ============================================================
     */

    private static final ParticleOptions TRAIL_PARTICLE =
            new DustParticleOptions(
                    0x33E6CC,
                    1.5F
            );

    private static final ParticleOptions HIT_PARTICLE =
            new DustParticleOptions(
                    0x1AFFE6,
                    2.0F
            );

    private static final ParticleOptions BLOCK_HIT_PARTICLE =
            new DustParticleOptions(
                    0x4DCCB3,
                    1.0F
            );

    /*
     * ============================================================
     * VORTEX
     * ============================================================
     */

    private float vortexStrength = 0.0F;

    /*
     * Knockback strength supplied by the bow.
     */
    private float pushStrength = 1.2F; // Reduced from 2.0F

    private int punch = 0;

    /*
     * ============================================================
     * CONSTRUCTORS
     * ============================================================
     */

    public VentiArrowEntity(
            EntityType<? extends AbstractArrow> entityType,
            Level level
    ) {
        super(entityType, level);
    }

    public VentiArrowEntity(
            Level level,
            LivingEntity owner,
            ItemStack pickupStack,
            @Nullable ItemStack firedFromWeapon
    ) {
        super(
                GileModEntities.VENTI_ARROW_TYPE,
                owner,
                level,
                pickupStack,
                firedFromWeapon
        );

        this.setBaseDamage(0.0D);

        if (owner instanceof Player player
                && player.getAbilities().instabuild) {

            this.pickup =
                    Pickup.CREATIVE_ONLY;

        } else {

            this.pickup =
                    Pickup.DISALLOWED;
        }
    }

    /*
     * ============================================================
     * PICKUP
     * ============================================================
     */

    @Override
    protected boolean tryPickup(Player player) {
        return false;
    }

    @Override
    protected ItemStack getPickupItem() {
        return ItemStack.EMPTY;
    }

    @Override
    protected ItemStack getDefaultPickupItem() {
        return ItemStack.EMPTY;
    }

    /*
     * ============================================================
     * VORTEX API
     * ============================================================
     */

    public void setVortexStrength(float strength) {

        this.vortexStrength =
                Mth.clamp(
                        strength,
                        0.0F,
                        1.0F
                );
    }

    public float getVortexStrength() {
        return this.vortexStrength;
    }

    public void setPunch(int punch) {
        this.punch = punch;
    }

    public void setPushStrength(float strength) {

        this.pushStrength =
                Math.max(
                        0.0F,
                        strength
                );
    }

    /*
     * ============================================================
     * ENTITY HIT
     * ============================================================
     */

    @Override
    protected void onHitEntity(
            EntityHitResult entityHitResult
    ) {

        Entity target =
                entityHitResult.getEntity();

        /*
         * Normal projectile damage first.
         */
        super.onHitEntity(entityHitResult);

        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }

        /*
         * ========================================================
         * VENTI KNOCKBACK (Reduced)
         * ========================================================
         */

        Vec3 velocity =
                this.getDeltaMovement();

        if (velocity.lengthSqr() > 0.0001D) {

            Vec3 direction =
                    velocity.normalize();

            /*
             * Reduced knockback values.
             */
            double horizontalStrength =
                    this.pushStrength
                            * (
                            0.45D  // Reduced from 0.65D
                                    + this.vortexStrength * 0.15D  // Reduced from 0.25D
                    );

            double verticalStrength =
                    0.10D  // Reduced from 0.20D
                            + this.vortexStrength * 0.20D;  // Reduced from 0.35D

            livingTarget.push(
                    direction.x * horizontalStrength,
                    verticalStrength,
                    direction.z * horizontalStrength
            );

            livingTarget.hurtMarked = true;
        }

        /*
         * ========================================================
         * VORTEX (Reduced)
         * ========================================================
         */

        if (this.level() instanceof ServerLevel serverLevel) {

            createVortex(
                    serverLevel,
                    livingTarget
            );

            /*
             * Bright Anemo impact.
             */
            serverLevel.sendParticles(
                    HIT_PARTICLE,
                    livingTarget.getX(),
                    livingTarget.getY()
                            + livingTarget.getBbHeight() / 2.0D,
                    livingTarget.getZ(),
                    30,  // Reduced from 40
                    0.8D,
                    1.0D,
                    0.8D,
                    0.1D
            );

            /*
             * Wind cloud.
             */
            serverLevel.sendParticles(
                    ParticleTypes.CLOUD,
                    livingTarget.getX(),
                    livingTarget.getY()
                            + livingTarget.getBbHeight() / 2.0D,
                    livingTarget.getZ(),
                    15,  // Reduced from 20
                    0.7D,
                    0.6D,
                    0.7D,
                    0.06D
            );

            serverLevel.playSound(
                    null,
                    livingTarget.getX(),
                    livingTarget.getY(),
                    livingTarget.getZ(),
                    SoundEvents.BREEZE_SHOOT,
                    SoundSource.PLAYERS,
                    1.0F,  // Reduced from 1.2F
                    0.75F
                            + this.vortexStrength * 0.3F  // Reduced from 0.4F
            );
        }
    }

    /*
     * ============================================================
     * VORTEX (Reduced)
     * ============================================================
     */

    private void createVortex(
            ServerLevel level,
            LivingEntity center
    ) {

        /*
         * Minimum radius: 1.5 blocks (reduced from 2.0)
         * Maximum radius: 5.0 blocks (reduced from 7.0)
         */
        double radius =
                1.5D
                        + this.vortexStrength * 3.5D;  // Reduced from 5.0D

        /*
         * ========================================================
         * PULL ENTITIES (Reduced)
         * ========================================================
         */

        for (LivingEntity entity :
                level.getEntitiesOfClass(
                        LivingEntity.class,
                        center.getBoundingBox()
                                .inflate(radius),
                        entity ->
                                entity != center
                                        && entity.isAlive()
                                        && !(
                                        entity instanceof Player player
                                                && player.isSpectator()
                                )
                )) {

            Vec3 difference =
                    center.position()
                            .subtract(
                                    entity.position()
                            );

            double distance =
                    difference.length();

            if (distance < 0.1D) {
                continue;
            }

            /*
             * 0 at edge
             * 1 at center
             */
            double proximity =
                    1.0D
                            - Math.min(
                            distance / radius,
                            1.0D
                    );

            /*
             * Base pull (Reduced)
             */
            double strength =
                    0.12D  // Reduced from 0.18D
                            + proximity * 0.30D;  // Reduced from 0.42D

            /*
             * Charge scaling (Reduced)
             */
            strength *=
                    0.35D  // Reduced from 0.45D
                            + this.vortexStrength * 0.60D;  // Reduced from 0.85D

            Vec3 pull =
                    difference
                            .normalize()
                            .scale(strength);

            entity.push(
                    pull.x,
                    Mth.clamp(
                            pull.y * 0.15D,  // Reduced from 0.25D
                            0.0D,
                            0.12D  // Reduced from 0.18D
                    ),
                    pull.z
            );

            entity.hurtMarked = true;
        }

        /*
         * ========================================================
         * VORTEX VISUAL (Reduced)
         * ========================================================
         */

        int particles =
                15  // Reduced from 20
                        + (int)
                        (this.vortexStrength * 30.0F);  // Reduced from 50.0F

        for (int i = 0; i < particles; i++) {

            double angle =
                    level.getRandom().nextDouble()
                            * Math.PI * 2.0D;

            double radiusPosition =
                    radius
                            * Math.sqrt(
                            level.getRandom().nextDouble()
                    );

            double x =
                    center.getX()
                            + Math.cos(angle)
                            * radiusPosition;

            double z =
                    center.getZ()
                            + Math.sin(angle)
                            * radiusPosition;

            double y =
                    center.getY()
                            + 0.4D
                            + level.getRandom().nextDouble()
                            * center.getBbHeight();

            /*
             * Pull particle velocity toward the center.
             */
            Vec3 centerPoint =
                    center.position()
                            .add(
                                    0.0D,
                                    center.getBbHeight()
                                            * 0.45D,
                                    0.0D
                            );

            Vec3 inward =
                    centerPoint
                            .subtract(
                                    new Vec3(
                                            x,
                                            y,
                                            z
                                    )
                            )
                            .normalize()
                            .scale(
                                    0.05D  // Reduced from 0.08D
                                            + this.vortexStrength
                                            * 0.08D  // Reduced from 0.14D
                            );

            level.sendParticles(
                    TRAIL_PARTICLE,
                    x,
                    y,
                    z,
                    1,
                    inward.x,
                    inward.y,
                    inward.z,
                    0.02D
            );
        }

        /*
         * Strong central wind pulse on a full-charge shot (Reduced)
         */
        if (this.vortexStrength >= 0.95F) {

            level.sendParticles(
                    ParticleTypes.GUST,
                    center.getX(),
                    center.getY()
                            + center.getBbHeight() * 0.5D,
                    center.getZ(),
                    5,  // Reduced from 8
                    0.6D,
                    0.5D,
                    0.6D,
                    0.12D
            );
        }
    }

    /*
     * ============================================================
     * BLOCK HIT
     * ============================================================
     */

    @Override
    protected void onHitBlock(
            BlockHitResult blockHitResult
    ) {

        super.onHitBlock(blockHitResult);

        if (this.level() instanceof ServerLevel serverLevel) {

            this.playSound(
                    SoundEvents.ARROW_HIT,
                    1.0F,
                    1.0F
            );

            serverLevel.sendParticles(
                    BLOCK_HIT_PARTICLE,
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    12,  // Reduced from 15
                    0.3D,
                    0.3D,
                    0.3D,
                    0.03D
            );

            serverLevel.sendParticles(
                    ParticleTypes.CLOUD,
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    6,  // Reduced from 8
                    0.25D,
                    0.25D,
                    0.25D,
                    0.03D
            );
        }
    }

    /*
     * ============================================================
     * TICK
     * ============================================================
     */

    @Override
    public void tick() {

        super.tick();

        /*
         * Flying Anemo trail.
         */
        if (this.level().isClientSide()
                && !this.isInGround()) {

            int count =
                    1  // Reduced from 2
                            + (int)
                            (this.vortexStrength * 2.0F);  // Reduced from 3.0F

            for (int i = 0; i < count; i++) {

                double offsetX =
                        (this.random.nextDouble() - 0.5D)
                                * 0.3D;

                double offsetY =
                        (this.random.nextDouble() - 0.5D)
                                * 0.3D;

                double offsetZ =
                        (this.random.nextDouble() - 0.5D)
                                * 0.3D;

                this.level().addParticle(
                        TRAIL_PARTICLE,
                        this.getX() + offsetX,
                        this.getY() + offsetY,
                        this.getZ() + offsetZ,
                        0.0D,
                        0.0D,
                        0.0D
                );
            }
        }

        /*
         * Small wind effect while embedded.
         */
        if (this.level().isClientSide()
                && this.isInGround()
                && this.tickCount % 20 == 0) {

            this.level().addParticle(
                    BLOCK_HIT_PARTICLE,
                    this.getX(),
                    this.getY() + 0.1D,
                    this.getZ(),
                    0.0D,
                    0.01D,
                    0.0D
            );
        }

        /*
         * Cleanup.
         */
        if (!this.level().isClientSide()
                && this.isInGround()
                && this.tickCount > 1200) {

            this.discard();
        }
    }

    @Override
    protected float getWaterInertia() {
        return 0.6F;
    }
}