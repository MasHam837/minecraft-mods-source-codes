package mh837.gile.block;

import mh837.gile.GileModParticleTypes;

import net.minecraft.world.level.block.WallTorchBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class MoonWallTorchBlock extends WallTorchBlock {

    public MoonWallTorchBlock(
            BlockBehaviour.Properties properties
    ) {
        super(GileModParticleTypes.END_FLAME,
                properties
        );
    }
}
