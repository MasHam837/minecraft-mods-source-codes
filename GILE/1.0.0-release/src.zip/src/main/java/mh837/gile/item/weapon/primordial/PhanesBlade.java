package mh837.gile.item.weapon.primordial;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class PhanesBlade extends Item {

    public PhanesBlade(Properties properties) {
        super(properties);
    }

    @Override
    public void inventoryTick(
            ItemStack stack,
            ServerLevel level,
            Entity owner,
            EquipmentSlot slot
    ) {
        super.inventoryTick(stack, level, owner, slot);

        if (!(owner instanceof Player player)) {
            return;
        }

        if (player.isSpectator()) {
            return;
        }

        boolean holding =
                player.getMainHandItem().is(this)
                        || player.getOffhandItem().is(this);

        if (holding) {
            player.getAbilities().mayfly = true;

            player.onUpdateAbilities();

            player.addEffect(
                    new MobEffectInstance(
                            MobEffects.RESISTANCE,
                            5,
                            2,
                            false,
                            false,
                            true
                    )
            );

            player.addEffect(
                    new MobEffectInstance(
                            MobEffects.STRENGTH,
                            5,
                            2,
                            false,
                            false,
                            true
                    )
            );

            long time = level.getGameTime();

            if (time % 8L == 0L) {
                level.sendParticles(
                        ParticleTypes.GLOW,
                        player.getX(),
                        player.getY() + 0.8D,
                        player.getZ(),
                        1,
                        0.20D,
                        0.35D,
                        0.20D,
                        0.005D
                );
            }

            /*
             * Occasional PHANES particle.
             */
            if (time % 20L == 0L) {
                level.sendParticles(
                        mh837.gile.GileModParticleTypes.PHANES,
                        player.getX(),
                        player.getY() + 1.0D,
                        player.getZ(),
                        2,
                        0.45D,
                        0.65D,
                        0.45D,
                        0.01D
                );
            }

            /*
             * Very rare primordial pulse.
             */
            if (time % 120L == 0L) {
                level.sendParticles(
                        ParticleTypes.END_ROD,
                        player.getX(),
                        player.getY() + 1.0D,
                        player.getZ(),
                        8,
                        0.7D,
                        0.9D,
                        0.7D,
                        0.015D
                );

                level.playSound(
                        null,
                        player.getX(),
                        player.getY(),
                        player.getZ(),
                        SoundEvents.BEACON_AMBIENT,
                        SoundSource.PLAYERS,
                        0.18F,
                        1.75F
                );
            }

        } else {

            if (!player.isCreative() && !player.isSpectator()) {
                player.getAbilities().mayfly = false;
                player.getAbilities().flying = false;
                player.onUpdateAbilities();
            }
        }
    }

    @Override
    public InteractionResult use(
            Level level,
            Player player,
            InteractionHand hand
    ) {
        ItemStack stack = player.getItemInHand(hand);

        if (level.isClientSide()) {
            return InteractionResult.PASS;
        }

        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.PASS;
        }

        if (!(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResult.PASS;
        }

        PhanesTimeUtility.activate(
                serverLevel,
                serverPlayer,
                stack
        );

        return InteractionResult.SUCCESS_SERVER;
    }

    @Override
    public void hurtEnemy(
            ItemStack stack,
            LivingEntity target,
            LivingEntity attacker
    ) {
        if (attacker instanceof Player player) {

            target.hurtServer(
                    (ServerLevel) target.level(),
                    target.damageSources().playerAttack(player),
                    6.0F
            );

            if (target.level() instanceof ServerLevel level) {

                level.sendParticles(
                        mh837.gile.GileModParticleTypes.PHANES,
                        target.getX(),
                        target.getY() + target.getBbHeight() * 0.5D,
                        target.getZ(),
                        8,
                        0.35D,
                        0.45D,
                        0.35D,
                        0.015D
                );

                level.sendParticles(
                        ParticleTypes.CRIT,
                        target.getX(),
                        target.getY() + target.getBbHeight() * 0.5D,
                        target.getZ(),
                        6,
                        0.3D,
                        0.4D,
                        0.3D,
                        0.15D
                );
            }
        }
    }
}