package mh837.gile.recipe;

import mh837.gile.GileMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.crafting.RecipeSerializer;

public final class GileModRecipeSerializers {

    private GileModRecipeSerializers() {
    }

    public static final RecipeSerializer<WeaponUpgradeRecipe> WEAPON_UPGRADE =
            Registry.register(
                    BuiltInRegistries.RECIPE_SERIALIZER,
                    Identifier.fromNamespaceAndPath(
                            GileMod.MOD_ID,
                            "weapon_upgrade"
                    ),
                    WeaponUpgradeRecipe.SERIALIZER
            );

    public static void initialize() {
        // Registration happens through static initialization.
    }
}