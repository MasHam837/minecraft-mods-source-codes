package mh837.gile.entity;

import mh837.gile.item.weapon.elemental.ElementalEffects;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import java.util.UUID;

public class SalonMemberEntity extends PathfinderMob {

    private static final String MEMBER_INDEX_TAG = "MemberIndex";
    private static final String OWNER_ID_TAG = "Owner";
    private static final String EXPIRE_TICK_TAG = "ExpireTick";

    private static final int LIFETIME_TICKS = 15 * 20;

    private static final EntityDataAccessor<Integer> MEMBER_INDEX =
            SynchedEntityData.defineId(
                    SalonMemberEntity.class,
                    EntityDataSerializers.INT
            );

    private UUID ownerId;

    /**
     * Absolute world game-time tick at which this entity disappears.
     * -1 means no expiration has been assigned yet.
     */
    private long expireTick = -1L;

    private int attackCooldown;

    // Model types - Only 3
    public static final int MODEL_USHER = 0;
    public static final int MODEL_CHEVALMARIN = 1;
    public static final int MODEL_CRABALETTA = 2;

    public SalonMemberEntity(
            EntityType<? extends SalonMemberEntity> type,
            Level level
    ) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createSalonMemberAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 2.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.20D)
                .add(Attributes.FLYING_SPEED, 0.25D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25D, true));
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        // Attack anything that hurt the owner.
        targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));

        // Attack anything the owner hurt.
        targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));

        // Normal hostile mob targeting.
        targetSelector.addGoal(
                5,
                new NearestAttackableTargetGoal<>(
                        this,
                        LivingEntity.class,
                        10,
                        true,
                        false,
                        (target, distance) -> {
                            ServerPlayer owner = getOwner();

                            return owner != null
                                    && target != owner
                                    && !(target instanceof SalonMemberEntity)
                                    && target instanceof Enemy;
                        }
                )
        );
    }

    /**
     * Targets the entity that most recently hurt the owner.
     */
    private static class OwnerHurtByTargetGoal extends TargetGoal {

        private final SalonMemberEntity member;
        private int timestamp;

        public OwnerHurtByTargetGoal(SalonMemberEntity member) {
            super(member, false);
            this.member = member;
        }

        @Override
        public boolean canUse() {
            ServerPlayer owner = member.getOwner();

            if (owner == null) {
                return false;
            }

            LivingEntity attacker = owner.getLastHurtByMob();

            if (attacker == null || attacker == member) {
                return false;
            }

            if (!member.canAttack(attacker)) {
                return false;
            }

            int ownerTimestamp = owner.getLastHurtByMobTimestamp();

            if (ownerTimestamp == this.timestamp) {
                return false;
            }

            this.timestamp = ownerTimestamp;
            return true;
        }

        @Override
        public void start() {
            ServerPlayer owner = member.getOwner();

            if (owner != null) {
                LivingEntity attacker = owner.getLastHurtByMob();

                if (attacker != null && member.canAttack(attacker)) {
                    member.setTarget(attacker);
                }
            }

            super.start();
        }
    }

    /**
     * Targets the entity that the owner most recently attacked.
     */
    private static class OwnerHurtTargetGoal extends TargetGoal {

        private final SalonMemberEntity member;
        private int timestamp;

        public OwnerHurtTargetGoal(SalonMemberEntity member) {
            super(member, false);
            this.member = member;
        }

        @Override
        public boolean canUse() {
            ServerPlayer owner = member.getOwner();

            if (owner == null) {
                return false;
            }

            LivingEntity target = owner.getLastHurtMob();

            if (target == null || target == member) {
                return false;
            }

            if (!member.canAttack(target)) {
                return false;
            }

            int ownerTimestamp = owner.getLastHurtMobTimestamp();

            if (ownerTimestamp == this.timestamp) {
                return false;
            }

            this.timestamp = ownerTimestamp;
            return true;
        }

        @Override
        public void start() {
            ServerPlayer owner = member.getOwner();

            if (owner != null) {
                LivingEntity target = owner.getLastHurtMob();

                if (target != null && member.canAttack(target)) {
                    member.setTarget(target);
                }
            }

            super.start();
        }
    }

    public void setOwner(ServerPlayer player) {
        this.ownerId = player.getUUID();
    }

    public ServerPlayer getOwner() {
        if (!(level() instanceof ServerLevel level) || ownerId == null) {
            return null;
        }

        return level.getServer().getPlayerList().getPlayer(ownerId);
    }

    /**
     * Starts the 15-second lifetime.
     *
     * This is based on world game time rather than tickCount, so unloading
     * and reloading the entity does not reset the lifetime.
     */
    public void setLifetime(int ticks) {
        this.expireTick = level().getGameTime() + ticks;
    }

    /**
     * Convenience method specifically for the Salon Member's normal lifetime.
     */
    public void startLifetime() {
        setLifetime(LIFETIME_TICKS);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);

        builder.define(MEMBER_INDEX, MODEL_USHER);
    }

    public void setMemberIndex(int index) {
        if (index != MODEL_USHER
                && index != MODEL_CHEVALMARIN
                && index != MODEL_CRABALETTA) {
            return;
        }

        this.entityData.set(MEMBER_INDEX, index);
    }

    public int getMemberIndex() {
        return this.entityData.get(MEMBER_INDEX);
    }

    public float getMemberScale() {
        return switch (getMemberIndex()) {
            case MODEL_USHER -> 1.0F;
            case MODEL_CHEVALMARIN -> 0.85F;
            case MODEL_CRABALETTA -> 1.15F;
            default -> 1.0F;
        };
    }

    public String getModelType() {
        return switch (getMemberIndex()) {
            case MODEL_USHER -> "usher";
            case MODEL_CHEVALMARIN -> "chevalmarin";
            case MODEL_CRABALETTA -> "crabaletta";
            default -> "usher";
        };
    }

    /**
     * Save custom entity data.
     */
    @Override
    public void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);

        output.putInt(
                MEMBER_INDEX_TAG,
                this.getMemberIndex()
        );

        if (this.ownerId != null) {
            output.putString(
                    OWNER_ID_TAG,
                    this.ownerId.toString()
            );
        }

        if (this.expireTick >= 0L) {
            output.putLong(
                    EXPIRE_TICK_TAG,
                    this.expireTick
            );
        }
    }

    /**
     * Load custom entity data.
     */
    @Override
    public void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);

        this.setMemberIndex(
                input.getIntOr(
                        MEMBER_INDEX_TAG,
                        MODEL_USHER
                )
        );

        String ownerString =
                input.getString(OWNER_ID_TAG).orElse(null);

        if (ownerString != null) {
            try {
                this.ownerId = UUID.fromString(ownerString);
            } catch (IllegalArgumentException ignored) {
                this.ownerId = null;
            }
        }

        this.expireTick =
                input.getLongOr(
                        EXPIRE_TICK_TAG,
                        -1L
                );
    }

    @Override
    public void tick() {
        super.tick();

        // 15-second expiration.
        if (expireTick >= 0L
                && level().getGameTime() >= expireTick) {

            if (level() instanceof ServerLevel level) {
                ElementalEffects.spawnFurinaMemberDismissEffect(
                        level,
                        this
                );
            }

            discard();
            return;
        }

        if (attackCooldown > 0) {
            attackCooldown--;
        }

        if (level() instanceof ServerLevel level
                && tickCount % 3 == 0) {

            ElementalEffects.spawnFurinaMemberParticles(
                    level,
                    this
            );
        }
    }

    /**
     * Completely immune to damage.
     *
     * This includes attacks, projectiles, fire, explosions,
     * magic, environmental damage, owner damage, etc.
     */
    @Override
    public boolean isInvulnerableTo(
            ServerLevel level,
            DamageSource source
    ) {
        return true;
    }

    /**
     * Explicitly prevents fall damage.
     */
    @Override
    public boolean causeFallDamage(
            double fallDistance,
            float damageMultiplier,
            DamageSource damageSource
    ) {
        return false;
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        ServerPlayer owner = getOwner();

        return owner != null
                && target != owner
                && !(target instanceof SalonMemberEntity)
                && super.canAttack(target);
    }

    @Override
    public boolean doHurtTarget(
            ServerLevel level,
            Entity target
    ) {
        ServerPlayer owner = getOwner();

        if (!(target instanceof LivingEntity living)
                || owner == null) {
            return false;
        }

        // Creative or Spectator.
        if (!isOwnerSurvivalOrAdventure(owner)) {
            float damage = owner.getMaxHealth() * 0.20F;

            living.hurt(
                    owner.damageSources().mobAttack(owner),
                    damage
            );

            ElementalEffects.spawnFurinaMemberAttackEffect(
                    level,
                    this,
                    living
            );

            return true;
        }

        // Survival or Adventure.
        float maxHealth = owner.getMaxHealth();
        float minimumHealth = maxHealth * 0.50F;

        if (owner.getHealth() <= minimumHealth) {
            return false;
        }

        float cost = Math.min(
                maxHealth * 0.02F,
                owner.getHealth() - minimumHealth
        );

        owner.setHealth(
                owner.getHealth() - cost
        );

        float damage = maxHealth * 0.08F;

        if (cost > 0.0F) {
            damage *= 1.5F;

            owner.addEffect(
                    new MobEffectInstance(
                            MobEffects.REGENERATION,
                            35,
                            0,
                            false,
                            false,
                            true
                    )
            );
        }

        living.hurt(
                owner.damageSources().mobAttack(owner),
                damage
        );

        ElementalEffects.spawnFurinaMemberAttackEffect(
                level,
                this,
                living
        );

        return true;
    }

    private boolean isOwnerSurvivalOrAdventure(
            ServerPlayer owner
    ) {
        GameType gameType =
                owner.gameMode.getGameModeForPlayer();

        return gameType == GameType.SURVIVAL
                || gameType == GameType.ADVENTURE;
    }

    @Override
    public ItemStack getPickResult() {
        return ItemStack.EMPTY;
    }
}