package mh837.gile;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

public class GileModParticleTypes {
    // Misc
    public static final SimpleParticleType GHOSTLY_BUBBLE = FabricParticleTypes.simple();
    public static final SimpleParticleType GLITTER = FabricParticleTypes.simple();
    public static final SimpleParticleType END_FLAME = FabricParticleTypes.simple();
    public static final SimpleParticleType FEATHER = FabricParticleTypes.simple();
    public static final SimpleParticleType ROPE = FabricParticleTypes.simple();
    public static final SimpleParticleType GUARD_SWEEP = FabricParticleTypes.simple();
    // Elemental
    public static final SimpleParticleType ANEMO = FabricParticleTypes.simple();
    public static final SimpleParticleType GEO = FabricParticleTypes.simple();
    public static final SimpleParticleType ELECTRO = FabricParticleTypes.simple();
    public static final SimpleParticleType DENDRO = FabricParticleTypes.simple();
    public static final SimpleParticleType HYDRO = FabricParticleTypes.simple();
    public static final SimpleParticleType PYRO = FabricParticleTypes.simple();
    public static final SimpleParticleType CRYO = FabricParticleTypes.simple();
    public static final SimpleParticleType LUNA = FabricParticleTypes.simple();
    // Legendary & Primordial
    public static final SimpleParticleType LIFE = FabricParticleTypes.simple();
    public static final SimpleParticleType SPACE = FabricParticleTypes.simple();
    public static final SimpleParticleType TIME = FabricParticleTypes.simple();
    public static final SimpleParticleType DEATH = FabricParticleTypes.simple();
    public static final SimpleParticleType PHANES = FabricParticleTypes.simple();

    public static void initialize() {
        // Misc
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "ghostly_bubble"), GHOSTLY_BUBBLE);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "glitter"), GLITTER);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "end_flame"), END_FLAME);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "feather"), FEATHER);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "rope"), ROPE);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "guard_sweep"), GUARD_SWEEP);
        // Elemental
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "anemo"), ANEMO);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "geo"), GEO);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "electro"), ELECTRO);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "dendro"), DENDRO);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "hydro"), HYDRO);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "pyro"), PYRO);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "cryo"), CRYO);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "luna"), LUNA);
        // Legendary & Primordial
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "life"), LIFE);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "space"), SPACE);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "time"), TIME);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "death"), DEATH);
        Registry.register(BuiltInRegistries.PARTICLE_TYPE, Identifier.fromNamespaceAndPath("gilemod", "phanes"), PHANES);

    }
}