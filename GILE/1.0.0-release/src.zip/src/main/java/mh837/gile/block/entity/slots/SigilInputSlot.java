package mh837.gile.block.entity.slots;

import mh837.gile.GileModTags;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class SigilInputSlot extends Slot {

    public SigilInputSlot(
            Container container,
            int slot,
            int x,
            int y
    ) {
        super(container, slot, x, y);
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return stack.is(GileModTags.Items.SIGIL_INPUT);
    }

    @Override
    public int getMaxStackSize() {return 1;}

}