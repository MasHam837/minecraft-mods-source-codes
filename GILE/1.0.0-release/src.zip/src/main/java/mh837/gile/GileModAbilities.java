package mh837.gile;

import mh837.gile.item.tool.FluttererUtil;
import mh837.gile.item.weapon.elemental.ElementalAbilities;
import mh837.gile.item.weapon.elemental.ElementalEffects;
import mh837.gile.item.weapon.elemental.ElementalWeaponItems;
import mh837.gile.item.weapon.legendary.LegendaryAbilities;
import mh837.gile.item.weapon.legendary.LegendaryEffects;
import mh837.gile.item.weapon.legendary.LegendaryWeaponItems;
import mh837.gile.item.weapon.primordial.DivineOblivion;
import mh837.gile.item.weapon.primordial.PhanesBlade;
import mh837.gile.item.weapon.primordial.PhanesGenesis;
import mh837.gile.network.ActiveAbilityPayload;
import mh837.gile.network.DivineAbilityPayload;
import mh837.gile.network.FluttererJumpPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class GileModAbilities {

    public static final Map<UUID, Long> STOMP_COOLDOWNS = new HashMap<>();

    public static void initialize() {

        // SPACE — FLUTTERER AIR JUMP
        PayloadTypeRegistry.serverboundPlay().register(FluttererJumpPayload.TYPE, FluttererJumpPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(FluttererJumpPayload.TYPE, (payload, context) -> {
                    context.server().execute(() -> {
                        ServerPlayer player = context.player();

                        if (!FluttererUtil.airJump(player)) {
                            return;
                        }

                        player.level().playSound(
                                null,
                                player.getX(),
                                player.getY(),
                                player.getZ(),
                                SoundEvents.WIND_CHARGE_BURST.value(),
                                SoundSource.PLAYERS,
                                0.25F,
                                1.0F + player.getRandom().nextFloat() * 0.5F
                        );

                        player.level().playSound(
                                null,
                                player.getX(),
                                player.getY(),
                                player.getZ(),
                                SoundEvents.WIND_CHARGE_THROW,
                                SoundSource.PLAYERS,
                                0.15F,
                                0.8F + player.getRandom().nextFloat() * 0.4F
                        );
                    });
                });
        ServerTickEvents.START_SERVER_TICK.register(server -> {for (ServerPlayer player : server.getPlayerList().getPlayers()) {FluttererUtil.updateGroundState(player);}});

        // V — ELEMENTAL / LEGENDARY / PHANES GENESIS / SHRINK INVISIBILITY / ENLARGE STOMP ABILITIES
        PayloadTypeRegistry.serverboundPlay().register(ActiveAbilityPayload.TYPE, ActiveAbilityPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActiveAbilityPayload.TYPE,
                (payload, context) -> { context.server().execute(() -> {ServerPlayer player = context.player();
                        if (!(player.level() instanceof ServerLevel level)) {return;} ItemStack heldItem = player.getMainHandItem();

                        // ELEMENTAL WEAPONS
                        if (heldItem.getItem() instanceof ElementalWeaponItems.DaybreakChronicles) {ElementalAbilities.VentiVortex.tryActivate(level, player);return;}
                        if (heldItem.getItem() instanceof ElementalWeaponItems.VortexVanquisher) {ElementalAbilities.ZhongLiBarricade.tryActivate(level, player);return;}
                        if (heldItem.getItem() instanceof ElementalWeaponItems.EngulfingLightning) {ElementalAbilities.RaidenShogunThunder.tryActivate(level, player);return;}
                        if (heldItem.getItem() instanceof ElementalWeaponItems.ThousandFloatingDreams) {ElementalAbilities.NahidaSowing.tryActivate(level, player);return;}
                        if (heldItem.getItem() instanceof ElementalWeaponItems.SplendorOfTranquilWaters) {ElementalAbilities.FurinaSalonMembers.tryActivate(level, player);return;}
                        if (heldItem.getItem() instanceof ElementalWeaponItems.ThousandBlazingSuns) {ElementalAbilities.MavuikaRage.tryActivate(level, player);return;}
                        if (heldItem.getItem() instanceof ElementalWeaponItems.HiemalMandate) {ElementalAbilities.TsaritsasBlizzard.tryActivate(level, player);return;}
                        if (heldItem.getItem() instanceof ElementalWeaponItems.NocturnesCurtainCall) {ElementalAbilities.LunarDomain.tryActivate(level, player);return;}

                        // LEGENDARY WEAPONS
                        if (heldItem.getItem() instanceof LegendaryWeaponItems.TomeOfNaberius) {
                            LegendaryAbilities.NaberiusBenediction.activate(level, player, heldItem);return;}

                        if (heldItem.getItem() instanceof LegendaryWeaponItems.PalmOfAsmoday) {LegendaryAbilities.AsmodayEventHorizon.activate(level, player, heldItem);return;}
                        if (heldItem.getItem() instanceof LegendaryWeaponItems.HourglassOfIstaroth) {
                            LegendaryAbilities.IstarothTimeManipulation.activate(level, player, heldItem);return;}
                        if (heldItem.getItem() instanceof LegendaryWeaponItems.ScytheOfRonova) {LegendaryAbilities.RonovaLifeSteal.activate(level, player, heldItem);
                            LegendaryEffects.tick(level, player);LegendaryAbilities.RonovaLifeSteal.tick(level);return;}

                        if (heldItem.getItem() instanceof PhanesBlade) {PhanesGenesis.activate(level, player, heldItem);return;}

                        // SHRINK
                        if (player.hasEffect(GileModEffects.SHRINK)) {
                            if (player.hasEffect(MobEffects.INVISIBILITY)) { player.removeEffect(MobEffects.INVISIBILITY);
                                player.sendSystemMessage(Component.translatable("message.gilemod.shrink_visibility_off"), true);} else {
                                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, MobEffectInstance.INFINITE_DURATION, 0,
                                                false, false, true));player.sendSystemMessage(Component.translatable(
                                                        "message.gilemod.shrink_visibility_on"), true);}return;}

                        // ENLARGE — LUNAR STOMP
                        if (player.hasEffect(GileModEffects.ENLARGE)) {long currentTime = System.currentTimeMillis();
                            long cooldownEnd = STOMP_COOLDOWNS.getOrDefault(player.getUUID(), 0L);
                            if (currentTime < cooldownEnd) {long remaining = Math.max(1L, (cooldownEnd - currentTime + 999L) / 1000L);
                                player.sendSystemMessage(Component.translatable("message.gilemod.stomp_cooldown",
                                        remaining).withStyle(ChatFormatting.RED), true);return;}
                            STOMP_COOLDOWNS.put(player.getUUID(), currentTime + 3000L);
                            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                                    SoundEvents.IRON_GOLEM_HURT, SoundSource.PLAYERS, 1.0F, 0.5F);

                            for (int i = 0; i < 360; i += 15) {double angle = Math.toRadians(i);
                                double x = player.getX() + Math.cos(angle) * 4.0D; double z = player.getZ() + Math.sin(angle) * 4.0D;
                                level.sendParticles(ParticleTypes.LARGE_SMOKE, x, player.getY() + 0.1D, z,
                                        2, 0.0D, 0.0D, 0.0D, 0.05D);}

                            AABB area = player.getBoundingBox().inflate(5.0D, 2.0D, 5.0D);
                            List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class,
                                            area, entity -> entity != player && entity.isAlive() && !entity.isSpectator());
                            for (LivingEntity target : targets) {target.hurtServer(level, level.damageSources().playerAttack(player), 4.0F);
                                target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS,
                                        100, 1, false, false)); double dx = target.getX() - player.getX();
                                double dz = target.getZ() - player.getZ();target.knockback(1.5D, -dx, -dz);}
                            player.sendSystemMessage(Component.translatable("message.gilemod.stomp"), true);}});});

        // B — DIVINE OBLIVION
        PayloadTypeRegistry.serverboundPlay().register(DivineAbilityPayload.TYPE, DivineAbilityPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(DivineAbilityPayload.TYPE,
                (payload, context) -> {context.server().execute(() -> {ServerPlayer player = context.player();
                        if (!(player.level() instanceof ServerLevel level)) { return; } ItemStack heldItem = player.getMainHandItem();
                        if (!(heldItem.getItem() instanceof PhanesBlade)) {return;} DivineOblivion.activate(level, player, heldItem);});});

        // SERVER TICK EVENTS
        ServerTickEvents.END_SERVER_TICK.register(server -> {for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (!player.hasEffect(GileModEffects.SHRINK)) {MobEffectInstance invisibility = player.getEffect(MobEffects.INVISIBILITY);
                    if (invisibility != null && invisibility.isInfiniteDuration()) player.removeEffect(MobEffects.INVISIBILITY);}}

            for (ServerLevel level : server.getAllLevels()) {
                ElementalAbilities.VentiVortex.tick(level);
                ElementalAbilities.ZhongLiBarricade.tick(level);
                ElementalAbilities.RaidenShogunThunder.tick(level);
                ElementalAbilities.NahidaSowing.tick(level);
                ElementalAbilities.FurinaSalonMembers.tick(level);
                ElementalAbilities.MavuikaRage.tick(level);
                ElementalAbilities.TsaritsasBlizzard.tick(level);
                ElementalAbilities.LunarDomain.tick(level);
                ElementalWeaponItems.NocturnesCurtainCall.cleanupNocturneModifiers(level);

                for (ServerPlayer player : level.players()) { ItemStack stack = player.getMainHandItem();

                    if (stack.getItem() instanceof ElementalWeaponItems.DaybreakChronicles) {ElementalEffects.ventiFootParticles(level, player);}
                    if (stack.getItem() instanceof ElementalWeaponItems.VortexVanquisher) {ElementalEffects.zhongliFootParticles(level, player);}
                    if (stack.getItem() instanceof ElementalWeaponItems.EngulfingLightning) {ElementalEffects.raidenFootParticles(level, player);}
                    if (stack.getItem() instanceof ElementalWeaponItems.ThousandFloatingDreams) {ElementalEffects.nahidaFootParticles(level, player);
                        player.removeEffect(MobEffects.POISON); player.removeEffect(MobEffects.WITHER);}
                    if (stack.getItem() instanceof ElementalWeaponItems.SplendorOfTranquilWaters && player.tickCount % 2 == 0)
                    { ElementalEffects.spawnFurinaFootWaves(level, player); }
                    if (stack.getItem() instanceof ElementalWeaponItems.SplendorOfTranquilWaters)
                    { player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 10, 0, false, false, true)); }
                    if (stack.getItem() instanceof ElementalWeaponItems.ThousandBlazingSuns) {ElementalEffects.mavuikaFootParticles(level, player);
                    player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 10, 0, false, false, true));}
                    if (stack.getItem() instanceof ElementalWeaponItems.HiemalMandate) {ElementalEffects.tsaritsaFootParticles(level, player);}
                    if (stack.getItem() instanceof ElementalWeaponItems.NocturnesCurtainCall) {ElementalEffects.columbinaFootParticles(level, player);
                    player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 10, 0, false, false, true));}

                }
            }
        });
    }
}