package mh837.gile.item.weapon.legendary;

import mh837.gile.GileModDataComponents;
import mh837.gile.GileModParticleTypes;

import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

public final class LegendaryAbilities { private LegendaryAbilities() {}

    // LIFE — NABERIUS BENEDICTIONO + HEALING UTILITY
    public static final class NaberiusBenediction {

        private NaberiusBenediction() {}

        private static final double RADIUS = 8.0D;

        private static final int DURATION = 200; // 10 seconds
        private static final int COOLDOWN = 240; // 12 seconds

        private static final int REGENERATION_AMPLIFIER = 2;

        public static void activate(
                ServerLevel level,
                ServerPlayer player,
                ItemStack stack
        ) {

            if (player.getCooldowns().isOnCooldown(stack)) {
                int remainingTicks = getRemainingCooldown(
                        player,
                        stack,
                        COOLDOWN
                );

                int seconds = Math.max(
                        1,
                        (remainingTicks + 19) / 20
                );

                player.sendSystemMessage(
                        Component.translatable(
                                "message.gilemod.naberius_benediction_cooldown",
                                seconds
                        ),
                        true
                );

                return;
            }

            // Heal EVERY living entity in the radius.
            // This deliberately includes enemies.
            AABB area = player.getBoundingBox().inflate(RADIUS);

            List<LivingEntity> targets =
                    level.getEntitiesOfClass(
                            LivingEntity.class,
                            area,
                            entity ->
                                    entity.isAlive()
                                            && !entity.isSpectator()
                    );

            for (LivingEntity target : targets) {
                target.addEffect(
                        new MobEffectInstance(
                                MobEffects.REGENERATION,
                                DURATION,
                                REGENERATION_AMPLIFIER,
                                false,
                                true,
                                true
                        )
                );
            }

            // Special Life visuals.
            spawnBenedictionEffects(level, player);

            level.playSound(
                    null,
                    player.blockPosition(),
                    SoundEvents.BEACON_ACTIVATE,
                    SoundSource.PLAYERS,
                    1.2F,
                    1.25F
            );

            level.playSound(
                    null,
                    player.blockPosition(),
                    SoundEvents.PLAYER_LEVELUP,
                    SoundSource.PLAYERS,
                    0.65F,
                    1.35F
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.naberius_benediction_activated"
                    ),
                    true
            );

            GileModTriggers.ABILITY_LIFE.trigger(player);

            player.getCooldowns().addCooldown(stack, COOLDOWN);
        }

        private static int getRemainingCooldown(
                ServerPlayer player,
                ItemStack stack,
                int maxCooldown
        ) {
            float percent =
                    player.getCooldowns()
                            .getCooldownPercent(stack, 0.0F);

            return Math.max(
                    1,
                    Math.round(percent * maxCooldown)
            );
        }

        private static void spawnBenedictionEffects(
                ServerLevel level,
                ServerPlayer player
        ) {
            double x = player.getX();
            double y = player.getY();
            double z = player.getZ();

            // =========================================================
            // CENTRAL LIFE BLOOM
            // =========================================================

            level.sendParticles(
                    GileModParticleTypes.LIFE,
                    x,
                    y + 0.9D,
                    z,
                    12,
                    0.45D,
                    0.8D,
                    0.45D,
                    0.02D
            );

            // =========================================================
            // LARGE 8-BLOCK LIFE RING
            // =========================================================
            // The technical ability radius is 8 blocks.
            // Keep the visual ring slightly inside it.

            final double visualRadius = 7.5D;
            final int ringPoints = 40;

            for (int i = 0; i < ringPoints; i++) {
                double angle =
                        Math.PI * 2.0D * i / ringPoints;

                double px =
                        x + Math.cos(angle) * visualRadius;

                double pz =
                        z + Math.sin(angle) * visualRadius;

                level.sendParticles(
                        GileModParticleTypes.LIFE,
                        px,
                        y + 0.08D,
                        pz,
                        1,
                        0.04D,
                        0.025D,
                        0.04D,
                        0.005D
                );
            }

            // =========================================================
            // SECONDARY INNER RING
            // =========================================================
            // Much lighter than the outer ring.

            final double innerRadius = 4.0D;
            final int innerPoints = 20;

            for (int i = 0; i < innerPoints; i++) {
                double angle =
                        Math.PI * 2.0D * i / innerPoints;

                level.sendParticles(
                        ParticleTypes.HAPPY_VILLAGER,
                        x + Math.cos(angle) * innerRadius,
                        y + 0.12D,
                        z + Math.sin(angle) * innerRadius,
                        1,
                        0.04D,
                        0.025D,
                        0.04D,
                        0.005D
                );
            }

            // =========================================================
            // SIX LIFE PETALS
            // =========================================================

            for (int i = 0; i < 6; i++) {
                double angle =
                        Math.PI * 2.0D * i / 6.0D;

                double radius = 1.1D;

                double px =
                        x + Math.cos(angle) * radius;

                double pz =
                        z + Math.sin(angle) * radius;

                level.sendParticles(
                        GileModParticleTypes.LIFE,
                        px,
                        y + 0.4D,
                        pz,
                        2,
                        0.08D,
                        0.3D,
                        0.08D,
                        0.01D
                );
            }

            // =========================================================
            // HEARTS
            // =========================================================

            level.sendParticles(
                    ParticleTypes.HEART,
                    x,
                    y + 1.1D,
                    z,
                    8,
                    0.7D,
                    0.7D,
                    0.7D,
                    0.015D
            );

            // =========================================================
            // FEW ASCENDING LIFE SPARKS
            // =========================================================

            for (int i = 0; i < 6; i++) {
                double angle =
                        Math.random() * Math.PI * 2.0D;

                double radius =
                        0.5D + Math.random() * 1.0D;

                level.sendParticles(
                        GileModParticleTypes.LIFE,
                        x + Math.cos(angle) * radius,
                        y + 0.2D + Math.random() * 0.6D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.01D,
                        0.05D,
                        0.01D,
                        0.01D
                );
            }
        }
    }
    public static final class NaberiusHealing {

        private NaberiusHealing() {}

        private static final int COOLDOWN = 120; // 6 seconds

        public static void touch(
                ServerLevel level,
                ServerPlayer player,
                LivingEntity target,
                ItemStack stack
        ) {
            // =========================================================
            // COOLDOWN
            // =========================================================

            if (player.getCooldowns().isOnCooldown(stack)) {
                int remainingTicks = Math.max(
                        1,
                        Math.round(
                                player.getCooldowns()
                                        .getCooldownPercent(stack, 0.0F)
                                        * COOLDOWN
                        )
                );

                int seconds = Math.max(
                        1,
                        (remainingTicks + 19) / 20
                );

                player.sendSystemMessage(
                        Component.translatable(
                                "message.gilemod.naberius_life_utility_cooldown",
                                seconds
                        ),
                        true
                );

                return;
            }

            // =========================================================
            // TARGET
            // =========================================================
            // Entity clicked -> heal that entity.
            // Empty click -> heal the caster.

            LivingEntity healTarget =
                    target != null
                            ? target
                            : player;

            if (!healTarget.isAlive()) {
                return;
            }

            boolean selfHeal =
                    healTarget == player;

            // =========================================================
            // HEAL
            // =========================================================

            healTarget.addEffect(
                    new MobEffectInstance(
                            MobEffects.INSTANT_HEALTH,
                            1,
                            0,
                            false,
                            true,
                            true
                    )
            );

            // =========================================================
            // VISUALS
            // =========================================================

            spawnTouchEffects(
                    level,
                    healTarget,
                    selfHeal
            );

            // =========================================================
            // SOUND
            // =========================================================

            if (selfHeal) {

                // Warm, intimate sound for healing yourself.
                level.playSound(
                        null,
                        healTarget.blockPosition(),
                        SoundEvents.ENCHANTMENT_TABLE_USE,
                        SoundSource.PLAYERS,
                        1.0F,
                        1.05F
                );

                level.playSound(
                        null,
                        healTarget.blockPosition(),
                        SoundEvents.ALLAY_ITEM_GIVEN,
                        SoundSource.PLAYERS,
                        0.8F,
                        1.25F
                );

            } else {

                // More distinct "Life being given" sound for another entity.
                level.playSound(
                        null,
                        healTarget.blockPosition(),
                        SoundEvents.ENCHANTMENT_TABLE_USE,
                        SoundSource.PLAYERS,
                        0.9F,
                        1.35F
                );

                level.playSound(
                        null,
                        healTarget.blockPosition(),
                        SoundEvents.PLAYER_ATTACK_STRONG,
                        SoundSource.PLAYERS,
                        0.7F,
                        1.6F
                );
            }

            // =========================================================
            // COOLDOWN
            // =========================================================

            player.getCooldowns().addCooldown(
                    stack,
                    COOLDOWN
            );
        }

        private static void spawnTouchEffects(
                ServerLevel level,
                LivingEntity target,
                boolean selfHeal
        ) {
            double x = target.getX();
            double y = target.getY() + target.getBbHeight() * 0.5D;
            double z = target.getZ();

            // =========================================================
            // SMALL LIFE BURST
            // =========================================================

            level.sendParticles(
                    GileModParticleTypes.LIFE,
                    x,
                    y,
                    z,
                    selfHeal ? 10 : 7,
                    0.22D,
                    0.4D,
                    0.22D,
                    0.015D
            );

            // =========================================================
            // HEARTS
            // =========================================================

            level.sendParticles(
                    ParticleTypes.HEART,
                    x,
                    y + 0.3D,
                    z,
                    selfHeal ? 5 : 3,
                    0.22D,
                    0.3D,
                    0.22D,
                    0.01D
            );

            // =========================================================
            // SMALL LIFE RING
            // =========================================================

            double ringY =
                    target.getY() + 0.15D;

            double radius =
                    selfHeal ? 0.75D : 0.6D;

            int ringPoints =
                    selfHeal ? 16 : 12;

            for (int i = 0; i < ringPoints; i++) {
                double angle =
                        Math.PI * 2.0D * i / ringPoints;

                level.sendParticles(
                        GileModParticleTypes.LIFE,
                        x + Math.cos(angle) * radius,
                        ringY,
                        z + Math.sin(angle) * radius,
                        1,
                        0.01D,
                        0.01D,
                        0.01D,
                        0.003D
                );
            }

            // =========================================================
            // SMALL HAPPY VILLAGER ACCENT
            // =========================================================

            level.sendParticles(
                    ParticleTypes.HAPPY_VILLAGER,
                    x,
                    y,
                    z,
                    selfHeal ? 8 : 5,
                    0.25D,
                    0.4D,
                    0.25D,
                    0.015D
            );

            // =========================================================
            // SELF-HEAL LIFE SPIRAL
            // =========================================================

            if (selfHeal) {
                for (int i = 0; i < 16; i++) {
                    double progress =
                            i / 16.0D;

                    double angle =
                            progress * Math.PI * 4.0D;

                    double spiralRadius =
                            0.12D + progress * 0.35D;

                    double px =
                            target.getX()
                                    + Math.cos(angle) * spiralRadius;

                    double py =
                            target.getY()
                                    + 0.1D
                                    + progress * target.getBbHeight();

                    double pz =
                            target.getZ()
                                    + Math.sin(angle) * spiralRadius;

                    level.sendParticles(
                            GileModParticleTypes.LIFE,
                            px,
                            py,
                            pz,
                            1,
                            0.01D,
                            0.01D,
                            0.01D,
                            0.005D
                    );
                }
            }
        }
    }

    // ASMODAY EVENT HORIZON + SPACE UTILITY
    public static final class AsmodayEventHorizon { private AsmodayEventHorizon() {}
        private static final int COOLDOWN = 240; // 12 seconds
        private static final double RADIUS = 7.0D;
        private static final int DARKNESS_DURATION = 120; // 9 sec
        private static final int BLINDNESS_DURATION = 180; // 6 sec
        private static final int STASIS_DURATION = 50; // 2.5 sec
        private static final float INITIAL_DAMAGE = 4.0F;
        private static final double TELEPORT_DISTANCE = 10.0D;
        private static final Map<UUID, EventHorizonData> ACTIVE_EVENT_HORIZONS = new HashMap<>();
        private record EventHorizonData(Vec3 center, long collapseTick) {}
        public static void activate(
                ServerLevel level,
                ServerPlayer player,
                ItemStack stack
        ) {
            if (player.getCooldowns().isOnCooldown(stack)) {
                sendCooldownMessage(
                        player,
                        stack
                );

                return;
            }

            Vec3 center =
                    player.position()
                            .add(0.0D, 0.6D, 0.0D);

            AABB area =
                    new AABB(
                            center.x - RADIUS,
                            center.y - RADIUS,
                            center.z - RADIUS,
                            center.x + RADIUS,
                            center.y + RADIUS,
                            center.z + RADIUS
                    );

            List<LivingEntity> targets =
                    level.getEntitiesOfClass(
                            LivingEntity.class,
                            area,
                            entity ->
                                    entity.isAlive()
                                            && entity != player
                                            && !(entity instanceof ServerPlayer other
                                            && player.isAlliedTo(other))
                    );

            /*
             * Direction the caster is looking.
             *
             * Normalize it so the displacement is exactly 5 blocks.
             */
            Vec3 lookDirection =
                    player.getLookAngle().normalize();

            /*
             * Move every entity in the Event Horizon
             * five blocks in the caster's looking direction.
             */
            for (LivingEntity target : targets) {

                Vec3 oldPosition =
                        target.position();

                Vec3 desiredPosition =
                        oldPosition.add(
                                lookDirection.scale(
                                        TELEPORT_DISTANCE
                                )
                        );

                Vec3 destination =
                        findSafeTeleportPosition(
                                level,
                                target,
                                desiredPosition
                        );

                if (destination != null) {

                    target.teleportTo(
                            destination.x,
                            destination.y,
                            destination.z
                    );

                    spawnTargetTeleportEffect(
                            level,
                            oldPosition,
                            destination
                    );
                }

                /*
                 * Spatial disorientation.
                 */
                target.addEffect(
                        new MobEffectInstance(
                                MobEffects.DARKNESS,
                                DARKNESS_DURATION,
                                0,
                                false,
                                true,
                                true
                        )
                );

                target.addEffect(
                        new MobEffectInstance(
                                MobEffects.BLINDNESS,
                                BLINDNESS_DURATION,
                                0,
                                false,
                                true,
                                true
                        )
                );

                target.addEffect(
                        new MobEffectInstance(
                                MobEffects.SLOWNESS,
                                STASIS_DURATION,
                                4,
                                false,
                                true,
                                true
                        )
                );

                /*
                 * Initial spatial damage.
                 */
                target.hurt(
                        level.damageSources().magic(),
                        INITIAL_DAMAGE
                );
            }

            /*
             * Main Event Horizon visual.
             */
            spawnEventHorizon(
                    level,
                    center
            );

            /*
             * Activation sound.
             */
            level.playSound(
                    null,
                    center.x,
                    center.y,
                    center.z,
                    SoundEvents.RESPAWN_ANCHOR_CHARGE,
                    SoundSource.PLAYERS,
                    1.2F,
                    0.45F
            );

            level.playSound(
                    null,
                    center.x,
                    center.y,
                    center.z,
                    SoundEvents.END_PORTAL_SPAWN,
                    SoundSource.PLAYERS,
                    0.7F,
                    0.8F
            );

            /*
             * Delayed collapse.
             */
            ACTIVE_EVENT_HORIZONS.put(
                    player.getUUID(),
                    new EventHorizonData(
                            center,
                            level.getGameTime() + STASIS_DURATION
                    )
            );

            player.getCooldowns().addCooldown(
                    stack,
                    COOLDOWN
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.asmoday_event_horizon_activated"
                    ),
                    true
            );

            GileModTriggers.ABILITY_SPACE.trigger(player);
        }
        private static Vec3 findSafeTeleportPosition(
                ServerLevel level,
                LivingEntity entity,
                Vec3 desired
        ) {
            BlockPos base =
                    BlockPos.containing(desired);

            /*
             * Try the desired position first,
             * then a few vertical adjustments.
             */
            for (int dy = 2; dy >= -2; dy--) {

                BlockPos feet =
                        base.above(dy);

                BlockPos head =
                        feet.above();

                BlockState feetState =
                        level.getBlockState(feet);

                BlockState headState =
                        level.getBlockState(head);

                BlockState belowState =
                        level.getBlockState(feet.below());

                /*
                 * Need solid ground.
                 */
                if (!belowState.isSolid()) {
                    continue;
                }

                /*
                 * Feet and head must be clear.
                 */
                if (!feetState
                        .getCollisionShape(level, feet)
                        .isEmpty()) {
                    continue;
                }

                if (!headState
                        .getCollisionShape(level, head)
                        .isEmpty()) {
                    continue;
                }

                Vec3 destination =
                        new Vec3(
                                desired.x,
                                feet.getY(),
                                desired.z
                        );

                AABB movedBox =
                        entity.getBoundingBox()
                                .move(
                                        destination.x - entity.getX(),
                                        destination.y - entity.getY(),
                                        destination.z - entity.getZ()
                                );

                if (level.noCollision(entity, movedBox)) {
                    return destination;
                }
            }

            return null;
        }
        private static void spawnTargetTeleportEffect(
                ServerLevel level,
                Vec3 from,
                Vec3 to
        ) {
            /*
             * Departure.
             */
            level.sendParticles(
                    ParticleTypes.REVERSE_PORTAL,
                    from.x,
                    from.y + 0.6D,
                    from.z,
                    6,
                    0.18D,
                    0.35D,
                    0.18D,
                    0.04D
            );

            /*
             * Arrival.
             */
            level.sendParticles(
                    ParticleTypes.REVERSE_PORTAL,
                    to.x,
                    to.y + 0.6D,
                    to.z,
                    8,
                    0.2D,
                    0.4D,
                    0.2D,
                    0.05D
            );

            /*
             * Small amount of custom SPACE.
             */
            level.sendParticles(
                    GileModParticleTypes.SPACE,
                    to.x,
                    to.y + 0.6D,
                    to.z,
                    3,
                    0.12D,
                    0.25D,
                    0.12D,
                    0.01D
            );

            level.playSound(
                    null,
                    to.x,
                    to.y,
                    to.z,
                    SoundEvents.ENDERMAN_TELEPORT,
                    SoundSource.PLAYERS,
                    0.55F,
                    0.65F
                            + level.getRandom().nextFloat() * 0.25F
            );
        }
        private static void spawnEventHorizon(
                ServerLevel level,
                Vec3 center
        ) {
            // =========================================================
            // CENTRAL SPATIAL CORE
            // =========================================================

            level.sendParticles(
                    GileModParticleTypes.SPACE,
                    center.x,
                    center.y,
                    center.z,
                    12,
                    0.45D,
                    0.45D,
                    0.45D,
                    0.01D
            );

            // =========================================================
            // REVERSE PORTAL CORE
            // =========================================================

            level.sendParticles(
                    ParticleTypes.REVERSE_PORTAL,
                    center.x,
                    center.y,
                    center.z,
                    35,
                    0.65D,
                    0.65D,
                    0.65D,
                    0.08D
            );

            // =========================================================
            // LARGE SPATIAL RING
            // =========================================================

            double radius = RADIUS * 0.9D;
            int points = 48;

            for (int i = 0; i < points; i++) {
                double angle =
                        Math.PI * 2.0D * i / points;

                double x =
                        center.x + Math.cos(angle) * radius;

                double z =
                        center.z + Math.sin(angle) * radius;

                level.sendParticles(
                        ParticleTypes.REVERSE_PORTAL,
                        x,
                        center.y + 0.08D,
                        z,
                        1,
                        0.04D,
                        0.03D,
                        0.04D,
                        0.025D
                );
            }

            // =========================================================
            // SECONDARY INNER RING
            // =========================================================

            double innerRadius = RADIUS * 0.55D;

            for (int i = 0; i < 24; i++) {
                double angle =
                        Math.PI * 2.0D * i / 24.0D;

                level.sendParticles(
                        ParticleTypes.SMOKE,
                        center.x + Math.cos(angle) * innerRadius,
                        center.y + 0.15D,
                        center.z + Math.sin(angle) * innerRadius,
                        1,
                        0.02D,
                        0.02D,
                        0.02D,
                        0.005D
                );
            }

            // =========================================================
            // VERTICAL SPACE DISTORTION
            // =========================================================

            for (int i = 0; i < 12; i++) {
                double angle =
                        Math.PI * 2.0D * i / 12.0D;

                double radiusOffset =
                        0.8D + (i % 3) * 0.35D;

                double px =
                        center.x
                                + Math.cos(angle) * radiusOffset;

                double pz =
                        center.z
                                + Math.sin(angle) * radiusOffset;

                level.sendParticles(
                        ParticleTypes.REVERSE_PORTAL,
                        px,
                        center.y + 0.3D + (i % 4) * 0.35D,
                        pz,
                        1,
                        0.02D,
                        0.04D,
                        0.02D,
                        0.03D
                );
            }
        }
        private static void sendCooldownMessage(ServerPlayer player, ItemStack stack) {
            final int cooldown = COOLDOWN;

            int remainingTicks =
                    Math.max(
                            1,
                            Math.round(
                                    player.getCooldowns()
                                            .getCooldownPercent(
                                                    stack,
                                                    0.0F
                                            )
                                            * cooldown
                            )
                    );

            int seconds =
                    Math.max(
                            1,
                            (remainingTicks + 19) / 20
                    );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.asmoday_event_horizon_cooldown",
                            seconds
                    ),
                    true
            );
        }
    }
    public static final class AsmodaySpace { private AsmodaySpace() {}
        private static final int COOLDOWN = 120; // 6 seconds
        private static final double MAX_DISTANCE = 32.0D;
        private static final float EXTRA_DAMAGE = 2.0F;
        private static final int DARKNESS_DURATION = 60;
        private static final int BLINDNESS_DURATION = 120;
        public static boolean activate(
                ServerLevel level,
                ServerPlayer player,
                ItemStack stack
        ) {
            if (player.isSpectator()) {
                return false;
            }

            if (player.getCooldowns().isOnCooldown(stack)) {
                sendCooldownMessage(
                        player,
                        stack
                );

                return false;
            }

            HitResult hit =
                    player.pick(
                            MAX_DISTANCE,
                            0.0F,
                            false
                    );

            if (!(hit instanceof BlockHitResult blockHit)) {
                return false;
            }

            BlockPos hitPos =
                    blockHit.getBlockPos();

            Direction face =
                    blockHit.getDirection();

            BlockPos destinationBlock =
                    hitPos.relative(face);

            Vec3 destination =
                    findSafeDestination(
                            level,
                            player,
                            destinationBlock
                    );

            if (destination == null) {
                player.sendSystemMessage(
                        Component.translatable(
                                "message.gilemod.asmoday_space_no_safe_position"
                        )
                );

                return false;
            }

            Vec3 oldPosition =
                    player.position();

            /*
             * Teleport.
             */
            player.teleportTo(
                    destination.x,
                    destination.y,
                    destination.z
            );

            /*
             * Spatial displacement has a cost.
             */
            player.hurt(
                    level.damageSources().generic(),
                    EXTRA_DAMAGE
            );

            /*
             * Darkness.
             */
            player.addEffect(
                    new MobEffectInstance(
                            MobEffects.DARKNESS,
                            DARKNESS_DURATION,
                            0,
                            false,
                            true,
                            true
                    )
            );

            /*
             * Shorter Blindness.
             *
             * Darkness remains after Blindness fades,
             * making the effect feel like temporary spatial disorientation.
             */
            player.addEffect(
                    new MobEffectInstance(
                            MobEffects.BLINDNESS,
                            BLINDNESS_DURATION,
                            0,
                            false,
                            true,
                            true
                    )
            );

            /*
             * Teleport visuals.
             */
            spawnTeleportEffects(
                    level,
                    oldPosition,
                    destination
            );

            /*
             * Arrival sound.
             */
            level.playSound(
                    null,
                    destination.x,
                    destination.y,
                    destination.z,
                    SoundEvents.ENDERMAN_TELEPORT,
                    SoundSource.PLAYERS,
                    1.0F,
                    0.75F
                            + level.getRandom().nextFloat() * 0.25F
            );

            /*
             * Additional spatial arrival sound.
             */
            level.playSound(
                    null,
                    destination.x,
                    destination.y,
                    destination.z,
                    SoundEvents.RESPAWN_ANCHOR_CHARGE,
                    SoundSource.PLAYERS,
                    0.45F,
                    1.6F
            );

            player.getCooldowns().addCooldown(
                    stack,
                    COOLDOWN
            );

            return true;
        }
        private static Vec3 findSafeDestination(ServerLevel level, ServerPlayer player, BlockPos block) {
            /*
             * First try the exact block position.
             */
            Vec3 exact =
                    getSafePosition(
                            level,
                            player,
                            block
                    );

            if (exact != null) {
                return exact;
            }

            /*
             * If the exact position is unsafe, try the
             * neighboring positions around the selected block.
             *
             * This still keeps the teleport tied to the
             * block the player selected rather than randomly
             * teleporting elsewhere.
             */
            for (Direction direction :
                    Direction.Plane.HORIZONTAL) {

                BlockPos nearby =
                        block.relative(direction);

                Vec3 safe =
                        getSafePosition(
                                level,
                                player,
                                nearby
                        );

                if (safe != null) {
                    return safe;
                }
            }

            return null;
        }
        private static Vec3 getSafePosition(ServerLevel level, ServerPlayer player, BlockPos block) {
            /*
             * The player needs:
             *
             * 1. Solid ground beneath them.
             * 2. Empty feet space.
             * 3. Empty head space.
             */
            BlockPos ground =
                    block.below();

            if (!level.getBlockState(ground)
                    .isSolid()) {
                return null;
            }

            if (!level.getBlockState(block)
                    .getCollisionShape(level, block)
                    .isEmpty()) {
                return null;
            }

            BlockPos head =
                    block.above();

            if (!level.getBlockState(head)
                    .getCollisionShape(level, head)
                    .isEmpty()) {
                return null;
            }

            Vec3 destination =
                    new Vec3(
                            block.getX() + 0.5D,
                            block.getY(),
                            block.getZ() + 0.5D
                    );

            AABB box =
                    player.getBoundingBox()
                            .move(
                                    destination.x - player.getX(),
                                    destination.y - player.getY(),
                                    destination.z - player.getZ()
                            );

            if (!level.noCollision(player, box)) {
                return null;
            }

            return destination;
        }
        private static void spawnTeleportEffects(ServerLevel level, Vec3 from, Vec3 to) {
            /*
             * Departure.
             */
            level.sendParticles(
                    GileModParticleTypes.SPACE,
                    from.x,
                    from.y + 0.6D,
                    from.z,
                    12,
                    0.25D,
                    0.5D,
                    0.25D,
                    0.015D
            );

            /*
             * Arrival.
             */
            level.sendParticles(
                    GileModParticleTypes.SPACE,
                    to.x,
                    to.y + 0.6D,
                    to.z,
                    12,
                    0.25D,
                    0.5D,
                    0.25D,
                    0.015D
            );

            level.sendParticles(
                    ParticleTypes.REVERSE_PORTAL,
                    to.x,
                    to.y + 0.6D,
                    to.z,
                    10,
                    0.2D,
                    0.45D,
                    0.2D,
                    0.04D
            );
        }
        private static void sendCooldownMessage(ServerPlayer player, ItemStack stack) {
            final int cooldown = COOLDOWN;

            int remainingTicks =
                    Math.max(
                            1,
                            Math.round(
                                    player.getCooldowns()
                                            .getCooldownPercent(
                                                    stack,
                                                    0.0F
                                            )
                                            * cooldown
                            )
                    );

            int seconds =
                    Math.max(
                            1,
                            (remainingTicks + 19) / 20
                    );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.asmoday_space_utility_cooldown",
                            seconds
                    ),
                    true
            );
        }
    }

    // ISTAROTH TIME MANIPULATION
    public static final class IstarothTimeManipulation { private IstarothTimeManipulation() {}
        private static final int ABILITY_COOLDOWN = 240; // 12 seconds
        private static final int UTILITY_COOLDOWN = 120; // 6 seconds
        private static final double ABILITY_RADIUS = 8.0D;
        private static final int BONEMEAL_RADIUS = 3;
        private static final int ABILITY_DURATION = 200; // 10 seconds
        private static final int SLOW_AMPLIFIER = 1; // Slowness II
        private static final int SPEED_AMPLIFIER = 1; // Speed II
        public static boolean utility(ServerLevel level, ServerPlayer player, ItemStack stack) {
            if (player.isSpectator()) {
                return false;
            }

            if (player.getCooldowns().isOnCooldown(stack)) {
                sendUtilityCooldownMessage(
                        player,
                        stack
                );

                return false;
            }

            int successfulApplications = 0;

            BlockPos playerFeet =
                    player.blockPosition();

            for (int x = -BONEMEAL_RADIUS;
                 x <= BONEMEAL_RADIUS;
                 x++) {

                for (int z = -BONEMEAL_RADIUS;
                     z <= BONEMEAL_RADIUS;
                     z++) {

                    BlockPos column =
                            playerFeet.offset(x, 0, z);

                    /*
                     * Ground level.
                     */
                    BlockPos ground =
                            column.below();

                    if (tryBonemeal(
                            level,
                            player,
                            ground
                    )) {
                        successfulApplications++;
                    }

                    if (tryBonemeal(
                            level,
                            player,
                            column
                    )) {
                        successfulApplications++;
                    }
                }
            }

            if (successfulApplications == 0) {
                return false;
            }

            spawnBonemealEffects(
                    level,
                    player
            );

            level.playSound(
                    null,
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    SoundEvents.RESPAWN_ANCHOR_CHARGE,
                    SoundSource.PLAYERS,
                    1.0F,
                    0.55F
            );

            level.playSound(
                    null,
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    SoundEvents.ENCHANTMENT_TABLE_USE,
                    SoundSource.PLAYERS,
                    0.8F,
                    0.75F
            );

            player.getCooldowns().addCooldown(
                    stack,
                    UTILITY_COOLDOWN
            );

            return true;
        }
        private static void sendUtilityCooldownMessage(
                ServerPlayer player,
                ItemStack stack
        ) {
            int remainingTicks = Math.max(
                    1,
                    Math.round(
                            player.getCooldowns().getCooldownPercent(
                                    stack,
                                    0.0F
                            ) * UTILITY_COOLDOWN
                    )
            );

            int seconds = Math.max(
                    1,
                    (remainingTicks + 19) / 20
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.istaroth_time_utility_cooldown",
                            seconds
                    ),
                    true
            );
        }
        private static boolean tryBonemeal(ServerLevel level, ServerPlayer player, BlockPos pos) {
            if (!level.isLoaded(pos)) {
                return false;
            }

            BlockState state =
                    level.getBlockState(pos);

            if (state.isAir()) {
                return false;
            }

            ItemStack temporaryBoneMeal =
                    new ItemStack(Items.BONE_MEAL);

            return BoneMealItem.growCrop(
                    temporaryBoneMeal,
                    level,
                    pos
            );
        }
        private static void spawnBonemealEffects(ServerLevel level, ServerPlayer player) {
            double x = player.getX();
            double y = player.getY() + 0.1D;
            double z = player.getZ();

            /*
             * Green temporal burst.
             */
            level.sendParticles(
                    ParticleTypes.HAPPY_VILLAGER,
                    x,
                    y + 0.4D,
                    z,
                    20,
                    1.2D,
                    0.4D,
                    1.2D,
                    0.03D
            );

            /*
             * Time particles.
             */
            level.sendParticles(
                    GileModParticleTypes.TIME,
                    x,
                    y + 0.5D,
                    z,
                    18,
                    1.0D,
                    0.6D,
                    1.0D,
                    0.02D
            );

            /*
             * Small ring.
             */
            for (int i = 0; i < 20; i++) {

                double angle =
                        Math.PI * 2.0D * i / 20.0D;

                double radius = 1.2D;

                level.sendParticles(
                        GileModParticleTypes.TIME,
                        x + Math.cos(angle) * radius,
                        y + 0.05D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.01D,
                        0.01D,
                        0.01D,
                        0.0D
                );
            }
        }
        public static void activate(ServerLevel level, ServerPlayer player, ItemStack stack) {
            if (player.isSpectator()) {
                return;
            }

            if (player.getCooldowns().isOnCooldown(stack)) {
                sendCooldownMessage(
                        player,
                        stack
                );

                return;
            }

            AABB area =
                    player.getBoundingBox()
                            .inflate(ABILITY_RADIUS);

            List<LivingEntity> targets =
                    level.getEntitiesOfClass(
                            LivingEntity.class,
                            area,
                            entity ->
                                    entity.isAlive()
                                            && entity != player
                    );

            /*
             * Slow everything around the caster.
             */
            for (LivingEntity target : targets) {

                target.addEffect(
                        new MobEffectInstance(
                                MobEffects.SLOWNESS,
                                ABILITY_DURATION,
                                SLOW_AMPLIFIER,
                                false,
                                true,
                                true
                        )
                );
            }

            /*
             * Accelerate the caster.
             */
            player.addEffect(
                    new MobEffectInstance(
                            MobEffects.SPEED,
                            ABILITY_DURATION,
                            SPEED_AMPLIFIER,
                            false,
                            true,
                            true
                    )
            );

            /*
             * Temporal visuals.
             */
            spawnTimeAbilityEffects(
                    level,
                    player,
                    targets
            );

            level.playSound(
                    null,
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    SoundEvents.ENCHANTMENT_TABLE_USE,
                    SoundSource.PLAYERS,
                    1.0F,
                    0.55F
            );

            level.playSound(
                    null,
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    SoundEvents.EXPERIENCE_ORB_PICKUP,
                    SoundSource.PLAYERS,
                    0.8F,
                    0.65F
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.istaroth_time_manipulation_activated"
                    ),
                    true
            );

            GileModTriggers.ABILITY_TIME.trigger(player);

            player.getCooldowns().addCooldown(
                    stack,
                    ABILITY_COOLDOWN
            );
        }
        private static void spawnTimeAbilityEffects(ServerLevel level, ServerPlayer player, List<LivingEntity> targets) {
            double x = player.getX();
            double y = player.getY() + 0.5D;
            double z = player.getZ();

            /*
             * Central temporal burst.
             */
            level.sendParticles(
                    GileModParticleTypes.TIME,
                    x,
                    y,
                    z,
                    30,
                    0.8D,
                    0.9D,
                    0.8D,
                    0.025D
            );

            /*
             * Enchantment-like temporal particles.
             */
            level.sendParticles(
                    ParticleTypes.ENCHANT,
                    x,
                    y,
                    z,
                    30,
                    2.0D,
                    0.8D,
                    2.0D,
                    0.25D
            );

            /*
             * A clock-like ring around the player.
             */
            for (int i = 0; i < 32; i++) {

                double angle =
                        Math.PI * 2.0D * i / 32.0D;

                double radius = ABILITY_RADIUS;

                level.sendParticles(
                        GileModParticleTypes.TIME,
                        x + Math.cos(angle) * radius,
                        player.getY() + 0.05D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.01D,
                        0.01D,
                        0.01D,
                        0.0D
                );
            }

            /*
             * Mark affected enemies individually.
             */
            for (LivingEntity target : targets) {

                level.sendParticles(
                        ParticleTypes.ENCHANT,
                        target.getX(),
                        target.getY()
                                + target.getBbHeight() * 0.5D,
                        target.getZ(),
                        5,
                        0.25D,
                        0.4D,
                        0.25D,
                        0.05D
                );
            }
        }
        private static void sendCooldownMessage(ServerPlayer player, ItemStack stack) {
            int remainingTicks =
                    Math.max(
                            1,
                            Math.round(
                                    player.getCooldowns()
                                            .getCooldownPercent(
                                                    stack,
                                                    0.0F
                                            )
                                            * ABILITY_COOLDOWN
                            )
                    );

            int seconds =
                    Math.max(
                            1,
                            (remainingTicks + 19) / 20
                    );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.istaroth_time_manipulation_cooldown",
                            seconds
                    ),
                    true
            );
        }
    }

    // RONOVA LIFESTEAL
    public static final class RonovaLifeSteal {

        private RonovaLifeSteal() {}

        private static final int ABILITY_COOLDOWN = 240; // 12 seconds
        private static final int UTILITY_COOLDOWN = 120; // 6 seconds

        private static final double ABILITY_RADIUS = 7.0D;

        private static final float ABILITY_DAMAGE = 6.0F;

        private static final int POISON_DURATION = 160; // 8 seconds
        private static final int WITHER_DURATION = 100; // 5 seconds

        // ============================================================
        // MORTAL EXCHANGE — NORMAL SCYTHE HIT
        // ============================================================

        public static void mortalExchange(
                ServerLevel level,
                ServerPlayer attacker,
                LivingEntity target,
                ItemStack stack
        ) {
            if (!target.isAlive()) {
                return;
            }

            /*
             * hurtEnemy() is called AFTER the normal weapon hit.
             *
             * Therefore this is the enemy's REMAINING health.
             */
            float remainingHealth =
                    target.getHealth();

            if (remainingHealth <= 0.0F) {
                return;
            }

            /*
             * Half of the enemy's remaining health
             * comes back as damage to the wielder.
             */
            float reflectedDamage =
                    remainingHealth * 0.5F;

            /*
             * Show the exchange BEFORE the lethal blow.
             */
            LegendaryEffects.ronovaOnHit(
                    level,
                    attacker,
                    target,
                    remainingHealth
            );

            /*
             * ========================================================
             * KILL THE ENEMY
             * ========================================================
             *
             * We intentionally set health to zero rather than relying
             * on another damage event.
             *
             * This guarantees the Mortal Exchange kills the target,
             * including extremely high-health mobs and bosses.
             */
            target.setHealth(0.0F);

            /*
             * Death sound.
             */
            level.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.SOUL_ESCAPE,
                    SoundSource.PLAYERS,
                    1.0F,
                    0.7F
            );

            /*
             * ========================================================
             * REFLECT HALF THE REMAINING HEALTH
             * ========================================================
             *
             * This is intentionally allowed to kill the player.
             */
            if (reflectedDamage > 0.0F
                    && attacker.isAlive()) {

                attacker.hurt(
                        level.damageSources().magic(),
                        reflectedDamage
                );

                spawnCasterExchangeEffects(
                        level,
                        attacker
                );

                level.playSound(
                        null,
                        attacker.getX(),
                        attacker.getY(),
                        attacker.getZ(),
                        SoundEvents.WITHER_HURT,
                        SoundSource.PLAYERS,
                        0.8F,
                        0.65F
                );
            }
        }

        // ============================================================
        // ABILITY
        // ============================================================

        public static void activate(
                ServerLevel level,
                ServerPlayer player,
                ItemStack stack
        ) {
            if (player.isSpectator()) {
                return;
            }

            if (player.getCooldowns().isOnCooldown(stack)) {

                sendCooldownMessage(
                        player,
                        stack
                );

                return;
            }

            AABB area =
                    player.getBoundingBox()
                            .inflate(ABILITY_RADIUS);

            List<LivingEntity> targets =
                    level.getEntitiesOfClass(
                            LivingEntity.class,
                            area,
                            entity ->
                                    entity.isAlive()
                                            && entity != player
                    );

            /*
             * Death burst:
             *
             * damage + poison + wither.
             *
             * This does NOT perform Mortal Exchange.
             */
            for (LivingEntity target : targets) {

                target.hurt(
                        level.damageSources().playerAttack(player),
                        ABILITY_DAMAGE
                );

                target.addEffect(
                        new MobEffectInstance(
                                MobEffects.POISON,
                                POISON_DURATION,
                                1,
                                false,
                                true,
                                true
                        )
                );

                target.addEffect(
                        new MobEffectInstance(
                                MobEffects.WITHER,
                                WITHER_DURATION,
                                1,
                                false,
                                true,
                                true
                        )
                );

                spawnLifeStealTargetEffects(
                        level,
                        target
                );
            }

            /*
             * Large Death burst around caster.
             */
            spawnLifeStealEffects(
                    level,
                    player
            );

            /*
             * Ability sound.
             */
            level.playSound(
                    null,
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    SoundEvents.WITHER_SPAWN,
                    SoundSource.PLAYERS,
                    0.45F,
                    1.65F
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.ronova_lifesteal_activated"
                    ),
                    true
            );

            GileModTriggers.ABILITY_DEATH.trigger(player);

            player.getCooldowns().addCooldown(
                    stack,
                    ABILITY_COOLDOWN
            );
        }

        // ============================================================
        // EFFECTS — ON HIT
        // ============================================================

        private static void spawnCasterExchangeEffects(
                ServerLevel level,
                ServerPlayer player
        ) {
            double x = player.getX();
            double y = player.getY() + 0.5D;
            double z = player.getZ();

            level.sendParticles(
                    ParticleTypes.SCULK_SOUL,
                    x,
                    y,
                    z,
                    12,
                    0.3D,
                    0.6D,
                    0.3D,
                    0.02D
            );

            level.sendParticles(
                    GileModParticleTypes.DEATH,
                    x,
                    y,
                    z,
                    8,
                    0.25D,
                    0.45D,
                    0.25D,
                    0.015D
            );

            level.sendParticles(
                    ParticleTypes.DAMAGE_INDICATOR,
                    x,
                    y,
                    z,
                    6,
                    0.2D,
                    0.3D,
                    0.2D,
                    0.01D
            );
        }

        // ============================================================
        // EFFECTS — ABILITY CASTER
        // ============================================================

        private static void spawnLifeStealEffects(
                ServerLevel level,
                ServerPlayer player
        ) {
            double x = player.getX();

            double y =
                    player.getY() + 0.4D;

            double z = player.getZ();

            level.sendParticles(
                    GileModParticleTypes.DEATH,
                    x,
                    y,
                    z,
                    35,
                    1.2D,
                    0.8D,
                    1.2D,
                    0.025D
            );

            level.sendParticles(
                    ParticleTypes.SCULK_SOUL,
                    x,
                    y,
                    z,
                    25,
                    1.0D,
                    0.7D,
                    1.0D,
                    0.025D
            );

            level.sendParticles(
                    ParticleTypes.DAMAGE_INDICATOR,
                    x,
                    y,
                    z,
                    15,
                    1.0D,
                    0.6D,
                    1.0D,
                    0.015D
            );

            /*
             * Outer Death ring.
             */
            for (int i = 0; i < 24; i++) {

                double angle =
                        Math.PI * 2.0D * i / 24.0D;

                double radius =
                        1.5D;

                level.sendParticles(
                        GileModParticleTypes.DEATH,
                        x + Math.cos(angle) * radius,
                        player.getY() + 0.05D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.01D,
                        0.01D,
                        0.01D,
                        0.0D
                );
            }
        }

        // ============================================================
        // EFFECTS — ABILITY TARGET
        // ============================================================

        private static void spawnLifeStealTargetEffects(
                ServerLevel level,
                LivingEntity target
        ) {
            double x = target.getX();

            double y =
                    target.getY()
                            + target.getBbHeight() * 0.5D;

            double z = target.getZ();

            level.sendParticles(
                    ParticleTypes.DAMAGE_INDICATOR,
                    x,
                    y,
                    z,
                    8,
                    0.3D,
                    0.45D,
                    0.3D,
                    0.015D
            );

            level.sendParticles(
                    ParticleTypes.SCULK_SOUL,
                    x,
                    y,
                    z,
                    8,
                    0.3D,
                    0.5D,
                    0.3D,
                    0.02D
            );

            level.sendParticles(
                    GileModParticleTypes.DEATH,
                    x,
                    y,
                    z,
                    6,
                    0.25D,
                    0.4D,
                    0.25D,
                    0.015D
            );
        }

        // ============================================================
        // COOLDOWN — UTILITY
        // ============================================================

        private static void sendUtilityCooldownMessage(
                ServerPlayer player,
                ItemStack stack
        ) {
            int remainingTicks = Math.max(
                    1,
                    Math.round(
                            player.getCooldowns().getCooldownPercent(
                                    stack,
                                    0.0F
                            ) * UTILITY_COOLDOWN
                    )
            );

            int seconds = Math.max(
                    1,
                    (remainingTicks + 19) / 20
            );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.ronova_lifesteal_utility_cooldown",
                            seconds
                    ),
                    true
            );
        }

        // ============================================================
        // COOLDOWN — ABILITY
        // ============================================================

        private static void sendCooldownMessage(
                ServerPlayer player,
                ItemStack stack
        ) {
            int remainingTicks =
                    Math.max(
                            1,
                            Math.round(
                                    player.getCooldowns()
                                            .getCooldownPercent(
                                                    stack,
                                                    0.0F
                                            )
                                            * ABILITY_COOLDOWN
                            )
                    );

            int seconds =
                    Math.max(
                            1,
                            (remainingTicks + 19) / 20
                    );

            player.sendSystemMessage(
                    Component.translatable(
                            "message.gilemod.ronova_lifesteal_cooldown",
                            seconds
                    ),
                    true
            );
        }

        /*
         * Kept so your existing SERVER TICK call:
         *
         * LegendaryAbilities.RonovaLifeSteal.tick(level);
         *
         * does not need to be changed.
         *
         * The old delayed-damage system is gone, so there is
         * deliberately nothing to process here.
         */
        public static void tick(ServerLevel level) {
        }
    }

}