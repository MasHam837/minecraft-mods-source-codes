package mh837.gile.entity;

import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import mh837.gile.GileModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.feline.CatSoundVariants;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

public class LuminousEntity extends Animal implements Leashable {
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(LuminousEntity.class, EntityDataSerializers.INT);

    public LuminousEntity(EntityType<? extends Animal> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        // Returns a high favor so it gladly spawns in the dark on End blocks
        return 10.0F;
    }

    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        EntityDimensions dimensions = super.getDefaultDimensions(pose);
        if (this.isBaby()) {
            return dimensions.scale(1.0f);
        }
        return dimensions;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(GileModItems.STAR_FRAGMENT);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.25));

        this.goalSelector.addGoal(2, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.15, stack -> stack.is(GileModItems.STAR_FRAGMENT), false));

        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0f));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    public static AttributeSupplier.Builder createLuminousAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 14.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FOLLOW_RANGE, 16.0)
                .add(Attributes.TEMPT_RANGE, 16.0)
                .add(Attributes.JUMP_STRENGTH, 0.17)
                .add(Attributes.GRAVITY, 0.01)
                .add(Attributes.FALL_DAMAGE_MULTIPLIER, 0.3);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(VARIANT, 0); // Default: 0 = Yellow, 1 = Light Blue, 2 = Pink
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, EntitySpawnReason spawnReason, @Nullable SpawnGroupData spawnData) {
        this.setVariant(this.random.nextInt(3));
        return super.finalizeSpawn(level, difficulty, spawnReason, spawnData);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        if (this.isFood(itemStack)) {
            int age = this.getAge();

            if (!this.level().isClientSide() && age == 0 && this.canFallInLove()) {
                this.usePlayerItem(player, hand, itemStack);
                this.setInLove(player);
                return InteractionResult.SUCCESS_SERVER;
            }

            if (this.isBaby()) {
                this.usePlayerItem(player, hand, itemStack);

                int currentAge = this.getAge();
                int ageIncrease = (int)((float)(-currentAge / 20) * 0.1F);
                this.ageUp(ageIncrease, true);
                return this.level().isClientSide() ? InteractionResult.SUCCESS : InteractionResult.SUCCESS_SERVER;
            }
        }

        return super.mobInteract(player, hand);
    }

    public int getVariant() {
        return this.entityData.get(VARIANT);
    }

    public void setVariant(int variant) {
        this.entityData.set(VARIANT, variant);
    }

    @Override
    public void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("Variant", this.getVariant());
    }

    @Override
    public void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.setVariant(input.getIntOr("Variant", 1));
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);
        int looting = 0;
        if (damageSource.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEnchant = registry.get(Enchantments.LOOTING);
            if (lootingEnchant.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(
                        lootingEnchant.get(),
                        attacker.getMainHandItem()
                );
            }
        }
        int dropCount = 1 + this.random.nextInt(2 + looting);
        this.spawnAtLocation(level, new ItemStack(this.isOnFire() ? GileModItems.COOKED_PHASMA : GileModItems.PHASMA, dropCount));
    }

    @Override
    public boolean requiresCustomPersistence() {
        return super.requiresCustomPersistence();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return !this.hasCustomName();
    }

    @Nullable
    @Override
    public LuminousEntity getBreedOffspring(ServerLevel level, AgeableMob entity) {
        LuminousEntity child = GileModEntities.LUMINOUS.create(level, EntitySpawnReason.BREEDING);
        if (child != null) {
            // Set variant - inherits from one of the parents
            child.setVariant(this.random.nextBoolean() ? this.getVariant() : ((LuminousEntity)entity).getVariant());

            // Forces the child to spawn as a baby
            child.setBaby(true);
        }
        return child;
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        boolean damaged = super.hurtServer(level, source, amount);

        if (damaged && !this.level().isClientSide()) {
            this.level().playSound(
                    null,
                    this.getX(), this.getY(), this.getZ(),
                    GileModSounds.LUMINOUS_HURT, SoundSource.HOSTILE,
                    0.8F,
                    2.0F
            );
        }

        return damaged;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return GileModSounds.LUMINOUS_AMBIENT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.CAT_SOUNDS
                .get(CatSoundVariants.SoundSet.CLASSIC)
                .adultSounds()
                .deathSound()
                .value();
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return this.random.nextInt(3) + 1;}
}