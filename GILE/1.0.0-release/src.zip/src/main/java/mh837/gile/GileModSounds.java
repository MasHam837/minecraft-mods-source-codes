package mh837.gile;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public class GileModSounds {

    private static SoundEvent registerSound(String name) {
        Identifier id = Identifier.fromNamespaceAndPath("gilemod", name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    // SOUNDS:
    public static final SoundEvent LUMINOUS_AMBIENT = registerSound("entity.luminous.ambient");
    public static final SoundEvent LUMINOUS_HURT = registerSound("entity.luminous.hurt");
    public static final SoundEvent WEASEL_THIEF_AMBIENT = registerSound("entity.weasel_thief.ambient");
    public static final SoundEvent HOVERING_GHOST_NYAN_AMBIENT = registerSound("entity.hovering_ghost.nyan_ambient");
    public static final SoundEvent RUIN_GUARD_HIT = registerSound("entity.ruin_guard.hit");
    public static final SoundEvent RUIN_GUARD_ROTATION = registerSound("entity.ruin_guard.rotation");

    public static void initialize() {
        System.out.println("Registering Sounds for gilemod");
    }
}