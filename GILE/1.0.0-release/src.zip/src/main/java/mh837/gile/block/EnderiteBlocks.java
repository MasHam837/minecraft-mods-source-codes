package mh837.gile.block;

import mh837.gile.GileModTags;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class EnderiteBlocks extends Block {

    public EnderiteBlocks(Properties properties) {super(properties);}

    @Override
    public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {ItemStack heldItem = player.getMainHandItem();
        if (heldItem.is(GileModTags.Items.ENDERITE_MINING_TOOLS)) {
            return super.getDestroyProgress(state, player, level, pos);}return 0.0F;}

    @Override
    public void playerDestroy(net.minecraft.world.level.Level level, Player player, BlockPos pos,
                              BlockState state, net.minecraft.world.level.block.entity.BlockEntity blockEntity, ItemStack tool) {

        // Only Netherite & Enderite pickaxes can produce a drop.
        tool.is(GileModTags.Items.ENDERITE_MINING_TOOLS);

        // Let Minecraft handle XP/tool damage/etc.
        super.playerDestroy(level, player, pos, state, blockEntity, tool);

    }
}