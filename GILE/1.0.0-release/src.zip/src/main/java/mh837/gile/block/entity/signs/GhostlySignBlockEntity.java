package mh837.gile.block.entity.signs;

import mh837.gile.GileModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.SignBlockEntity;

public class GhostlySignBlockEntity extends SignBlockEntity {

    public GhostlySignBlockEntity(BlockPos pos, BlockState state) {
        super(GileModBlockEntities.GHOSTLY_SIGN_ENTITY, pos, state);
    }
}