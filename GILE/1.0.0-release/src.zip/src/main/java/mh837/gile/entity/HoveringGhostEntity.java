package mh837.gile.entity;

import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import mh837.gile.GileModSounds;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class HoveringGhostEntity extends TamableAnimal implements ItemSteerable, FlyingAnimal, PlayerRideable, Leashable {

    private static final EntityDataAccessor<Boolean> SADDLED =
            SynchedEntityData.defineId(HoveringGhostEntity.class, EntityDataSerializers.BOOLEAN);

    private static final EntityDataAccessor<Integer> BOOST_TIME =
            SynchedEntityData.defineId(HoveringGhostEntity.class, EntityDataSerializers.INT);

    private final ItemBasedSteering saddledComponent;

    public HoveringGhostEntity(EntityType<? extends TamableAnimal> entityType, Level level) {
        super(entityType, level);
        this.moveControl = new FlyingMoveControl(this, 10, false);
        this.saddledComponent = new ItemBasedSteering(this.entityData, BOOST_TIME);
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengers().size() < 2;
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction moveFunction) {
        if (this.hasPassenger(passenger)) {
            int seatIndex = this.getPassengers().indexOf(passenger);
            float zOffset = (seatIndex == 0) ? 0.0F : -1.2F;
            float yawRad = this.yBodyRot * ((float)Math.PI / 180F);
            double offsetX = -Math.sin(yawRad) * zOffset;
            double offsetZ = Math.cos(yawRad) * zOffset;

            moveFunction.accept(passenger, this.getX() + offsetX, this.getY() + 0.35D, this.getZ() + offsetZ);
        } else {
            super.positionRider(passenger, moveFunction);
        }
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);
        if (this.isSaddled()) {
            this.spawnAtLocation(level, new ItemStack(Items.SADDLE));
        }

        int looting = 0;
        if (damageSource.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEnchant = registry.get(Enchantments.LOOTING);
            if (lootingEnchant.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(
                        lootingEnchant.get(),
                        attacker.getMainHandItem()
                );
            }
        }

        int dropCount = 2 + this.random.nextInt(3 + looting);
        this.spawnAtLocation(level, new ItemStack(this.isOnFire() ? GileModItems.COOKED_PHASMA : GileModItems.PHASMA, dropCount));
    }

    @Override
    public boolean requiresCustomPersistence() {
        return super.requiresCustomPersistence();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return !this.hasCustomName();
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return this.random.nextInt(3) + 1;}

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.25));
        this.goalSelector.addGoal(2, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.1, Ingredient.of(GileModItems.JELLY, GileModItems.JELLY_ON_A_STICK), false));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0f));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    public static AttributeSupplier.Builder createHoveringGhostAttributes() {
        return TamableAnimal.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.FLYING_SPEED, 0.2)
                .add(Attributes.MOVEMENT_SPEED, 0.2)
                .add(Attributes.FOLLOW_RANGE, 10.0)
                .add(Attributes.TEMPT_RANGE, 10.0);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation flyingNavigation = new FlyingPathNavigation(this, level);
        flyingNavigation.setCanOpenDoors(false);
        flyingNavigation.setCanFloat(true);
        return flyingNavigation;
    }

    @Override
    public boolean isFlying() {
        return !this.onGround();
    }

    @Override
    public boolean causeFallDamage(double fallDistance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean isFlapping() {
        return true;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(GileModItems.JELLY);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SADDLED, false);
        builder.define(BOOST_TIME, 0);
    }

    @Override
    public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        return 10.0F;
    }

    @Override
    public void tick() {
        super.tick();

        if (this.isAlive()) {
            if (!this.level().isClientSide()) {
                int currentBoost = this.entityData.get(BOOST_TIME);
                if (currentBoost > 0) {
                    this.entityData.set(BOOST_TIME, currentBoost - 1);
                }
            }

            boolean isNyanCat = this.hasCustomName() && "Nyan Cat".equalsIgnoreCase(this.getCustomName().getString());
            boolean shouldTrail = false;

            if (this.isVehicle() && this.getControllingPassenger() instanceof Player player) {
                ItemStack mainHand = player.getItemInHand(InteractionHand.MAIN_HAND);
                ItemStack offHand = player.getItemInHand(InteractionHand.OFF_HAND);
                shouldTrail = mainHand.is(GileModItems.JELLY_ON_A_STICK) || offHand.is(GileModItems.JELLY_ON_A_STICK);
            }

            if (this.level().isClientSide() && isNyanCat && shouldTrail) {
                float yawRad = this.yBodyRot * ((float)Math.PI / 180F);
                double trailLength = 1.3;
                double spawnX = this.getX() + Math.sin(yawRad) * trailLength;
                double spawnZ = this.getZ() - Math.cos(yawRad) * trailLength;
                double spawnY = this.getY() + (this.getBbHeight() * 0.4);

                int[] rainbowColors = {
                        0xFF0000, // Red
                        0xFF8000, // Orange
                        0xFFFF00, // Yellow
                        0x00FF00, // Green
                        0x0080FF, // Blue
                        0x4D00CC, // Indigo
                        0x800080  // Violet
                };

                double totalSpread = 1.2;

                for (int i = 0; i < rainbowColors.length; i++) {
                    double lateralOffset = ((double) i / (rainbowColors.length - 1) - 0.5) * totalSpread;
                    double particleX = spawnX + Math.cos(yawRad) * lateralOffset;
                    double particleZ = spawnZ + Math.sin(yawRad) * lateralOffset;

                    DustParticleOptions dustOptions = new DustParticleOptions(rainbowColors[i], 1.2F);
                    this.level().addParticle(dustOptions, particleX, spawnY, particleZ, 0.0, 0.0, 0.0);
                }
            }
        }

        if (!this.onGround() && this.getDeltaMovement().y < 0.0 && !this.isVehicle()) {
            this.setDeltaMovement(this.getDeltaMovement().multiply(1.0, 0.6, 1.0));
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        // Taming Logic
        if (!this.isTame() && itemStack.is(GileModItems.JELLY)) {
            if (!this.level().isClientSide()) {
                this.usePlayerItem(player, hand, itemStack);

                if (this.random.nextInt(3) == 0) {
                    this.tame(player);
                    this.level().broadcastEntityEvent(this, (byte)7);
                } else {
                    this.level().broadcastEntityEvent(this, (byte)6);
                }
            }

            return this.level().isClientSide()
                    ? InteractionResult.SUCCESS
                    : InteractionResult.SUCCESS_SERVER;
        }

        // Equipping Saddle Logic
        if (this.isTame() && !this.isSaddled() && !this.isBaby() && itemStack.is(Items.SADDLE)) {
            if (!this.level().isClientSide()) {
                itemStack.consume(1, player);
                this.equipSaddle(SoundSource.NEUTRAL);
            }

            return this.level().isClientSide()
                    ? InteractionResult.SUCCESS
                    : InteractionResult.SUCCESS_SERVER;
        }

        // Unsaddling Logic using Shears
        if (this.isTame() && this.isSaddled() && itemStack.is(Items.SHEARS)) {
            if (!this.level().isClientSide()) {
                this.entityData.set(SADDLED, false);

                // Fixed: Removed 'level,' since the entity already knows its world
                this.spawnAtLocation((ServerLevel) level(), new ItemStack(Items.SADDLE));

                EquipmentSlot equipmentSlot = hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND;

                if (this.level() instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
                    itemStack.hurtAndBreak(1, serverLevel, serverPlayer, brokenItem -> {
                        serverPlayer.onEquippedItemBroken(brokenItem, equipmentSlot);
                    });
                }

                this.level().playSound(null, this.blockPosition(), SoundEvents.SHEEP_SHEAR, SoundSource.NEUTRAL, 1.0F, 1.0F);
            }

            return this.level().isClientSide()
                    ? InteractionResult.SUCCESS
                    : InteractionResult.SUCCESS_SERVER;
        }

        // Mounting Logic
        boolean isBreedingItem = this.isFood(itemStack);

        if (!isBreedingItem
                && this.isSaddled()
                && !this.isBaby()
                && this.getPassengers().size() < 2
                && !player.isPassenger()) {

            if (!this.level().isClientSide()) {
                player.startRiding(this);
            }

            if (player instanceof ServerPlayer serverPlayer) {
                GileModTriggers.RIDE_HOVERING_GHOST.trigger(serverPlayer);
            }

            return this.level().isClientSide()
                    ? InteractionResult.SUCCESS
                    : InteractionResult.SUCCESS_SERVER;
        }
        return super.mobInteract(player, hand);

    }

    @Override
    public void travel(Vec3 movementInput) {
        if (this.isAlive()) {
            if (this.isVehicle() && this.getControllingPassenger() instanceof Player player) {
                ItemStack itemStack = player.getItemInHand(InteractionHand.MAIN_HAND);
                ItemStack offHandStack = player.getItemInHand(InteractionHand.OFF_HAND);

                if (itemStack.is(GileModItems.JELLY_ON_A_STICK) || offHandStack.is(GileModItems.JELLY_ON_A_STICK)) {
                    this.setYRot(player.getYRot());
                    this.yRotO = this.getYRot();
                    this.setXRot(player.getXRot() * 0.5F);
                    this.setRot(this.getYRot(), this.getXRot());
                    this.yBodyRot = this.getYRot();
                    this.yHeadRot = this.yBodyRot;

                    Vec3 lookVec = player.getViewVector(1.0F);
                    double baseSpeed = this.getAttributeValue(Attributes.FLYING_SPEED);

                    boolean isBoosting = this.entityData.get(BOOST_TIME) > 0;
                    double speedMultiplier = 1.5;

                    double finalSpeed = isBoosting ? (baseSpeed * 2.5) : (baseSpeed * speedMultiplier);

                    this.setDeltaMovement(lookVec.scale(finalSpeed));
                    this.move(MoverType.SELF, this.getDeltaMovement());
                    return;
                } else {
                    this.setDeltaMovement(this.getDeltaMovement().scale(0.7));
                    this.move(MoverType.SELF, this.getDeltaMovement());
                    return;
                }
            }
            super.travel(movementInput);
        }
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        Entity entity = this.getFirstPassenger();
        return entity instanceof Player ? (Player)entity : null;
    }

    @Override
    public boolean boost() {
        if (this.entityData.get(BOOST_TIME) > 0) {
            return false;
        }

        if (!this.level().isClientSide()) {
            this.entityData.set(BOOST_TIME, 140 + this.random.nextInt(841));

            boolean isNyanCat = this.hasCustomName() && "Nyan Cat".equalsIgnoreCase(this.getCustomName().getString());
            if (isNyanCat) {
                this.level().playSound(
                        null,
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        GileModSounds.HOVERING_GHOST_NYAN_AMBIENT,
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                );
            }
        }

        return true;
    }

    @Override
    public boolean isSaddled() {
        return this.entityData.get(SADDLED);
    }

    public void equipSaddle(@Nullable SoundSource source) {
        this.entityData.set(SADDLED, true);

        if (source != null) {
            this.level().playSound(
                    null,
                    this.blockPosition(),
                    SoundEvents.HORSE_SADDLE.value(),
                    source,
                    1.0F,
                    1.0F
            );
        }
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.GHAST_AMBIENT; }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VEX_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VEX_DEATH;
    }

    @Nullable
    @Override
    public HoveringGhostEntity getBreedOffspring(ServerLevel level, AgeableMob entity) {
        HoveringGhostEntity child = GileModEntities.HOVERING_GHOST.create(level, EntitySpawnReason.BREEDING);
        if (child != null) {
            child.setBaby(true);
            child.setTame(false, false);
        }
        return child;
    }

    @Override
    public void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putBoolean("Saddled", this.isSaddled());
    }

    @Override
    public void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.entityData.set(SADDLED, input.getBooleanOr("Saddled", false));
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        if (name == null || this.level().isClientSide()) {return;}
        if (!(this.level() instanceof ServerLevel serverLevel)) {return;}
        if (!"Nyan Cat".equals(name.getString())) {return;}
        for (ServerPlayer player : serverLevel.players()) {
            if (player.distanceToSqr(this) < 100) {
                GileModTriggers.NAME_NYAN.trigger(player);
            }
        }
    }
}