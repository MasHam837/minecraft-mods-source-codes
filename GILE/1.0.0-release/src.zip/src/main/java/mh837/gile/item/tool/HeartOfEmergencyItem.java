package mh837.gile.item.tool;

import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class HeartOfEmergencyItem extends Item {

    public HeartOfEmergencyItem(Properties properties) {
        super(properties);
    }

    @Override
    public void inventoryTick(ItemStack itemStack, ServerLevel level, Entity owner, EquipmentSlot slot) {
        if (owner instanceof Player player) {

            // Check if this item is already on cooldown (this also triggers the visual overlay)
            if (player.getCooldowns().isOnCooldown(itemStack)) {
                super.inventoryTick(itemStack, level, owner, slot);
                return;
            }

            float lowHealthThreshold = player.getMaxHealth() * 0.35F;

            // Check if player's health is low and they are alive
            if (player.getHealth() < lowHealthThreshold && player.getHealth() > 0.0F) {
                // 1. Execute healing effects, sound, and particles
                executeEmergencyHeal(player, level);
                // 2. Add the vanilla cooldown (100 ticks = 5 seconds) to show the visual overlay
                player.getCooldowns().addCooldown(itemStack, 100);
                // 3. Make the heart disappear from the inventory after use
                itemStack.shrink(1);

            }
        }
        super.inventoryTick(itemStack, level, owner, slot);
    }

    private void executeEmergencyHeal(Player player, ServerLevel level) {
        // Apply emergency buffs
        player.addEffect(new MobEffectInstance(MobEffects.INSTANT_HEALTH, 1, 1));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 200, 3));

        // Play Totem sound
        level.playSound(
                null,
                player.getX(), player.getY(), player.getZ(),
                SoundEvents.TOTEM_USE,
                SoundSource.PLAYERS,
                1.0F, 1.2F
        );

        // Spawn heart particles
        level.sendParticles(
                ParticleTypes.HEART,
                player.getX(), player.getY(), player.getZ(),
                15, 0.4, 0.4, 0.4, 0.1
        );
    }
}