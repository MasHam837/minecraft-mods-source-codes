package mh837.gile.advancement;

import com.mojang.serialization.Codec;
import net.minecraft.advancements.CriterionTrigger;
import net.minecraft.advancements.criterion.ContextAwarePredicate;
import net.minecraft.advancements.criterion.SimpleCriterionTrigger;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

import static mh837.gile.GileMod.MOD_ID;

public final class GileModTriggers {

    private GileModTriggers() {}
    public static final class GileModTrigger extends SimpleCriterionTrigger<GileModTrigger.Conditions> {
        @Override
        public Codec<Conditions> codec() {
            return Conditions.CODEC;
        }
        public void trigger(ServerPlayer player) {
            trigger(player, Conditions::requirementsMet);
        }
        public record Conditions(Optional<ContextAwarePredicate> player) implements SimpleCriterionTrigger.SimpleInstance {
            public static final Codec<Conditions> CODEC = ContextAwarePredicate.CODEC.optionalFieldOf("player").xmap(Conditions::new, Conditions::player).codec();
            @Override public Optional<ContextAwarePredicate> player() {return player;} public boolean requirementsMet() { return true;}}
    }

    private static <T extends CriterionTrigger<?>> T register(String name, T criterion) {
        return Registry.register(BuiltInRegistries.TRIGGER_TYPES, Identifier.fromNamespaceAndPath(MOD_ID, name), criterion);
    }

    // Abilities
    public static final GileModTrigger ABILITY_ANEMO = register("ability_anemo", new GileModTrigger());
    public static final GileModTrigger ABILITY_GEO = register("ability_geo", new GileModTrigger());
    public static final GileModTrigger ABILITY_ELECTRO = register("ability_electro", new GileModTrigger());
    public static final GileModTrigger ABILITY_DENDRO = register("ability_dendro", new GileModTrigger());
    public static final GileModTrigger ABILITY_HYDRO = register("ability_hydro", new GileModTrigger());
    public static final GileModTrigger ABILITY_PYRO = register("ability_pyro", new GileModTrigger());
    public static final GileModTrigger ABILITY_CRYO = register("ability_cryo", new GileModTrigger());
    public static final GileModTrigger ABILITY_LUNA = register("ability_luna", new GileModTrigger());
    public static final GileModTrigger ABILITY_LIFE = register("ability_life", new GileModTrigger());
    public static final GileModTrigger ABILITY_SPACE = register("ability_space", new GileModTrigger());
    public static final GileModTrigger ABILITY_TIME = register("ability_time", new GileModTrigger());
    public static final GileModTrigger ABILITY_DEATH = register("ability_death", new GileModTrigger());
    public static final GileModTrigger ABILITY_DIVINE = register("ability_divine", new GileModTrigger());
    // Defeat
    public static final GileModTrigger DEFEAT_RUIN_GUARD = register("defeat_ruin_guard", new GileModTrigger());
    // Discover
    public static final GileModTrigger DISCOVER_ANCIENT_RUINS = register("discover_ancient_ruins", new GileModTrigger());
    public static final GileModTrigger DISCOVER_END_THRESHOLD = register("discover_end_threshold", new GileModTrigger());
    public static final GileModTrigger DISCOVER_MOON = register("discover_moon", new GileModTrigger());
    public static final GileModTrigger DISCOVER_GHOSTLY_THICKETS = register("discover_ghostly_thickets", new GileModTrigger());
    public static final GileModTrigger DISCOVER_MOON_DESERT = register("discover_moon_desert", new GileModTrigger());
    // Encounter
    public static final GileModTrigger ENCOUNTER_MOON_MOBS = register("encounter_moon_mobs", new GileModTrigger());
    public static final GileModTrigger ENCOUNTER_HOVERING_GHOST = register("encounter_hovering_ghost", new GileModTrigger());
    public static final GileModTrigger ENCOUNTER_JERBOA = register("encounter_jerboa", new GileModTrigger());
    public static final GileModTrigger ENCOUNTER_GLOOMY_LYNX = register("encounter_gloomy_lynx", new GileModTrigger());
    public static final GileModTrigger ENCOUNTER_WEASEL_THIEF = register("encounter_weasel_thief", new GileModTrigger());
    // Hit By
    public static final GileModTrigger HIT_BY_ENDER_FLY = register("hit_by_ender_fly", new GileModTrigger());
    // Make (custom)
    public static final GileModTrigger MAKE_A_WISH = register("make_a_wish", new GileModTrigger());
    public static final GileModTrigger MAKE_JERBOA_EMERGE = register("make_jerboa_emerge", new GileModTrigger());
    // Name
    public static final GileModTrigger NAME_RADIANCE = register("name_radiance", new GileModTrigger());
    public static final GileModTrigger NAME_NYAN = register("name_nyan", new GileModTrigger());
    // Trade
    public static final GileModTrigger TRADE_WEASEL_THIEF = register("trade_weasel_thief", new GileModTrigger());
    public static final GileModTrigger TRADE_WITH_WISHER = register("trade_with_wisher", new GileModTrigger());
    // Use
    public static final GileModTrigger USE_FLUTTERER = register("use_flutterer", new GileModTrigger());
    public static final GileModTrigger USE_GRAPPLING_HOOK = register("use_grappling_hook", new GileModTrigger());
    public static final GileModTrigger USE_WARP_CLOCK = register("use_warp_clock", new GileModTrigger());
    public static final GileModTrigger USE_SHRINKER = register("use_shrinker", new GileModTrigger());
    public static final GileModTrigger USE_ENLARGER = register("use_enlarger", new GileModTrigger());
    // Ride
    public static final GileModTrigger RIDE_HOVERING_GHOST = register("ride_hovering_ghost", new GileModTrigger());

    public static void initialize() {
    }
}