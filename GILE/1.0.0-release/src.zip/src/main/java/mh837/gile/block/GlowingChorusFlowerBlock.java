package mh837.gile.block;

import mh837.gile.GileModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.ChorusFlowerBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public class GlowingChorusFlowerBlock extends ChorusFlowerBlock {

    public GlowingChorusFlowerBlock(
            GlowingChorusPlantBlock plantBlock,
            BlockBehaviour.Properties properties
    ) {
        super(plantBlock, properties);
    }

    @Override
    protected BlockState updateShape(
            BlockState state,
            LevelReader level,
            ScheduledTickAccess ticks,
            BlockPos pos,
            Direction directionToNeighbour,
            BlockPos neighbourPos,
            BlockState neighbourState,
            RandomSource random
    ) {

        if (directionToNeighbour != Direction.UP
                && !state.canSurvive(level, pos)) {
            ticks.scheduleTick(pos, this, 1);
        }

        if (neighbourState.is(GileModBlocks.GLOWING_CHORUS_PLANT)) {
            BlockPos plantPos = neighbourPos;

            if (level instanceof Level actualLevel) {
                BlockState plantState = actualLevel.getBlockState(plantPos);

                if (plantState.is(GileModBlocks.GLOWING_CHORUS_PLANT)) {
                    actualLevel.setBlock(
                            plantPos,
                            GlowingChorusPlantBlock.getGlowingStateWithConnections(
                                    actualLevel,
                                    plantPos,
                                    plantState
                            ),
                            3
                    );
                }
            }
        }

        return super.updateShape(
                state,
                level,
                ticks,
                pos,
                directionToNeighbour,
                neighbourPos,
                neighbourState,
                random
        );
    }

    @Override
    protected void tick(
            BlockState state,
            ServerLevel level,
            BlockPos pos,
            RandomSource random
    ) {

        if (!state.canSurvive(level, pos)) {
            level.setBlock(
                    pos,
                    Blocks.AIR.defaultBlockState(),
                    3
            );
        }
    }

    @Override
    protected boolean canSurvive(
            BlockState state,
            LevelReader level,
            BlockPos pos
    ) {
        BlockState below = level.getBlockState(pos.below());

        if (below.is(GileModBlocks.GLOWING_CHORUS_PLANT)
                || below.is(GileModBlocks.MOON_SAND)
                || below.is(BlockTags.SUPPORTS_CHORUS_FLOWER)) {
            return true;
        }

        if (below.isAir()) {
            boolean foundPlant = false;

            for (Direction direction : Direction.Plane.HORIZONTAL) {
                BlockState neighbour =
                        level.getBlockState(pos.relative(direction));

                if (neighbour.is(GileModBlocks.GLOWING_CHORUS_PLANT)) {
                    if (foundPlant) {
                        return false;
                    }

                    foundPlant = true;
                } else if (!neighbour.isAir()) {
                    return false;
                }
            }

            return foundPlant;
        }

        return false;
    }
}