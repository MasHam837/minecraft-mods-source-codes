package mh837.gile;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.equipment.trim.TrimMaterial;

public final class GileModTrimMaterials {

    public static final ResourceKey<TrimMaterial> WISH_INGOT =
            ResourceKey.create(
                    Registries.TRIM_MATERIAL,
                    Identifier.fromNamespaceAndPath(
                            GileMod.MOD_ID,
                            "wish_ingot"
                    )
            );

    public static final ResourceKey<TrimMaterial> ENDERITE_INGOT =
            ResourceKey.create(
                    Registries.TRIM_MATERIAL,
                    Identifier.fromNamespaceAndPath(
                            GileMod.MOD_ID,
                            "enderite_ingot"
                    )
            );

    private GileModTrimMaterials() {
    }
}