package mh837.gile.entity;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModEntities;
import mh837.gile.GileModItems;
import mh837.gile.advancement.GileModTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class MothEntity extends Animal implements FlyingAnimal, Leashable {
    private static final EntityDataAccessor<Byte> MOTH_FLAGS =
            SynchedEntityData.defineId(MothEntity.class, EntityDataSerializers.BYTE);

    public MothEntity(EntityType<? extends Animal> entityType, Level level) {
        super(entityType, level);
        this.moveControl = new FlyingMoveControl(this, 10, true);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(2, new TemptGoal(this, 1.0, Ingredient.of(GileModBlocks.MOON_FLOWER), false));
        this.goalSelector.addGoal(3, new FollowParentGoal(this, 1.1));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(MOTH_FLAGS, (byte)0);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(GileModBlocks.MOON_FLOWER.asItem());
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation birdNavigation = new FlyingPathNavigation(this, level);
        birdNavigation.setCanOpenDoors(false);
        birdNavigation.setCanFloat(true);
        return birdNavigation;
    }

    @Override
    public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        return level.getBlockState(pos.below()).isAir() ? 10.0F : 0.0F;
    }

    @Override
    public boolean isFlying() {
        return !this.onGround();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        if (this.isFood(itemStack)) {
            int age = this.getAge();

            if (!this.level().isClientSide() && age == 0 && this.canFallInLove()) {
                this.usePlayerItem(player, hand, itemStack);
                this.setInLove(player);
                return InteractionResult.SUCCESS_SERVER;
            }

            if (this.isBaby()) {
                this.usePlayerItem(player, hand, itemStack);
                this.ageUp(AgeableMob.getSpeedUpSecondsWhenFeeding(this.getAge()), true);
                return this.level().isClientSide() ? InteractionResult.SUCCESS : InteractionResult.SUCCESS_SERVER;
            }
        }

        return super.mobInteract(player, hand);
    }

    @Override
    public void aiStep() {
        super.aiStep();

        if (!this.onGround() && this.getDeltaMovement().y < 0.0) {
            this.setDeltaMovement(this.getDeltaMovement().multiply(1.0, 0.6, 1.0));
        }

        if (this.level().isClientSide()) {
            if (this.isInLove() && this.random.nextInt(5) == 0) {
                this.level().addParticle(
                        ParticleTypes.HEART,
                        this.getRandomX(0.5),
                        this.getY() + 0.5,
                        this.getRandomZ(0.5),
                        0.0, 0.0, 0.0
                );
            }
        }
    }

    @Override
    public void travel(Vec3 movementInput) {
        if (this.isEffectiveAi()) {
            if (this.isInWater()) {
                this.moveRelative(0.02F, movementInput);
                this.move(MoverType.SELF, this.getDeltaMovement());
                this.setDeltaMovement(this.getDeltaMovement().scale(0.8F));
            } else if (this.isInLava()) {
                this.moveRelative(0.02F, movementInput);
                this.move(MoverType.SELF, this.getDeltaMovement());
                this.setDeltaMovement(this.getDeltaMovement().scale(0.5D));
            } else {
                float f = 0.91F;
                if (this.onGround()) {
                    f = this.level().getBlockState(this.getBlockPosBelowThatAffectsMyMovement())
                            .getBlock().getFriction() * 0.91F;
                }
                float g = 0.16277137F / (f * f * f);
                this.moveRelative(this.onGround() ? 0.1F * g : 0.02F, movementInput);
                f = 0.91F;
                if (this.onGround()) {
                    f = this.level().getBlockState(this.getBlockPosBelowThatAffectsMyMovement())
                            .getBlock().getFriction() * 0.91F;
                }
                this.move(MoverType.SELF, this.getDeltaMovement());
                this.setDeltaMovement(this.getDeltaMovement().scale(f));
            }
        }
    }

    @Override
    public boolean causeFallDamage(double fallDistance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource damageSource, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, damageSource, recentlyHit);

        int looting = 0;
        if (damageSource.getEntity() instanceof LivingEntity attacker) {
            var registry = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            var lootingEntry = registry.get(Enchantments.LOOTING);
            if (lootingEntry.isPresent()) {
                looting = EnchantmentHelper.getItemEnchantmentLevel(lootingEntry.get(), attacker.getMainHandItem());
            }
        }

        // Determine min and max drops based on the looting level
        int minDrops = Math.min(3, looting); // 0, 1, 2, or 3
        int maxDrops = Math.min(4, 2 + looting); // 2, 3, 4, or 4

        // random.nextInt(bound) is exclusive, so we add 1 to the difference
        int dropCount = minDrops + this.random.nextInt((maxDrops - minDrops) + 1);

        if (dropCount > 0) {
            this.spawnAtLocation(level, new ItemStack(GileModItems.MOTH_WING, dropCount));
        }
    }

    @Override
    public boolean requiresCustomPersistence() {
        return super.requiresCustomPersistence();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        // Frees up the 10-mob CREATURE cap dynamically!
        return !this.hasCustomName() && !this.isLeashed();
    }

    @Override
    @Nullable
    public MothEntity getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return GileModEntities.MOTH.create(level, EntitySpawnReason.BREEDING);
    }

    public static AttributeSupplier.Builder createMothAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 6.0)
                .add(Attributes.FLYING_SPEED, 0.4)
                .add(Attributes.MOVEMENT_SPEED, 0.2)
                .add(Attributes.FOLLOW_RANGE, 10.0)
                .add(Attributes.TEMPT_RANGE, 10.0);
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.BEE_LOOP;
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.BEE_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BEE_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.3F;
    }

    @Override
    public float getVoicePitch() {
        return 1.3F;
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        if (name == null || this.level().isClientSide()) {return;}
        if (!(this.level() instanceof ServerLevel serverLevel)) {return;}
        if (!"Radiance".equals(name.getString())) {return;}
        for (ServerPlayer player : serverLevel.players()) {
            if (player.distanceToSqr(this) < 100) {
                GileModTriggers.NAME_RADIANCE.trigger(player);
            }
        }
    }

    @Override
    protected int getBaseExperienceReward(ServerLevel level) {return this.random.nextInt(3) + 1;}

}