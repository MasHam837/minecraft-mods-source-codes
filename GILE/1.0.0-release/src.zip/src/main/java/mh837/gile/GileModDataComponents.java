package mh837.gile;

import com.mojang.serialization.Codec;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.enchantment.Repairable;

import java.util.UUID;

public class GileModDataComponents {

    public static final DataComponentType<Integer> GLITTER_COUNT = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "glitter_count"),
                    DataComponentType.<Integer>builder().persistent(Codec.intRange(1, 4)).networkSynchronized(ByteBufCodecs.VAR_INT).build());

    public static final DataComponentType<Boolean> END_WARNING_SEEN = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
                    Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "end_warning_seen"),
                    DataComponentType.<Boolean>builder().persistent(Codec.BOOL).networkSynchronized(ByteBufCodecs.BOOL).build());

    public static final DataComponentType<UUID> GRAPPLE_ID = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
                    Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "grapple_id"), DataComponentType.<UUID>builder()
                            .persistent(Codec.STRING.xmap(UUID::fromString, UUID::toString))
                            .networkSynchronized(ByteBufCodecs.STRING_UTF8.map(UUID::fromString, UUID::toString)).build());

    public static final DataComponentType<Boolean> GRAPPLE_ACTIVE = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "grapple_active"),
                    DataComponentType.<Boolean>builder().persistent(Codec.BOOL).networkSynchronized(ByteBufCodecs.BOOL).build());

    public static final DataComponentType<Boolean> RONOVA_SPEAR = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "ronova_spear"),
                    DataComponentType.<Boolean>builder().persistent(Codec.BOOL).networkSynchronized(ByteBufCodecs.BOOL).build());

    public static final DataComponentType<Integer> WEAPON_LEVEL = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "weapon_level"), DataComponentType.<Integer>builder()
                    .persistent(Codec.intRange(1, 5)).networkSynchronized(ByteBufCodecs.VAR_INT).build());

    public static final DataComponentType<Boolean> NUCLEAR_CANNON_BROKEN = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
            Identifier.fromNamespaceAndPath(GileMod.MOD_ID, "nuclear_cannon_broken"), DataComponentType.<Boolean>builder()
                    .persistent(Codec.BOOL).networkSynchronized(ByteBufCodecs.BOOL).build());

    public static void initialize() {
        // Registration happens when the static fields initialize.
    }
}