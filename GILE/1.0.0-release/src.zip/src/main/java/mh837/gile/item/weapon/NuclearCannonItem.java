package mh837.gile.item.weapon;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModDataComponents;
import mh837.gile.GileModEnchantments;
import mh837.gile.GileModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class NuclearCannonItem extends Item {

    private static final int MAX_DURABILITY = 40;
    private static final double BASE_RANGE = 40.0;
    private static final double RANGE_PER_LEVEL = 12.0;
    private static final int DURABILITY_COST_PER_SECOND = 2;

    public NuclearCannonItem(Properties properties) {
        super(properties);
    }

    /**
     * Gets the maximum range based on the Range enchantment level.
     */
    private double getMaxRange(Level level, ItemStack stack) {
        Holder<Enchantment> rangeEnchantment =
                level.registryAccess()
                        .lookupOrThrow(Registries.ENCHANTMENT)
                        .getOrThrow(GileModEnchantments.RANGE);

        int rangeLevel = EnchantmentHelper.getItemEnchantmentLevel(rangeEnchantment, stack);
        return BASE_RANGE + (rangeLevel * RANGE_PER_LEVEL);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        Level level = context.getLevel();
        ItemStack stack = context.getItemInHand();

        if (player == null) return InteractionResult.PASS;

        // SHIFT + RIGHT-CLICK: Repair the cannon
        if (player.isShiftKeyDown() && stack.getItem() instanceof NuclearCannonItem) {
            // Check if cannon is already at full durability
            if (stack.getDamageValue() == 0) {
                if (player instanceof ServerPlayer serverPlayer) {
                    serverPlayer.sendSystemMessage(
                            net.minecraft.network.chat.Component.translatable("message.gilemod.nuclear_cannon_full"), true
                    );
                }
                return InteractionResult.FAIL;
            }

            // Look for an Wish Nugget in the offhand
            ItemStack offhand = player.getOffhandItem();

            if (offhand.is(GileModItems.WISH_NUGGET)) {
                int newDamage = stack.getDamageValue() - 10;
                if (newDamage < 0) newDamage = 0;
                stack.setDamageValue(newDamage);

                // Remove the broken component if repaired
                if (stack.has(GileModDataComponents.NUCLEAR_CANNON_BROKEN)) {
                    stack.remove(GileModDataComponents.NUCLEAR_CANNON_BROKEN);
                }

                offhand.shrink(1);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1.0F, 1.0F);

                if (player instanceof ServerPlayer serverPlayer) {
                    serverPlayer.sendSystemMessage(
                            net.minecraft.network.chat.Component.translatable("message.gilemod.nuclear_cannon_repaired"), true);
                }
                return InteractionResult.SUCCESS;
            } else {
                if (player instanceof ServerPlayer serverPlayer) {
                    serverPlayer.sendSystemMessage(
                            net.minecraft.network.chat.Component.translatable("message.gilemod.nuclear_cannon_ammo"), true);
                }
                return InteractionResult.FAIL;
            }
        }

        return InteractionResult.PASS;
    }

    // Allows the item to be used continuously for a long time
    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 72000;
    }

    // Gives the player the "aiming" animation while firing
    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {
        return ItemUseAnimation.BOW;
    }

    // Starts the continuous use action when the player right-clicks
    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Check if the item is broken (durability at 0)
        if (stack.getDamageValue() >= MAX_DURABILITY || stack.getOrDefault(GileModDataComponents.NUCLEAR_CANNON_BROKEN, false)) {
            // Play a click/error sound when trying to use a broken cannon
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 1.0F, 1.0F);

            // Send as overlay message (appears above hotbar)
            if (player instanceof ServerPlayer serverPlayer) {
                serverPlayer.sendSystemMessage(
                        net.minecraft.network.chat.Component.translatable("message.gilemod.nuclear_cannon_broken"), true
                );
            }
            return InteractionResult.FAIL;
        }

        player.startUsingItem(hand);

        // Play an initial activation sound
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 2.0F);

        return InteractionResult.CONSUME;
    }

    // This method fires every single tick the player holds right-click
    @Override
    public void onUseTick(Level level, LivingEntity livingEntity, ItemStack stack, int remainingUseDuration) {
        if (!(livingEntity instanceof ServerPlayer player)) return;

        // Check if the item is broken
        if (stack.getDamageValue() >= MAX_DURABILITY || stack.getOrDefault(GileModDataComponents.NUCLEAR_CANNON_BROKEN, false)) {
            player.stopUsingItem();
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 1.0F, 1.0F);
            return;
        }

        int useTime = this.getUseDuration(stack, livingEntity) - remainingUseDuration;

        // Loop an ambient beacon sound every second (20 ticks) while firing
        if (useTime % 20 == 0) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 1.0F, 2.0F);
        }

        // Only execute on the Server side
        if (!level.isClientSide() && level instanceof ServerLevel serverLevel) {

            // Calculate beam every 2 ticks
            if (useTime % 2 == 0) {
                // RECENTERED: Start from the item position (slightly in front of the player)
                Vec3 startPos = player.position().add(0, player.getEyeHeight() * 0.6, 0)
                        .add(player.getViewVector(1.0F).scale(0.5));
                Vec3 lookVec = player.getViewVector(1.0F);

                // Get dynamic range from enchantment
                double maxDistance = getMaxRange(level, stack);
                double step = 0.5;
                boolean hitBlock = false;
                BlockPos hitPos = null;

                // 1. Find the closest block in the ray path
                for (double d = 0; d < maxDistance; d += step) {
                    Vec3 currentPos = startPos.add(lookVec.scale(d));
                    BlockPos blockPos = BlockPos.containing(currentPos);

                    // Check if this is a new block position
                    if (hitPos == null || !hitPos.equals(blockPos)) {
                        BlockState state = level.getBlockState(blockPos);
                        if (!state.isAir()) {
                            // Check if the block is explosion resistant or protected
                            if (isExplosionResistant(state) || isProtectedBlock(state)) {
                                break; // Stop at protected blocks
                            }

                            // Check if block can be destroyed
                            if (state.getDestroySpeed(level, blockPos) >= 0.0F) {
                                hitPos = blockPos;
                                hitBlock = true;
                                break; // Found the first destroyable block
                            }
                        }
                    }
                }

                // 2. Destroy the closest block if found
                if (hitBlock && hitPos != null) {
                    BlockState state = level.getBlockState(hitPos);
                    level.destroyBlock(hitPos, true, player);

                    // Occasional explosions (1% chance)
                    if (level.getRandom().nextFloat() < 0.01F) {
                        Vec3 center = Vec3.atCenterOf(hitPos);
                        level.explode(
                                player,
                                center.x, center.y, center.z,
                                1.5F,
                                Level.ExplosionInteraction.TNT
                        );
                    }
                }

                // 3. Deal damage to entities along the ray (every second)
                if (useTime % 20 == 0) {
                    // Check entities along the ray path
                    for (double d = 0; d < maxDistance; d += step) {
                        Vec3 currentPos = startPos.add(lookVec.scale(d));
                        AABB hitBox = new AABB(currentPos, currentPos).inflate(2.0);
                        serverLevel.getEntities(player, hitBox).forEach(entity -> {
                            if (entity != player && entity.isAlive()) {
                                if (entity instanceof LivingEntity living) {
                                    living.addEffect(new MobEffectInstance(
                                            MobEffects.INSTANT_DAMAGE,
                                            1,  // Duration (1 tick = instant)
                                            0,  // Amplifier (level 1)
                                            false,
                                            true
                                    ));
                                    living.hurt(level.damageSources().playerAttack(player), 2.0F);
                                    living.igniteForSeconds(1);
                                }
                            }
                        });
                    }
                }

                // 4. Consume Durability every second (20 ticks)
                // Only consume durability if player is NOT in Creative mode
                if (useTime % 20 == 0 && !player.isCreative()) {
                    int newDamage = stack.getDamageValue() + DURABILITY_COST_PER_SECOND;

                    if (newDamage >= MAX_DURABILITY) {
                        // Item is now broken
                        stack.setDamageValue(MAX_DURABILITY);
                        stack.set(GileModDataComponents.NUCLEAR_CANNON_BROKEN, true);
                        player.stopUsingItem();
                        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                                SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 1.0F, 1.0F);

                        // Send overlay message
                        if (player instanceof ServerPlayer serverPlayer) {
                            serverPlayer.sendSystemMessage(
                                    net.minecraft.network.chat.Component.translatable("message.gilemod.nuclear_cannon_overheated"), true
                            );
                        }
                    } else {
                        stack.setDamageValue(newDamage);
                    }
                }
            }
        }
    }

    /**
     * Checks if a block is explosion resistant.
     */
    private boolean isExplosionResistant(BlockState state) {
        return state.is(Blocks.BEDROCK) ||
                state.is(Blocks.OBSIDIAN) ||
                state.is(Blocks.CRYING_OBSIDIAN) ||
                state.is(Blocks.RESPAWN_ANCHOR) ||
                state.is(Blocks.REINFORCED_DEEPSLATE) ||
                state.is(Blocks.END_PORTAL_FRAME) ||
                state.is(Blocks.END_PORTAL) ||
                state.is(Blocks.ENDER_CHEST) ||
                state.is(Blocks.ANCIENT_DEBRIS) ||
                state.is(Blocks.NETHERITE_BLOCK) ||
                state.getDestroySpeed(null, null) < 0.0F;
    }

    /**
     * Checks if a block is protected (custom mod blocks that shouldn't be destroyed).
     */
    private boolean isProtectedBlock(BlockState state) {
        return state.is(GileModBlocks.ENDERITE_ORE) ||
                state.is(GileModBlocks.ENDERITE_BLOCK);
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getBarColor(ItemStack stack) {
        // Always yellow
        return 0xFFFF00;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        // Custom bar width showing remaining durability
        float durability = (float) (MAX_DURABILITY - stack.getDamageValue()) / MAX_DURABILITY;
        return Math.round(13.0F * durability);
    }
}