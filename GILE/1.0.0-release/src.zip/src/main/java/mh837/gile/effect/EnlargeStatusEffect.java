package mh837.gile.effect;

import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class EnlargeStatusEffect extends MobEffect {

    private static final Identifier SCALE_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.scale");
    private static final Identifier HEALTH_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.health");
    private static final Identifier SPEED_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.speed");
    private static final Identifier JUMP_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.jump");
    private static final Identifier STRENGTH_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.strength");
    private static final Identifier REACH_ENTITY_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.reach_entity");
    private static final Identifier REACH_BLOCK_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.reach_block");
    private static final Identifier GRAVITY_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.gravity");
    private static final Identifier STEP_HEIGHT_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.step_height");
    private static final Identifier FALL_DIST_ID = Identifier.fromNamespaceAndPath("gilemod", "enlarge.fall_distance");

    public EnlargeStatusEffect() {
        super(MobEffectCategory.NEUTRAL, 0x98BC35);
    }

    @Override
    public void addAttributeModifiers(AttributeMap attributes, int amplifier) {
        super.addAttributeModifiers(attributes, amplifier);

        double scaleGrowth = 0.2 * (amplifier + 1);
        if (scaleGrowth > 16.0) {
            scaleGrowth = 16.0;
        }

        double statsGrowth = 0.1 * (amplifier + 1);
        if (statsGrowth > 8.0) {
            statsGrowth = 8.0;
        }

        applyModifier(attributes, Attributes.SCALE, SCALE_ID, scaleGrowth);
        applyModifier(attributes, Attributes.MAX_HEALTH, HEALTH_ID, statsGrowth);
        applyModifier(attributes, Attributes.MOVEMENT_SPEED, SPEED_ID, statsGrowth);
        applyModifier(attributes, Attributes.JUMP_STRENGTH, JUMP_ID, statsGrowth);
        applyModifier(attributes, Attributes.ATTACK_DAMAGE, STRENGTH_ID, statsGrowth);
        applyModifier(attributes, Attributes.ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID, statsGrowth);
        applyModifier(attributes, Attributes.BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID, statsGrowth);
        applyModifier(attributes, Attributes.GRAVITY, GRAVITY_ID, statsGrowth);
        applyModifier(attributes, Attributes.STEP_HEIGHT, STEP_HEIGHT_ID, statsGrowth);
        applyModifier(attributes, Attributes.SAFE_FALL_DISTANCE, FALL_DIST_ID, statsGrowth);
    }

    @Override
    public void removeAttributeModifiers(AttributeMap attributes) {
        super.removeAttributeModifiers(attributes);

        removeModifier(attributes, Attributes.SCALE, SCALE_ID);
        removeModifier(attributes, Attributes.MAX_HEALTH, HEALTH_ID);
        removeModifier(attributes, Attributes.MOVEMENT_SPEED, SPEED_ID);
        removeModifier(attributes, Attributes.JUMP_STRENGTH, JUMP_ID);
        removeModifier(attributes, Attributes.ATTACK_DAMAGE, STRENGTH_ID);
        removeModifier(attributes, Attributes.ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID);
        removeModifier(attributes, Attributes.BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID);
        removeModifier(attributes, Attributes.GRAVITY, GRAVITY_ID);
        removeModifier(attributes, Attributes.STEP_HEIGHT, STEP_HEIGHT_ID);
        removeModifier(attributes, Attributes.SAFE_FALL_DISTANCE, FALL_DIST_ID);
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        return true;
    }

    @Override
    public boolean applyEffectTick(ServerLevel serverLevel, LivingEntity mob, int amplifier) {
        AttributeInstance scaleInstance = mob.getAttribute(Attributes.SCALE);
        if (scaleInstance != null && !scaleInstance.hasModifier(SCALE_ID)) {
            this.addAttributeModifiers(mob.getAttributes(), amplifier);
        }
        return super.applyEffectTick(serverLevel, mob, amplifier);
    }

    // ----------------------------------------------

    private void applyModifier(AttributeMap attributes, Holder<Attribute> attribute, Identifier id, double value) {
        AttributeInstance instance = attributes.getInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id);
            instance.addTransientModifier(new AttributeModifier(
                    id, value, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
            ));
        }
    }

    private void removeModifier(AttributeMap attributes, Holder<Attribute> attribute, Identifier id) {
        AttributeInstance instance = attributes.getInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id);
        }
    }
}