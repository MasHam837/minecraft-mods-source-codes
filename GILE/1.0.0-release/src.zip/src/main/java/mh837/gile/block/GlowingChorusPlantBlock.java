package mh837.gile.block;

import mh837.gile.GileModBlocks;
import mh837.gile.GileModTags;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.ChorusPlantBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public class GlowingChorusPlantBlock extends ChorusPlantBlock {

    public GlowingChorusPlantBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return getGlowingStateWithConnections(
                context.getLevel(),
                context.getClickedPos(),
                defaultBlockState()
        );
    }

    @Override
    protected BlockState updateShape(
            BlockState state,
            LevelReader level,
            ScheduledTickAccess ticks,
            BlockPos pos,
            Direction directionToNeighbour,
            BlockPos neighbourPos,
            BlockState neighbourState,
            RandomSource random
    ) {

        if (!state.canSurvive(level, pos)) {
            ticks.scheduleTick(pos, this, 1);
        }

        return getGlowingStateWithConnections(
                level,
                pos,
                state
        );
    }

    @Override
    protected void tick(
            BlockState state,
            ServerLevel level,
            BlockPos pos,
            RandomSource random
    ) {

        if (!state.canSurvive(level, pos)) {
            level.destroyBlock(pos, true);
        }
    }

    @Override
    protected boolean canSurvive(
            BlockState state,
            LevelReader level,
            BlockPos pos
    ) {
        BlockState belowState = level.getBlockState(pos.below());

        boolean blockAboveOrBelow =
                !level.getBlockState(pos.above()).isAir()
                        && !belowState.isAir();

        for (Direction direction : Direction.Plane.HORIZONTAL) {
            BlockPos neighbourPos = pos.relative(direction);
            BlockState neighbourState = level.getBlockState(neighbourPos);

            if (neighbourState.is(this)) {
                if (blockAboveOrBelow) {
                    return false;
                }

                BlockState neighbourBelow =
                        level.getBlockState(neighbourPos.below());

                if (neighbourBelow.is(this)
                        || neighbourBelow.is(
                        GileModTags.Blocks.GLOWING_CHORUS_SUPPORT
                )) {
                    return true;
                }
            }
        }

        return belowState.is(GileModBlocks.MOON_SAND)
                || belowState.is(GileModTags.Blocks.GLOWING_CHORUS_SUPPORT);
    }

    public static BlockState getGlowingStateWithConnections(
            BlockGetter level,
            BlockPos pos,
            BlockState state
    ) {
        BlockState down = level.getBlockState(pos.below());
        BlockState up = level.getBlockState(pos.above());
        BlockState north = level.getBlockState(pos.north());
        BlockState east = level.getBlockState(pos.east());
        BlockState south = level.getBlockState(pos.south());
        BlockState west = level.getBlockState(pos.west());

        boolean downConnection =
                down.is(GileModBlocks.GLOWING_CHORUS_PLANT)
                        || down.is(GileModBlocks.GLOWING_CHORUS_FLOWER)
                        || down.is(GileModTags.Blocks.GLOWING_CHORUS_SUPPORT);

        boolean upConnection =
                up.is(GileModBlocks.GLOWING_CHORUS_PLANT)
                        || up.is(GileModBlocks.GLOWING_CHORUS_FLOWER);

        boolean northConnection =
                north.is(GileModBlocks.GLOWING_CHORUS_PLANT)
                        || north.is(GileModBlocks.GLOWING_CHORUS_FLOWER);

        boolean eastConnection =
                east.is(GileModBlocks.GLOWING_CHORUS_PLANT)
                        || east.is(GileModBlocks.GLOWING_CHORUS_FLOWER);

        boolean southConnection =
                south.is(GileModBlocks.GLOWING_CHORUS_PLANT)
                        || south.is(GileModBlocks.GLOWING_CHORUS_FLOWER);

        boolean westConnection =
                west.is(GileModBlocks.GLOWING_CHORUS_PLANT)
                        || west.is(GileModBlocks.GLOWING_CHORUS_FLOWER);

        return state
                .setValue(DOWN, downConnection)
                .setValue(UP, upConnection)
                .setValue(NORTH, northConnection)
                .setValue(EAST, eastConnection)
                .setValue(SOUTH, southConnection)
                .setValue(WEST, westConnection);
    }
}