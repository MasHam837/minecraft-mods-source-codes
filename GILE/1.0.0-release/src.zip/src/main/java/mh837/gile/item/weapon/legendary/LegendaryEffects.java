package mh837.gile.item.weapon.legendary;

import mh837.gile.GileModParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class LegendaryEffects { private LegendaryEffects() {}

    private static final Identifier ASMODAY_SPEED_ID = Identifier.fromNamespaceAndPath("gilemod", "asmoday_space_speed");
    private static final double ASMODAY_SPEED_BONUS = 0.10D;

    public static void tick(ServerLevel level, Player player) {
        if (player.isSpectator()) return;
        if (level.getGameTime() % 3L != 0L) return;

        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();

        if (is(main, LegendaryWeaponItems.TomeOfNaberius.class) ||
                is(off, LegendaryWeaponItems.TomeOfNaberius.class)) {
            life(level, player);
        } else if (is(main, LegendaryWeaponItems.PalmOfAsmoday.class) ||
                is(off, LegendaryWeaponItems.PalmOfAsmoday.class)) {
            space(level, player);
        } else if (is(main, LegendaryWeaponItems.HourglassOfIstaroth.class) ||
                is(off, LegendaryWeaponItems.HourglassOfIstaroth.class)) {
            time(level, player);
        } else if (is(main, LegendaryWeaponItems.ScytheOfRonova.class) ||
                is(off, LegendaryWeaponItems.ScytheOfRonova.class)) {
            death(level, player);
        }
    }
    private static boolean is(ItemStack stack, Class<?> type) {
        return !stack.isEmpty() && type.isInstance(stack.getItem());
    }

    // NABERIUS
    private static void life(ServerLevel level, Player player) {
        double x = player.getX();
        double y = player.getY() + 0.08D;
        double z = player.getZ();

        long time = level.getGameTime();

        // Small Life flower.
        if (time % 4L == 0L) {
            level.sendParticles(
                    GileModParticleTypes.LIFE,
                    x,
                    y,
                    z,
                    1,
                    0.06D,
                    0.02D,
                    0.06D,
                    0.005D
            );
        }

        // Six rotating petals.
        if (time % 4L == 0L) {
            double rotation =
                    (time % 80L)
                            * (Math.PI * 2.0D / 80.0D);

            for (int i = 0; i < 6; i++) {
                double angle =
                        rotation
                                + Math.PI * 2.0D * i / 6.0D;

                double radius = 0.34D;

                level.sendParticles(
                        GileModParticleTypes.LIFE,
                        x + Math.cos(angle) * radius,
                        y + 0.015D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.045D,
                        0.015D,
                        0.045D,
                        0.005D
                );
            }
        }

        // Small secondary petals.
        if (time % 8L == 0L) {
            level.sendParticles(
                    ParticleTypes.CHERRY_LEAVES,
                    x,
                    y + 0.10D,
                    z,
                    3,
                    0.38D,
                    0.08D,
                    0.38D,
                    0.01D
            );
        }

        // Rare hearts.
        if (time % 60L == 0L) {
            level.sendParticles(
                    ParticleTypes.HEART,
                    x,
                    y + 0.35D,
                    z,
                    2,
                    0.30D,
                    0.18D,
                    0.30D,
                    0.01D
            );
        }
    }
    public static void naberiusOnHit(ServerLevel level, LivingEntity target) {
        double x = target.getX();
        double y =
                target.getY()
                        + target.getBbHeight() * 0.55D;
        double z = target.getZ();

        level.sendParticles(
                GileModParticleTypes.LIFE,
                x,
                y,
                z,
                1,
                0.40D,
                0.55D,
                0.40D,
                0.025D
        );

        level.sendParticles(
                ParticleTypes.HEART,
                x,
                y + 0.25D,
                z,
                3,
                0.20D,
                0.30D,
                0.20D,
                0.01D
        );

        level.sendParticles(
                ParticleTypes.HAPPY_VILLAGER,
                x,
                y,
                z,
                5,
                0.25D,
                0.35D,
                0.25D,
                0.015D
        );
    }

    // ASMODAY
    private static void space(ServerLevel level, Player player) {
        long time = level.getGameTime();

        /*
         * Passive:
         * The Palm of Asmoday bends space around its holder,
         * granting 10% movement speed.
         */
        AttributeInstance speed =
                player.getAttribute(Attributes.MOVEMENT_SPEED);

        if (speed != null && !speed.hasModifier(ASMODAY_SPEED_ID)) {
            speed.addPermanentModifier(
                    new AttributeModifier(
                            ASMODAY_SPEED_ID,
                            ASMODAY_SPEED_BONUS,
                            AttributeModifier.Operation.ADD_MULTIPLIED_BASE
                    )
            );
        }

        double x = player.getX();
        double y = player.getY() + 0.08D;
        double z = player.getZ();

        /*
         * Small rotating spatial distortion.
         * Twice as frequent as before, but still only
         * a few SPACE particles.
         */
        if (time % 4L == 0L) {
            double rotation =
                    (time % 80L)
                            * (Math.PI * 2.0D / 80.0D);

            for (int i = 0; i < 3; i++) {
                double angle =
                        rotation
                                + Math.PI * 2.0D * i / 3.0D;

                double radius =
                        0.28D + i * 0.08D;

                level.sendParticles(
                        GileModParticleTypes.SPACE,
                        x + Math.cos(angle) * radius,
                        y + 0.015D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.025D,
                        0.012D,
                        0.025D,
                        0.004D
                );
            }
        }

        /*
         * Portal particles give the effect more visibility
         * without flooding the world with SPACE particles.
         */
        if (time % 8L == 0L) {
            level.sendParticles(
                    ParticleTypes.PORTAL,
                    x,
                    y + 0.05D,
                    z,
                    3,
                    0.18D,
                    0.025D,
                    0.18D,
                    0.015D
            );
        }

        /*
         * Occasional larger spatial ripple.
         */
        if (time % 20L == 0L) {
            double radius = 0.48D;

            for (int i = 0; i < 8; i++) {
                double angle =
                        Math.PI * 2.0D * i / 8.0D;

                level.sendParticles(
                        ParticleTypes.REVERSE_PORTAL,
                        x + Math.cos(angle) * radius,
                        y + 0.02D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.015D,
                        0.01D,
                        0.015D,
                        0.02D
                );
            }
        }
    }
    private static Vec3 findSafeTeleportPosition(ServerLevel level, LivingEntity entity, double x, double y, double z) {
        BlockPos base =
                BlockPos.containing(x, y, z);

        /*
         * Check the target block and a couple of blocks above it.
         * We want the entity standing ON a block, not inside it.
         */
        for (int dy = 2; dy >= -2; dy--) {

            BlockPos feet =
                    base.above(dy);

            BlockPos head =
                    feet.above();

            BlockState feetState =
                    level.getBlockState(feet);

            BlockState headState =
                    level.getBlockState(head);

            BlockState belowState =
                    level.getBlockState(feet.below());

            if (!belowState.isSolid()) {
                continue;
            }

            if (!feetState.getCollisionShape(level, feet).isEmpty()) {
                continue;
            }

            if (!headState.getCollisionShape(level, head).isEmpty()) {
                continue;
            }

            Vec3 destination =
                    new Vec3(
                            feet.getX() + 0.5D,
                            feet.getY(),
                            feet.getZ() + 0.5D
                    );

            AABB movedBox =
                    entity.getBoundingBox()
                            .move(
                                    destination.x - entity.getX(),
                                    destination.y - entity.getY(),
                                    destination.z - entity.getZ()
                            );

            if (level.noCollision(entity, movedBox)) {
                return destination;
            }
        }

        return null;
    }
    private static void spawnTeleportEffect(ServerLevel level, Vec3 from, Vec3 to) {
        level.sendParticles(
                GileModParticleTypes.SPACE,
                from.x,
                from.y + 0.5D,
                from.z,
                8,
                0.2D,
                0.5D,
                0.2D,
                0.015D
        );

        level.sendParticles(
                ParticleTypes.REVERSE_PORTAL,
                to.x,
                to.y + 0.5D,
                to.z,
                8,
                0.2D,
                0.5D,
                0.2D,
                0.05D
        );
    }
    public static void asmodayOnHit(ServerLevel level, Player attacker, LivingEntity target) {
        if (!target.isAlive() || target == attacker) {
            return;
        }

        Vec3 attackerPos = attacker.position();

        for (int attempt = 0; attempt < 12; attempt++) {

            double angle =
                    level.getRandom().nextDouble()
                            * Math.PI * 2.0D;

            double distance =
                    2.0D
                            + level.getRandom().nextDouble() * 3.0D;

            double x =
                    attackerPos.x
                            + Math.cos(angle) * distance;

            double z =
                    attackerPos.z
                            + Math.sin(angle) * distance;

            double y = attackerPos.y;

            Vec3 destination =
                    findSafeTeleportPosition(
                            level,
                            target,
                            x,
                            y,
                            z
                    );

            if (destination == null) {
                continue;
            }

            Vec3 oldPosition = target.position();

            target.teleportTo(
                    destination.x,
                    destination.y,
                    destination.z
            );

            spawnTeleportEffect(
                    level,
                    oldPosition,
                    target.position()
            );

            level.playSound(
                    null,
                    target.blockPosition(),
                    SoundEvents.ENDERMAN_TELEPORT,
                    SoundSource.PLAYERS,
                    0.65F,
                    1.25F
            );

            return;
        }
    }

    // ISTAROTH
    private static void time(ServerLevel level, Player player) {
        long gameTime = level.getGameTime();

        /*
         * Passive temporal acceleration.
         */
        player.addEffect(
                new MobEffectInstance(
                        MobEffects.SPEED,
                        5,
                        0,
                        false,
                        false,
                        true
                )
        );

        double x = player.getX();
        double y = player.getY() + 0.08D;
        double z = player.getZ();

        /*
         * Rotating Time particles.
         *
         * Twice as frequent as before:
         * every 4 ticks instead of every 8.
         */
        if (gameTime % 4L == 0L) {

            double age =
                    gameTime * 0.18D;

            for (int i = 0; i < 4; i++) {

                double angle =
                        age
                                + Math.PI * 2.0D * i / 4.0D;

                double radius =
                        0.48D + (i % 2) * 0.08D;

                level.sendParticles(
                        GileModParticleTypes.TIME,
                        x + Math.cos(angle) * radius,
                        y,
                        z + Math.sin(angle) * radius,
                        1,
                        0.012D,
                        0.012D,
                        0.012D,
                        0.002D
                );
            }
        }

        /*
         * Small secondary temporal sparks.
         *
         * More visible than the old effect, but still subtle.
         */
        if (gameTime % 12L == 0L) {

            level.sendParticles(
                    ParticleTypes.ENCHANT,
                    x,
                    y + 0.08D,
                    z,
                    3,
                    0.28D,
                    0.08D,
                    0.28D,
                    0.045D
            );
        }

        /*
         * Small rotating foot-ring.
         *
         * This makes the Hourglass visually distinct from
         * the other legendary weapons without flooding
         * the player with particles.
         */
        if (gameTime % 8L == 0L) {

            double rotation =
                    gameTime * 0.12D;

            double radius = 0.62D;

            for (int i = 0; i < 6; i++) {

                double angle =
                        rotation
                                + Math.PI * 2.0D * i / 6.0D;

                level.sendParticles(
                        GileModParticleTypes.TIME,
                        x + Math.cos(angle) * radius,
                        y - 0.015D,
                        z + Math.sin(angle) * radius,
                        1,
                        0.008D,
                        0.008D,
                        0.008D,
                        0.001D
                );
            }
        }
    }
    public static void istarothOnHit(ServerLevel level, Player attacker, LivingEntity target) {
        if (!target.isAlive()
                || target == attacker) {
            return;
        }

        /*
         * Slow the enemy.
         *
         * Slowness II for 4 seconds.
         */
        target.addEffect(
                new MobEffectInstance(
                        MobEffects.SLOWNESS,
                        80,
                        1,
                        false,
                        true,
                        true
                )
        );

        double x =
                target.getX();

        double y =
                target.getY()
                        + target.getBbHeight() * 0.5D;

        double z =
                target.getZ();

        /*
         * Temporal particles.
         */
        level.sendParticles(
                GileModParticleTypes.TIME,
                x,
                y,
                z,
                12,
                0.35D,
                0.55D,
                0.35D,
                0.015D
        );

        /*
         * Enchantment particles make the target look like
         * they're caught in a time distortion.
         */
        level.sendParticles(
                ParticleTypes.ENCHANT,
                x,
                y,
                z,
                8,
                0.35D,
                0.5D,
                0.35D,
                0.08D
        );

        /*
         * A few clock-like particles around their feet.
         */
        for (int i = 0; i < 6; i++) {

            double angle =
                    Math.PI * 2.0D * i / 6.0D;

            double radius =
                    0.45D;

            level.sendParticles(
                    GileModParticleTypes.TIME,
                    x + Math.cos(angle) * radius,
                    target.getY() + 0.05D,
                    z + Math.sin(angle) * radius,
                    1,
                    0.005D,
                    0.005D,
                    0.005D,
                    0.0D
            );
        }

        level.playSound(
                null,
                target.blockPosition(),
                SoundEvents.AMETHYST_BLOCK_CHIME,
                SoundSource.PLAYERS,
                0.5F,
                0.65F
        );
    }

    // RONOVA
    private static void death(ServerLevel level, Player player) {
        long time =
                level.getGameTime();

        /*
         * Keep Resistance comfortably refreshed.
         *
         * The effect is refreshed while the scythe is held,
         * but 40 ticks gives a safe 2-second buffer.
         */
        player.addEffect(
                new MobEffectInstance(
                        MobEffects.RESISTANCE,
                        5,
                        0,
                        false,
                        false,
                        true
                )
        );

        double x = player.getX();
        double y = player.getY() + 0.08D;
        double z = player.getZ();

        /*
         * Rotating Death ring beneath the feet.
         */
        if (time % 6L == 0L) {

            double rotation =
                    time * 0.14D;

            for (int i = 0; i < 3; i++) {

                double angle =
                        rotation
                                + Math.PI * 2.0D * i / 3.0D;

                double radius =
                        0.38D + i * 0.07D;

                level.sendParticles(
                        ParticleTypes.SCULK_SOUL,
                        x + Math.cos(angle) * radius,
                        y,
                        z + Math.sin(angle) * radius,
                        1,
                        0.01D,
                        0.015D,
                        0.01D,
                        0.002D
                );
            }
        }

        /*
         * Occasional Death particle.
         */
        if (time % 18L == 0L) {

            level.sendParticles(
                    GileModParticleTypes.DEATH,
                    x,
                    player.getY() + 0.2D,
                    z,
                    2,
                    0.18D,
                    0.2D,
                    0.18D,
                    0.005D
            );
        }
    }
    public static void ronovaOnHit(ServerLevel level, Player attacker, LivingEntity target, float stolenHealth) {
        if (!target.isAlive()) {
            return;
        }

        double x =
                target.getX();

        double y =
                target.getY()
                        + target.getBbHeight() * 0.5D;

        double z =
                target.getZ();

        /*
         * Death particles.
         */
        level.sendParticles(
                GileModParticleTypes.DEATH,
                x,
                y,
                z,
                16,
                0.35D,
                0.6D,
                0.35D,
                0.015D
        );

        /*
         * Soul particles.
         */
        level.sendParticles(
                ParticleTypes.SCULK_SOUL,
                x,
                y,
                z,
                10,
                0.3D,
                0.5D,
                0.3D,
                0.02D
        );

        /*
         * Damage indicators make the lethal effect obvious.
         */
        level.sendParticles(
                ParticleTypes.DAMAGE_INDICATOR,
                x,
                y,
                z,
                8,
                0.25D,
                0.4D,
                0.25D,
                0.01D
        );
    }

}