package mh837.gile.item.weapon.elemental;

import mh837.gile.GileModParticleTypes;
import mh837.gile.entity.SalonMemberEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class ElementalEffects { private ElementalEffects() {}

    private static final DustParticleOptions VENTI_DUST = new DustParticleOptions(0x55FFE8, 1.25F);
    private static final DustParticleOptions VENTI_FOOT_DUST = new DustParticleOptions(0x5DE8D0, 0.8F);
    private static final DustParticleOptions GEO_DUST = new DustParticleOptions(0xC79A62, 1.15F);
    private static final DustParticleOptions GEO_FOOT_DUST = new DustParticleOptions(0xB87945, 0.8F);
    private static final DustParticleOptions NAHIDA_DUST = new DustParticleOptions(0x7CFF65, 1.15F);
    private static final DustParticleOptions NAHIDA_FOOT_DUST = new DustParticleOptions(0xA8FF78, 0.8F);
    private static final DustParticleOptions FURINA_WATER = new DustParticleOptions(0x66D9FF, 1.15F);
    private static final DustParticleOptions FURINA_LIGHT = new DustParticleOptions(0xB8F5FF, 0.8F);

    // VENTI
    public static void ventiFootParticles(ServerLevel level, Player player) { double y = player.getY() + 0.08D;
        for (int i = 0; i < 4; i++) {double angle = level.getGameTime() * 0.12D + i * Math.PI * 2.0D / 4.0D;
            double radius = 0.28D + Math.sin(level.getGameTime() * 0.15D + i) * 0.04D; double x = player.getX() + Math.cos(angle) * radius;
            double z = player.getZ() + Math.sin(angle) * radius; BlockPos pos = BlockPos.containing(x, y, z);
            if (!level.getBlockState(pos).isAir()) {continue;}
            level.sendParticles(VENTI_FOOT_DUST, x, y, z, 1, 0.025D, 0.035D, 0.025D, 0.015D);}
        if (level.getGameTime() % 3L == 0L) {double angle = level.getGameTime() * 0.12D + Math.PI * 2.0D / 4.0D;
            double radius = 0.28D + Math.sin(level.getGameTime() * 0.15D) * 0.04D;
            double x = player.getX() + Math.cos(angle) * radius; double z = player.getZ() + Math.sin(angle) * radius;
            level.sendParticles(GileModParticleTypes.ANEMO, player.getX(), y + 0.02D, player.getZ(),
                1, 0.22D, 0.025D, 0.22D, 0.012D);
            level.sendParticles(VENTI_FOOT_DUST, x, y, z, 1, 0.025D, 0.035D, 0.025D, 0.015D);}
    }

    public static void spawnVortexCastEffect(ServerLevel level, Player player, Vec3 center) {
        for (int i = 0; i < 48; i++) {double angle = Math.PI * 2.0D * i / 48.0D;double radius = 0.8D + (i / 48.0D) * 1.5D;
            double x = center.x + Math.cos(angle) * radius;double z = center.z + Math.sin(angle) * radius;
            double y = center.y + 0.15D + Math.sin(angle * 3.0D) * 0.15D;
            level.sendParticles(VENTI_DUST, x, y, z, 1, 0.0D, 0.12D, 0.0D, 0.025D);}
        level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.25D, center.z, 28, 0.8D, 0.35D, 0.8D, 0.045D);
        level.sendParticles(ParticleTypes.GUST, center.x, center.y + 0.5D, center.z, 6, 0.45D, 0.35D, 0.45D, 0.08D);
        level.sendParticles(GileModParticleTypes.ANEMO, center.x, center.y + 0.5D, center.z, 6, 0.45D, 0.35D, 0.45D, 0.08D);
    }

    public static void spawnVortexParticles(ServerLevel level, ElementalAbilities.VentiVortex.ActiveVortex vortex) {
        Vec3 position = vortex.getPosition(); double centerX = position.x; double centerY = position.y; double centerZ = position.z;

        for (int arm = 0; arm < 3; arm++) {
            double armOffset = Math.PI * 2.0D * arm / 3.0D;
            double angle = vortex.getAge() * 0.24D + armOffset;
            double pulse = 0.88D + Math.sin(vortex.getAge() * 0.11D + arm) * 0.12D;
            double radius = ElementalAbilities.VentiVortex.getRadius() * pulse; double x = centerX + Math.cos(angle) * radius;
            double z = centerZ + Math.sin(angle) * radius; double y = centerY + 0.35D + Math.sin(vortex.getAge() * 0.16D + arm * 1.7D) * 0.9D;
            Vec3 inward = new Vec3(centerX, centerY + 0.8D, centerZ).subtract(new Vec3(x, y, z)).normalize();
            level.sendParticles(VENTI_DUST, x, y, z,
                    2, inward.x * 0.4D, inward.y * 0.4D, inward.z * 0.4D, 0.035D);}
        if (vortex.getAge() % 2 == 0) { double angle = vortex.getAge() * 0.38D; double radius = ElementalAbilities.VentiVortex.getRadius() * 0.55D;
            double x = centerX + Math.cos(angle) * radius; double z = centerZ + Math.sin(angle) * radius;
            level.sendParticles(VENTI_DUST, x, centerY + 0.6D, z,
                    1, 0.0D, 0.08D, 0.0D, 0.025D);}
        if (vortex.getAge() % 4 == 0) {level.sendParticles(ParticleTypes.CLOUD, centerX, centerY + 0.8D, centerZ,
                    4, 0.45D, 0.35D, 0.45D, 0.025D);
            level.sendParticles(GileModParticleTypes.ANEMO, centerX, centerY + 0.8D, centerZ,
                    4, 0.45D, 0.35D, 0.45D, 0.025D);}
        if (vortex.getAge() % 12 == 0) {level.sendParticles(ParticleTypes.GUST, centerX, centerY + 0.6D, centerZ,
                    2, 0.45D, 0.3D, 0.45D, 0.055D);}
    }

    public static void spawnVortexEndEffect(ServerLevel level, Vec3 center) {
        level.sendParticles(VENTI_DUST, center.x, center.y + 0.5D, center.z, 20, 1.5D, 0.8D, 1.5D, 0.09D);
        level.sendParticles(GileModParticleTypes.ANEMO, center.x, center.y + 0.5D, center.z, 25, 1.5D, 0.8D, 1.5D, 0.09D);
        level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.5D, center.z, 25, 1.3D, 0.5D, 1.3D, 0.065D);
        level.sendParticles(ParticleTypes.GUST, center.x, center.y + 0.7D, center.z, 8, 0.8D, 0.5D, 0.8D, 0.1D);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.BREEZE_CHARGE, SoundSource.PLAYERS, 0.8F, 0.8F);
    }

    // ZHONG LI
    public static void zhongliFootParticles(ServerLevel level, LivingEntity entity) {
        double feetY = entity.getBoundingBox().minY + 0.035D; double time = entity.tickCount * 0.12D;
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()),
                entity.getX(), feetY, entity.getZ(), 2, 0.22D, 0.025D, 0.22D, 0.025D);
        double radius = 0.28D + Math.sin(time) * 0.05D;
        for (int i = 0; i < 2; i++) { double angle = time + Math.PI * i; double x = entity.getX() + Math.cos(angle) * radius;
            double z = entity.getZ() + Math.sin(angle) * radius; double y = feetY + 0.025D + Math.sin(time * 1.4D + i) * 0.025D;
            level.sendParticles(GEO_FOOT_DUST, x, y, z, 1, 0.018D, 0.025D, 0.018D, 0.008D);}
        if (entity.tickCount % 5 == 0) { double angle = time * 0.85D; double radiusOffset = 0.2D;
            double x = entity.getX() + Math.cos(angle) * radiusOffset; double z = entity.getZ() + Math.sin(angle) * radiusOffset;
            level.sendParticles(GEO_DUST, x, feetY + 0.07D, z, 1, 0.035D, 0.06D, 0.035D, 0.015D);
            level.sendParticles(GileModParticleTypes.GEO, x, feetY + 0.07D, z, 1, 0.035D, 0.06D, 0.035D, 0.015D);
        }
    }

    public static void spawnZhongLiAttackEffect(ServerLevel level, LivingEntity attacker, LivingEntity target) {
        double x = target.getX(); double y = target.getY() + target.getBbHeight() * 0.55D; double z = target.getZ();
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()), x, y, z,
                12, 0.35D, 0.45D, 0.35D, 0.16D);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()), x, y, z,
                8, 0.30D, 0.35D, 0.30D, 0.12D);
        level.sendParticles(GEO_DUST, x, y, z, 18, 0.45D, 0.45D, 0.45D, 0.07D);
        level.sendParticles(ParticleTypes.CLOUD, x, target.getY() + 0.15D, z, 5, 0.45D, 0.12D, 0.45D, 0.045D);
        level.sendParticles(GileModParticleTypes.GEO, x, target.getY() + 0.15D, z, 5, 0.45D, 0.12D, 0.45D, 0.045D);
        level.playSound(null, x, y, z, SoundEvents.STONE_HIT, SoundSource.PLAYERS,
                0.9F, 0.65F + level.getRandom().nextFloat() * 0.25F);
    }

    public static void spawnZhongLiActivationEffect(ServerLevel level, Vec3 center) {
        for (int i = 0; i < 72; i++) { double angle = Math.PI * 2.0D * i / 72.0D;
            double radius = 0.8D + (i / 72.0D) * 2.8D; double x = center.x + Math.cos(angle) * radius;
            double z = center.z + Math.sin(angle) * radius; double y = center.y + 0.05D + Math.sin(angle * 4.0D) * 0.08D;
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()),
                    x, y, z, 1, 0.04D, 0.025D, 0.04D, 0.06D);}
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()),
                center.x, center.y + 0.3D, center.z, 35, 1.2D, 0.35D, 1.2D, 0.12D);
        level.sendParticles(GEO_DUST, center.x, center.y + 0.5D, center.z, 45, 1.8D, 0.7D, 1.8D, 0.08D);
        level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.3D, center.z, 35, 1.3D, 0.35D, 1.3D, 0.055D);
        level.sendParticles(ParticleTypes.GUST, center.x, center.y + 0.8D, center.z, 10, 1.0D, 0.6D, 1.0D, 0.10D);
        level.sendParticles(GileModParticleTypes.GEO, center.x, center.y + 0.8D, center.z, 10, 1.0D, 0.6D, 1.0D, 0.10D);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.STONE_PLACE, SoundSource.PLAYERS, 1.25F, 0.55F);
    }

    // RAIDEN
    public static void raidenFootParticles(ServerLevel level, LivingEntity entity) {
        double feetY = entity.getBoundingBox().minY + 0.025D;double time = entity.tickCount * 0.55D;
        for (int i = 0; i < 3; i++) { double angle = time * 1.7D + Math.PI * 2.0D * i / 3.0D;
            double radius = 0.22D + Math.sin(time * 2.0D + i) * 0.035D;
            double x = entity.getX() + Math.cos(angle) * radius; double z = entity.getZ() + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, feetY, z, 1, 0.015D, 0.012D, 0.015D, 0.22D);}
        if (entity.tickCount % 2 == 0) { double angle = time * 2.4D; double radius = 0.32D;
            double x = entity.getX() + Math.cos(angle) * radius; double z = entity.getZ() + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, feetY + 0.035D, z, 2, 0.02D, 0.018D, 0.02D, 0.3D);
            level.sendParticles(GileModParticleTypes.ELECTRO, x, feetY, z, 1, 0.02D, 0.018D, 0.02D, 0.022D);
        }
    }

    public static void spawnRaidenLightningImpact(ServerLevel level, Vec3 center) {
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, center.x, center.y + 0.15D, center.z,
                80, 0.7D, 0.5D, 0.7D, 0.4D);
        level.sendParticles(ParticleTypes.END_ROD, center.x, center.y + 0.3D, center.z,
                20, 0.45D, 0.5D, 0.45D, 0.15D);
        level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.05D, center.z,
                12, 0.6D, 0.08D, 0.6D, 0.04D);
        for (int i = 0; i < 24; i++) { double angle = Math.PI * 2.0D * i / 24.0D; double radius = 0.3D + (i / 24.0D) * 1.1D;
            double x = center.x + Math.cos(angle) * radius; double z = center.z + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, center.y + 0.08D, z,
                    2, 0.04D, 0.05D, 0.04D, 0.3D);}
    }

    // NAHIDA
    public static void nahidaFootParticles(ServerLevel level, LivingEntity entity) {
        double feetY = entity.getBoundingBox().minY + 0.025D; double time = entity.tickCount * 0.16D;
        for (int i = 0; i < 3; i++) { double angle = time + Math.PI * 2.0D * i / 3.0D; double radius = 0.22D + Math.sin(time * 1.7D + i) * 0.035D;
            double x = entity.getX() + Math.cos(angle) * radius; double z = entity.getZ() + Math.sin(angle) * radius;
            level.sendParticles(NAHIDA_FOOT_DUST, x, feetY, z, 1, 0.018D, 0.018D, 0.018D, 0.01D);}
        if (entity.tickCount % 4 == 0) { double angle = time * 1.4D; double radius = 0.32D;
            double x = entity.getX() + Math.cos(angle) * radius; double z = entity.getZ() + Math.sin(angle) * radius;
            level.sendParticles(NAHIDA_DUST, x, feetY + 0.045D, z, 1, 0.025D, 0.035D, 0.025D, 0.012D);}
        if (entity.tickCount % 8 == 0) { double angle = time * 1.4D; double radius = 0.32D;
            double x = entity.getX() + Math.cos(angle) * radius; double z = entity.getZ() + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, entity.getX(), feetY + 0.08D, entity.getZ(),
                    2, 0.2D, 0.03D, 0.2D, 0.01D);
        level.sendParticles(GileModParticleTypes.DENDRO, x, feetY + 0.045D, z, 2, 0.025D, 0.035D, 0.025D, 0.012D);}
    }

    public static void spawnNahidaAttackEffect(ServerLevel level, LivingEntity attacker, LivingEntity target) {
        double x = target.getX(); double y = target.getY() + target.getBbHeight() * 0.5D; double z = target.getZ();

        level.sendParticles(NAHIDA_DUST, x, y, z, 10, 0.4D, 0.55D, 0.4D, 0.06D);
        level.sendParticles(GileModParticleTypes.DENDRO, x, y, z, 20, 0.4D, 0.55D, 0.4D, 0.06D);
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y, z, 10, 0.35D, 0.5D, 0.35D, 0.025D);
        level.sendParticles(ParticleTypes.COMPOSTER, x, target.getY() + 0.1D, z, 8, 0.3D, 0.15D, 0.3D, 0.025D);

        for (int i = 0; i < 3; i++) {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            double radius = 0.25D + level.getRandom().nextDouble() * 0.65D;

            level.sendParticles(NAHIDA_DUST,
                    x + Math.cos(angle) * radius,
                    target.getY() + 0.15D + level.getRandom().nextDouble() * target.getBbHeight(),
                    z + Math.sin(angle) * radius, 3, 0.03D, 0.08D, 0.03D, 0.025D);}
        level.playSound(null, x, y, z, SoundEvents.AMETHYST_BLOCK_CHIME,
                SoundSource.PLAYERS, 0.55F, 1.5F + level.getRandom().nextFloat() * 0.25F);
    }

    // FURINA
    public static void spawnFurinaFootWaves(ServerLevel level, Player player) {
        double x = player.getX(); double y = player.getBoundingBox().minY + 0.025D; double z = player.getZ(); double time = player.tickCount * 0.18D;
        for (int ring = 0; ring < 3; ring++) { double radius = 0.25D + ring * 0.22D + ((time * 0.55D) % 0.22D); for (int i = 0; i < 18; i++) {
                double angle = Math.PI * 2.0D * i / 18.0D; double px = x + Math.cos(angle) * radius; double pz = z + Math.sin(angle) * radius;
                level.sendParticles(FURINA_LIGHT, px, y, pz, 1, 0.012D, 0.012D, 0.012D, 0.008D);}}
        level.sendParticles(ParticleTypes.SPLASH, x, y, z, 5, 0.28D, 0.025D, 0.28D, 0.04D);
        level.sendParticles(GileModParticleTypes.HYDRO, x, y, z, 1, 0.28D, 0.025D, 0.28D, 0.04D);
    }

    public static void spawnFurinaAttackEffect(ServerLevel level, LivingEntity attacker, LivingEntity target) {
        double x = target.getX(); double y = target.getY() + target.getBbHeight() * 0.55D; double z = target.getZ();
        level.sendParticles(ParticleTypes.SPLASH, x, y, z, 35, 0.55D, 0.65D, 0.55D, 0.13D);
        level.sendParticles(ParticleTypes.BUBBLE, x, y, z, 24, 0.45D, 0.6D, 0.45D, 0.09D);
        level.sendParticles(FURINA_WATER, x, y, z, 25, 0.5D, 0.65D, 0.5D, 0.075D);
        for (int i = 0; i < 3; i++) {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D; double radius = 0.3D + level.getRandom().nextDouble() * 0.8D;
            level.sendParticles(FURINA_LIGHT, x + Math.cos(angle) * radius,
                    target.getY() + 0.15D + level.getRandom().nextDouble() * target.getBbHeight(), z + Math.sin(angle) * radius,
                    4, 0.03D, 0.08D, 0.03D, 0.025D);}
        level.sendParticles(ParticleTypes.FALLING_WATER, x, target.getY() + 0.1D, z, 15, 0.4D, 0.1D, 0.4D, 0.04D);
        level.sendParticles(GileModParticleTypes.HYDRO, x, target.getY() + 0.1D, z, 15, 0.4D, 0.1D, 0.4D, 0.04D);
        level.playSound(null, x, y, z, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, SoundSource.PLAYERS,
                0.9F, 0.85F + level.getRandom().nextFloat() * 0.3F);
    }

    public static void spawnFurinaMemberParticles(ServerLevel level, SalonMemberEntity member) {
        double x = member.getX(); double y = member.getY() + 0.65D; double z = member.getZ();
        level.sendParticles(ParticleTypes.FALLING_WATER, x, y, z, 3, 0.18D, 0.25D, 0.18D, 0.025D);
        level.sendParticles(ParticleTypes.BUBBLE, x, y, z, 2, 0.14D, 0.18D, 0.14D, 0.025D);
        if (member.tickCount % 8 == 0) {
            level.sendParticles(FURINA_LIGHT, x, y + 0.15D, z, 2, 0.2D, 0.25D, 0.2D, 0.015D);
            level.sendParticles(GileModParticleTypes.HYDRO, x, y, z, 1, 0.14D, 0.18D, 0.14D, 0.025D);
        }
    }

    public static void spawnFurinaMemberAttackEffect(ServerLevel level, SalonMemberEntity member, LivingEntity target) {
        double x = target.getX(); double y = target.getY() + target.getBbHeight() * 0.5D; double z = target.getZ();
        level.sendParticles(ParticleTypes.SPLASH, x, y, z, 22, 0.4D, 0.5D, 0.4D, 0.1D);
        level.sendParticles(ParticleTypes.BUBBLE_POP, x, y, z, 6, 0.3D, 0.35D, 0.3D, 0.07D);
        level.sendParticles(GileModParticleTypes.HYDRO, x, y, z, 6, 0.3D, 0.35D, 0.3D, 0.07D);
        level.sendParticles(FURINA_WATER, x, y, z, 15, 0.35D, 0.45D, 0.35D, 0.06D);
        level.playSound(null, x, y, z, SoundEvents.PLAYER_SPLASH, SoundSource.PLAYERS, 0.65F, 1.15F);
    }

    public static void spawnFurinaSummonEffect(ServerLevel level, ServerPlayer player) {
        double x = player.getX(); double y = player.getY() + 0.1D; double z = player.getZ();
        for (int i = 0; i < 72; i++) { double angle = Math.PI * 2.0D * i / 72.0D; double radius = 0.5D + (i / 72.0D) * 2.6D;
            level.sendParticles(FURINA_LIGHT, x + Math.cos(angle) * radius, y, z + Math.sin(angle) * radius,
                    1, 0.025D, 0.01D, 0.025D, 0.02D);}
        level.sendParticles(ParticleTypes.SPLASH, x, y + 0.2D, z, 35, 1.4D, 0.25D, 1.4D, 0.1D);
        level.sendParticles(ParticleTypes.BUBBLE, x, y + 0.5D, z, 20, 1.1D, 0.7D, 1.1D, 0.06D);
        level.sendParticles(GileModParticleTypes.HYDRO, x, y + 0.5D, z, 20, 1.1D, 0.7D, 1.1D, 0.06D);
        level.playSound(null, x, y, z, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, SoundSource.PLAYERS, 1.2F, 0.75F);
    }

    public static void spawnFurinaMemberDismissEffect(ServerLevel level, SalonMemberEntity member) {
        level.sendParticles(ParticleTypes.SPLASH, member.getX(), member.getY() + 0.5D, member.getZ(),
                12, 0.3D, 0.35D, 0.3D, 0.08D);
        level.sendParticles(GileModParticleTypes.HYDRO, member.getX(), member.getY() + 0.5D, member.getZ(),
                12, 0.3D, 0.35D, 0.3D, 0.08D);

    }

    public static void spawnFurinaSalonParticles(ServerLevel level, ServerPlayer player, List<SalonMemberEntity> members) {
        for (SalonMemberEntity member : members) { if (!member.isAlive()) continue;
            level.sendParticles(ParticleTypes.FALLING_WATER, member.getX(), member.getY() + 0.5D, member.getZ(),
                    1, 0.08D, 0.12D, 0.08D, 0.015D);}
    }

    // MAVUIKA
    public static void mavuikaFootParticles(ServerLevel level, LivingEntity entity) {
        double feetY = entity.getBoundingBox().minY + 0.025D; double time = entity.tickCount * 0.32D;
        for (int i = 0; i < 3; i++) {
            double angle = time * 1.4D + Math.PI * 2.0D * i / 3.0D; double radius = 0.23D + Math.sin(time * 1.8D + i) * 0.04D;
            double x = entity.getX() + Math.cos(angle) * radius; double z = entity.getZ() + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.FLAME, x, feetY, z, 2, 0.025D, 0.035D, 0.025D, 0.018D);}
        if (entity.tickCount % 3 == 0) {level.sendParticles(ParticleTypes.FLAME, entity.getX(), feetY + 0.08D, entity.getZ(),
                    2, 0.16D, 0.08D, 0.16D, 0.025D);
                                        level.sendParticles(GileModParticleTypes.PYRO, entity.getX(), feetY + 0.08D, entity.getZ(),
                    1, 0.14D, 0.16D, 0.14D, 0.01D);}
        if (entity.tickCount % 8 == 0) {level.sendParticles(ParticleTypes.SMOKE, entity.getX(), feetY + 0.05D, entity.getZ(),
                    1, 0.12D, 0.025D, 0.12D, 0.01D);}
    }

    public static void spawnMavuikaActivationEffect(ServerLevel level, ServerPlayer player) {
        double yaw = Math.toRadians(player.getYRot()); double backX = Math.sin(yaw); double backZ = -Math.cos(yaw);
        double centerX = player.getX() + backX * 0.8D; double centerY = player.getY() + 1.15D; double centerZ = player.getZ() + backZ * 0.8D;
        double radius = 1.7D;
        for (int i = 0; i < 72; i++) {double angle = Math.PI * 2.0D * i / 72.0D;
            double sideX = Math.cos(yaw) * Math.cos(angle) * radius; double sideZ = Math.sin(yaw) * Math.cos(angle) * radius;
            double py = centerY + Math.sin(angle) * radius; double px = centerX + sideX; double pz = centerZ + sideZ;
            level.sendParticles(ParticleTypes.FLAME, px, py, pz, 2, 0.025D, 0.025D, 0.025D, 0.02D);
            if (i % 3 == 0) {level.sendParticles(ParticleTypes.LAVA, px, py, pz, 1, 0.015D, 0.015D, 0.015D, 0.01D);}}
        level.sendParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 0.2D, player.getZ(),
                25, 1.4D, 0.35D, 1.4D, 0.04D);
        level.sendParticles(GileModParticleTypes.PYRO, player.getX(), player.getY() + 0.2D, player.getZ(),
                20, 1.4D, 0.35D, 1.4D, 0.04D);
        level.sendParticles(ParticleTypes.LAVA, player.getX(), player.getY() + 0.5D, player.getZ(),
                25, 0.8D, 0.4D, 0.8D, 0.035D);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.FIRECHARGE_USE,
                SoundSource.PLAYERS, 1.25F, 0.65F);
    }

    public static void spawnMavuikaAttackEffect(ServerLevel level, LivingEntity attacker, LivingEntity target) {
        double x = target.getX(); double y = target.getY() + target.getBbHeight() * 0.5D; double z = target.getZ();
        level.sendParticles(ParticleTypes.FLAME, x, y, z, 30, 0.45D, 0.6D, 0.45D, 0.08D);
        level.sendParticles(ParticleTypes.LAVA, x, y, z, 8, 0.3D, 0.4D, 0.3D, 0.025D);
        for (int i = 0; i < 3; i++) {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D; double radius = 0.2D + level.getRandom().nextDouble() * 0.65D;
            level.sendParticles(ParticleTypes.FLAME, x + Math.cos(angle) * radius,
                    target.getY() + 0.1D + level.getRandom().nextDouble() * target.getBbHeight(), z + Math.sin(angle) * radius,
                    5, 0.03D, 0.12D, 0.03D, 0.035D);}
        if (attacker != null) {level.sendParticles(ParticleTypes.FLAME, attacker.getX(), attacker.getBoundingBox().minY + 0.05D, attacker.getZ(),
                    8, 0.25D, 0.05D, 0.25D, 0.025D);
        level.sendParticles(GileModParticleTypes.PYRO, attacker.getX(), attacker.getBoundingBox().minY + 0.05D, attacker.getZ(),
                    8, 0.25D, 0.05D, 0.25D, 0.025D);
        }
    }

    // TSARITSA
    public static void tsaritsaFootParticles(ServerLevel level, LivingEntity entity) {
        double feetY = entity.getBoundingBox().minY + 0.025D;
        double time = entity.tickCount * 0.18D;

        for (int i = 0; i < 3; i++) {
            double angle = time + Math.PI * 2.0D * i / 3.0D;
            double radius = 0.22D + Math.sin(time * 1.5D + i) * 0.035D;
            double x = entity.getX() + Math.cos(angle) * radius;
            double z = entity.getZ() + Math.sin(angle) * radius;

            level.sendParticles(ParticleTypes.SNOWFLAKE, x, feetY, z,
                    2, 0.025D, 0.02D, 0.025D, 0.015D);
        }

        if (entity.tickCount % 3 == 0)
            level.sendParticles(ParticleTypes.SNOWFLAKE, entity.getX(), feetY + 0.08D, entity.getZ(),
                    3, 0.18D, 0.06D, 0.18D, 0.025D);

        if (entity.tickCount % 5 == 0)
            level.sendParticles(GileModParticleTypes.CRYO, entity.getX(), feetY + 0.04D, entity.getZ(),
                    2, 0.17D, 0.04D, 0.17D, 0.018D);

        if (entity.tickCount % 8 == 0)
            level.sendParticles(ParticleTypes.CLOUD, entity.getX(), feetY + 0.04D, entity.getZ(),
                    1, 0.16D, 0.025D, 0.16D, 0.012D);
    }

    public static void spawnTsaritsaAttackEffect(ServerLevel level, LivingEntity attacker, LivingEntity target) {
        double x = target.getX();
        double y = target.getY() + target.getBbHeight() * 0.5D;
        double z = target.getZ();

        level.sendParticles(ParticleTypes.SNOWFLAKE, x, y, z,
                20, 0.5D, 0.65D, 0.5D, 0.08D);
        level.sendParticles(GileModParticleTypes.CRYO, x, y, z,
                10, 0.45D, 0.35D, 0.45D, 0.1D);
        level.sendParticles(ParticleTypes.CLOUD, x, target.getY() + 0.15D, z,
                10, 0.4D, 0.12D, 0.4D, 0.035D);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState()),
                x, y, z, 14, 0.35D, 0.45D, 0.35D, 0.12D);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.ICE.defaultBlockState()),
                x, y, z, 10, 0.3D, 0.4D, 0.3D, 0.1D);

        for (int i = 0; i < 3; i++) {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            double radius = 0.3D + level.getRandom().nextDouble() * 0.75D;

            level.sendParticles(ParticleTypes.SNOWFLAKE,
                    x + Math.cos(angle) * radius,
                    target.getY() + 0.1D + level.getRandom().nextDouble() * target.getBbHeight(),
                    z + Math.sin(angle) * radius,
                    4, 0.04D, 0.08D, 0.04D, 0.025D);
        }

        level.playSound(null, x, y, z, SoundEvents.GLASS_BREAK,
                SoundSource.PLAYERS, 0.9F, 0.75F + level.getRandom().nextFloat() * 0.3F);
    }

    // COLUMBINA
    public static void spawnNocturneAttackEffect(ServerLevel level, LivingEntity target) {
        double x = target.getX(); double y = target.getY() + target.getBbHeight() * 0.5D; double z = target.getZ();
        level.sendParticles(ParticleTypes.END_ROD, x, y, z, 4, 0.35D, 0.5D, 0.35D, 0.045D);
        level.sendParticles(GileModParticleTypes.LUNA, x, y, z, 10, 0.35D, 0.5D, 0.35D, 0.045D);
        level.sendParticles(ParticleTypes.ENCHANT, x, y, z, 10, 0.3D, 0.45D, 0.3D, 0.12D);
        level.sendParticles(ParticleTypes.CLOUD, x, target.getY() + 0.08D, z, 6, 0.3D, 0.08D, 0.3D, 0.025D);
        double ringY = target.getY() + 0.15D; for (int i = 0; i < 12; i++) {
            double angle = Math.PI * 2.0D * i / 12.0D; double radius = 0.35D + i * 0.035D;
            level.sendParticles(ParticleTypes.END_ROD, x + Math.cos(angle) * radius, ringY + Math.sin(angle * 2.0D) * 0.08D,
                    z + Math.sin(angle) * radius, 1, 0.01D, 0.025D, 0.01D, 0.01D);}
    }

    public static void spawnLunarDomainOpening(ServerLevel level, ServerPlayer player, Vec3 center) {
        double yaw = Math.toRadians(player.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);

        // === Ring behind caster ===
        double rx = player.getX() - fx * 0.8D;
        double ry = player.getY() + 1.0D;
        double rz = player.getZ() - fz * 0.8D;

        for (int i = 0; i < 36; i++) {
            double a = Math.PI * 2.0D * i / 36.0D;
            level.sendParticles(ParticleTypes.END_ROD,
                    rx + Math.cos(a) * 1.05D,
                    ry + Math.sin(a) * 1.05D,
                    rz,
                    1, 0.012D, 0.012D, 0.012D, 0.006D);
        }

        // === Large lunar hemisphere ===
        double domeRadius = 7.0D;
        double domeHeight = 5.5D;

        for (int layer = 0; layer < 5; layer++) {
            double offset = layer * 0.35D;
            double radius = domeRadius - offset;

            for (int i = 0; i < 28; i++) {
                double theta = Math.PI * 0.5D * i / 27.0D;
                double y = center.y + Math.sin(theta) * domeHeight;
                double r = Math.cos(theta) * radius;

                for (int j = 0; j < 2; j++) {
                    double angle = Math.PI * 2.0D * j / 2.0D
                            + i * 0.23D + layer * 0.8D;

                    double x = center.x + Math.cos(angle) * r;
                    double z = center.z + Math.sin(angle) * r;

                    level.sendParticles(
                            ParticleTypes.END_ROD,
                            x, y, z,
                            1,
                            0.025D, 0.025D, 0.025D,
                            0.008D);

                    level.sendParticles(
                            GileModParticleTypes.LUNA,
                            x, y, z,
                            1,
                            0.035D, 0.035D, 0.035D,
                            0.006D);
                }
            }
        }

        // === Floating lunar dust inside dome ===
        for (int i = 0; i < 70; i++) {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            double r = Math.sqrt(level.getRandom().nextDouble()) * (domeRadius - 0.4D);
            double y = center.y + level.getRandom().nextDouble() * domeHeight;

            // Keep particles inside the hemisphere
            double maxR = domeRadius * Math.sqrt(
                    Math.max(0.0D, 1.0D - Math.pow((y - center.y) / domeHeight, 2.0D)));

            r = Math.min(r, maxR);

            level.sendParticles(
                    GileModParticleTypes.LUNA,
                    center.x + Math.cos(angle) * r,
                    y,
                    center.z + Math.sin(angle) * r,
                    1,
                    0.02D, 0.025D, 0.02D,
                    0.012D);
        }

        // === Bright opening at the floor ===
        for (int i = 0; i < 72; i++) {
            double a = Math.PI * 2.0D * i / 72.0D;
            double r = 0.7D + (i / 72.0D) * 2.8D;

            level.sendParticles(
                    ParticleTypes.END_ROD,
                    center.x + Math.cos(a) * r,
                    center.y + 0.05D + Math.sin(a * 4.0D) * 0.08D,
                    center.z + Math.sin(a) * r,
                    1, 0.015D, 0.025D, 0.015D, 0.008D);

            if (i % 2 == 0)
                level.sendParticles(
                        GileModParticleTypes.LUNA,
                        center.x + Math.cos(a) * r,
                        center.y + 0.08D,
                        center.z + Math.sin(a) * r,
                        1, 0.02D, 0.02D, 0.02D, 0.006D);
        }

        level.sendParticles(
                ParticleTypes.ENCHANT,
                center.x, center.y + 1.0D, center.z,
                45, 1.5D, 1.0D, 1.5D, 0.09D);

        level.sendParticles(
                ParticleTypes.END_ROD,
                center.x, center.y + 0.5D, center.z,
                35, 0.9D, 0.6D, 0.9D, 0.04D);

        level.sendParticles(
                ParticleTypes.CLOUD,
                center.x, center.y + 0.08D, center.z,
                25, 1.8D, 0.1D, 1.8D, 0.025D);
    }

    public static void spawnLunarDomainParticles(ServerLevel level, Vec3 center, int age, double radius) { double time = age * 0.18D;
        for (int arm = 0; arm < 3; arm++) {double angle = time + Math.PI * 2.0D * arm / 3.0D;
            double pulse = 0.88D + Math.sin(age * 0.09D + arm) * 0.12D; double r = radius * pulse;
            double x = center.x + Math.cos(angle) * r; double z = center.z + Math.sin(angle) * r; double y = center.y + 0.35D
                    + Math.sin(time * 1.5D + arm) * 0.7D; level.sendParticles(ParticleTypes.END_ROD,  x, y, z, 1,
                    0.025D, 0.08D, 0.025D, 0.012D); level.sendParticles(GileModParticleTypes.LUNA,  x, y, z, 2,
                    0.025D, 0.08D, 0.025D, 0.012D); }
        if (age % 5 == 0) {for (int i = 0; i < 18; i++) {double angle = Math.PI * 2.0D * i / 18.0D + time;
                double r = radius * (0.35D + level.getRandom().nextDouble() * 0.55D);
                level.sendParticles(ParticleTypes.ENCHANT, center.x + Math.cos(angle) * r,
                        center.y + 0.15D + level.getRandom().nextDouble() * 1.5D, center.z + Math.sin(angle) * r,
                        1, 0.02D, 0.05D, 0.02D, 0.08D);}}
        if (age % 12 == 0) {level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.15D, center.z,
                    5, radius * 0.45D, 0.12D, radius * 0.45D, 0.02D);}
    }

    public static void spawnLunarDomainCollapse(ServerLevel level, Vec3 center, double radius) {
        level.sendParticles(ParticleTypes.END_ROD, center.x, center.y + 1.2D, center.z, 40, radius, 1.8D, radius, -0.025D);
        level.sendParticles(GileModParticleTypes.LUNA, center.x, center.y + 1.2D, center.z, 40, radius, 1.8D, radius, -0.025D);
        level.sendParticles(ParticleTypes.ENCHANT, center.x, center.y + 1.0D, center.z,
                55, radius * 0.8D, 1.0D, radius * 0.8D, -0.035D);
        level.sendParticles(ParticleTypes.CLOUD, center.x, center.y + 0.3D, center.z, 35, radius, 0.3D, radius, -0.015D);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.1F, 0.65F);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 0.35F, 1.7F);
    }

    public static void columbinaFootParticles(ServerLevel level, LivingEntity entity) {
        double y = entity.getBoundingBox().minY + 0.035D; double time = entity.tickCount * 0.08D;
        for (int i = 0; i < 2; i++) { double angle = time + Math.PI * i; double radius = 0.28D + Math.sin(time * 1.3D + i) * 0.04D;
            level.sendParticles(ParticleTypes.END_ROD, entity.getX() + Math.cos(angle) * radius,
                    y + 0.025D + Math.sin(time + i) * 0.025D, entity.getZ() + Math.sin(angle) * radius,
                    1, 0.012D, 0.018D, 0.012D, 0.004D);}
        if (entity.tickCount % 3 == 0) {level.sendParticles(GileModParticleTypes.LUNA, entity.getX(), y + 0.06D, entity.getZ(),
                1, 0.12D, 0.025D, 0.12D, 0.003D);}
        if (entity.tickCount % 6 == 0) {level.sendParticles(ParticleTypes.END_ROD, entity.getX(), y + 0.06D, entity.getZ(),
                    1, 0.12D, 0.025D, 0.12D, 0.003D);}
    }

}