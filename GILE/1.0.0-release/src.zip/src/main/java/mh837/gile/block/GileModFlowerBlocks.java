package mh837.gile.block;

import mh837.gile.GileModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.state.BlockState;

public class GileModFlowerBlocks extends FlowerBlock {

    public GileModFlowerBlocks(Holder<MobEffect> effect, int duration, Properties properties) {
        super(effect, duration, properties);
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        return super.mayPlaceOn(state, level, pos)
                || state.is(GileModBlocks.MOON_SAND)
                || state.is(GileModBlocks.END_GRASS_BLOCK);
    }
}