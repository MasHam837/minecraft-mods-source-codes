package mh837.gile.block.entity;

import mh837.gile.GileModBlockEntities;
import mh837.gile.GileModTags;
import mh837.gile.block.entity.slots.SigilInputSlot;
import mh837.gile.block.entity.slots.WishInputSlot;
import mh837.gile.block.entity.slots.WishOutputSlot;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class WishTableScreenHandler extends AbstractContainerMenu {

    private final WishTableBlockEntity wishTable; private final ContainerData data;

    public WishTableScreenHandler(int syncId, Inventory playerInventory) {this(syncId, playerInventory, null);}

    public WishTableScreenHandler(int syncId, Inventory playerInventory, WishTableBlockEntity wishTable) {
        super(GileModBlockEntities.WISH_TABLE_SCREEN_HANDLER, syncId);this.wishTable = wishTable;
        if (wishTable != null) {this.data = wishTable.getData();} else {this.data = new SimpleContainerData(5);}this.addDataSlots(this.data);
        Container container = wishTable != null ? wishTable : new SimpleContainer(4);

        // Wish slot
        this.addSlot(new WishInputSlot(container, WishTableBlockEntity.WISH_SLOT, 18, 46));
        // Sigil slot
        this.addSlot(new SigilInputSlot(container, WishTableBlockEntity.SIGIL_SLOT, 48, 46));
        // Main output slot
        this.addSlot(new WishOutputSlot(container, WishTableBlockEntity.MAIN_OUTPUT_SLOT, 112, 46));
        // Complementary output slot
        this.addSlot(new WishOutputSlot(container, WishTableBlockEntity.COMPLEMENTARY_OUTPUT_SLOT, 142, 46));
        // Inventory slots
        for (int row = 0; row < 3; row++) {for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(playerInventory, column + row * 9 + 9, 8 + column * 18, 84 + row * 18));}}
        // Hotbar slots
        for (int slot = 0; slot < 9; slot++) {this.addSlot(new Slot(playerInventory, slot, 8 + slot * 18, 142));}}

    // DATA
    public int getWishProgress() {return data.get(0);}
    public int getWishDuration() {return data.get(1);}
    public WishRarity getCurrentRarity() {return WishRarity.fromId(data.get(2));}
    public int getPermanentProgress() {return data.get(3);}
    public boolean isProcessing() {return data.get(4) != 0;}

    // SHIFT CLICK
    @Override
    public ItemStack quickMoveStack(Player player, int index) {Slot clickedSlot = this.slots.get(index);if (!clickedSlot.hasItem()) {return ItemStack.EMPTY;}
        ItemStack sourceStack = clickedSlot.getItem();ItemStack originalStack = sourceStack.copy();
        if (index < 4) {if (!this.moveItemStackTo(sourceStack, 4, 40, true)) {return ItemStack.EMPTY;}
        } else {if (sourceStack.is(GileModTags.Items.WISH_INPUT)) {if (!this.moveItemStackTo(sourceStack, WishTableBlockEntity.WISH_SLOT,
                WishTableBlockEntity.WISH_SLOT + 1, false)) {return ItemStack.EMPTY;}
        } else if (sourceStack.is(GileModTags.Items.SIGIL_INPUT)) {if (!this.moveItemStackTo(sourceStack, WishTableBlockEntity.SIGIL_SLOT,
                WishTableBlockEntity.SIGIL_SLOT + 1, false)) {return ItemStack.EMPTY;}
            } else {return ItemStack.EMPTY;}} if (sourceStack.isEmpty()) {clickedSlot.setByPlayer(ItemStack.EMPTY);} else {clickedSlot.setChanged();}
        if (sourceStack.getCount() == originalStack.getCount()) {return ItemStack.EMPTY;}clickedSlot.onTake(player, sourceStack);return originalStack;}

    // VALIDITY
    @Override
    public boolean stillValid(Player player) {return this.wishTable == null || this.wishTable.stillValid(player);}

}