package com.gile.tool.item;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class FateSwordItem extends class_1829 {
    public FateSwordItem(class_1832 toolMaterial, class_1793 settings) {
        super(toolMaterial, settings);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        // Call the parent method to apply damage
        boolean result = super.method_7873(stack, target, attacker);
        // Add particles on hit
        if (attacker.method_37908() instanceof class_3218 serverWorld) {
            // Spawn particles at the target's position
            serverWorld.method_14199(
                    class_2398.field_11248,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    40,
                    0.5,  0.5, 0.5,
                    0.1 );
            // Play a sound effect
            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_26979,
                    class_3419.field_15248,
                    1.0f,
                    1.0f);
        }
        return result;
    }
}