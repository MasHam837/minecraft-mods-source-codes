package com.gile.tool.item;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

import static net.minecraft.class_1304.field_6173;
import static net.minecraft.class_1304.field_6171;

public class GrapplingHookItem extends class_1792 {

    private static class GrappleState {
        final class_243 target;
        int ticksActive = 0;

        GrappleState(class_243 target) {
            this.target = target;
        }
    }

    private final Map<UUID, GrappleState> activeHooks = new ConcurrentHashMap<>();

    public GrapplingHookItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        // --- UPDATED: Distance increased from 32.0 to 64.0 blocks ---
        double maxDistance = 64.0;
        class_243 eyePos = user.method_33571();
        class_243 lookVec = user.method_5828(1.0F);
        class_243 traceEnd = eyePos.method_1019(lookVec.method_1021(maxDistance));

        class_3965 hitResult = world.method_17742(new class_3959(
                eyePos,
                traceEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                user
        ));

        if (hitResult.method_17783() == class_239.class_240.field_1332) {
            class_243 hookPoint = hitResult.method_17784();

            if (!world.method_8608()) {
                activeHooks.put(user.method_5667(), new GrappleState(hookPoint));

                // 3 second cooldown remains active
                user.method_7357().method_7906(this, 60);

                world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(),
                        class_3417.field_49045, class_3419.field_15248, 1.0F, 1.5F);

                if (user instanceof class_3222 serverPlayer) {
                    stack.method_7970(
                            1,
                            serverPlayer,
                            hand == class_1268.field_5808 ? field_6173 : field_6171
                    );
                }
            }
            return class_1271.method_22427(stack);
        } else {
            if (!world.method_8608()) {
                world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(),
                        class_3417.field_24065, class_3419.field_15248, 0.5F, 0.8F);
            }
        }

        return class_1271.method_22430(stack);
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if (world.method_8608() || !(entity instanceof class_3222 player)) return;

        UUID uuid = player.method_5667();
        if (!activeHooks.containsKey(uuid)) return;

        boolean isHolding = player.method_6047() == stack || player.method_6079() == stack;
        if (!isHolding) {
            activeHooks.remove(uuid);
            return;
        }

        GrappleState state = activeHooks.get(uuid);
        state.ticksActive++;
        class_243 currentPos = player.method_19538();

        // --- UPDATED: Timeout filter increased from 80 to 120 ticks ---
        // This gives you up to 6 full seconds to cross the massive 64-block gap.
        if (state.ticksActive > 120) {
            activeHooks.remove(uuid);
            return;
        }

        if (currentPos.method_1022(state.target) < 2.2) {
            activeHooks.remove(uuid);
            return;
        }

        if (state.ticksActive > 5 && player.method_24828()) {
            activeHooks.remove(uuid);
            return;
        }

        spawnRopeParticles((class_3218) world, player.method_33571(), state.target);

        class_243 pullDirection = state.target.method_1020(currentPos);
        double pullSpeed = 0.85;
        class_243 velocityVector = pullDirection.method_1029().method_1021(pullSpeed);

        player.method_18800(velocityVector.field_1352, velocityVector.field_1351 + 0.1, velocityVector.field_1350);
        player.field_6037 = true;
        player.field_6017 = 0.0F;
    }

    private void spawnRopeParticles(class_3218 world, class_243 start, class_243 end) {
        double distance = start.method_1022(end);
        int particleCount = (int) (distance * 2);

        for (int i = 0; i <= particleCount; i++) {
            double pct = (double) i / particleCount;
            double x = start.field_1352 + (end.field_1352 - start.field_1352) * pct;
            double y = start.field_1351 + (end.field_1351 - start.field_1351) * pct;
            double z = start.field_1350 + (end.field_1350 - start.field_1350) * pct;

            world.method_14199(class_2398.field_11205, x, y, z, 1, 0, 0, 0, 0);
        }
    }
}