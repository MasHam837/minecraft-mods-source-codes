package com.gile.tool.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.joml.Vector3f;

public class ThousandBlazingSunsItem extends class_1829 {
    private static final int FIRE_DURATION = 100; // 5 seconds

    public ThousandBlazingSunsItem(class_1832 toolMaterial, class_1793 settings) {
        super(toolMaterial, settings);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(this.method_7866(stack)).method_27694(style ->
                style.method_10977(net.minecraft.class_124.field_1054)
        );
    }

    private static final class_2394 HIT_PARTICLE = new class_2390(
            new Vector3f(0.9f, 0.15f, 0.1f),
            1.5f
    );

    private static final class_2394 FEET_PARTICLE = new class_2390(
            new Vector3f(1.0f, 0.35f, 0.0f), // Orange-red color
            1.0f
    );

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        boolean result = super.method_7873(stack, target, attacker);

        if (attacker.method_37908() instanceof class_3218 serverWorld) {
            // Set target on fire
            target.method_5639(FIRE_DURATION);

            // Spawn particles at the target's position
            serverWorld.method_14199(
                    HIT_PARTICLE,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    40,
                    0.5, 0.5, 0.5,
                    0.01);

            serverWorld.method_14199(
                    class_2398.field_27783,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    25,
                    0.5, 0.5, 0.5,
                    0.05);

            serverWorld.method_14199(
                    class_2398.field_11240,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    10,
                    0.3, 0.3, 0.3,
                    0.02);

            // Play fire-related sounds
            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_14993,
                    class_3419.field_15248,
                    1.0f,
                    1.0f);

            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_15013,
                    class_3419.field_15248,
                    0.8f,
                    1.2f);
        }
        return result;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        super.method_7888(stack, world, entity, slot, selected);

        if (entity instanceof class_1309 livingEntity) {
            // Apply effects constantly when held in main hand or offhand
            boolean isHeld = selected || livingEntity.method_6079() == stack;

            if (isHeld) {
                // Constant Speed I effect (infinite duration, no particles)
                livingEntity.method_6092(new class_1293(
                        class_1294.field_5904,
                        1,
                        0,
                        false, // No ambient particles
                        false, // No icon particles
                        true   // Show icon
                ));

                livingEntity.method_6092(new class_1293(
                        class_1294.field_5900,
                        1,
                        0,
                        false,
                        false,
                        true
                ));

                livingEntity.method_6092(new class_1293(
                        class_1294.field_5913,
                        1,
                        0,
                        false,
                        false,
                        true
                ));

                livingEntity.method_6092(new class_1293(
                        class_1294.field_5918,
                        1,
                        0,
                        false,
                        false,
                        true
                ));
            }

            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof class_3218 serverWorld) {
                if (world.method_8510() % 2 == 0) { // Every other tick
                    double x = livingEntity.method_23317();
                    double y = livingEntity.method_23318() + 0.1; // Feet level
                    double z = livingEntity.method_23321();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.field_9229.method_43058() - 0.5) * 0.6;
                        double offsetZ = (world.field_9229.method_43058() - 0.5) * 0.6;

                        serverWorld.method_14199(
                                class_2398.field_27783,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Spawn colored dust at feet
                    serverWorld.method_14199(
                            FEET_PARTICLE,
                            x,
                            y,
                            z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );

                    // Occasional smoke
                    if (world.method_8510() % 6 == 0) {
                        serverWorld.method_14199(
                                class_2398.field_11251,
                                x,
                                y + 0.3,
                                z,
                                1,
                                0.2, 0.1, 0.2,
                                0.01
                        );
                    }
                }
            }
        }
    }
}