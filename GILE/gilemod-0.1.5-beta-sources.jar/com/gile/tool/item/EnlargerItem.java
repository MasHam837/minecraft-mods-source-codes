package com.gile.tool.item;

import com.gile.GileMod;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;

public class EnlargerItem extends class_1792 {

    public EnlargerItem(class_1793 settings) {
        super(settings);
    }

    /**
     * Handles applying Enlarge OR countering an active Shrink effect.
     */
    private void processEnlargeTarget(class_1309 target, class_1937 world, class_1657 user, class_1799 stack, boolean isSelf) {
        boolean isCountering = target.method_6059(GileMod.SHRINK_EFFECT);

        if (!world.field_9236) {
            if (isCountering) {
                // COUNTER LOGIC: Subtract 5 mins (6000 ticks) from Shrink
                class_1293 currentEffect = target.method_6112(GileMod.SHRINK_EFFECT);
                int remainingTicks = currentEffect != null ? currentEffect.method_5584() : 0;

                target.method_6016(GileMod.SHRINK_EFFECT);

                // If they had more than 5 minutes left, give back the remainder
                if (remainingTicks > 6000) {
                    target.method_6092(new class_1293(GileMod.SHRINK_EFFECT, remainingTicks - 6000, 3, true, true));
                }

                // Play cancel visuals
                if (world instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11204, target.method_23317(), target.method_23323(0.5), target.method_23321(), 20, 0.3, 0.5, 0.3, 0.1);
                }
            } else {
                // NORMAL APPLY LOGIC
                int finalDuration = 6000;
                if (target.method_6059(GileMod.ENLARGE_EFFECT)) {
                    class_1293 currentEffect = target.method_6112(GileMod.ENLARGE_EFFECT);
                    if (currentEffect != null) {
                        finalDuration += currentEffect.method_5584();
                    }
                }

                target.method_6092(new class_1293(GileMod.ENLARGE_EFFECT, finalDuration, 3, true, true));

                if (world instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11211, target.method_23317(), target.method_23323(0.5), target.method_23321(), 20, 0.3, 0.5, 0.3, 0.1);
                }

                // Trigger advancement
                if (user instanceof net.minecraft.class_3222 serverPlayer) {
                    com.gile.advancement.UsedScepterCriterion.CRITERION.trigger(serverPlayer, stack);
                }
            }

            // Consume durability in both scenarios
            stack.method_7970(1, user, class_1304.field_6173);
        }

        // Handle Sound Effects (Runs on client and server for sync)
        if (isCountering) {
            class_3414 cancelSound = isSelf ? class_3417.field_19344 : class_3417.field_14701;
            world.method_43128(null, target.method_23317(), target.method_23318(), target.method_23321(), cancelSound, class_3419.field_15248, 1.0F, 1.0F);
        } else {
            world.method_43128(null, target.method_23317(), target.method_23318(), target.method_23321(), class_3417.field_14545, class_3419.field_15248, 1.0F, 2.0F);
        }
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        // --- SELF-INTERACTION MODE (Shift + Right Click) ---
        if (user.method_5715()) {
            // 1. SMART TOGGLE CANCEL
            if (user.method_36455() >= 80.0F && user.method_6059(GileMod.ENLARGE_EFFECT)) {
                if (!world.field_9236) {
                    user.method_6016(GileMod.ENLARGE_EFFECT);
                    if (world instanceof class_3218 serverWorld) {
                        serverWorld.method_14199(class_2398.field_11204, user.method_23317(), user.method_23323(0.5), user.method_23321(), 20, 0.3, 0.5, 0.3, 0.1);
                    }
                }
                world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_19344, class_3419.field_15248, 1.0F, 1.0F);
                user.method_7357().method_7906(this, 20);
                return class_1271.method_29237(stack, world.method_8608());
            }

            // 2. APPLY OR COUNTER
            processEnlargeTarget(user, world, user, stack, true);
            user.method_7357().method_7906(this, 40);
            return class_1271.method_29237(stack, world.method_8608());
        }

        // --- RAYCAST MODE ---
        double maxDistance = 20.0;
        class_243 startPos = user.method_33571();
        class_243 lookDir = user.method_5828(1.0F);
        class_243 endPos = startPos.method_1019(lookDir.method_1021(maxDistance));

        class_238 searchBox = user.method_5829().method_18804(lookDir.method_1021(maxDistance)).method_1009(1.0, 1.0, 1.0);

        class_3966 hitResult = class_1675.method_18075(
                user, startPos, endPos, searchBox,
                entity -> entity instanceof class_1309 && !entity.method_7325(),
                maxDistance * maxDistance
        );

        if (hitResult != null && hitResult.method_17782() instanceof class_1309 target) {
            double distance = startPos.method_1022(hitResult.method_17784());

            // 1. Proximity Cancel Check
            if (distance <= 3.0 && target.method_6059(GileMod.ENLARGE_EFFECT)) {
                if (!world.field_9236) {
                    target.method_6016(GileMod.ENLARGE_EFFECT);
                    if (world instanceof class_3218 serverWorld) {
                        serverWorld.method_14199(class_2398.field_11204, target.method_23317(), target.method_23323(0.5), target.method_23321(), 20, 0.3, 0.5, 0.3, 0.1);
                    }
                }
                world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_14701, class_3419.field_15248, 1.0F, 1.0F);
                user.method_7357().method_7906(this, 20);
                return class_1271.method_29237(stack, world.method_8608());
            }
        }

        // 2. Draw Ray Particles
        class_243 traceEnd = (hitResult != null) ? hitResult.method_17784() : endPos;
        if (!world.field_9236 && world instanceof class_3218 serverWorld) {
            double distance = startPos.method_1022(traceEnd);
            int particleCount = (int) (distance * 2);

            for (int i = 0; i <= particleCount; i++) {
                double delta = (double) i / particleCount;
                class_243 particlePos = startPos.method_35590(traceEnd, delta);
                serverWorld.method_14199(
                        class_2398.field_11211,
                        particlePos.field_1352, particlePos.field_1351 - 0.2, particlePos.field_1350,
                        1, 0.0, 0.0, 0.0, 0.0
                );
            }
        }

        // 3. Normal Enlarge Hit Logic
        if (hitResult != null && hitResult.method_17782() instanceof class_1309 target) {
            processEnlargeTarget(target, world, user, stack, false);
            user.method_7357().method_7906(this, 40);
            return class_1271.method_29237(stack, world.method_8608());
        }

        // 4. Missed Target
        world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_14701, class_3419.field_15248, 1.0F, 1.5F);
        user.method_7357().method_7906(this, 40);
        return class_1271.method_22430(stack);
    }
}