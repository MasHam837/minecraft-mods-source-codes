package com.gile.tool.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_4981;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class JellyOnAStickItem extends class_1792 {
    public JellyOnAStickItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);

        // Check if the player is riding an entity capable of being steered
        if (user.method_5765() && user.method_5854() instanceof class_4981 itemSteerable) {

            // consumeOnAStickItem checks if the ghost is saddled. If true, it activates the boost.
            if (itemSteerable.method_6577()) {

                // Only modify item stacks and check durability on the logical server side
                if (!world.field_9236 && !user.method_7337()) {
                    class_1304 equipmentSlot = hand == class_1268.field_5808 ?
                            class_1304.field_6173 : class_1304.field_6171;

                    itemStack.method_7970(1, user, equipmentSlot);

                    // If the item breaks, replace it cleanly with a regular fishing rod frame
                    if (itemStack.method_7960()) {
                        class_1799 fishingRod = new class_1799(class_1802.field_8378);

                        // Safely transfer 1.21.1 custom data components over to the broken frame
                        class_9279 nbtComponent = itemStack.method_57824(class_9334.field_49628);
                        if (nbtComponent != null) {
                            fishingRod.method_57379(class_9334.field_49628, nbtComponent);
                        }
                        return class_1271.method_22427(fishingRod);
                    }
                }

                // Returns success on both client and server to synchronize animations and network packets
                return class_1271.method_22427(itemStack);
            }
        }

        // If the player isn't riding your ghost, pass the interaction to default behavior
        return class_1271.method_22430(itemStack);
    }
}