package com.gile.tool.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5134;
import org.joml.Vector3f;

public class NocturnesCurtainCallItem extends class_1829 {

    // Store original gravity for reset
    private static final double MOON_GRAVITY = 0.029; // Lower gravity (vanilla is -0.08)
    private static final double MOON_JUMP_BOOST = 0.36; // Higher jump

    public NocturnesCurtainCallItem(class_1832 toolMaterial, class_1793 settings) {
        super(toolMaterial, settings);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(this.method_7866(stack)).method_27694(style ->
                style.method_10977(net.minecraft.class_124.field_1054)
        );
    }

    // Pale moonlight (silver-white)
    private static final class_2394 HIT_PARTICLE = new class_2390(
            new Vector3f(0.85f, 0.85f, 0.95f),
            2.0f
    );

    private static final class_2394 FEET_PARTICLE = new class_2390(
            new Vector3f(0.75f, 0.75f, 0.85f),
            1.8f
    );

    private static final class_2394 MOON_GOLD_PARTICLE = new class_2390(
            new Vector3f(0.95f, 0.85f, 0.55f),
            2.0f
    );

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        super.method_7888(stack, world, entity, slot, selected);

        if (entity instanceof class_1309 livingEntity) {
            boolean isHeld = selected || livingEntity.method_6079() == stack;

            // Apply moon gravity when held in either hand
            if (isHeld) {
                applyMoonGravity(livingEntity, true);

                // Add slow falling effect for moon-like floating
                livingEntity.method_6092(new class_1293(
                        class_1294.field_5906,
                        20,  // 2 seconds
                        0,
                        false,
                        false,
                        true
                ));

                // Add strength effect when held
                livingEntity.method_6092(new class_1293(
                        class_1294.field_5910,
                        20,
                        0,
                        false,
                        false,
                        true
                ));
            } else {
                // Reset gravity when not held
                applyMoonGravity(livingEntity, false);
            }

            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof class_3218 serverWorld) {
                if (world.method_8510() % 2 == 0) {
                    double x = livingEntity.method_23317();
                    double y = livingEntity.method_23318() + 0.1;
                    double z = livingEntity.method_23321();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.field_9229.method_43058() - 0.5) * 0.6;
                        double offsetZ = (world.field_9229.method_43058() - 0.5) * 0.6;

                        serverWorld.method_14199(
                                class_2398.field_11215,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                5,
                                0.1, 0.15, 0.1,
                                0.05
                        );

                        serverWorld.method_14199(
                                class_2398.field_11207,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0,
                                0.02
                        );
                    }

                    serverWorld.method_14199(
                            FEET_PARTICLE,
                            x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );
                }
            }
        }
    }

    private void applyMoonGravity(class_1309 entity, boolean apply) {
        if (apply) {
            // Set lower gravity (moon-like)
            entity.method_5996(class_5134.field_49078).method_6192(MOON_GRAVITY);

            // Increase jump strength
            entity.method_5996(class_5134.field_23728).method_6192(MOON_JUMP_BOOST);
        } else {
            // Reset to vanilla values
            if (entity.method_5996(class_5134.field_49078).method_6201() == MOON_GRAVITY) {
                entity.method_5996(class_5134.field_49078).method_6192(0.08);
            }
            if (entity.method_5996(class_5134.field_23728).method_6201() == MOON_JUMP_BOOST) {
                entity.method_5996(class_5134.field_23728).method_6192(0.42);
            }
        }
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        boolean result = super.method_7873(stack, target, attacker);

        if (attacker.method_37908() instanceof class_3218 serverWorld) {
            // Effects
            class_1293 levitationEffect = new class_1293(
                    class_1294.field_5902,
                    40,
                    1,
                    true,
                    false);
            target.method_6092(levitationEffect);

            serverWorld.method_14199(
                    HIT_PARTICLE,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    40,
                    0.5, 0.5, 0.5,
                    0.01
            );
            serverWorld.method_14199(
                    MOON_GOLD_PARTICLE,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    40,
                    0.5, 0.5, 0.5,
                    0.02
            );

            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_15119,
                    class_3419.field_15248,
                    1.0f,
                    1.0f
            );
        }
        return result;
    }
}