package com.gile.tool.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.joml.Vector3f;

public class TsaritsasScepterItem extends class_1829 {
    public TsaritsasScepterItem(class_1832 toolMaterial, class_1793 settings) {
        super(toolMaterial, settings);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(this.method_7866(stack)).method_27694(style ->
                style.method_10977(net.minecraft.class_124.field_1054)
        );
    }

    private static final class_2394 HIT_PARTICLE = new class_2390(
            new Vector3f(0.6f, 0.8f, 1.0f),
            2.0f
    );

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        // Call the parent method to apply damage
        boolean result = super.method_7873(stack, target, attacker);
        // Add particles on hit
        if (attacker.method_37908() instanceof class_3218 serverWorld) {
            // Spawn particles at the target's position
            serverWorld.method_14199(
                    HIT_PARTICLE,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    40,
                    0.5,  0.5, 0.5,
                    0.01 );
            // Play a sound effect
            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_15081,
                    class_3419.field_15248,
                    1.0f,
                    1.0f);
        }
        return result;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        super.method_7888(stack, world, entity, slot, selected);

        if (entity instanceof class_1309 livingEntity) {
            // Apply effects constantly when held in main hand or offhand
            boolean isHeld = selected || livingEntity.method_6079() == stack;

            if (isHeld) {
                // Constant Speed I effect (infinite duration, no particles)
                livingEntity.method_6092(new class_1293(
                        class_1294.field_5907,
                        1,
                        1,
                        false, // No ambient particles
                        false, // No icon particles
                        true   // Show icon
                ));}
            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof class_3218 serverWorld) {
                if (world.method_8510() % 2 == 0) { // Every other tick
                    double x = livingEntity.method_23317();
                    double y = livingEntity.method_23318() + 0.1; // Feet level
                    double z = livingEntity.method_23321();

                    // Spawn frost particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.field_9229.method_43058() - 0.5) * 0.6;
                        double offsetZ = (world.field_9229.method_43058() - 0.5) * 0.6;

                        // Frost Walker-style ice particles
                        serverWorld.method_14199(
                                class_2398.field_28013, // Snowflake particles like Frost Walker
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Additional frost effects
                    // Blue-white dust particles for cold aura
                    serverWorld.method_14199(
                            new class_2390(
                                    new Vector3f(0.6f, 0.8f, 1.0f), // Ice blue color
                                    1.0f
                            ), x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );

                    // Ultra-sensitive Frost Walker - freezes all water in radius
                    if (world.method_8510() % 2 == 0) { // Every other tick for maximum responsiveness
                        class_2338 playerPos = livingEntity.method_24515();
                        int radius = 2;
                        // Check multiple vertical levels
                        for (int yOffset = -1; yOffset <= 1; yOffset++) {
                            class_2338 checkCenter = playerPos.method_10069(0, yOffset, 0);
                            for (class_2338 pos : class_2338.method_25996(checkCenter, radius, 0, radius)) {
                                // Use sphere shape for more natural freezing
                                double distance = Math.sqrt(pos.method_40081(playerPos.method_10263(), playerPos.method_10264(), playerPos.method_10260()));
                                if (distance <= radius) {
                                    class_2680 state = world.method_8320(pos);
                                    // Freeze water
                                    if (state.method_27852(class_2246.field_10382)) {
                                        world.method_8501(pos, class_2246.field_10110.method_9564());
                                    }
                                    // Freeze adjacent water blocks too
                                    if (distance <= radius - 1) { // Inner radius gets extra freezing
                                        for (class_2338 neighborPos : class_2338.method_25996(pos, 1, 1, 1)) {
                                            if (world.method_8320(neighborPos).method_27852(class_2246.field_10382)) {
                                                world.method_8501(neighborPos, class_2246.field_10110.method_9564());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // Play frost sound effect when freezing water
                        if (world.method_8510() % 20 == 0) {
                            serverWorld.method_43128(
                                    null,
                                    livingEntity.method_23317(), livingEntity.method_23318(), livingEntity.method_23321(),
                                    class_3417.field_14843,
                                    class_3419.field_15248,
                                    0.3f,
                                    1.5f
                            );
                        }
                    }
                }
            }
        }
    }
}