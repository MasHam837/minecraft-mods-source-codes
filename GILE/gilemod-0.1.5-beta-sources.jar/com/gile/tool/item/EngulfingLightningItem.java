package com.gile.tool.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.joml.Vector3f;

public class EngulfingLightningItem extends class_1829 {
    public EngulfingLightningItem(class_1832 toolMaterial, class_1793 settings) {
        super(toolMaterial, settings);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(this.method_7866(stack)).method_27694(style ->
                style.method_10977(net.minecraft.class_124.field_1054)
        );
    }

    private static final class_2394 HIT_PARTICLE = new class_2390(
            new Vector3f(0.5f, 0.1f, 0.9f),
            1.0f
    );

    private static final class_2394 FEET_PARTICLE = new class_2390(
            new Vector3f(0.5f, 0.3f, 0.9f),
            0.75f
    );

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        super.method_7888(stack, world, entity, slot, selected);

        if (entity instanceof class_1309 livingEntity) {
            // Apply effects constantly when held in main hand or offhand
            boolean isHeld = selected || livingEntity.method_6079() == stack;

            if (isHeld) {
                // Constant Speed I effect (infinite duration, no particles)
                livingEntity.method_6092(new class_1293(
                        class_1294.field_5918,
                        1,
                        0,
                        false, // No ambient particles
                        false, // No icon particles
                        true   // Show icon
                ));
            }

            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof class_3218 serverWorld) {
                if (world.method_8510() % 2 == 0) { // Every other tick
                    double x = livingEntity.method_23317();
                    double y = livingEntity.method_23318() + 0.1; // Feet level
                    double z = livingEntity.method_23321();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.field_9229.method_43058() - 0.5) * 0.6;
                        double offsetZ = (world.field_9229.method_43058() - 0.5) * 0.6;

                        serverWorld.method_14199(
                                class_2398.field_29644,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Spawn colored dust at feet
                    serverWorld.method_14199(
                            FEET_PARTICLE, x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );

                    // Occasional smoke
                    if (world.method_8510() % 6 == 0) {
                        serverWorld.method_14199(
                                class_2398.field_11207,
                                x,
                                y + 0.3,
                                z,
                                1,
                                0.2, 0.1, 0.2,
                                0.01
                        );
                    }
                }
            }
        }
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        // Call the parent method to apply damage
        boolean result = super.method_7873(stack, target, attacker);

        // Add lightning and particles on hit
        if (attacker.method_37908() instanceof class_3218 serverWorld) {
            class_1937 world = attacker.method_37908();

            // SUMMON LIGHTNING BOLT at the target's position
            class_1538 lightning = new class_1538(class_1299.field_6112, world);
            lightning.method_5814(target.method_23317(), target.method_23318(), target.method_23321());
            world.method_8649(lightning);

            // Spawn electric particles
            serverWorld.method_14199(
                    HIT_PARTICLE,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    60,
                    0.8, 0.8, 0.8,
                    0.5
            );

            // Add spark particles
            serverWorld.method_14199(
                    net.minecraft.class_2398.field_29644,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    30,
                    0.5, 0.5, 0.5,
                    0.2
            );

            // Play thunder sound
            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_14865,
                    class_3419.field_15248,
                    1.0f,
                    1.0f
            );

            // Electric crackle sound
            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_14891,
                    class_3419.field_15248,
                    1.0f,
                    0.5f
            );
        }

        return result;
    }
}