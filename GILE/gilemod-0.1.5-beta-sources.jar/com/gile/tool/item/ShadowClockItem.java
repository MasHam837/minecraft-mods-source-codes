package com.gile.tool.item;

import com.gile.GileMod;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2586;
import net.minecraft.class_2625;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class ShadowClockItem extends class_1792 {

    public ShadowClockItem(class_1793 settings) {
        super(settings);
    }

    // =========================================================
    // 1. RIGHT CLICK SIGN = CREATE / REPLACE WARP
    // =========================================================

    @Override
    public class_1269 method_7884(class_1838 context) {

        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();
        class_1799 stack = context.method_8041();
        class_1657 player = context.method_8036();

        if (player == null || world.method_8608()) {
            return class_1269.field_5812;
        }

        // =========================================================
        // SHIFT RIGHT CLICK = UNLINK
        // =========================================================

        if (player.method_5715()) {

            if (stack.method_57826(class_9334.field_49628)) {

                stack.method_57381(class_9334.field_49628);

                world.method_60511(
                        null,
                        player.method_23317(),
                        player.method_23318(),
                        player.method_23321(),
                        class_3417.field_23117,
                        class_3419.field_15248,
                        0.7F,
                        1.3F
                );

                ((class_3218) world).method_14199(
                        class_2398.field_11251,
                        player.method_23317(),
                        player.method_23318() + 1.0,
                        player.method_23321(),
                        15,
                        0.2,
                        0.2,
                        0.2,
                        0.03
                );

                player.method_7353(
                        class_2561.method_43471("message.gilemod.shadow_clock.unlinked")
                                .method_27692(class_124.field_1065),
                        true
                );

                return class_1269.field_5812;
            }
        }

        class_2586 blockEntity = world.method_8321(pos);

        // Non-sign block -> use teleport behavior instead
        if (!(blockEntity instanceof class_2625 sign)) {
            return this.method_7836(world, player, context.method_20287()).method_5467();
        }

        // Read sign text
        class_2561 rawText = sign.method_49853().method_49859(0, false);

        String signText = rawText.getString().trim();
        String warpName = signText.isBlank() ? "Warp Point" : signText;

        // Safe teleport position ABOVE sign
        class_2338 warpPos = pos;

        // Save custom data
        class_2487 nbt = new class_2487();

        nbt.method_10569("X", warpPos.method_10263());
        nbt.method_10569("Y", warpPos.method_10264());
        nbt.method_10569("Z", warpPos.method_10260());

        nbt.method_10582("Name", warpName);

        nbt.method_10582(
                "Dimension",
                world.method_27983().method_29177().toString()
        );

        // Save sign color if present
        class_2583 style = rawText.method_10866();

        if (style.method_10973() != null) {
            nbt.method_10582("Color", style.method_10973().method_27721());
        }

        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));

        // Visuals
        world.method_43128(
                null,
                player.method_23317(),
                player.method_23318(),
                player.method_23321(),
                class_3417.field_15119,
                class_3419.field_15248,
                1.0F,
                1.0F
        );

        ((class_3218) world).method_14199(
                class_2398.field_28479,
                warpPos.method_10263() + 0.5,
                warpPos.method_10264() + 0.5,
                warpPos.method_10260() + 0.5,
                30,
                0.3,
                0.3,
                0.3,
                0.05
        );

        player.method_7353(
                class_2561.method_43470("Warp linked to: ")
                        .method_27692(class_124.field_1080)
                        .method_10852(class_2561.method_43470(warpName).method_27692(class_124.field_1075)),
                true
        );

        return class_1269.field_5812;
    }

    // =========================================================
    // 2. RIGHT CLICK AIR = TELEPORT
    // =========================================================

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {

        class_1799 stack = user.method_5998(hand);

        if (world.method_8608()) {
            return class_1271.method_22427(stack);
        }

        // No warp stored
        if (!stack.method_57826(class_9334.field_49628)) {

            user.method_7353(
                    class_2561.method_43471("message.gilemod.shadow_clock.click_sign")
                            .method_27692(class_124.field_1060),
                    true
            );

            return class_1271.method_22427(stack);
        }

        class_2487 nbt = stack.method_57824(class_9334.field_49628).method_57461();

        if (!nbt.method_10545("X")) {

            user.method_7353(
                    class_2561.method_43471("message.gilemod.shadow_clock.click_sign")
                            .method_27692(class_124.field_1060),
                    true
            );

            return class_1271.method_22427(stack);
        }

        // Dimension validation
        String dimensionId = nbt.method_10558("Dimension");

        if (!world.method_27983().method_29177().toString().equals(dimensionId)) {

            user.method_7353(
                    class_2561.method_43471("message.gilemod.shadow_clock.wrong_dimension")
                            .method_27692(class_124.field_1061),
                    true
            );

            return class_1271.method_22431(stack);
        }

        class_2338 targetPos = new class_2338(
                nbt.method_10550("X"),
                nbt.method_10550("Y"),
                nbt.method_10550("Z")
        );

        // Sign should still exist below warp position
        class_2338 signPos = targetPos;

        if (!(world.method_8321(signPos) instanceof class_2625)) {

            user.method_7353(
                    class_2561.method_43471("message.gilemod.shadow_clock.missing_sign")
                            .method_27692(class_124.field_1061),
                    true
            );

            world.method_43128(
                    null,
                    user.method_23317(),
                    user.method_23318(),
                    user.method_23321(),
                    class_3417.field_15236,
                    class_3419.field_15248,
                    0.5F,
                    1.5F
            );

            return class_1271.method_22431(stack);
        }

        // =====================================================
// CHRONO GEAR CHECK
// =====================================================

        if (!user.method_7337()) {

            boolean hasChronoGear = false;

            for (int i = 0; i < user.method_31548().method_5439(); i++) {

                class_1799 inventoryStack = user.method_31548().method_5438(i);

                if (inventoryStack.method_31574(GileMod.CHRONO_GEAR)) {

                    hasChronoGear = true;

                    inventoryStack.method_7934(1);

                    break;
                }
            }

            if (!hasChronoGear) {

                user.method_7353(
                        class_2561.method_43471("message.gilemod.shadow_clock.no_chrono_gear")
                                .method_27692(class_124.field_1061),
                        true
                );

                return class_1271.method_22431(stack);
            }
        }

        // =====================================================
        // TELEPORT
        // =====================================================

        if (user instanceof class_3222 serverPlayer) {

            serverPlayer.method_14251(
                    (class_3218) world,
                    targetPos.method_10263() + 0.5,
                    targetPos.method_10264(),
                    targetPos.method_10260() + 0.5,
                    user.method_36454(),
                    user.method_36455()
            );

            world.method_43128(
                    null,
                    targetPos.method_10263(),
                    targetPos.method_10264(),
                    targetPos.method_10260(),
                    class_3417.field_14879,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );

            ((class_3218) world).method_14199(
                    class_2398.field_11214,
                    targetPos.method_10263() + 0.5,
                    targetPos.method_10264() + 0.5,
                    targetPos.method_10260() + 0.5,
                    40,
                    0.5,
                    0.5,
                    0.5,
                    0.2
            );
        }

        return class_1271.method_22427(stack);
    }

    // =========================================================
    // 3. GLINT WHEN LINKED
    // =========================================================

    @Override
    public boolean method_7886(class_1799 stack) {

        if (!stack.method_57826(class_9334.field_49628)) {
            return false;
        }

        class_2487 nbt = stack.method_57824(class_9334.field_49628).method_57461();

        return nbt.method_10545("X");
    }

    // =========================================================
    // 4. TOOLTIP
    // =========================================================

    @Override
    public void method_7851(class_1799 stack,
                              class_9635 context,
                              List<class_2561> tooltip,
                              class_1836 type) {

        if (!stack.method_57826(class_9334.field_49628)) {

            tooltip.add(
                    class_2561.method_43471("tooltip.gilemod.shadow_clock.unlinked")
                            .method_27692(class_124.field_1080)
            );

            return;
        }

        class_2487 nbt = stack.method_57824(class_9334.field_49628).method_57461();

        if (!nbt.method_10545("X")) {

            tooltip.add(
                    class_2561.method_43471("tooltip.gilemod.shadow_clock.unlinked")
                            .method_27692(class_124.field_1080)
            );

            return;
        }

        int x = nbt.method_10550("X");
        int y = nbt.method_10550("Y");
        int z = nbt.method_10550("Z");

        String name = nbt.method_10558("Name");

        // Coordinates
        tooltip.add(
                class_2561.method_43471("tooltip.gilemod.shadow_clock.coordinates")
                        .method_27692(class_124.field_1080)
                        .method_10852(
                                class_2561.method_43470(x + ", " + y + ", " + z)
                                        .method_27692(class_124.field_1075)
                        )
        );

        // Warp name
        if (!name.isBlank() && !name.equals("Warp Point")) {

            class_5250 warpText = class_2561.method_43470(name);

            if (nbt.method_10545("Color")) {

                try {

                    class_124 formatting =
                            class_124.valueOf(nbt.method_10558("Color").toUpperCase());

                    warpText.method_27692(formatting);

                } catch (Exception ignored) {
                }
            }

            tooltip.add(
                    class_2561.method_43471("tooltip.gilemod.shadow_clock.linked_warp")
                            .method_27692(class_124.field_1080)
                            .method_10852(warpText)
            );
        }

        tooltip.add(
                class_2561.method_43471("tooltip.gilemod.shadow_clock.consumes")
                        .method_27692(class_124.field_1080)
                        .method_10852(
                                class_2561.method_43471("item.gilemod.chrono_gear")
                                        .method_27692(class_124.field_1076)
                        )
        );
    }
}