package com.gile.tool.item;

import org.joml.Vector3f;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class SplendorOfTranquilWatersItem extends class_1829 {

    // A transient map to track the height at which an entity started falling
    private static final Map<class_1297, Double> FALL_START_Y = new WeakHashMap<>();

    public SplendorOfTranquilWatersItem(class_1832 toolMaterial, class_1793 settings) {
        super(toolMaterial, settings);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return class_2561.method_43471(this.method_7866(stack)).method_27694(style ->
                style.method_10977(net.minecraft.class_124.field_1054)
        );
    }

    private static final class_2394 HIT_PARTICLE = new class_2390(
            new Vector3f(0.1f, 0.1f, 0.85f),
            2.0f
    );

    private static final class_2394 FEET_PARTICLE = new class_2390(
            new Vector3f(0.3f, 0.3f, 0.85f),
            1.0f
    );

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        super.method_7888(stack, world, entity, slot, selected);

        if (entity instanceof class_1309 livingEntity) {

            // If the item is not in the main hand, remove them from the fall tracker
            if (!selected) {
                FALL_START_Y.remove(livingEntity);
                return;
            }

            // --- CUSTOM FALL TRACKING FOR THE SPLASH ANIMATION ---
            if (!livingEntity.method_24828() && livingEntity.method_18798().field_1351 < -0.1) {
                // Record the exact Y height when they start falling
                FALL_START_Y.putIfAbsent(livingEntity, livingEntity.method_23318());
            } else if (livingEntity.method_24828()) {
                // They just landed. Check how far they fell
                Double startY = FALL_START_Y.remove(livingEntity);

                if (startY != null && world instanceof class_3218 serverWorld) {
                    double fallHeight = startY - livingEntity.method_23318();

                    // Trigger the dynamic splash if they fell 4 or more blocks
                    if (fallHeight >= 4.0) {
                        double x = livingEntity.method_23317();
                        double y = livingEntity.method_23318();
                        double z = livingEntity.method_23321();

                        // --- DYNAMIC SCALING MATH ---
                        // Cap the fall height at 100 blocks to prevent server lag from too many particles
                        double effectiveFall = Math.min(fallHeight, 100.0);

                        // Count scales linearly with height (maxes out around 1500 particles total)
                        int splashCount = (int) (effectiveFall * 15);
                        int bubbleCount = (int) (effectiveFall * 4);
                        int dustCount   = (int) (effectiveFall * 8);

                        // Spread and Speed scale up to make huge falls explode outwards wider
                        double spread = 0.5 + (effectiveFall * 0.03);
                        double speed  = 0.1 + (effectiveFall * 0.005);

                        // Sound gets louder and deeper (lower pitch) the further you fall
                        float volume = (float) Math.min(4.0, 1.0 + (effectiveFall * 0.05));
                        float pitch  = (float) Math.max(0.6, 1.5 - (effectiveFall * 0.01));

                        // 1. Explosive outward water splash
                        serverWorld.method_14199(class_2398.field_11202, x, y, z, splashCount, spread, 0.5, spread, speed);
                        // 2. Popping bubbles for detail
                        serverWorld.method_14199(class_2398.field_11241, x, y, z, bubbleCount, spread * 0.7, 0.2, spread * 0.7, speed * 0.5);
                        // 3. A blast of your custom blue dust
                        serverWorld.method_14199(FEET_PARTICLE, x, y, z, dustCount, spread, 0.2, spread, speed * 0.8);

                        // 4. Play the vanilla high-speed dive splash sound
                        serverWorld.method_43128(null, x, y, z, class_3417.field_14876, class_3419.field_15248, volume, pitch);
                    }
                }
            }
            // -----------------------------------------------------

            // 1. Reset fall distance on BOTH client and server to prevent damage and camera jerking
            livingEntity.field_6017 = 0.0F;

            // 2. Handle server-side only logic (Effects and Particles)
            if (world instanceof class_3218 serverWorld) {
                // Constant Reg I effect (infinite duration, no particles)
                livingEntity.method_6092(new class_1293(
                        class_1294.field_5924,
                        3,
                        1,
                        false, // No ambient particles
                        false, // No icon particles
                        true   // Show icon
                ));
                livingEntity.method_6092(new class_1293(
                        class_1294.field_5923,
                        1,
                        0,
                        false,
                        false,
                        true
                ));

                if (world.method_8510() % 2 == 0) { // Every other tick
                    double x = livingEntity.method_23317();
                    double y = livingEntity.method_23318() + 0.1; // Feet level
                    double z = livingEntity.method_23321();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.field_9229.method_43058() - 0.5) * 0.6;
                        double offsetZ = (world.field_9229.method_43058() - 0.5) * 0.6;

                        serverWorld.method_14199(
                                class_2398.field_11202,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );

                        serverWorld.method_14199(
                                class_2398.field_11247,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );

                        serverWorld.method_14199(
                                class_2398.field_11238,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Spawn colored dust at feet
                    serverWorld.method_14199(
                            FEET_PARTICLE,
                            x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );
                }
            }
        }
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        // Call the parent method to apply damage
        boolean result = super.method_7873(stack, target, attacker);
        // Add particles on hit
        if (attacker.method_37908() instanceof class_3218 serverWorld) {
            // Spawn particles at the target's position
            serverWorld.method_14199(
                    HIT_PARTICLE,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    40,
                    0.5,  0.5, 0.5,
                    0.01 );
            serverWorld.method_14199(
                    class_2398.field_11247,
                    target.method_23317(),
                    target.method_23318() + target.method_17682() / 2,
                    target.method_23321(),
                    40,
                    0.5,  0.5, 0.5,
                    0.01 );
            // Play a sound effect
            serverWorld.method_43128(
                    null,
                    target.method_23317(),
                    target.method_23318(),
                    target.method_23321(),
                    class_3417.field_14810,
                    class_3419.field_15248,
                    1.0f,
                    1.0f);
        }
        return result;
    }
}