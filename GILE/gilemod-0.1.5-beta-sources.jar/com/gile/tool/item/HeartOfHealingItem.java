package com.gile.tool.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class HeartOfHealingItem extends class_1792 {

    public HeartOfHealingItem(class_1793 settings) {
        super(settings);}

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {

        if (entity instanceof class_1657 player && !world.method_8608()) {

            if (player.method_7357().method_7904(this)) {
                return;}
            float lowHealthThreshold = player.method_6063() * 0.2F;

            if (player.method_6032() < lowHealthThreshold) {
                executeEmergencyHeal(stack, (class_3218) world, player);
                player.method_7357().method_7906(this, 20);
            }
        }

        super.method_7888(stack, world, entity, slot, selected);
    }

    private void executeEmergencyHeal(class_1799 stack, class_3218 world, class_1657 player) {

        player.method_6092(new class_1293(class_1294.field_5915, 1, 1));
        player.method_6092(new class_1293(class_1294.field_5924, 200, 1));
        player.method_6092(new class_1293(class_1294.field_5907, 200, 3));

        world.method_43128(
                null,
                player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_14931,
                class_3419.field_15248,
                1.0F, 1.2F);

        world.method_14199(
                class_2398.field_11201,
                player.method_23317(), player.method_23318(), player.method_23321(),
                15, 0.4, 0.4, 0.4, 0.1);

        // Consume only this stack
        stack.method_7934(1);
    }
}