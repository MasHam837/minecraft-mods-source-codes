package com.gile.tool.material;

import com.gile.GileMod;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;

public enum FloatingToolMaterials implements class_1832 {
    THOUSAND_FLOATING_DREAMS_MATERIAL(class_3481.field_49926,
            1, 1.0f, 9.0f,
            15, class_1856.method_8091(GileMod.DENDRO_SIGIL));

    private final class_6862<class_2248> inverseTag;
    private final int durability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final class_1856 repairIngredient;

    FloatingToolMaterials(class_6862<class_2248> inverseTag, int durability, float miningSpeed, float attackDamage, int enchantability, class_1856 repairIngredient) {
        this.inverseTag = inverseTag;
        this.durability = durability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int method_8025() {
        return this.durability;
    }

    @Override
    public float method_8027() {
        return this.miningSpeed;
    }

    @Override
    public float method_8028() {
        return this.attackDamage;
    }

    @Override
    public class_6862<class_2248> method_58419() {
        return this.inverseTag;
    }

    @Override
    public int method_8026() {
        return this.enchantability;
    }

    @Override
    public class_1856 method_8023() {
        return this.repairIngredient;
    }
}