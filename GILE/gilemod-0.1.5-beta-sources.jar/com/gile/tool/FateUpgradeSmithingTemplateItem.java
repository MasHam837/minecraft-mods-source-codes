package com.gile.tool;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_8052;

public class FateUpgradeSmithingTemplateItem extends class_8052 {

    public FateUpgradeSmithingTemplateItem() {
        super(
                class_2561.method_43473(),
                class_2561.method_43473(),
                class_2561.method_43471("trim_pattern.gilemod.fate_upgrade").method_27692(class_124.field_1080),
                class_2561.method_43473(),
                class_2561.method_43473(),
                List.of(),
                List.of()
        );
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("trim_pattern.gilemod.fate_upgrade").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43473());
        tooltip.add(class_2561.method_43471("item.minecraft.smithing_template.applies_to").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43471("smithing_template.gilemod.fate_upgrade.applies_to").method_27692(class_124.field_1078));
        tooltip.add(class_2561.method_43471("item.minecraft.smithing_template.ingredients").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43471("smithing_template.gilemod.fate_upgrade.ingredients").method_27692(class_124.field_1078));
    }
}