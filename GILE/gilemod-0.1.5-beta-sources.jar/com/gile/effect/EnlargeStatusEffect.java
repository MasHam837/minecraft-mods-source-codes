package com.gile.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_5131;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

public class EnlargeStatusEffect extends class_1291 {

    private static final class_2960 SCALE_ID = class_2960.method_60655("gilemod", "enlarge.scale");
    private static final class_2960 HEALTH_ID = class_2960.method_60655("gilemod", "enlarge.health");
    private static final class_2960 SPEED_ID = class_2960.method_60655("gilemod", "enlarge.speed");
    private static final class_2960 JUMP_ID = class_2960.method_60655("gilemod", "enlarge.jump");
    private static final class_2960 STRENGTH_ID = class_2960.method_60655("gilemod", "enlarge.strength");
    private static final class_2960 REACH_ENTITY_ID = class_2960.method_60655("gilemod", "enlarge.reach_entity");
    private static final class_2960 REACH_BLOCK_ID = class_2960.method_60655("gilemod", "enlarge.reach_block");
    private static final class_2960 GRAVITY_ID = class_2960.method_60655("gilemod", "enlarge.gravity");
    private static final class_2960 STEP_HEIGHT_ID = class_2960.method_60655("gilemod", "enlarge.step_height");
    private static final class_2960 FALL_DIST_ID = class_2960.method_60655("gilemod", "enlarge.fall_distance");

    public EnlargeStatusEffect() {
        super(class_4081.field_18273, 0x98BC35);
    }

    @Override
    public void method_5555(class_5131 attributes, int amplifier) {
        super.method_5555(attributes, amplifier);

        // Scale grows by 20% (0.2) per level
        double scaleGrowth = 0.2 * (amplifier + 1);
        if (scaleGrowth > 16.0) {
            scaleGrowth = 16.0;
        }

        // Other stats grow by 10% (0.1) per level
        double statsGrowth = 0.1 * (amplifier + 1);
        if (statsGrowth > 8.0) { // Capped proportionally to the scale cap
            statsGrowth = 8.0;
        }

        // Apply 20% scaling exclusively to GENERIC_SCALE
        applyModifier(attributes, class_5134.field_47760, SCALE_ID, scaleGrowth);

        // Apply 10% scaling to everything else
        applyModifier(attributes, class_5134.field_23716, HEALTH_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_23719, SPEED_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_23728, JUMP_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_23721, STRENGTH_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_47759, REACH_ENTITY_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_47758, REACH_BLOCK_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_49078, GRAVITY_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_47761, STEP_HEIGHT_ID, statsGrowth);
        applyModifier(attributes, class_5134.field_49079, FALL_DIST_ID, statsGrowth);
    }

    @Override
    public void method_5562(class_5131 attributes) {
        super.method_5562(attributes);

        removeModifier(attributes, class_5134.field_47760, SCALE_ID);
        removeModifier(attributes, class_5134.field_23716, HEALTH_ID);
        removeModifier(attributes, class_5134.field_23719, SPEED_ID);
        removeModifier(attributes, class_5134.field_23728, JUMP_ID);
        removeModifier(attributes, class_5134.field_23721, STRENGTH_ID);
        removeModifier(attributes, class_5134.field_47759, REACH_ENTITY_ID);
        removeModifier(attributes, class_5134.field_47758, REACH_BLOCK_ID);
        removeModifier(attributes, class_5134.field_49078, GRAVITY_ID);
        removeModifier(attributes, class_5134.field_47761, STEP_HEIGHT_ID);
        removeModifier(attributes, class_5134.field_49079, FALL_DIST_ID);
    }

    // --- WATCHDOG LOGIC (Handles World Reloads) ---
    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }

    @Override
    public boolean method_5572(class_1309 entity, int amplifier) {
        class_1324 scaleInstance = entity.method_5996(class_5134.field_47760);

        if (scaleInstance != null && !scaleInstance.method_6196(SCALE_ID)) {
            this.method_5555(entity.method_6127(), amplifier);
        }

        return true;
    }
    // ----------------------------------------------

    private void applyModifier(class_5131 attributes, class_6880<class_1320> attribute, class_2960 id, double value) {
        class_1324 instance = attributes.method_45329(attribute);
        if (instance != null) {
            instance.method_6200(id);
            instance.method_26835(new class_1322(
                    id, value, class_1322.class_1323.field_6331
            ));
        }
    }

    private void removeModifier(class_5131 attributes, class_6880<class_1320> attribute, class_2960 id) {
        class_1324 instance = attributes.method_45329(attribute);
        if (instance != null) {
            instance.method_6200(id);
        }
    }
}