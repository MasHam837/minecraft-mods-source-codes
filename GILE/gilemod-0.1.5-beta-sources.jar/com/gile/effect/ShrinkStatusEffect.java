package com.gile.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_5131;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

public class ShrinkStatusEffect extends class_1291 {

    private static final class_2960 SCALE_ID = class_2960.method_60655("gilemod", "shrink.scale");
    private static final class_2960 HEALTH_ID = class_2960.method_60655("gilemod", "shrink.health");
    private static final class_2960 SPEED_ID = class_2960.method_60655("gilemod", "shrink.speed");
    private static final class_2960 JUMP_ID = class_2960.method_60655("gilemod", "shrink.jump");
    private static final class_2960 STRENGTH_ID = class_2960.method_60655("gilemod", "shrink.strength");
    private static final class_2960 REACH_ENTITY_ID = class_2960.method_60655("gilemod", "shrink.reach_entity");
    private static final class_2960 REACH_BLOCK_ID = class_2960.method_60655("gilemod", "shrink.reach_block");
    private static final class_2960 GRAVITY_ID = class_2960.method_60655("gilemod", "shrink.gravity");
    private static final class_2960 STEP_HEIGHT_ID = class_2960.method_60655("gilemod", "shrink.step_height");
    private static final class_2960 FALL_DIST_ID = class_2960.method_60655("gilemod", "shrink.fall_distance");

    public ShrinkStatusEffect() {
        super(class_4081.field_18273, 0x6743CA);
    }

    @Override
    public void method_5555(class_5131 attributes, int amplifier) {
        super.method_5555(attributes, amplifier);

        // Scale shrinks by 20% (0.2) per level
        double scaleShrink = 0.2 * (amplifier + 1);
        if (scaleShrink > 0.95) {
            scaleShrink = 0.95;
        }

        // Other stats shrink by 10% (0.1) per level
        double statsShrink = 0.1 * (amplifier + 1);
        if (statsShrink > 0.95) { // Critical: MUST remain below 1.0 to avoid 0 Max Health instadeath
            statsShrink = 0.95;
        }

        // Apply -20% scaling exclusively to GENERIC_SCALE
        applyModifier(attributes, class_5134.field_47760, SCALE_ID, -scaleShrink);

        // Apply -10% scaling to everything else
        applyModifier(attributes, class_5134.field_23716, HEALTH_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_23719, SPEED_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_23728, JUMP_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_23721, STRENGTH_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_47759, REACH_ENTITY_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_47758, REACH_BLOCK_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_49078, GRAVITY_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_47761, STEP_HEIGHT_ID, -statsShrink);
        applyModifier(attributes, class_5134.field_49079, FALL_DIST_ID, -statsShrink);
    }

    @Override
    public void method_5562(class_5131 attributes) {
        super.method_5562(attributes);

        removeModifier(attributes, class_5134.field_47760, SCALE_ID);
        removeModifier(attributes, class_5134.field_23716, HEALTH_ID);
        removeModifier(attributes, class_5134.field_23719, SPEED_ID);
        removeModifier(attributes, class_5134.field_23728, JUMP_ID);
        removeModifier(attributes, class_5134.field_23721, STRENGTH_ID);
        removeModifier(attributes, class_5134.field_47759, REACH_ENTITY_ID);
        removeModifier(attributes, class_5134.field_47758, REACH_BLOCK_ID);
        removeModifier(attributes, class_5134.field_49078, GRAVITY_ID);
        removeModifier(attributes, class_5134.field_47761, STEP_HEIGHT_ID);
        removeModifier(attributes, class_5134.field_49079, FALL_DIST_ID);
    }

    // --- ADDED WATCHDOG LOGIC HERE ---

    @Override
    public boolean method_5552(int duration, int amplifier) {
        // Return true every tick so the game constantly validates the effect
        return true;
    }

    @Override
    public boolean method_5572(class_1309 entity, int amplifier) {
        class_1324 scaleInstance = entity.method_5996(class_5134.field_47760);

        // Double-check: If the entity has this effect active, but our custom scale modifier is missing (e.g., after reloading the world)
        if (scaleInstance != null && !scaleInstance.method_6196(SCALE_ID)) {
            // Reapply all custom attributes safely
            this.method_5555(entity.method_6127(), amplifier);
        }

        return true;
    }

    // ---------------------------------

    private void applyModifier(class_5131 attributes, class_6880<class_1320> attribute, class_2960 id, double value) {
        class_1324 instance = attributes.method_45329(attribute);
        if (instance != null) {
            instance.method_6200(id); // Safely ensures no duplicate stacking
            instance.method_26835(new class_1322(
                    id, value, class_1322.class_1323.field_6331
            ));
        }
    }

    private void removeModifier(class_5131 attributes, class_6880<class_1320> attribute, class_2960 id) {
        class_1324 instance = attributes.method_45329(attribute);
        if (instance != null) {
            instance.method_6200(id);
        }
    }
}