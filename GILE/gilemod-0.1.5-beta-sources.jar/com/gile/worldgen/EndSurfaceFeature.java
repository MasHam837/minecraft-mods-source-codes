package com.gile.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_3532;
import net.minecraft.class_5281;
import net.minecraft.class_5821;

public class EndSurfaceFeature extends class_3031<class_3175> {

    public EndSurfaceFeature(Codec<class_3175> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_3175> context) {

        class_5281 world = context.method_33652();
        class_2338 origin = context.method_33655();
        var random = context.method_33654();

        boolean placed = false;

        /*
         * Medium-large radius
         * big enough to merge naturally
         * small enough to avoid chunk squares
         */
        int radius = 18;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {

                /*
                 * TRUE circular mask
                 */
                double distSq = dx * dx + dz * dz;

                if (distSq > radius * radius)
                    continue;

                int x = origin.method_10263() + dx;
                int z = origin.method_10260() + dz;

                /*
                 * Circular distance
                 */
                double dist = Math.sqrt(distSq);

                /*
                 * Organic edge warping
                 */
                double noise =
                        Math.sin(x * 0.09)
                                + Math.cos(z * 0.09)
                                + Math.sin((x + z) * 0.05);

                noise *= 2.2;

                /*
                 * Distorted circular biome edge
                 */
                double warpedDist = dist + noise;

                /*
                 * Smooth edge fade
                 */
                double edge = 1.0 - (warpedDist / radius);

                edge = class_3532.method_15350(edge, 0.0, 1.0);

                /*
                 * IMPORTANT:
                 * only reject VERY outer edge
                 * prevents holes everywhere else
                 */
                if (edge <= 0.08)
                    continue;

                int y = world.method_8624(
                        class_2902.class_2903.field_13197,
                        x,
                        z
                );

                class_2338 groundPos = new class_2338(x, y - 1, z);
                class_2338 topPos = groundPos.method_10084();

                if (!world.method_8320(groundPos).method_27852(class_2246.field_10471))
                    continue;

                /*
                 * FULL terrain coverage
                 */
                world.method_8652(
                        groundPos,
                        com.gile.GileMod.END_GRASS_BLOCK.method_9564(),
                        2
                );

                placed = true;

                /*
                 * Vegetation density
                 * strongest toward center
                 */
                if (world.method_22347(topPos)) {

                    double plantDensity =
                            edge
                                    + (random.method_43058() * 0.25);

                    if (plantDensity > 0.78 &&
                            random.method_43057() < 0.45f) {

                        world.method_8652(
                                topPos,
                                com.gile.GileMod.TALL_END_GRASS.method_9564(),
                                2
                        );

                    } else if (plantDensity > 0.45 &&
                            random.method_43057() < 0.75f) {

                        world.method_8652(
                                topPos,
                                com.gile.GileMod.END_GRASS.method_9564(),
                                2
                        );
                    }
                }
            }
        }

        return placed;
    }
}