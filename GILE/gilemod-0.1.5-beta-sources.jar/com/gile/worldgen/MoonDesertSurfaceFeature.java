package com.gile.worldgen;

import com.gile.GileMod;
import com.mojang.serialization.Codec;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_5281;
import net.minecraft.class_5821;

public class MoonDesertSurfaceFeature extends class_3031<class_3175> {

    public MoonDesertSurfaceFeature(Codec<class_3175> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_3175> context) {

        class_5281 world = context.method_33652();
        class_2338 origin = context.method_33655();

        boolean placed = false;

        int radius = 18;

        class_2248 moonSand = GileMod.MOON_SAND;
        class_2248 moonSandstone = GileMod.MOON_SANDSTONE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {

                double distSq = dx * dx + dz * dz;

                if (distSq > radius * radius)
                    continue;

                int x = origin.method_10263() + dx;
                int z = origin.method_10260() + dz;

                int topY = world.method_8624(
                        class_2902.class_2903.field_13197,
                        x,
                        z
                );

                class_2338 topPos = new class_2338(x, topY - 1, z);

                if (!world.method_8320(topPos).method_27852(class_2246.field_10471))
                    continue;

                for (int depth = 0; depth < 3; depth++) {

                    class_2338 replacePos = topPos.method_10087(depth);

                    if (world.method_8320(replacePos).method_27852(class_2246.field_10471)) {

                        world.method_8652(
                                replacePos,
                                moonSand.method_9564(),
                                2
                        );
                    }
                }

                class_2338 sandstonePos = topPos.method_10087(3);

                if (world.method_8320(sandstonePos).method_27852(class_2246.field_10471)) {

                    world.method_8652(sandstonePos,moonSandstone.method_9564(),2);
                }

                placed = true;
            }
        }

        return placed;
    }
}