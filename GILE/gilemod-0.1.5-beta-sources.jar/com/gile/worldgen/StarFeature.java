package com.gile.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.class_2338;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class StarFeature extends class_3031<class_3175> {
    public StarFeature(Codec<class_3175> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_3175> context) {
        class_5281 world = context.method_33652();
        class_2338 origin = context.method_33655();
        class_5819 random = context.method_33654();
        class_3175 config = context.method_33656();

        // 1. Calculate the exact same height as your clouds: 15-25 blocks above the surface
        int heightOffset = random.method_43048(6) + 20;
        class_2338 targetPos = origin.method_10086(heightOffset);

        // 2. Check if the spot is empty, then place exactly ONE block
        if (world.method_8320(targetPos).method_26215()) {
            world.method_8652(targetPos, config.comp_156().method_23455(random, targetPos), 3);
            return true; // Successfully placed a star
        }

        return false; // Did not place anything (wasn't air)
    }
}