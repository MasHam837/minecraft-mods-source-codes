package com.gile.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.class_2338;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class CloudBlobFeature extends class_3031<class_3175> {
    public CloudBlobFeature(Codec<class_3175> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_3175> context) {
        class_5281 world = context.method_33652();
        class_2338 origin = context.method_33655();
        class_5819 random = context.method_33654();
        class_3175 config = context.method_33656();

        // Rise 15-25 blocks above surface
        int heightOffset = random.method_43048(11) + 15;
        class_2338 center = origin.method_10086(heightOffset);

        // Rectangular dimensions: wider than tall, always 1 block high
        int radiusX = 3 + random.method_43048(3);  // 3-5 blocks in X
        int radiusZ = 3 + random.method_43048(3);  // 3-5 blocks in Z
        // Y is always 0 (single layer)

        class_2338.class_2339 mutable = new class_2338.class_2339();

        // Generate a single flat layer with rectangular shape
        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                // Rectangular shape with rough edges (optional noise)
                double edgeFactor = 1.0;

                // Add some randomness to edges for natural look
                if (Math.abs(dx) == radiusX || Math.abs(dz) == radiusZ) {
                    // 60% chance to place blocks at the edges (makes it slightly irregular)
                    if (random.method_43057() > 0.6f) {
                        continue;
                    }
                }

                // Corner blocks have even lower chance (rounded corners)
                if (Math.abs(dx) == radiusX && Math.abs(dz) == radiusZ) {
                    if (random.method_43057() > 0.3f) {
                        continue;
                    }
                }

                mutable.method_25504(center, dx, 0, dz);

                // Only replace air
                if (world.method_8320(mutable).method_26215()) {
                    world.method_8652(mutable, config.comp_156().method_23455(random, mutable), 3);
                }
            }
        }

        return true;
    }
}