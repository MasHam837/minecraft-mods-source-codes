package com.gile.entity;

import com.gile.GileMod;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1374;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class LuminousEntity extends class_1429 {
    private static final class_2940<Integer> VARIANT = class_2945.method_12791(LuminousEntity.class, class_2943.field_13327);

    public LuminousEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    public float method_6144(class_2338 pos, net.minecraft.class_4538 world) {
        // Returns a high favor so it gladly spawns in the dark on End blocks
        return 10.0F;
    }

    @Override
    public class_4048 method_55694(class_4050 pose) {
        class_4048 dimensions = super.method_55694(pose);
        if (this.method_6109()) {
            return dimensions.method_18383(1.0f);
        }
        return dimensions;
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(GileMod.STAR_FRAGMENT);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1374(this, 1.25));

        this.field_6201.method_6277(2, new class_1341(this, 1.0));
        this.field_6201.method_6277(3, new class_1391(this, 1.15, stack -> stack.method_31574(GileMod.STAR_FRAGMENT), false));

        this.field_6201.method_6277(4, new class_1394(this, 1.0));
        this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 6.0f));
        this.field_6201.method_6277(6, new class_1376(this));
    }

    public static class_5132.class_5133 createLuminousAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 14.0)
                .method_26868(class_5134.field_23719, 0.25)
                .method_26868(class_5134.field_23717, 16.0)
                .method_26868(class_5134.field_23728, 0.17)
                .method_26868(class_5134.field_49078, 0.01);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(VARIANT, 0); // Default: 0 = Yellow, 1 = Light Blue, 2 = Pink
    }

    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason, @Nullable class_1315 entityData) {
        // Assign a random variant upon spawning naturally
        this.setVariant(this.field_5974.method_43048(3));
        return super.method_5943(world, difficulty, spawnReason, entityData);
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);

        if (this.method_6481(itemStack)) {
            int age = this.method_5618();

            if (!this.method_37908().field_9236 && age == 0 && this.method_6482()) {
                this.method_6475(player, hand, itemStack);
                this.method_6480(player);
                return class_1269.field_5812;
            }

            if (this.method_6109()) {
                this.method_6475(player, hand, itemStack);

                int currentAge = this.method_5618();
                int ageIncrease = (int)((float)(-currentAge / 20) * 0.1F);
                this.method_5620(ageIncrease, true);
                return class_1269.method_29236(this.method_37908().field_9236);
            }

        }

        return super.method_5992(player, hand);
    }

    public int getVariant() {
        return this.field_6011.method_12789(VARIANT);
    }

    public void setVariant(int variant) {
        this.field_6011.method_12778(VARIANT, variant);
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10569("Variant", this.getVariant());
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        this.setVariant(nbt.method_10550("Variant"));
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        int looting = 0;
        if (source.method_5529() instanceof class_1309 attacker) {
            class_6880<class_1887> lootingEnchant = attacker.method_37908()
                    .method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_40264(class_1893.field_9110)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = class_1890.method_8203(lootingEnchant, attacker);}}
        int dropCount = 1 + this.field_5974.method_43048(2 + looting);
        this.method_5775(new class_1799(GileMod.PHASMA, dropCount));
    }

    @Nullable
    @Override
    public LuminousEntity method_5613(class_3218 world, class_1296 entity) {
        LuminousEntity child = GileMod.LUMINOUS.method_5883(world);
        if (child != null) {
            // Set variant - inherits from one of the parents
            child.setVariant(this.field_5974.method_43056() ? this.getVariant() : ((LuminousEntity)entity).getVariant());

            // ADD THIS: Forces the child to spawn as a baby
            child.method_7217(true);
        }
        return child;
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        boolean damaged = super.method_5643(source, amount);

        if (damaged && !this.method_37908().field_9236) {
            this.method_37908().method_43128(
                    null,
                    this.method_23317(), this.method_23318(), this.method_23321(),
                    GileMod.LUMINOUS_HURT, class_3419.field_15251,
                    0.8F,
                    2.0F
            );
        }

        return damaged;
    }

    @Override
    protected class_3414 method_5994() {
        return GileMod.LUMINOUS_AMBIENT;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14971;
    }

}