package com.gile.entity;

import com.gile.GileMod;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1338;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1374;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_6880;
import net.minecraft.class_6908;
import net.minecraft.class_7924;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.List;

public class JerboaEntity extends class_1429 {

    private static final class_2940<Boolean> HIDING = class_2945.method_12791(JerboaEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> DESERT_VARIANT = class_2945.method_12791(JerboaEntity.class, class_2943.field_13323);

    public JerboaEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    public float method_6144(class_2338 pos, net.minecraft.class_4538 world) {
        return 10.0F;
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1374(this, 1.5));
        this.field_6201.method_6277(2, new class_1338<>(this, class_1588.class, 8.0F, 1.2, 1.5));
        this.field_6201.method_6277(3, new class_1338<>(this, class_1657.class, 8.0F, 1.1, 1.4, player -> !isHoldingDryFlower((class_1657) player)));
        this.field_6201.method_6277(4, new HideGoal(this));
        this.field_6201.method_6277(5, new class_1341(this, 1.0));
        this.field_6201.method_6277(6, new class_1391(this, 1.1, class_1856.method_8091(GileMod.DRY_FLOWER_ITEM), false));
        this.field_6201.method_6277(7, new class_1394(this, 1.0));
        this.field_6201.method_6277(8, new class_1361(this, class_1657.class, 6.0f));
        this.field_6201.method_6277(9, new class_1376(this));
    }

    public static class_5132.class_5133 createJerboaAttributes() {
        return class_1429.method_26828()
                .method_26868(class_5134.field_23716, 6.0)
                .method_26868(class_5134.field_23719, 0.32)
                .method_26868(class_5134.field_23717, 16.0);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(HIDING, false);
        builder.method_56912(DESERT_VARIANT, false); // Register the desert variant tracker
    }

    public boolean isHiding() {
        return this.field_6011.method_12789(HIDING);
    }

    public void setHiding(boolean hiding) {
        this.field_6011.method_12778(HIDING, hiding);
    }

    public boolean isDesertVariant() {
        return this.field_6011.method_12789(DESERT_VARIANT);
    }

    public void setDesertVariant(boolean variant) {
        this.field_6011.method_12778(DESERT_VARIANT, variant);
    }

    // Save and load the variant so it persists when chunks unload
    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10556("DesertVariant", this.isDesertVariant());
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        this.setDesertVariant(nbt.method_10577("DesertVariant"));
    }

    // Check the biome when the Jerboa naturally spawns
    @Nullable
    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason, @Nullable class_1315 entityData) {
        if (world.method_23753(this.method_24515()).method_40220(class_6908.field_37393)) {
            this.setDesertVariant(true);
        }
        return super.method_5943(world, difficulty, spawnReason, entityData);
    }

    // Complete Invincibility while hiding
    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (this.isHiding()) {
            return false; // Cancels all damage, knockback, and hurt animations
        }
        return super.method_5643(source, amount);
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(GileMod.DRY_FLOWER_ITEM);
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_37908().field_9236 || !this.method_5805()) {
            return;
        }

        boolean afraid = false;
        class_238 searchBox = this.method_5829().method_1014(8.0);

        List<class_1588> hostiles = this.method_37908().method_8390(class_1588.class, searchBox, entity -> true);
        if (!hostiles.isEmpty()) {
            afraid = true;
        }

        boolean playersNearby = this.method_37908().method_18456().stream()
                .anyMatch(player -> player.method_5858(this) < 100 && !isHoldingDryFlower(player));

        if (playersNearby) {
            afraid = true;
        }

        class_2680 below = this.method_37908().method_8320(this.method_24515().method_10074());
        boolean canHide = below.method_27852(GileMod.MOON_SAND) || below.method_27852(class_2246.field_10102) || below.method_27852(class_2246.field_10534);

        boolean shouldHide = afraid && canHide;

        // Run 2x faster if scared and cannot hide
        if (afraid && !canHide) {
            this.method_5996(class_5134.field_23719)
                    .method_6192(0.64); // 2x normal speed
        } else {
            this.method_5996(class_5134.field_23719)
                    .method_6192(0.32); // normal speed
        }

        if (shouldHide != this.isHiding()) {
            this.setHiding(shouldHide);
            this.method_37908().method_8421(this, (byte)(shouldHide ? 10 : 11));
        }

        if (this.isHiding()) {
            this.method_5942().method_6340();
        }
    }

    private boolean isHoldingDryFlower(class_1657 player) {
        return player.method_6047().method_31574(GileMod.DRY_FLOWER_ITEM) || player.method_6079().method_31574(GileMod.DRY_FLOWER_ITEM);
    }

    @Override
    public void method_5711(byte status) {
        if (status == 10 || status == 11) {
            class_2680 state = this.method_37908().method_8320(this.method_24515().method_10074());
            for (int i = 0; i < 12; ++i) {
                double offsetX = (this.field_5974.method_43058() - 0.5) * this.method_17681() * 1.5;
                double offsetZ = (this.field_5974.method_43058() - 0.5) * this.method_17681() * 1.5;
                this.method_37908().method_8406(new class_2388(class_2398.field_11217, state),
                        this.method_23317() + offsetX, this.method_23318() + 0.1, this.method_23321() + offsetZ, 0.0, 0.15, 0.0);
            }
        } else {
            super.method_5711(status);
        }
    }

    @Override
    public void method_6091(class_243 movementInput) {
        if (this.isHiding()) {
            super.method_6091(class_243.field_1353);
        } else {
            super.method_6091(movementInput);
        }
    }

    @Override
    public boolean method_5810() {
        return !this.isHiding();
    }

    @Override
    protected void method_6087(class_1297 entity) {
        if (!this.isHiding()) {
            super.method_6087(entity);
        }
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        int looting = 0;
        if (source.method_5529() instanceof class_1309 attacker) {
            class_6880<class_1887> lootingEnchant = attacker.method_37908()
                    .method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_40264(class_1893.field_9110)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = class_1890.method_8203(lootingEnchant, attacker);
            }
        }
        float[] chances = {0.25f, 0.33f, 0.40f, 0.50f};
        // Prevent crashes if modded looting goes above 3
        int index = Math.min(looting, chances.length - 1);
        if (this.field_5974.method_43057() < chances[index]) {
            this.method_5775(new class_1799(GileMod.JERBOAS_TAIL, 1));
        }
    }

    @Nullable
    @Override
    public JerboaEntity method_5613(class_3218 world, class_1296 entity) {
        JerboaEntity baby = GileMod.JERBOA.method_5883(world);
        if (baby != null && entity instanceof JerboaEntity parent) {
            // Baby inherits variant from parents
            baby.setDesertVariant(this.field_5974.method_43056() ? this.isDesertVariant() : parent.isDesertVariant());
        }
        return baby;
    }

    @Nullable
    @Override
    protected class_3414 method_5994() {
        return this.isHiding() ? null : class_3417.field_14693;
    }

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_15164;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14872;
    }

    static class HideGoal extends class_1352 {
        private final JerboaEntity jerboa;

        public HideGoal(JerboaEntity jerboa) {
            this.jerboa = jerboa;
            this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406, class_4134.field_18407));
        }

        @Override
        public boolean method_6264() {
            return this.jerboa.isHiding();
        }

        @Override
        public void method_6269() {
            this.jerboa.method_5942().method_6340();
        }

        @Override
        public void method_6268() {
            this.jerboa.method_5942().method_6340();
        }
    }
}