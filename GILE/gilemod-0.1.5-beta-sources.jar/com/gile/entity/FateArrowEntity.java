package com.gile.entity;

import com.gile.GileMod;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class FateArrowEntity extends class_1665 {
    public FateArrowEntity(class_1299<? extends class_1665> entityType, class_1937 world) {
        super(entityType, world);
        this.field_7572 = class_1666.field_7593;
    }

    public FateArrowEntity(class_1937 world, class_1309 owner, class_1799 pickupStack) {
        super(GileMod.FATE_ARROW_TYPE, owner, world, pickupStack, null);
        this.method_7438(6.0);
        this.field_7572 = class_1666.field_7593;
    }

    @Override
    protected class_1799 method_7445() {
        return new class_1799(GileMod.FATE_ARROW);
    }

    @Override
    protected class_1799 method_57314() {
        return new class_1799(GileMod.FATE_ARROW);
    }
    private int punch = 0;
    public void setPunch(int punch) {
        this.punch = punch;
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        // Correctly define the target from the hit result
        net.minecraft.class_1297 target = entityHitResult.method_17782();
        // Handle the Knockback logic
        if (this.punch > 0 && target instanceof class_1309 livingTarget) {
            class_243 velocity = this.method_18798().method_18805(1, 0, 1).method_1029().method_1021(this.punch * 0.6);
            livingTarget.method_5762(velocity.field_1352, 0.1, velocity.field_1350); }
        // Call super after custom knockback logic
        super.method_7454(entityHitResult);

        if (!this.method_37908().field_9236) {
            if (target instanceof class_1309 livingEntity) {
                // Apply levitation effect
                class_1293 levitationEffect = new class_1293(
                        class_1294.field_5902,
                        100,
                        0,
                        true,
                        true);
                livingEntity.method_37222(levitationEffect, this.method_24921());
                // Add particles
                if (this.method_37908() instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(
                            class_2398.field_11248,
                            livingEntity.method_23317(),
                            livingEntity.method_23318() + livingEntity.method_17682() / 2,
                            livingEntity.method_23321(),
                            40,
                            0.5, 0.5, 0.5,
                            0.1 );
                    // Play sound
                    serverWorld.method_43128(
                            null,
                            livingEntity.method_23317(),
                            livingEntity.method_23318(),
                            livingEntity.method_23321(),
                            class_3417.field_26979,
                            class_3419.field_15248,
                            1.0f,
                            1.0f );
                }
            }
        }
    }

    @Override
    protected void method_24920(class_3965 blockHitResult) {
        super.method_24920(blockHitResult);

        if (!this.method_37908().field_9236) {
            // Only play sound on block hit, no particles
            this.method_5783(net.minecraft.class_3417.field_15151, 1.0F, 1.0F);
        }
    }

    @Override
    public void method_5773() {
        super.method_5773();

        // Trail particles while flying
        if (this.method_37908().field_9236 && !this.field_7588) {
            // Spawn 5 particles with random offset
            for (int i = 0; i < 3; i++) {
                double offsetX = (this.field_5974.method_43058() - 0.5) * 0.5; // Increased from 0.2 to 0.5
                double offsetY = (this.field_5974.method_43058() - 0.5) * 0.5; // Increased from 0.2 to 0.5
                double offsetZ = (this.field_5974.method_43058() - 0.5) * 0.5; // Increased from 0.2 to 0.5

                this.method_37908().method_8406(class_2398.field_11245,
                        this.method_23317() + offsetX,
                        this.method_23318() + offsetY,
                        this.method_23321() + offsetZ,
                        0.0, 0.0, 0.0);
            }
        }

        // Particles when stuck in ground
        if (this.method_37908().field_9236 && this.field_7588 && this.field_6012 % 10 == 0) {
            for (int i = 0; i < 2; i++) {
                double offsetX = (this.field_5974.method_43058() - 0.5) * 0.5; // Increased from 0.3 to 0.5
                double offsetZ = (this.field_5974.method_43058() - 0.5) * 0.5; // Increased from 0.3 to 0.5

                this.method_37908().method_8406(class_2398.field_11245,
                        this.method_23317() + offsetX,
                        this.method_23318() + 0.1,
                        this.method_23321() + offsetZ,
                        0.0, 0.0, 0.0);
            }
        }
    }
    @Override
    protected float method_7436() {
        return 0.6F;
    }
}