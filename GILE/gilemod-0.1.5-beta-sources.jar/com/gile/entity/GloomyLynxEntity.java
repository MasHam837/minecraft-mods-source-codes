package com.gile.entity;

import com.gile.GileMod;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1359;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1400;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class GloomyLynxEntity extends class_1429 {

    // Track the angry state so the client knows when to swap the model parts
    private static final class_2940<Boolean> ANGRY = class_2945.method_12791(GloomyLynxEntity.class, class_2943.field_13323);

    public GloomyLynxEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        // Pounce at targets before striking
        this.field_6201.method_6277(1, new class_1359(this, 0.4F));
        this.field_6201.method_6277(2, new class_1366(this, 1.2, true));
        this.field_6201.method_6277(3, new class_1341(this, 1.0));
        this.field_6201.method_6277(4, new class_1391(this, 1.1, class_1856.method_8091(GileMod.COOKED_PHASMA), false));
        this.field_6201.method_6277(5, new class_1394(this, 0.8));
        this.field_6201.method_6277(6, new class_1361(this, class_1657.class, 8.0F));
        this.field_6201.method_6277(7, new class_1376(this));

        // Hunting logic: Actively target ghosts!
        this.field_6185.method_6277(1, new class_1400<>(this, class_1657.class, true));
        this.field_6185.method_6277(1, new class_1400<>(this, LuminousEntity.class, true));
        this.field_6185.method_6277(1, new class_1400<>(this, HoveringGhostEntity.class, true));
    }

    public static class_5132.class_5133 createLynxAttributes() {
        return class_1429.method_26828()
                .method_26868(class_5134.field_23716, 24.0)
                .method_26868(class_5134.field_23719, 0.3) // Faster than normal animals
                .method_26868(class_5134.field_23721, 7.0)
                .method_26868(class_5134.field_23717, 32.0); // Can spot ghosts from far away
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(ANGRY, false);
    }

    public boolean isAngry() {
        return this.field_6011.method_12789(ANGRY);
    }

    public void setAngry(boolean angry) {
        this.field_6011.method_12778(ANGRY, angry);
    }

    @Override
    protected void method_5958() {
        // Automatically become angry if it has a target it is actively hunting
        this.setAngry(this.method_5968() != null);
        super.method_5958();
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(GileMod.COOKED_PHASMA);
    }

    @Override
    public float method_6144(class_2338 pos, net.minecraft.class_4538 world) {
        // Forces the game to accept this spawn location even in absolute darkness
        // without needing vanilla Grass Blocks.
        return 10.0F;
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        int looting = 0;
        if (source.method_5529() instanceof class_1309 attacker) {
            class_6880<class_1887> lootingEnchant = attacker.method_37908()
                    .method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_40264(class_1893.field_9110)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = class_1890.method_8203(lootingEnchant, attacker);}}
        int dropCount = 2 + this.field_5974.method_43048(3 + looting * 2);
        this.method_5775(new class_1799(GileMod.PHASMA, dropCount));
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return GileMod.GLOOMY_LYNX.method_5883(world);
    }

    @Nullable
    @Override
    protected class_3414 method_5994() {
        return this.isAngry() ? class_3417.field_14938 : class_3417.field_16437;
    }

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_16441;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_16442;
    }
}