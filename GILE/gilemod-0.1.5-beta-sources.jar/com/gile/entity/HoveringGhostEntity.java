package com.gile.entity;

import com.gile.GileMod;
import com.gile.advancement.NamedEntityCriterion;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1331;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1374;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1432;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4538;
import net.minecraft.class_4980;
import net.minecraft.class_4981;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class HoveringGhostEntity extends class_1321 implements class_4981, class_1432 {

    private static final class_2940<Boolean> SADDLED =
            class_2945.method_12791(HoveringGhostEntity.class, class_2943.field_13323);

    private static final class_2940<Integer> BOOST_TIME =
            class_2945.method_12791(HoveringGhostEntity.class, class_2943.field_13327);

    private final class_4980 saddledComponent;

    public HoveringGhostEntity(class_1299<? extends class_1321> entityType, class_1937 world) {
        super(entityType, world);
        this.field_6207 = new class_1331(this, 10, false);
        this.saddledComponent = new class_4980(this.field_6011, BOOST_TIME, SADDLED);
    }

    @Override
    protected boolean method_5818(class_1297 passenger) {
        return this.method_5685().size() < 2;
    }

    @Override
    protected void method_5865(class_1297 passenger, class_1297.class_4738 positionUpdater) {
        if (this.method_5626(passenger)) {
            int seatIndex = this.method_5685().indexOf(passenger);
            float zOffset = (seatIndex == 0) ? 0.0F : -1.2F;
            float yawRad = this.field_6283 * ((float)Math.PI / 180F);
            double offsetX = -Math.sin(yawRad) * zOffset;
            double offsetZ = Math.cos(yawRad) * zOffset;

            positionUpdater.accept(passenger, this.method_23317() + offsetX, this.method_23318() + 0.35D, this.method_23321() + offsetZ);
        } else {
            super.method_5865(passenger, positionUpdater);
        }
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        if (this.isSaddled()) {
            this.method_5775(new class_1799(class_1802.field_8175));
        }

        int looting = 0;
        if (source.method_5529() instanceof class_1309 attacker) {
            class_6880<class_1887> lootingEnchant = attacker.method_37908()
                    .method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_40264(class_1893.field_9110)
                    .orElse(null);

            if (lootingEnchant != null) {
                looting = class_1890.method_8203(lootingEnchant, attacker);
            }
        }

        int dropCount = 1 + this.field_5974.method_43048(2 + looting);
        this.method_5775(new class_1799(GileMod.PHASMA, dropCount));
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1374(this, 1.25));
        this.field_6201.method_6277(2, new class_1341(this, 1.0));
        this.field_6201.method_6277(3, new class_1391(this, 1.1, class_1856.method_8091(GileMod.JELLY, GileMod.JELLY_ON_A_STICK), false));
        this.field_6201.method_6277(4, new class_1394(this, 1.0));
        this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 6.0f));
        this.field_6201.method_6277(6, new class_1376(this));
    }

    public static class_5132.class_5133 createHoveringGhostAttributes() {
        return class_1321.method_26828()
                .method_26868(class_5134.field_23716, 40.0)
                .method_26868(class_5134.field_23720, 0.2)
                .method_26868(class_5134.field_23719, 0.2)
                .method_26868(class_5134.field_23717, 10.0);
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 birdNavigation = new class_1407(this, world);
        birdNavigation.method_6332(false);
        birdNavigation.method_6354(true);
        birdNavigation.method_6331(true);
        return birdNavigation;
    }

    @Override
    public boolean method_6581() {
        return !this.method_24828();
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 damageSource) {
        return false;
    }

    @Override
    public boolean method_21750() {
        return true;
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(GileMod.JELLY);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(SADDLED, false);
        builder.method_56912(BOOST_TIME, 0);
    }

    @Override
    public float method_6144(class_2338 pos, class_4538 world) {
        return 10.0F;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_5805()) {
            // FIX: Treat BOOST_TIME as a countdown timer. This completely removes the need
            // to call any methods on SaddledComponent, sidestepping the error entirely.
            if (!this.method_37908().field_9236) {
                int currentBoost = this.field_6011.method_12789(BOOST_TIME);
                if (currentBoost > 0) {
                    this.field_6011.method_12778(BOOST_TIME, currentBoost - 1);
                }
            }

            boolean isNyanCat = this.method_16914() && "Nyan Cat".equalsIgnoreCase(this.method_5797().getString());
            boolean shouldTrail = false;

            if (this.method_5782() && this.method_5642() instanceof class_1657 player) {
                class_1799 mainHand = player.method_5998(class_1268.field_5808);
                class_1799 offHand = player.method_5998(class_1268.field_5810);
                shouldTrail = mainHand.method_31574(GileMod.JELLY_ON_A_STICK) || offHand.method_31574(GileMod.JELLY_ON_A_STICK);
            }

            if (this.method_37908().field_9236 && isNyanCat && shouldTrail) {

                float yawRad = this.field_6283 * ((float)Math.PI / 180F);
                double trailLength = 1.3;
                double spawnX = this.method_23317() + Math.sin(yawRad) * trailLength;
                double spawnZ = this.method_23321() - Math.cos(yawRad) * trailLength;
                double spawnY = this.method_23318() + (this.method_17682() * 0.4);

                org.joml.Vector3f[] rainbowColors = new org.joml.Vector3f[]{
                        new org.joml.Vector3f(1.0F, 0.0F, 0.0F),
                        new org.joml.Vector3f(1.0F, 0.5F, 0.0F),
                        new org.joml.Vector3f(1.0F, 1.0F, 0.0F),
                        new org.joml.Vector3f(0.0F, 1.0F, 0.0F),
                        new org.joml.Vector3f(0.0F, 0.5F, 1.0F),
                        new org.joml.Vector3f(0.3F, 0.0F, 0.8F),
                        new org.joml.Vector3f(0.5F, 0.0F, 0.5F)
                };

                double totalSpread = 1.2;

                for (int i = 0; i < 7; i++) {
                    double lateralOffset = ((double)i / 6.0 - 0.5) * totalSpread;
                    double particleX = spawnX + Math.cos(yawRad) * lateralOffset;
                    double particleZ = spawnZ + Math.sin(yawRad) * lateralOffset;

                    net.minecraft.class_2390 dustOptions =
                            new net.minecraft.class_2390(rainbowColors[i], 1.2F);

                    this.method_37908().method_8406(dustOptions, particleX, spawnY, particleZ, 0.0, 0.0, 0.0);
                }
            }
        }

        if (!this.method_24828() && this.method_18798().field_1351 < 0.0 && !this.method_5782()) {
            this.method_18799(this.method_18798().method_18805(1.0, 0.6, 1.0));
        }
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);

        if (!this.method_6181() && itemStack.method_31574(GileMod.JELLY)) {
            if (!this.method_37908().field_9236) {
                this.method_6475(player, hand, itemStack);
                if (this.field_5974.method_43048(3) == 0) {
                    this.method_6170(player);
                    this.method_6173(true, true);
                    this.method_37908().method_8421(this, (byte)7);
                } else {
                    this.method_37908().method_8421(this, (byte)6);
                }
            }
            return class_1269.method_29236(this.method_37908().field_9236);
        }

        if (this.method_6181() && !this.isSaddled() && !this.method_6109() && itemStack.method_31574(class_1802.field_8175)) {
            if (!this.method_37908().field_9236) {
                itemStack.method_57008(1, player);
                this.saddledComponent.method_26310(true);
            }
            return class_1269.method_29236(this.method_37908().field_9236);
        }

        boolean isBreedingItem = this.method_6481(itemStack);
        if (!isBreedingItem && this.isSaddled() && !this.method_6109() && this.method_5685().size() < 2 && !player.method_5765()) {
            if (!this.method_37908().field_9236) {
                player.method_5804(this);
            }
            return class_1269.method_29236(this.method_37908().field_9236);
        }

        return super.method_5992(player, hand);
    }

    @Override
    public void method_6091(class_243 movementInput) {
        if (this.method_5805()) {
            if (this.method_5782() && this.method_5642() instanceof class_1657 player) {
                class_1799 itemStack = player.method_5998(class_1268.field_5808);
                class_1799 offHandStack = player.method_5998(class_1268.field_5810);

                if (itemStack.method_31574(GileMod.JELLY_ON_A_STICK) || offHandStack.method_31574(GileMod.JELLY_ON_A_STICK)) {
                    this.method_36456(player.method_36454());
                    this.field_5982 = this.method_36454();
                    this.method_36457(player.method_36455() * 0.5F);
                    this.method_5710(this.method_36454(), this.method_36455());
                    this.field_6283 = this.method_36454();
                    this.field_6241 = this.field_6283;

                    class_243 lookVec = player.method_5828(1.0F);
                    double baseSpeed = this.method_45325(class_5134.field_23720);

                    // Because BOOST_TIME ticks down to 0 now, this naturally resets and allows re-boosting!
                    boolean isBoosting = this.field_6011.method_12789(BOOST_TIME) > 0;
                    double speedMultiplier = 1.5;

                    double finalSpeed = isBoosting ? (baseSpeed * 2.5) : (baseSpeed * speedMultiplier);

                    this.method_18799(lookVec.method_1021(finalSpeed));
                    this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
                    return;
                } else {
                    this.method_18799(this.method_18798().method_1021(0.7));
                    this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
                    return;
                }
            }
            super.method_6091(movementInput);
        }
    }

    @Nullable
    @Override
    public class_1309 method_5642() {
        class_1297 entity = this.method_31483();
        return entity instanceof class_1657 ? (class_1657)entity : null;
    }

    @Override
    public boolean method_6577() {
        // FIX: If already boosting, ignore.
        if (this.field_6011.method_12789(BOOST_TIME) > 0) {
            return false;
        }

        // Start the boost timer natively by updating the tracker.
        if (!this.method_37908().field_9236) {
            // Set the countdown duration (140 to 981 ticks, similar to vanilla pigs)
            this.field_6011.method_12778(BOOST_TIME, 140 + this.field_5974.method_43048(841));

            boolean isNyanCat = this.method_16914() && "Nyan Cat".equalsIgnoreCase(this.method_5797().getString());
            if (isNyanCat) {
                // Play the Nyan Cat sound
                this.method_37908().method_43128(
                        null,
                        this.method_23317(),
                        this.method_23318(),
                        this.method_23321(),
                        GileMod.HOVERING_GHOST_NYAN_AMBIENT,
                        class_3419.field_15254,
                        1.0F,    // Volume
                        1.0F     // Pitch (normal)
                );
            }
        }

        return true;
    }

    public boolean isSaddled() {
        return this.saddledComponent.method_26311();
    }

    @Nullable
    @Override
    protected class_3414 method_5994() {return class_3417.field_14812;}

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_15072;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14964;
    }

    @Nullable
    @Override
    public HoveringGhostEntity method_5613(class_3218 world, class_1296 entity) {
        HoveringGhostEntity child = GileMod.HOVERING_GHOST.method_5883(world);
        if (child != null) {
            child.method_7217(true);
            child.method_6173(false, false);
        }
        return child;
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        this.saddledComponent.method_26309(nbt);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        this.saddledComponent.method_26312(nbt);
    }

    @Override
    public void method_5665(@Nullable class_2561 name) {
        super.method_5665(name);
        if (name != null && !this.method_37908().field_9236 && this.method_37908() instanceof class_3218) {
            // Get the owner or nearby players
            this.method_37908().method_18456().forEach(player -> {
                if (player instanceof class_3222 serverPlayer &&
                        player.method_5858(this) < 100) { // Within 10 blocks
                    NamedEntityCriterion.CRITERION.trigger(serverPlayer, this, name.getString());
                }
            });
        }
    }
}