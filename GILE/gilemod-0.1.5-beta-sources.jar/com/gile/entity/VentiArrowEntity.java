package com.gile.entity;

import com.gile.GileMod;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import org.joml.Vector3f;

public class VentiArrowEntity extends class_1665 {
    // Custom colored dust particles - greenish-cyan
    private static final class_2394 TRAIL_PARTICLE = new class_2390(
            new Vector3f(0.2f, 0.9f, 0.8f), // RGB: greenish-cyan
            1.5f // size
    );

    private static final class_2394 HIT_PARTICLE = new class_2390(
            new Vector3f(0.1f, 1.0f, 0.9f), // Brighter cyan for hits
            2.0f
    );

    private static final class_2394 BLOCK_HIT_PARTICLE = new class_2390(
            new Vector3f(0.3f, 0.8f, 0.7f), // Slightly different shade
            1.0f
    );

    private float pushStrength = 1.5f;

    public VentiArrowEntity(class_1299<? extends class_1665> entityType, class_1937 world) {
        super(entityType, world);
        this.field_7572 = class_1666.field_7592;
    }

    public VentiArrowEntity(class_1937 world, class_1309 owner) {
        super(GileMod.VENTI_ARROW_TYPE, owner, world, new class_1799(class_1802.field_8107), null);
        this.method_7438(7.0);
        this.field_7572 = class_1666.field_7592;
    }

    @Override
    protected class_1799 method_7445() {
        return new class_1799(class_1802.field_8107);
    }

    @Override
    protected class_1799 method_57314() {
        return new class_1799(class_1802.field_8107);
    }

    private int punch = 0;
    public void setPunch(int punch) {
        this.punch = punch;
    }

    public void setPushStrength(float strength) {
        this.pushStrength = strength;
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        net.minecraft.class_1297 target = entityHitResult.method_17782();

        if (target instanceof class_1309 livingTarget) {
            class_243 velocity = this.method_18798().method_1029().method_1021(this.pushStrength);
            if (this.punch > 0) {
                velocity = velocity.method_1021(1.0 + (this.punch * 0.5));
            }
            livingTarget.method_5762(velocity.field_1352, 0.2, velocity.field_1350);
            livingTarget.field_6037 = true;
        }

        super.method_7454(entityHitResult);

        if (!this.method_37908().field_9236) {
            if (target instanceof class_1309 livingEntity) {

                if (this.method_37908() instanceof class_3218 serverWorld) {
                    // Colored dust burst on hit
                    serverWorld.method_14199(
                            HIT_PARTICLE,
                            livingEntity.method_23317(),
                            livingEntity.method_23318() + livingEntity.method_17682() / 2,
                            livingEntity.method_23321(),
                            40,
                            0.8, 1.0, 0.8,
                            0.1);

                    // White cloud overlay
                    serverWorld.method_14199(
                            class_2398.field_11204,
                            livingEntity.method_23317(),
                            livingEntity.method_23318() + livingEntity.method_17682() / 2,
                            livingEntity.method_23321(),
                            15,
                            0.5, 0.5, 0.5,
                            0.05);

                    serverWorld.method_43128(
                            null,
                            livingEntity.method_23317(),
                            livingEntity.method_23318(),
                            livingEntity.method_23321(),
                            class_3417.field_47195,
                            class_3419.field_15248,
                            1.0f,
                            1.0f);
                }
            }
        }
    }

    @Override
    protected void method_24920(class_3965 blockHitResult) {
        super.method_24920(blockHitResult);

        if (!this.method_37908().field_9236) {
            this.method_5783(class_3417.field_15151, 1.0F, 1.0F);

            // Rarer colored dust on block hit
            if (this.field_5974.method_43057() < 0.3f && this.method_37908() instanceof class_3218 serverWorld) {
                serverWorld.method_14199(
                        BLOCK_HIT_PARTICLE,
                        this.method_23317(),
                        this.method_23318(),
                        this.method_23321(),
                        10,
                        0.3, 0.3, 0.3,
                        0.03);
            }
        }
    }

    @Override
    public void method_5773() {
        super.method_5773();

        // Trail particles while flying - colored dust
        if (this.method_37908().field_9236 && !this.field_7588) {
            for (int i = 0; i < 3; i++) {
                double offsetX = (this.field_5974.method_43058() - 0.5) * 0.3;
                double offsetY = (this.field_5974.method_43058() - 0.5) * 0.3;
                double offsetZ = (this.field_5974.method_43058() - 0.5) * 0.3;

                this.method_37908().method_8406(TRAIL_PARTICLE,
                        this.method_23317() + offsetX,
                        this.method_23318() + offsetY,
                        this.method_23321() + offsetZ,
                        0.0, 0.0, 0.0);
            }
        }

        // Rarer particles when stuck in ground
        if (this.method_37908().field_9236 && this.field_7588 && this.field_6012 % 40 == 0) {
            if (this.field_5974.method_43057() < 0.3f) {
                this.method_37908().method_8406(BLOCK_HIT_PARTICLE,
                        this.method_23317(),
                        this.method_23318() + 0.1,
                        this.method_23321(),
                        0.0, 0.01, 0.0);
            }
        }

        // Auto-discard after being in ground too long
        if (!this.method_37908().field_9236 && this.field_7588 && this.field_6012 > 1200) {
            this.method_31472();
        }
    }

    @Override
    protected float method_7436() {
        return 0.6F;
    }

    @Override
    public void method_5694(class_1657 player) {
        // Do nothing - prevent pickup
    }
}