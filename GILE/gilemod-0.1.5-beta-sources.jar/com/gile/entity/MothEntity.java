package com.gile.entity;

import com.gile.GileMod;
import com.gile.advancement.NamedEntityCriterion;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1331;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1353;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_1432;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_4538;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class MothEntity extends class_1429 implements class_1432 {
    private static final class_2940<Byte> MOTH_FLAGS =
            class_2945.method_12791(MothEntity.class, class_2943.field_13319);

    public MothEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
        this.field_6207 = new class_1331(this, 10, true);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1341(this, 1.0));
        this.field_6201.method_6277(2, new class_1391(this, 1.0, class_1856.method_8091(GileMod.MOON_FLOWER_ITEM), false));
        this.field_6201.method_6277(3, new class_1353(this, 1.1));
        this.field_6201.method_6277(4, new class_1394(this, 1.0));
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(MOTH_FLAGS, (byte)0);
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(GileMod.MOON_FLOWER_ITEM);
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 birdNavigation = new class_1407(this, world);
        birdNavigation.method_6332(false);
        birdNavigation.method_6354(true);
        birdNavigation.method_6331(true);
        return birdNavigation;
    }

    @Override
    public float method_6144(class_2338 pos, class_4538 world) {
        return world.method_8320(pos.method_10074()).method_26215() ? 10.0F : 0.0F;
    }

    @Override
    public boolean method_6581() {
        return !this.method_24828();
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);

        if (this.method_6481(itemStack)) {
            int age = this.method_5618();

            if (!this.method_37908().field_9236 && age == 0 && this.method_6482()) {
                this.method_6475(player, hand, itemStack);
                this.method_6480(player);
                return class_1269.field_5812;
            }

            if (this.method_6109()) {
                this.method_6475(player, hand, itemStack);
                this.method_5620(method_41321(-24000), true);
                return class_1269.method_29236(this.method_37908().field_9236);
            }
        }

        return super.method_5992(player, hand);
    }

    @Override
    public void method_6007() {
        super.method_6007();

        // Try to fly higher when not on ground
        if (!this.method_24828() && this.method_18798().field_1351 < 0.0) {
            this.method_18799(this.method_18798().method_18805(1.0, 0.6, 1.0));
        }

        if (this.method_37908().field_9236) {
            // Wing scale particles while flying
            if (this.field_5974.method_43048(10) == 0) {
                this.method_37908().method_8406(
                        class_2398.field_11207,
                        this.method_23322(0.5),
                        this.method_23318() + 0.3,
                        this.method_23325(0.5),
                        0.0, 0.0, 0.0
                );
            }

            // Extra particles when in love mode
            if (this.method_6479() && this.field_5974.method_43048(5) == 0) {
                this.method_37908().method_8406(
                        class_2398.field_11201,
                        this.method_23322(0.5),
                        this.method_23318() + 0.5,
                        this.method_23325(0.5),
                        0.0, 0.0, 0.0
                );
            }
        }
    }

    @Override
    public void method_6091(class_243 movementInput) {
        if (this.method_5787()) {
            if (this.method_5799()) {
                this.method_5724(0.02F, movementInput);
                this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
                this.method_18799(this.method_18798().method_1021(0.8F));
            } else if (this.method_5771()) {
                this.method_5724(0.02F, movementInput);
                this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
                this.method_18799(this.method_18798().method_1021(0.5));
            } else {
                float f = 0.91F;
                if (this.method_24828()) {
                    f = this.method_37908().method_8320(this.method_23314())
                            .method_26204().method_9499() * 0.91F;
                }
                float g = 0.16277137F / (f * f * f);
                this.method_5724(this.method_24828() ? 0.1F * g : 0.02F, movementInput);
                f = 0.91F;
                if (this.method_24828()) {
                    f = this.method_37908().method_8320(this.method_23314())
                            .method_26204().method_9499() * 0.91F;
                }
                this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
                this.method_18799(this.method_18798().method_1021(f));
            }
        }
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 damageSource) {
        return false; // No fall damage
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        int looting = 0;
        if (source.method_5529() instanceof class_1309 attacker) {
            class_6880<class_1887> lootingEnchant = attacker.method_37908()
                    .method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_40264(class_1893.field_9110)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = class_1890.method_8203(lootingEnchant, attacker);}}
        int dropCount = this.field_5974.method_43048(2 + looting);
        this.method_5775(new class_1799(GileMod.MOTH_WING, dropCount));
    }

    @Nullable
    @Override
    public MothEntity method_5613(class_3218 world, class_1296 entity) {
        return GileMod.MOTH.method_5883(world);
    }

    public static class_5132.class_5133 createMothAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 6.0)
                .method_26868(class_5134.field_23720, 0.4) // Increased from 0.3
                .method_26868(class_5134.field_23719, 0.2)
                .method_26868(class_5134.field_23717, 10.0);
    }

    @Nullable
    @Override
    protected class_3414 method_5994() {
        return class_3417.field_20605;
    }

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_20603;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_20602;
    }

    @Override
    protected float method_6107() {
        return 0.3F;
    }

    @Override
    public float method_6017() {
        return 1.3F;
    }

    @Override
    public void method_5665(@Nullable class_2561 name) {
        super.method_5665(name);
        if (name != null && !this.method_37908().field_9236 && this.method_37908() instanceof class_3218) {
            this.method_37908().method_18456().forEach(player -> {
                if (player instanceof class_3222 serverPlayer &&
                        player.method_5858(this) < 100) { // Within 10 blocks
                    NamedEntityCriterion.CRITERION.trigger(serverPlayer, this, name.getString());
                }
            });
        }
    }
}