package com.gile.entity;

import com.gile.GileMod;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1338;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1657;
import net.minecraft.class_1772;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1889;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_3988;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9306;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class WeaselThiefEntity extends class_3988 {

    private static final class_2940<Integer> VARIANT = class_2945.method_12791(WeaselThiefEntity.class, class_2943.field_13327);
    private int dropCooldown = 0;

    public WeaselThiefEntity(class_1299<? extends class_3988> entityType, class_1937 world) {
        super(entityType, world);
    }

    public static class_5132.class_5133 createWeaselAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 10.0)
                .method_26868(class_5134.field_23719, 0.4); // Very fast!
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        // Flee from players within 16 blocks, runs at 1.2x speed near, 1.5x speed far
        this.field_6201.method_6277(1, new class_1338<>(this, class_1657.class, 16.0F, 1.2, 1.5));
        this.field_6201.method_6277(2, new class_1394(this, 1.0));
        this.field_6201.method_6277(3, new class_1361(this, class_1657.class, 8.0F));
        this.field_6201.method_6277(4, new class_1376(this));
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(VARIANT, 0);
    }

    public WeaselVariant getVariant() {
        return WeaselVariant.byId(this.field_6011.method_12789(VARIANT));
    }

    public void setVariant(WeaselVariant variant) {
        this.field_6011.method_12778(VARIANT, variant.getId());
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        int looting = 0;
        if (source.method_5529() instanceof class_1309 attacker) {
            class_6880<class_1887> lootingEnchant = attacker.method_37908()
                    .method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_40264(class_1893.field_9110)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = class_1890.method_8203(lootingEnchant, attacker);}}
        int dropCount = 1 + this.field_5974.method_43048(10 + looting);
        this.method_5775(new class_1799(GileMod.PRIMOGEM, dropCount));
    }

    @Override
    public void method_6007() {
        super.method_6007();

        if (!this.method_37908().field_9236 && this.method_5805()) {
            // Check if moving fast (fleeing)
            if (this.method_18798().method_37268() > 0.01) {
                class_1657 closest = this.method_37908().method_18460(this, 16.0);
                if (closest != null) {
                    if (this.dropCooldown <= 0) {
                        // REPLACE Items.GOLD_NUGGET WITH YOUR MORA ITEM
                        this.method_5706(GileMod.MORA);
                        // Random cooldown between 3 to 8 seconds
                        this.dropCooldown = 60 + this.field_5974.method_43048(100);
                    }
                }
            }
            if (this.dropCooldown > 0) {
                this.dropCooldown--;
            }
        }
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (this.method_5805() && !this.method_18009() && !this.method_6109()) {
            if (!this.method_37908().field_9236) {
                this.method_8259(player);
                this.method_17449(player, this.method_5476(), 1);
            }
            return class_1269.method_29236(this.method_37908().field_9236);
        }
        return super.method_5992(player, hand);
    }

    @Override
    protected void method_7237() {
        class_1916 offers = new class_1916();
        WeaselVariant variant = this.getVariant();

        // 1. Define Trade Limits based on Rarity
        int maxUses = variant == WeaselVariant.AMATEUR ? 5 : (variant == WeaselVariant.HOARDER ? 3 : 1);
        int xp = variant == WeaselVariant.AMATEUR ? 2 : (variant == WeaselVariant.HOARDER ? 5 : 10);

        // 2. Load Modded Items (Sigils & Currency)
        class_1792 mora = getCustomItem("mora");
        class_1792 pyro = getCustomItem("pyro_sigil");
        class_1792 geo = getCustomItem("geo_sigil");
        class_1792 dendro = getCustomItem("dendro_sigil");
        class_1792 electro = getCustomItem("electro_sigil");
        class_1792 hydro = getCustomItem("hydro_sigil");
        class_1792 anemo = getCustomItem("anemo_sigil");
        class_1792 cryo = getCustomItem("cryo_sigil");
        class_1792 luna = getCustomItem("luna_sigil");

        // --- TRADE 1: MORA CONVERTER ---
        // Trades Mora for 1 random elemental Sigil. Cost depends on rarity variant.
        int moraCost = switch (variant) {
            case HOARDER -> 4; // Hoarder (Rare)
            case GOLDEN -> 2; // Golden (Epic)
            default -> 8; // Amateur (Common)
        };

        class_1792[] allSigils = {pyro, geo, dendro, electro, hydro, anemo, cryo, luna};
        class_1792 randomSigil = allSigils[this.field_5974.method_43048(allSigils.length)];

        offers.add(createTrade(mora, moraCost, randomSigil, 1, maxUses, xp));

        // Let's roll a random index (0, 1, or 2) for each of the 8 elements
        int rAir = this.field_5974.method_43048(3);
        int rEarth = this.field_5974.method_43048(3);
        int rElectro = this.field_5974.method_43048(3);
        int rNature = this.field_5974.method_43048(3);
        int rWater = this.field_5974.method_43048(3);
        int rFire = this.field_5974.method_43048(3);
        int rFrost = this.field_5974.method_43048(3);
        int rMoon = this.field_5974.method_43048(3);

        // --- TRADE 2: AIR ---
        switch (variant) {
            case AMATEUR -> offers.add(rAir == 0 ? createTrade(anemo, 2, class_1802.field_8614, 4, maxUses, xp) : rAir == 1 ? createTrade(anemo, 1, class_1802.field_8803, 2, maxUses, xp) : createTrade(anemo, 4, createDuration3Rocket(8), maxUses, xp));
            case HOARDER -> offers.add(rAir == 0 ? createTrade(anemo, 6, class_1802.field_49821, 4, maxUses, xp) : rAir == 1 ? createTrade(anemo, 15, class_1802.field_8613, 8, maxUses, xp) : createTrade(anemo, 7, class_1802.field_8786, 12, maxUses, xp));
            case GOLDEN -> offers.add(rAir == 0 ? createTrade(anemo, 30, class_1802.field_49813, 1, maxUses, xp) : rAir == 1 ? createTrade(anemo, 40, class_1802.field_8833, 1, maxUses, xp) : createTrade(anemo, 64, getCustomItem("daybreak_chronicles"), 1, maxUses, xp));
        }

        // --- TRADE 3: EARTH ---
        switch (variant) {
            case AMATEUR -> offers.add(rEarth == 0 ? createTrade(geo, 1, class_1802.field_8858, 16, maxUses, xp) : rEarth == 1 ? createTrade(geo, 2, class_1802.field_8270, 4, maxUses, xp) : createTrade(geo, 4, class_1802.field_20391, 32, maxUses, xp));
            case HOARDER -> offers.add(rEarth == 0 ? createTrade(geo, 8, class_1802.field_28042, 4, maxUses, xp) : rEarth == 1 ? createTrade(geo, 4, class_1802.field_27069, 8, maxUses, xp) : createTrade(geo, 6, getCustomItem("wish"), 1, maxUses, xp));
            case GOLDEN -> offers.add(rEarth == 0 ? createTrade(geo, 15, class_1802.field_8603, 1, maxUses, xp) : rEarth == 1 ? createTrade(geo, 30, class_1802.field_29216, 1, maxUses, xp) : createTrade(geo, 64, getCustomItem("vortex_vanquisher"), 1, maxUses, xp));
        }

        // --- TRADE 4: ELECTRO ---
        switch (variant) {
            case AMATEUR -> offers.add(rElectro == 0 ? createTrade(electro, 1, class_1802.field_8725, 32, maxUses, xp) : rElectro == 1 ? createTrade(electro, 3, class_1802.field_8619, 18, maxUses, xp) : createTrade(electro, 5, class_1802.field_8857, 12, maxUses, xp));
            case HOARDER -> offers.add(rElectro == 0 ? createTrade(electro, 4, class_1802.field_8626, 8, maxUses, xp) : rElectro == 1 ? createTrade(electro, 6, class_1802.field_8801, 12, maxUses, xp) : createTrade(electro, 8, class_1802.field_27074, 4, maxUses, xp));
            case GOLDEN -> offers.add(rElectro == 0 ? createTrade(electro, 10, class_1802.field_8793, 8, maxUses, xp) : rElectro == 1 ? createTrade(electro, 32, createThunderTrident(), maxUses, xp) : createTrade(electro, 64, getCustomItem("engulfing_lightning"), 1, maxUses, xp));
        }

        // --- TRADE 5: NATURE ---
        switch (variant) {
            case AMATEUR -> offers.add(rNature == 0 ? createTrade(dendro, 1, class_1802.field_28654, 16, maxUses, xp) : rNature == 1 ? createTrade(dendro, 2, class_1802.field_17524, 8, maxUses, xp) : createTrade(dendro, 3, class_1802.field_28652, 1, maxUses, xp));
            case HOARDER -> offers.add(rNature == 0 ? createTrade(dendro, 5, class_1802.field_17531, 12, maxUses, xp) : rNature == 1 ? createTrade(dendro, 8, class_1802.field_8648, 4, maxUses, xp) : createTrade(dendro, 6, class_1802.field_8116, 2, maxUses, xp));
            case GOLDEN -> offers.add(rNature == 0 ? createTrade(dendro, 15, class_1802.field_20415, 1, maxUses, xp) : rNature == 1 ? createTrade(dendro, 20, class_1802.field_43193, 1, maxUses, xp) : createTrade(dendro, 64, getCustomItem("thousand_floating_dreams"), 1, maxUses, xp));
        }

        // --- TRADE 6: WATER ---
        switch (variant) {
            case AMATEUR -> offers.add(rWater == 0 ? createTrade(hydro, 2, class_1802.field_8434, 16, maxUses, xp) : rWater == 1 ? createTrade(hydro, 1, class_1802.field_17498, 8, maxUses, xp) : createTrade(hydro, 1, class_1802.field_17533, 4, maxUses, xp));
            case HOARDER -> offers.add(rWater == 0 ? createTrade(hydro, 6, class_1802.field_8864, 2, maxUses, xp) : rWater == 1 ? createTrade(hydro, 10, class_1802.field_28354, 1, maxUses, xp) : createTrade(hydro, 8, class_1802.field_8535, 4, maxUses, xp));
            case GOLDEN -> offers.add(rWater == 0 ? createTrade(hydro, 25, class_1802.field_8207, 1, maxUses, xp) : rWater == 1 ? createTrade(hydro, 32, createRiptideTrident(), maxUses, xp) : createTrade(hydro, 64, getCustomItem("splendor_of_tranquil_waters"), 1, maxUses, xp));
        }

        // --- TRADE 7: FIRE ---
        switch (variant) {
            case AMATEUR -> offers.add(rFire == 0 ? createTrade(pyro, 1, class_1802.field_8354, 16, maxUses, xp) : rFire == 1 ? createTrade(pyro, 3, class_1802.field_8187, 1, maxUses, xp) : createTrade(pyro, 2, class_1802.field_8814, 8, maxUses, xp));
            case HOARDER -> offers.add(rFire == 0 ? createTrade(pyro, 6, class_1802.field_8281, 1, maxUses, xp) : rFire == 1 ? createTrade(pyro, 2, class_1802.field_8183, 4, maxUses, xp) : createTrade(pyro, 4, class_1802.field_8070, 2, maxUses, xp));
            case GOLDEN -> offers.add(rFire == 0 ? createTrade(pyro, 30, class_1802.field_8791, 1, maxUses, xp) : rFire == 1 ? createTrade(pyro, 25, class_1802.field_22021, 1, maxUses, xp) : createTrade(pyro, 64, getCustomItem("thousand_blazing_suns"), 1, maxUses, xp));
        }

        // --- TRADE 8: FROST ---
        switch (variant) {
            case AMATEUR -> offers.add(rFrost == 0 ? createTrade(cryo, 2, class_1802.field_27876, 1, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 1, class_1802.field_8246, 4, maxUses, xp) : createTrade(cryo, 1, class_1802.field_8426, 16, maxUses, xp));
            case HOARDER -> offers.add(rFrost == 0 ? createTrade(cryo, 8, class_1802.field_8081, 32, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 10, createFrostWalkerBook(), maxUses, xp) : createTrade(cryo, 9, class_1802.field_28101, 16, maxUses, xp));
            case GOLDEN -> offers.add(rFrost == 0 ? createTrade(cryo, 20, class_1802.field_8178, 64, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 36, createEpicPickaxe(), maxUses, xp) : createTrade(cryo, 64, getCustomItem("tsaritsas_scepter"), 1, maxUses, xp));
        }

        // --- TRADE 9: MOON ---
        switch (variant) {
            case AMATEUR -> offers.add(rMoon == 0 ? createTrade(luna, 1, getCustomItem("end_grass_block"), 2, maxUses, xp) : rMoon == 1 ? createTrade(luna, 1, class_1802.field_20399, 16, maxUses, xp) : createTrade(luna, 2, getCustomItem("ghostly_sapling"), 1, maxUses, xp));
            case HOARDER -> offers.add(rMoon == 0 ? createTrade(luna, 6, class_1802.field_8634, 8, maxUses, xp) : rMoon == 1 ? createTrade(luna, 8, class_1802.field_8815, 2, maxUses, xp) : createTrade(luna, 8, getCustomItem("heart_of_healing"), 1, maxUses, xp));
            case GOLDEN -> offers.add(rMoon == 0 ? createTrade(luna, 20, class_1802.field_8301, 2, maxUses, xp) : rMoon == 1 ? createTrade(luna, 15, getCustomItem("shadow_clock"), 1, maxUses, xp) : createTrade(luna, 64, getCustomItem("nocturnes_curtain_call"), 1, maxUses, xp));
        }

        this.field_17721 = offers;
    }

    // ==========================================
    // TRADE CREATION HELPERS
    // ==========================================

    private class_1792 getCustomItem(String id) {
        return net.minecraft.class_7923.field_41178.method_10223(net.minecraft.class_2960.method_60655("gilemod", id));
    }

    private class_1914 createTrade(class_1792 cost, int costCount, class_1792 reward, int rewardCount, int maxUses, int xp) {
        return new class_1914(new class_9306(cost, costCount), new class_1799(reward, rewardCount), maxUses, xp, 0.0f);
    }

    private class_1914 createTrade(class_1792 cost, int costCount, class_1799 rewardStack, int maxUses, int xp) {
        return new class_1914(new class_9306(cost, costCount), rewardStack, maxUses, xp, 0.0f);
    }

    // 1.21.1 Component System for Fireworks
    private class_1799 createDuration3Rocket(int count) {
        class_1799 stack = new class_1799(class_1802.field_8639, count);
        stack.method_57379(net.minecraft.class_9334.field_49616, new net.minecraft.class_9284(3, java.util.List.of()));
        return stack;
    }

    // 1.21.1 Registry System for Enchanted Books
    private class_1799 createFrostWalkerBook() {
        var registryManager = this.method_37908().method_30349();
        var enchantmentRegistry = registryManager.method_30530(class_7924.field_41265);
        var frostWalkerEntry = enchantmentRegistry.method_40264(class_1893.field_9122).orElseThrow();
        return class_1772.method_7808(new class_1889(frostWalkerEntry, 2));
    }

    // 1.21.1 Registry System for Enchanted Pickaxe
    private class_1799 createEpicPickaxe() {
        class_1799 stack = new class_1799(class_1802.field_8377);
        var registryManager = this.method_37908().method_30349();
        var enchantmentRegistry = registryManager.method_30530(class_7924.field_41265);

        var silkTouchEntry = enchantmentRegistry.method_40264(class_1893.field_9099).orElseThrow();
        var efficiencyEntry = enchantmentRegistry.method_40264(class_1893.field_9131).orElseThrow();

        stack.method_7978(silkTouchEntry, 1);
        stack.method_7978(efficiencyEntry, 3);
        return stack;
    }

    // 1.21.1 Registry System for Riptide Trident
    private class_1799 createRiptideTrident() {
        class_1799 stack = new class_1799(class_1802.field_8547);
        var registryManager = this.method_37908().method_30349();
        var enchantmentRegistry = registryManager.method_30530(class_7924.field_41265);

        var riptideEntry = enchantmentRegistry.method_40264(class_1893.field_9104).orElseThrow();

        stack.method_7978(riptideEntry, 1);
        return stack;
    }

    // 1.21.1 Registry System for Thunder Trident
    private class_1799 createThunderTrident() {
        class_1799 stack = new class_1799(class_1802.field_8547);
        var registryManager = this.method_37908().method_30349();
        var enchantmentRegistry = registryManager.method_30530(class_7924.field_41265);

        var channelingEntry = enchantmentRegistry.method_40264(class_1893.field_9117).orElseThrow();
        var loyaltyEntry = enchantmentRegistry.method_40264(class_1893.field_9120).orElseThrow();

        stack.method_7978(channelingEntry, 1);
        stack.method_7978(loyaltyEntry, 2);
        return stack;
    }

    @Nullable
    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason, @Nullable class_1315 entityData) {
        // Roll for rarity: 10% Golden, 30% Hoarder, 60% Amateur
        int roll = this.field_5974.method_43048(100);
        if (roll < 10) {
            this.setVariant(WeaselVariant.GOLDEN);
        } else if (roll < 40) {
            this.setVariant(WeaselVariant.HOARDER);
        } else {
            this.setVariant(WeaselVariant.AMATEUR);
        }
        return super.method_5943(world, difficulty, spawnReason, entityData);
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10569("WeaselVariant", this.getVariant().getId());
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        this.setVariant(WeaselVariant.byId(nbt.method_10550("WeaselVariant")));
    }

    @Override
    protected void method_18008(class_1914 offer) {
        // This is a mandatory method in 1.21.1. It triggers every time a trade is completed.
        // If you still want the Weasel to drop XP when traded with, you can add it here!

        if (!this.method_37908().field_9236) {
            // Drops a small amount of XP when the player buys something
            int xp = 3 + this.field_5974.method_43048(4);
            this.method_37908().method_8649(new net.minecraft.class_1303(this.method_37908(), this.method_23317(), this.method_23318() + 0.5D, this.method_23321(), xp));
        }
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return null; // They don't breed
    }

    @Override
    protected class_3414 method_5994() {
        return GileMod.WEASEL_THIEF_AMBIENT;
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_18061;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_18059;
    }
}