package com.gile.entity;

import com.gile.GileMod;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1333;
import net.minecraft.class_1335;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.entity.ai.goal.*;
import org.joml.Vector3f;

import java.util.EnumSet;

public class VoidSlimeEntity extends class_1588 {
    private static final class_2940<Integer> SLIME_SIZE = class_2945.method_12791(VoidSlimeEntity.class, class_2943.field_13327);
    public float targetStretch;
    public float stretch;
    public float lastStretch;
    private boolean onGroundLastTick;

    public VoidSlimeEntity(class_1299<? extends class_1588> entityType, class_1937 world) {
        super(entityType, world);
        this.onGroundLastTick = false;
        this.field_6207 = new class_1335(this);
        this.field_6206 = new class_1333(this);}

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new class_1347(this));
        this.field_6201.method_6277(2, new VoidSlimeAttackGoal(this));
        this.field_6201.method_6277(3, new VoidSlimeFaceTargetGoal(this));
        this.field_6201.method_6277(4, new VoidSlimeRandomLookGoal(this));
        this.field_6201.method_6277(5, new VoidSlimeMoveGoal(this));

        this.field_6185.method_6277(1, new class_1400<>(this, class_1657.class, true));}

    public static class_5132.class_5133 createVoidSlimeAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 10.0)
                .method_26868(class_5134.field_23719, 0.3)
                .method_26868(class_5134.field_23721, 4.0)
                .method_26868(class_5134.field_23717, 24.0)
                .method_26868(class_5134.field_49078, 0.04);}

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(SLIME_SIZE, 1);}

    public void setSize(int size, boolean heal) {
        this.field_6011.method_12778(SLIME_SIZE, size);
        this.method_23311();
        this.method_18382();
        this.method_5996(class_5134.field_23716).method_6192(10.0);
        this.method_5996(class_5134.field_23719).method_6192(0.3 + 0.1 * size);
        this.method_5996(class_5134.field_23721).method_6192(4.0);
        if (heal) {
            this.method_6033(this.method_6063());}}

    public int getSize() {
        return this.field_6011.method_12789(SLIME_SIZE);
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10569("Size", this.getSize() - 1);
        nbt.method_10556("wasOnGround", this.onGroundLastTick);}

    @Override
    public void method_5749(class_2487 nbt) {
        this.setSize(nbt.method_10550("Size") + 1, false);
        super.method_5749(nbt);
        this.onGroundLastTick = nbt.method_10577("wasOnGround");}

    @Override
    public void method_5773() {
        // Force face target if it has one
        if (this.method_5968() != null) {
            this.method_5951(this.method_5968(), 30.0F, 30.0F);
            this.field_6283 = this.method_36454();
            this.field_6241 = this.method_36454();}

        this.stretch += (this.targetStretch - this.stretch) * 0.5F;
        this.lastStretch = this.stretch;
        super.method_5773();

        if (this.method_24828() && !this.onGroundLastTick) {
            this.targetStretch = -0.5F;
            // Spawn particles when landing
            if (this.method_37908().field_9236) {
                for (int i = 0; i < 8; i++) {
                    this.method_37908().method_8406(
                            new class_2390(new Vector3f(0.22f, 0.16f, 0.36f), 1.0F),
                            this.method_23317() + (this.field_5974.method_43058() - 0.5) * 0.8,
                            this.method_23318() + 0.1,
                            this.method_23321() + (this.field_5974.method_43058() - 0.5) * 0.8,
                            (this.field_5974.method_43058() - 0.5) * 0.1,
                            0.05,
                            (this.field_5974.method_43058() - 0.5) * 0.1 );}}
        } else if (!this.method_24828() && this.onGroundLastTick) {
            this.targetStretch = 1.0F;}

        this.onGroundLastTick = this.method_24828();
        if (this.method_24828()) {this.targetStretch *= 0.6F;}

        // Constant subtle particles while on ground
        if (this.method_37908().field_9236 && this.method_24828() && this.field_5974.method_43048(2) == 0) {
            for (int i = 0; i < 3; i++) {
                this.method_37908().method_8406(
                        new class_2390(new Vector3f(0.22f, 0.16f, 0.36f), 1.0F),
                        this.method_23322(0.5),
                        this.method_23319(),
                        this.method_23325(0.5),
                        (this.field_5974.method_43058() - 0.5) * 0.02,
                        0.01,
                        (this.field_5974.method_43058() - 0.5) * 0.02 );}
        }
    }

    @Override
    public void method_5694(class_1657 player) {
        // Only damage if close enough (matches attack range)
        double distance = this.method_5858(player);
        double hitboxRange = 1.5; // Match entity dimensions

        if (distance <= hitboxRange * hitboxRange && this.method_5805() && !player.method_7337() && player.method_5805()) {
            player.method_5643(this.method_48923().method_48812(this),
                    (float)this.method_45325(class_5134.field_23721));
            this.pushPlayerAway(player);}
    }

    private void pushPlayerAway(class_1657 player) {
        double dX = player.method_23317() - this.method_23317();
        double dZ = player.method_23321() - this.method_23321();
        double distance = Math.max(Math.sqrt(dX * dX + dZ * dZ), 0.001);
        double pushStrength = 0.5; // Stronger push
        player.method_5762(dX / distance * pushStrength, 0.15, dZ / distance * pushStrength);
        player.field_6037 = true;
    }

    @Override
    public void method_5951(class_1297 targetEntity, float maxYawChange, float maxPitchChange) {
        double dX = targetEntity.method_23317() - this.method_23317();
        double dZ = targetEntity.method_23321() - this.method_23321();
        double dY;

        if (targetEntity instanceof class_1309 livingEntity) {
            dY = livingEntity.method_23320() - this.method_23320();}
        else {
            dY = (targetEntity.method_5829().field_1322 + targetEntity.method_5829().field_1325) / 2.0 - this.method_23320();}

        double distance = Math.sqrt(dX * dX + dZ * dZ);
        float targetYaw = (float)(Math.atan2(dZ, dX) * 57.2957763671875) - 90.0F;
        float targetPitch = (float)(-(Math.atan2(dY, distance) * 57.2957763671875));

        this.method_36457(this.method_5960(this.method_36455(), targetPitch, maxPitchChange));
        this.method_36456(this.method_5960(this.method_36454(), targetYaw, maxYawChange));
        this.field_6283 = this.method_36454();
        this.field_6241 = this.method_36454();
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_15014;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14763;
    }

    @Override
    protected float method_6107() {
        return 0.4F;
    }

    @Override
    public float method_6017() {
        return 1.0F;
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        // Get looting level
        int looting = 0;
        if (source.method_5529() instanceof class_1309 attacker) {
            class_6880<class_1887> lootingEnchant = attacker.method_37908()
                    .method_30349()
                    .method_30530(class_7924.field_41265)
                    .method_40264(class_1893.field_9110)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = class_1890.method_8203(lootingEnchant, attacker);}}
        // Drop 1-2 slimeballs, +1 extra per looting level
        int dropCount = 1 + this.field_5974.method_43048(2 + looting);
        this.method_5775(new class_1799(GileMod.VOID_SLIMEBALL, dropCount));
    }

    static class VoidSlimeMoveGoal extends class_1352 {
        private final VoidSlimeEntity slime;

        public VoidSlimeMoveGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.method_6265(EnumSet.of(class_1352.class_4134.field_18407, class_1352.class_4134.field_18405));}

        @Override
        public boolean method_6264() {
            return this.slime.method_5968() != null && this.slime.method_24828();
        }

        @Override
        public void method_6268() {
            class_1309 target = this.slime.method_5968();
            if (target != null) {
                this.slime.method_5951(target, 30.0F, 30.0F);
                this.slime.field_6283 = this.slime.method_36454();
                this.slime.field_6241 = this.slime.method_36454();}}
    }

    static class VoidSlimeFaceTargetGoal extends class_1352 {
        private final VoidSlimeEntity slime;

        public VoidSlimeFaceTargetGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.method_6265(EnumSet.of(class_1352.class_4134.field_18406));}

        @Override
        public boolean method_6264() {
            return this.slime.method_5968() != null;
        }

        @Override
        public boolean method_6266() {
            return this.slime.method_5968() != null && this.slime.method_5968().method_5805();
        }

        @Override
        public void method_6268() {
            class_1309 target = this.slime.method_5968();
            if (target != null) {
                this.slime.method_5951(target, 30.0F, 30.0F);
                this.slime.field_6283 = this.slime.method_36454();
                this.slime.field_6241 = this.slime.method_36454();}}
    }

    static class VoidSlimeAttackGoal extends class_1352 {
        private final VoidSlimeEntity slime;
        private int timer;

        public VoidSlimeAttackGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.method_6265(EnumSet.of(class_1352.class_4134.field_18407, class_1352.class_4134.field_18405));
            this.timer = this.slime.method_59922().method_43048(20);}

        @Override
        public boolean method_6264() {
            return this.slime.method_5968() != null;
        }

        @Override
        public void method_6268() {
            class_1309 target = this.slime.method_5968();
            if (target != null && this.slime.method_24828()) {
                if (--this.timer <= 0) {
                    this.timer = 15 + this.slime.method_59922().method_43048(15);

                    if (this.slime.method_37908().field_9236) {
                        for (int i = 0; i < 5; i++) {
                            this.slime.method_37908().method_8406(
                                    new class_2390(new Vector3f(0.22f, 0.16f, 0.36f), 1.0F),
                                    this.slime.method_23317() + (this.slime.field_5974.method_43058() - 0.5) * 0.5,
                                    this.slime.method_23318() + 0.1,
                                    this.slime.method_23321() + (this.slime.field_5974.method_43058() - 0.5) * 0.5,
                                    (this.slime.field_5974.method_43058() - 0.5) * 0.2,
                                    0.1,
                                    (this.slime.field_5974.method_43058() - 0.5) * 0.2);}}

                    double dX = target.method_23317() - this.slime.method_23317();
                    double dZ = target.method_23321() - this.slime.method_23321();
                    double distance = Math.sqrt(dX * dX + dZ * dZ);

                    if (distance > 0.01) {
                        class_243 velocity = this.slime.method_18798();
                        // Cap jump so it lands on target, not past it
                        double jumpStrength = Math.min(distance, 0.8) * 0.5;
                        this.slime.method_18800(
                                velocity.field_1352 + (dX / distance) * jumpStrength,
                                0.4,
                                velocity.field_1350 + (dZ / distance) * jumpStrength);
                        this.slime.field_6037 = true;}

                    this.slime.method_5951(target, 30.0F, 30.0F);
                    this.slime.field_6283 = this.slime.method_36454();
                    this.slime.field_6241 = this.slime.method_36454();}}}
    }

    static class VoidSlimeRandomLookGoal extends class_1352 {
        private final VoidSlimeEntity slime;
        private float targetYaw;
        private int timer;
        private int jumpTimer;

        public VoidSlimeRandomLookGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.method_6265(EnumSet.of(class_1352.class_4134.field_18406, class_1352.class_4134.field_18407));}

        @Override
        public boolean method_6264() {
            return this.slime.method_5968() == null && this.slime.method_24828();
        }

        @Override
        public boolean method_6266() {
            return this.slime.method_5968() == null;
        }

        @Override
        public void method_6269() {
            // Random initial timers so each slime is out of sync
            this.timer = this.slime.method_59922().method_43048(40);
            this.jumpTimer = 20 + this.slime.method_59922().method_43048(60);
            // Pick initial random look direction
            if (this.slime.method_59922().method_43048(3) == 0) {
                this.targetYaw = this.slime.method_36454() + (this.slime.method_59922().method_43057() - 0.5F) * 180.0F;}}

        @Override
        public void method_6268() {
            // Random looking around occasionally
            if (--this.timer <= 0) {
                this.timer = 30 + this.slime.method_59922().method_43048(70); // Varied interval
                this.targetYaw = this.slime.method_59922().method_43057() * 360.0F;}
            // Smoothly turn towards target yaw
            this.slime.method_36456(this.slime.method_5960(this.slime.method_36454(), this.targetYaw, 10.0F));
            this.slime.field_6283 = this.slime.method_36454();
            this.slime.field_6241 = this.slime.method_36454();
            // Random idle jumping in the direction it's looking
            if (--this.jumpTimer <= 0 && this.slime.method_24828()) {
                this.jumpTimer = 40 + this.slime.method_59922().method_43048(120); // Varied timing
                float yaw = this.slime.method_36454() * ((float)Math.PI / 180F);
                double jumpStrength = 0.2 + this.slime.method_59922().method_43058() * 0.2; // Varied strength
                double dX = -Math.sin(yaw) * jumpStrength;
                double dZ = Math.cos(yaw) * jumpStrength;
                this.slime.method_18800(dX, 0.2 + this.slime.method_59922().method_43058() * 0.2, dZ);
                this.slime.field_6037 = true; }}
    }

    public float method_5960(float from, float to, float max) {
        float f = class_3532.method_15393(to - from);
        if (f > max) {
            f = max;}
        if (f < -max) {
            f = -max;}
        return from + f;}
}