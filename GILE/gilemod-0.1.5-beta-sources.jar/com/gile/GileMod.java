package com.gile;

import com.gile.advancement.NamedEntityCriterion;
import com.gile.advancement.UsedScepterCriterion;
import com.gile.block.*;
import com.gile.block.entity.GhostlyHangingSignBlockEntity;
import com.gile.block.entity.GhostlySignBlockEntity;
import com.gile.block.entity.MoonCampfireBlockEntity;
import com.gile.effect.EnlargeStatusEffect;
import com.gile.effect.ShrinkStatusEffect;
import com.gile.entity.*;
import com.gile.network.ActiveAbilityPayload;
import com.gile.tool.FateUpgradeSmithingTemplateItem;
import com.gile.tool.item.*;
import com.gile.tool.material.LightningToolMaterials;
import com.gile.worldgen.CloudBlobFeature;
import com.gile.worldgen.EndSurfaceFeature;
import com.gile.worldgen.MoonDesertSurfaceFeature;
import com.gile.worldgen.StarFeature;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.TheEndBiomes;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_174;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1822;
import net.minecraft.class_1826;
import net.minecraft.class_1827;
import net.minecraft.class_1829;
import net.minecraft.class_1839;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2354;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2397;
import net.minecraft.class_2398;
import net.minecraft.class_2431;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3749;
import net.minecraft.class_3962;
import net.minecraft.class_4174;
import net.minecraft.class_4970;
import net.minecraft.class_5172;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_6796;
import net.minecraft.class_6880;
import net.minecraft.class_7707;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8813;
import net.minecraft.class_9169;
import net.minecraft.class_9300;
import net.minecraft.class_9334;
import net.minecraft.entity.*;
import java.util.*;
import java.util.function.Predicate;
import net.minecraft.item.*;
import net.minecraft.world.gen.feature.*;
import org.joml.Vector3f;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.gile.tool.material.BlazingToolMaterials.THOUSAND_BLAZING_SUNS_MATERIAL;
import static com.gile.tool.material.FloatingToolMaterials.THOUSAND_FLOATING_DREAMS_MATERIAL;
import static com.gile.tool.material.ModToolMaterials.FATE_SWORD_MATERIAL;
import static com.gile.tool.material.NocturneToolMaterials.NOCTURNES_CURTAIN_CALL_MATERIAL;
import static com.gile.tool.material.SplendorToolMaterials.SPLENDOR_OF_TRANQUIL_WATERS_MATERIAL;
import static com.gile.tool.material.TsaritsaToolMaterials.TSARITSAS_SCEPTER_MATERIAL;
import static com.gile.tool.material.VortexToolMaterials.VORTEX_VANQUISHER_MATERIAL;

public class GileMod implements ModInitializer {
	public static final String MOD_ID = "gilemod";
	public static final Logger LOGGER = LoggerFactory.getLogger("gile");

	/*=================
	ITEM DECLARATIONS:
	=================*/

	public static final class_1792 PRIMOGEM = new class_1792(new class_1792.class_1793());
	public static final class_1792 ANEMO_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 GEO_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 ELECTRO_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 DENDRO_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 HYDRO_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 PYRO_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 CRYO_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 LUNA_SIGIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 MORA = new class_1792(new class_1792.class_1793());
	public static final class_1792 WISH_INGOT = new class_1792(new class_1792.class_1793());
	public static final class_1792 WISH_NUGGET = new class_1792(new class_1792.class_1793());
	public static final class_1792 CRYSTAL = new class_1792(new class_1792.class_1793());
	public static final class_1792 FATE_UPGRADE_SMITHING_TEMPLATE = new FateUpgradeSmithingTemplateItem();
	public static final class_1792 MOTH_WING = new class_1792(new class_1792.class_1793());
	public static final class_1792 VOID_SLIMEBALL = new class_1792(new class_1792.class_1793());
	public static final class_1792 PHASMA = new class_1792(new class_1792.class_1793());
	public static final class_1792 CHRONO_GEAR = new class_1792(new class_1792.class_1793());
	public static final class_1792 STAR_FRAGMENT = new class_1792(new class_1792.class_1793());
	public static final class_1792 HEART_OF_HEALING = new HeartOfHealingItem(new class_1792.class_1793().method_7889(1));
	public static final class_1792 SHADOW_CLOCK = new ShadowClockItem(new class_1792.class_1793());
	public static final class_1792 GRAPPLING_HOOK = new GrapplingHookItem(new class_1792.class_1793().method_7889(1).method_7895(374));
	public static final class_1792 JERBOAS_TAIL = new class_1792(new class_1792.class_1793());
	public static final class_1792 SHRINKER = new ShrinkerItem(new class_1792.class_1793().method_7895(191));
	public static final class_1792 ENLARGER = new EnlargerItem(new class_1792.class_1793().method_7895(191));

	/*==================
	BLOCK DECLARATIONS:
	==================*/

	// PRIMOGEM/PEARLESCENT:
	public static final class_2248 PRIMOGEM_ORE = new class_2431(
			class_6019.method_35017(2, 6),
			class_4970.class_2251.method_9637()
					.method_29292()
					.method_9629(3.0f, 3.0f));
	public static final class_1792 PRIMOGEM_ORE_ITEM = new class_1747(PRIMOGEM_ORE, new class_1792.class_1793());
	public static final class_2248 DEEPSLATE_PRIMOGEM_ORE = new class_2431(
			class_6019.method_35017(2, 6),
			class_4970.class_2251.method_9637()
					.method_29292()
					.method_9629(3.5f, 3.5f));
	public static final class_1792 DEEPSLATE_PRIMOGEM_ORE_ITEM = new class_1747(DEEPSLATE_PRIMOGEM_ORE, new class_1792.class_1793());
	public static final class_2248 END_PRIMOGEM_ORE = new class_2431(
			class_6019.method_35017(2, 6),
			class_4970.class_2251.method_9637()
					.method_29292()
					.method_9629(4.0f, 4.0f));
	public static final class_1792 END_PRIMOGEM_ORE_ITEM = new class_1747(END_PRIMOGEM_ORE, new class_1792.class_1793());
	public static final class_2248 WISH = new class_2248(
			class_4970.class_2251.method_9637()
					.method_9629(2.0f, 2.0f)
					.method_9626(net.minecraft.class_2498.field_27197));
	public static final class_1792 WISH_ITEM = new class_1747(WISH, new class_1792.class_1793());
	public static final class_2248 PEARLESCENT_BLOCK = new class_2248(
			class_4970.class_2251.method_9637()
					.method_29292().method_9629(2.0f, 2.0f)
					.method_9626(net.minecraft.class_2498.field_47085));
	public static final class_1792 PEARLESCENT_BLOCK_ITEM = new class_1747(PEARLESCENT_BLOCK, new class_1792.class_1793());
	public static final class_2248 PEARLESCENT_BRICKS = new class_2248(
			class_4970.class_2251.method_9630(PEARLESCENT_BLOCK));
	public static final class_1792 PEARLESCENT_BRICKS_ITEM = new class_1747(PEARLESCENT_BRICKS, new class_1792.class_1793());
	public static final class_2248 PEARLESCENT_STAIRS = new class_2510(
			PEARLESCENT_BLOCK.method_9564(),
			class_4970.class_2251.method_9630(PEARLESCENT_BLOCK));
	public static final class_1792 PEARLESCENT_STAIRS_ITEM = new class_1747(PEARLESCENT_STAIRS, new class_1792.class_1793());
	public static final class_2248 PEARLESCENT_SLAB = new class_2482(
			class_4970.class_2251.method_9630(PEARLESCENT_BLOCK));
	public static final class_1792 PEARLESCENT_SLAB_ITEM = new class_1747(PEARLESCENT_SLAB, new class_1792.class_1793());
	public static final class_2248 PEARLESCENT_WALL = new class_2544(
			class_4970.class_2251.method_9630(PEARLESCENT_BLOCK));
	public static final class_1792 PEARLESCENT_WALL_ITEM = new class_1747(PEARLESCENT_WALL, new class_1792.class_1793());

	// GHOSTLY LOG:
	public static final class_2248 GHOSTLY_LOG = new class_2465(
			class_4970.class_2251.method_9630(class_2246.field_10431));
	public static final class_1792 GHOSTLY_LOG_ITEM = new class_1747(GHOSTLY_LOG, new class_1792.class_1793());
	public static final class_2248 STRIPPED_GHOSTLY_LOG = new class_2465(
			class_4970.class_2251.method_9630(class_2246.field_10519));
	public static final class_1792 STRIPPED_GHOSTLY_LOG_ITEM = new class_1747(STRIPPED_GHOSTLY_LOG, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_WOOD = new class_2465(
			class_4970.class_2251.method_9630(class_2246.field_10126));
	public static final class_1792 GHOSTLY_WOOD_ITEM = new class_1747(GHOSTLY_WOOD, new class_1792.class_1793());
	public static final class_2248 STRIPPED_GHOSTLY_WOOD = new class_2465(
			class_4970.class_2251.method_9630(class_2246.field_10250));
	public static final class_1792 STRIPPED_GHOSTLY_WOOD_ITEM = new class_1747(STRIPPED_GHOSTLY_WOOD, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_PLANKS = new class_2248(
			class_4970.class_2251.method_9630(class_2246.field_10161));
	public static final class_1792 GHOSTLY_PLANKS_ITEM = new class_1747(GHOSTLY_PLANKS, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_STAIRS = new class_2510(GHOSTLY_PLANKS.method_9564(),
			class_4970.class_2251.method_9630(GHOSTLY_PLANKS));
	public static final class_1792 GHOSTLY_STAIRS_ITEM = new class_1747(GHOSTLY_STAIRS, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_SLAB = new class_2482(
			class_4970.class_2251.method_9630(GHOSTLY_PLANKS));
	public static final class_1792 GHOSTLY_SLAB_ITEM = new class_1747(GHOSTLY_SLAB, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_FENCE = new class_2354(
			class_4970.class_2251.method_9630(GHOSTLY_PLANKS));
	public static final class_1792 GHOSTLY_FENCE_ITEM = new class_1747(GHOSTLY_FENCE, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_FENCE_GATE = new class_2349(
			ModWoodTypes.GHOSTLY_WOOD_TYPE, class_4970.class_2251.method_9630(GHOSTLY_PLANKS));
	public static final class_1792 GHOSTLY_FENCE_GATE_ITEM = new class_1747(GHOSTLY_FENCE_GATE, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_DOOR = new class_2323(
			ModWoodTypes.GHOSTLY_BLOCK_SET, class_4970.class_2251.method_9630(GHOSTLY_PLANKS).method_22488());
	public static final class_1792 GHOSTLY_DOOR_ITEM = new class_1747(GHOSTLY_DOOR, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_TRAPDOOR = new class_2533(
			ModWoodTypes.GHOSTLY_BLOCK_SET, class_4970.class_2251.method_9630(GHOSTLY_PLANKS).method_22488());
	public static final class_1792 GHOSTLY_TRAPDOOR_ITEM = new class_1747(GHOSTLY_TRAPDOOR, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_PRESSURE_PLATE = new class_2440(
			ModWoodTypes.GHOSTLY_BLOCK_SET, class_4970.class_2251.method_9630(GHOSTLY_PLANKS).method_9634());
	public static final class_1792 GHOSTLY_PRESSURE_PLATE_ITEM = new class_1747(GHOSTLY_PRESSURE_PLATE, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_BUTTON = new class_2269(
			ModWoodTypes.GHOSTLY_BLOCK_SET, 30, class_4970.class_2251.method_9630(GHOSTLY_PLANKS).method_9634());
	public static final class_1792 GHOSTLY_BUTTON_ITEM = new class_1747(GHOSTLY_BUTTON, new class_1792.class_1793());
	public static final class_2248 GHOSTLY_SIGN = new GhostlySignBlocks.GhostlySignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			class_4970.class_2251.method_9630(class_2246.field_10121).method_9634());
	public static final class_2248 GHOSTLY_WALL_SIGN = new GhostlySignBlocks.GhostlyWallSignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			class_4970.class_2251.method_9630(class_2246.field_10187).method_9634().method_16228(GHOSTLY_SIGN));
	public static final class_2248 GHOSTLY_HANGING_SIGN = new GhostlySignBlocks.GhostlyHangingSignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			class_4970.class_2251.method_9630(class_2246.field_40262).method_9634());
	public static final class_2248 GHOSTLY_WALL_HANGING_SIGN = new GhostlySignBlocks.GhostlyWallHangingSignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			class_4970.class_2251.method_9630(class_2246.field_40272).method_9634().method_16228(GHOSTLY_HANGING_SIGN));
	public static final class_1792 GHOSTLY_SIGN_ITEM = new class_1822(
			new class_1792.class_1793().method_7889(16), GHOSTLY_SIGN, GHOSTLY_WALL_SIGN);
	public static final class_1792 GHOSTLY_HANGING_SIGN_ITEM = new class_7707(
			GHOSTLY_HANGING_SIGN, GHOSTLY_WALL_HANGING_SIGN, new class_1792.class_1793().method_7889(16));
	public static final class_2248 GHOSTLY_LEAVES = class_2378.method_10230(
			class_7923.field_41175, class_2960.method_60655("gilemod", "ghostly_leaves"),
			new class_2397(class_4970.class_2251.method_9630(class_2246.field_10503).method_31710(class_3620.field_16030)));
	public static final class_1792 GHOSTLY_LEAVES_ITEM = new class_1747(GHOSTLY_LEAVES, new class_1792.class_1793());

	// MOON SAND(STONE)
	public static final class_2248 MOON_SAND = new FallingMoonSand(
			class_4970.class_2251.method_9637()
					.method_29292().method_9629(1.2f, 1.2f)
					.method_9626(net.minecraft.class_2498.field_11526).method_31710(class_3620.field_15991));
	public static final class_1792 MOON_SAND_ITEM = new class_1747(MOON_SAND, new class_1792.class_1793());

	public static final class_2248 MOON_SANDSTONE = new class_2248(
			class_4970.class_2251.method_9630(class_2246.field_9979).method_29292());
	public static final class_1792 MOON_SANDSTONE_ITEM = new class_1747(MOON_SANDSTONE, new class_1792.class_1793());
	public static final class_2248 MOON_SANDSTONE_STAIRS = new class_2510(MOON_SANDSTONE.method_9564(),
			class_4970.class_2251.method_9630(MOON_SANDSTONE));
	public static final class_1792 MOON_SANDSTONE_STAIRS_ITEM = new class_1747(MOON_SANDSTONE_STAIRS, new class_1792.class_1793());
	public static final class_2248 MOON_SANDSTONE_SLAB = new class_2482(
			class_4970.class_2251.method_9630(MOON_SANDSTONE));
	public static final class_1792 MOON_SANDSTONE_SLAB_ITEM = new class_1747(MOON_SANDSTONE_SLAB, new class_1792.class_1793());
	public static final class_2248 MOON_SANDSTONE_WALL = new class_2544(
			class_4970.class_2251.method_9630(MOON_SANDSTONE));
	public static final class_1792 MOON_SANDSTONE_WALL_ITEM = new class_1747(MOON_SANDSTONE_WALL, new class_1792.class_1793());
	public static final class_2248 MOON_CHISELED_SANDSTONE = new class_2248(
			class_4970.class_2251.method_9630(class_2246.field_9979).method_29292());
	public static final class_1792 MOON_CHISELED_SANDSTONE_ITEM = new class_1747(MOON_CHISELED_SANDSTONE, new class_1792.class_1793());
	public static final class_2248 MOON_SMOOTH_SANDSTONE = new class_2248(
			class_4970.class_2251.method_9630(class_2246.field_9979).method_29292());
	public static final class_1792 MOON_SMOOTH_SANDSTONE_ITEM = new class_1747(MOON_SMOOTH_SANDSTONE, new class_1792.class_1793());
	public static final class_2248 MOON_SMOOTH_SANDSTONE_STAIRS = new class_2510(MOON_SMOOTH_SANDSTONE.method_9564(),
			class_4970.class_2251.method_9630(MOON_SMOOTH_SANDSTONE));
	public static final class_1792 MOON_SMOOTH_SANDSTONE_STAIRS_ITEM = new class_1747(MOON_SMOOTH_SANDSTONE_STAIRS, new class_1792.class_1793());
	public static final class_2248 MOON_SMOOTH_SANDSTONE_SLAB = new class_2482(
			class_4970.class_2251.method_9630(MOON_SMOOTH_SANDSTONE));
	public static final class_1792 MOON_SMOOTH_SANDSTONE_SLAB_ITEM = new class_1747(MOON_SMOOTH_SANDSTONE_SLAB, new class_1792.class_1793());
	public static final class_2248 MOON_CUT_SANDSTONE = new class_2248(
			class_4970.class_2251.method_9630(class_2246.field_9979).method_29292());
	public static final class_1792 MOON_CUT_SANDSTONE_ITEM = new class_1747(MOON_CUT_SANDSTONE, new class_1792.class_1793());
	public static final class_2248 MOON_CUT_SANDSTONE_SLAB = new class_2482(
			class_4970.class_2251.method_9630(MOON_CUT_SANDSTONE));
	public static final class_1792 MOON_CUT_SANDSTONE_SLAB_ITEM = new class_1747(MOON_CUT_SANDSTONE_SLAB, new class_1792.class_1793());

	/*=========================
	(BLOCK)ENTITY DECLARATIONS:
	=========================*/

	public static final class_1792 FATE_ARROW = new class_1792(new class_1792.class_1793());
	public static class_1299<FateArrowEntity> FATE_ARROW_TYPE;
	public static class_1299<VentiArrowEntity> VENTI_ARROW_TYPE;
	public static class_1299<VoidSlimeEntity> VOID_SLIME;
	public static class_1792 VOID_SLIME_SPAWN_EGG;
	public static class_1299<MothEntity> MOTH;
	public static class_1792 MOTH_SPAWN_EGG;
	public static class_1299<LuminousEntity> LUMINOUS;
	public static class_1792 LUMINOUS_SPAWN_EGG;
	public static class_1299<HoveringGhostEntity> HOVERING_GHOST;
	public static class_1792 HOVERING_GHOST_SPAWN_EGG;
	public static class_1299<JerboaEntity> JERBOA;
	public static class_1792 JERBOA_SPAWN_EGG;
	public static class_1299<GloomyLynxEntity> GLOOMY_LYNX;
	public static class_1792 GLOOMY_LYNX_SPAWN_EGG;
	public static class_1299<WeaselThiefEntity> WEASEL_THIEF;
	public static class_1792 WEASEL_THIEF_SPAWN_EGG;
	public static class_2591<GhostlySignBlockEntity> GHOSTLY_SIGN_BLOCK_ENTITY;
	public static class_2591<GhostlyHangingSignBlockEntity> GHOSTLY_HANGING_SIGN_BLOCK_ENTITY;

	/*========================
	COMPLEX ITEM DECLARATIONS:
	========================*/

	public static final class_1792 OFFERING = new class_1792(new class_1792.class_1793()
			.method_7889(1).method_19265(
					new class_4174.class_4175().method_19238(8).method_19237(1.2f).method_19240().method_19242())) {
		@Override
		public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
			if (!world.field_9236) {
				user.method_6092(new class_1293(class_1294.field_5906, 1200, 0));}
			class_1799 result = super.method_7861(stack, world, user); //Applies effects
			if (user instanceof class_1657 player && !player.method_31549().field_7477) {
				return new class_1799(class_1802.field_8428);} //Returns bowl after eating if not Creative Mode
			return result;}};

	public static final class_1792 JELLY = new class_1792(new class_1792.class_1793()
			.method_19265(new class_4174.class_4175().method_19238(1).method_19237(0.6f).method_19242()));

	public static final class_1792 JELLY_ON_A_STICK = class_2378.method_10230(class_7923.field_41178,
			class_2960.method_60655("gilemod", "jelly_on_a_stick"),
			new JellyOnAStickItem(new class_1792.class_1793().method_7895(25)));

	public static final class_1792 JAM = new class_1792(new class_1792.class_1793()
			.method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.4f).method_19242()));

	public static final class_1792 COOKED_PHASMA = new class_1792(new class_1792.class_1793()
			.method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.5f).method_19242()));

	public static final class_1792 FATE_SWORD = new FateSwordItem(
			FATE_SWORD_MATERIAL, new class_1792.class_1793().method_57348(
							class_1829.method_57394(FATE_SWORD_MATERIAL, 3, -2.4f)));

	// FATE BOW:
	public static final class_1792 FATE_BOW = new class_1753(new class_1792.class_1793().method_7895(1536)) {
		// Prevents pulling bow without arrows
		public boolean isSuitableFor(class_1799 stack, class_1309 user) {
			if (user instanceof net.minecraft.class_1657 player) {
				// Check if player has any fate arrows in creative OR survival
				if (player.method_7337()) return true;
				// In survival, check for arrows
				for (int i = 0; i < player.method_31548().method_5439(); i++) {
					if (player.method_31548().method_5438(i).method_7909() == FATE_ARROW) {
						return true;}} return false;} return true;}

		@Override
		// Arrow amount decreases by 1 if shot
		public void method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
			if (user instanceof net.minecraft.class_1657 player) {
				int arrowSlot = -1;
				for (int i = 0; i < player.method_31548().method_5439(); i++) {
					if (player.method_31548().method_5438(i).method_7909() == FATE_ARROW) {
						arrowSlot = i; break;}}
				// Creative mode: always shoot even without arrows in inventory
				boolean hasArrow = player.method_7337() || arrowSlot != -1;
				boolean hasInfinity = class_1890.method_8225(world.method_30349()
						.method_30530(class_7924.field_41265).method_40264(class_1893.field_9125).get(), stack) > 0;
				if (!world.field_9236 && hasArrow) {
					// Remove arrow from inventory (unless creative)
					if (!player.method_7337() && !hasInfinity && arrowSlot != -1) {
						player.method_31548().method_5434(arrowSlot, 1);}
					// Create the custom arrow
					FateArrowEntity arrow = new FateArrowEntity(world, player, new class_1799(FATE_ARROW));
					// For creative mode, mark arrow as picked up immediately
					if (player.method_7337() || hasInfinity) {
						arrow.field_7572 = class_1665.class_1666.field_7594;}
					// Optionalize created arrow
					int useTime = this.method_7881(stack, user) - remainingUseTicks;
					float velocity = class_1753.method_7722(useTime);
					arrow.method_5808(
							player.method_23317(), player.method_23320() - 0.1, player.method_23321(),
							player.method_36454(), player.method_36455());
					net.minecraft.class_243 rotation = player.method_5720();
					arrow.method_7485(rotation.field_1352, rotation.field_1351, rotation.field_1350, velocity * 3.0F, 1.0F);
					// Enchantments simulating:
					// 1. Power Enchantment (Increases Damage)
					var enchantmentRegistry = world.method_30349().method_30530(class_7924.field_41265);
					int powerLevel = class_1890.method_8225(enchantmentRegistry.method_40264(class_1893.field_9103).get(), stack);
					if (powerLevel > 0) {arrow.method_7438(arrow.method_7448() + (double)powerLevel * 0.5 + 0.5);}
					// 2. Punch Enchantment (Try setPunch first, then setKnockback)
					int punchLevel = class_1890.method_8225(enchantmentRegistry.method_40264(class_1893.field_9116).get(), stack);
					if (punchLevel > 0) {arrow.setPunch(punchLevel);}
					// 3. Flame Enchantment
					int flameLevel = class_1890.method_8225(enchantmentRegistry.method_40264(class_1893.field_9126).get(), stack);
					if (flameLevel > 0) {arrow.method_5639(100);}
					// Summon custom arrow
					world.method_8649(arrow);
					world.method_43128(null, player.method_31477(), player.method_31478(), player.method_31479(),
							class_3417.field_14600, class_3419.field_15248, 1.0F, 1.0F);
					// Stack damage to the bow
					if (!player.method_7337()) {
						stack.method_7970(1, player, class_1304.field_6173);}}}}
		//Pulling max time, use action & projectile
		@Override
		public int method_7881(class_1799 stack, class_1309 user) {
			return 72000;}
		@Override
		public class_1839 method_7853(class_1799 stack) {
			return class_1839.field_8953;}
		@Override
		public Predicate<class_1799> method_19268() {
			return (stack) -> stack.method_7909() == FATE_ARROW;}};

	// VENTI:
	public static final class_1792 DAYBREAK_CHRONICLES = new class_1753(new class_1792.class_1793().method_7895(1)
			.method_57349(class_9334.field_49630, new class_9300(true))) {
		// Always allow pulling the bow since we don't need arrows
		public boolean isSuitableFor(class_1799 stack, class_1309 user) {
			return true;}

		@Override
		public class_2561 method_7864(class_1799 stack) {
			return class_2561.method_43471(this.method_7866(stack)).method_27694(style ->
					style.method_10977(net.minecraft.class_124.field_1054));}
		private static final class_2394 FEET_PARTICLE = new class_2390(
				new Vector3f(0.1f, 1.0f, 0.9f),
				1.0f);
		private static final class_2394 CLOUD_PARTICLE = new class_2390(
				new Vector3f(1.0f, 1.0f, 1.0f),
				1.5f);

		@Override
		public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
			super.method_7888(stack, world, entity, slot, selected);
			if (entity instanceof class_1309 livingEntity) {
				// Spawn particles at feet when selected in main hand
				if (selected && world instanceof class_3218 serverWorld) {
					if (world.method_8510() % 2 == 0) { // Every other tick
						double x = livingEntity.method_23317();
						double y = livingEntity.method_23318() + 0.1; // Feet level
						double z = livingEntity.method_23321();

						for (int i = 0; i < 3; i++) {
							double offsetX = (world.field_9229.method_43058() - 0.5) * 0.6;
							double offsetZ = (world.field_9229.method_43058() - 0.5) * 0.6;
							serverWorld.method_14199(CLOUD_PARTICLE,
									x + offsetX, y, z + offsetZ,
									1, 0.0, 0.05, 0.0, 0.02);}

						serverWorld.method_14199(
								FEET_PARTICLE,
								x, y, z,
								1, 0.3, 0.05, 0.3, 0.01);}}}}

		@Override
		public void method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
			if (user instanceof net.minecraft.class_1657 player) {
				if (!world.field_9236) {
					// Create the custom arrow entity directly without any arrow item
					VentiArrowEntity arrow = new VentiArrowEntity(world, player);
					// Arrow can never be picked up
					arrow.field_7572 = class_1665.class_1666.field_7594;
					// Calculate velocity
					int useTime = this.method_7881(stack, user) - remainingUseTicks;
					float velocity = class_1753.method_7722(useTime);
					arrow.method_5808(
							player.method_23317(), player.method_23320() - 0.1, player.method_23321(),
							player.method_36454(), player.method_36455());
					net.minecraft.class_243 rotation = player.method_5720();
					arrow.method_7485(rotation.field_1352, rotation.field_1351, rotation.field_1350, velocity * 3.0F, 1.0F);
					// Enchantments
					var enchantmentRegistry = world.method_30349().method_30530(class_7924.field_41265);
					// Power Enchantment
					int powerLevel = class_1890.method_8225(enchantmentRegistry.method_40264(class_1893.field_9103).get(), stack);
					if (powerLevel > 0) {
						arrow.method_7438(arrow.method_7448() + (double)powerLevel * 0.5 + 0.5);}
					// Punch Enchantment
					int punchLevel = class_1890.method_8225(enchantmentRegistry.method_40264(class_1893.field_9116).get(), stack);
					if (punchLevel > 0) {
						arrow.setPunch(punchLevel);}
					// Flame Enchantment
					int flameLevel = class_1890.method_8225(enchantmentRegistry.method_40264(class_1893.field_9126).get(), stack);
					if (flameLevel > 0) {
						arrow.method_5639(100);}
					// Spawn the arrow entity
					world.method_8649(arrow);
					world.method_43128(null, player.method_31477(), player.method_31478(), player.method_31479(),
							class_3417.field_14600, class_3419.field_15248, 1.0F, 1.0F);}}}

		@Override
		public int method_7881(class_1799 stack, class_1309 user) {
			return 54000;}

		@Override
		public class_1839 method_7853(class_1799 stack) {
			return class_1839.field_8953;}

		@Override
		public Predicate<class_1799> method_19268() {
			// Return a predicate that always returns true since we don't need arrows
			return (stack) -> true;}};

	// ZHONG LI:
	public static final class_1792 VORTEX_VANQUISHER = new VortexVanquisherItem(
			VORTEX_VANQUISHER_MATERIAL,
			new class_1792.class_1793()
					.method_57348(
							class_1829.method_57394(
									VORTEX_VANQUISHER_MATERIAL, 3, -2.6f))
					.method_57349(class_9334.field_49630, new class_9300(true)));

	// RAIDEN:
	public static final class_1792 ENGULFING_LIGHTNING = new EngulfingLightningItem(
			LightningToolMaterials.ENGULFING_LIGHTNING_MATERIAL,
			new class_1792.class_1793()
					.method_57348(
							class_1829.method_57394(
									LightningToolMaterials.ENGULFING_LIGHTNING_MATERIAL, 3, -2.9f))
					.method_57349(class_9334.field_49630, new class_9300(true)));

	// MAVUIKA:
	public static final class_1792 THOUSAND_BLAZING_SUNS = new ThousandBlazingSunsItem(
			THOUSAND_BLAZING_SUNS_MATERIAL,
			new class_1792.class_1793()
					.method_57348(
							class_1829.method_57394(
									THOUSAND_BLAZING_SUNS_MATERIAL, 3, -2.6f))
					.method_57349(class_9334.field_49630, new class_9300(true)));

	// FURINA:
	public static final class_1792 SPLENDOR_OF_TRANQUIL_WATERS = new SplendorOfTranquilWatersItem(
			SPLENDOR_OF_TRANQUIL_WATERS_MATERIAL,
			new class_1792.class_1793()
					.method_57348(
							class_1829.method_57394(
									SPLENDOR_OF_TRANQUIL_WATERS_MATERIAL, 3, -2.6f))
					.method_57349(class_9334.field_49630, new class_9300(true)));

	// TSARITSA:
	public static final class_1792 TSARITSAS_SCEPTER = new TsaritsasScepterItem(
			TSARITSAS_SCEPTER_MATERIAL,
			new class_1792.class_1793()
					.method_57348(
							class_1829.method_57394(
									TSARITSAS_SCEPTER_MATERIAL, 3, -2.6f))
					.method_57349(class_9334.field_49630, new class_9300(true)));

	// NAHIDA:
	public static final class_1792 THOUSAND_FLOATING_DREAMS = new ThousandFloatingDreamsItem(
			THOUSAND_FLOATING_DREAMS_MATERIAL,
			new class_1792.class_1793()
					.method_57348(
							class_1829.method_57394(
									THOUSAND_FLOATING_DREAMS_MATERIAL, 3, -2.2f))
					.method_57349(class_9334.field_49630, new class_9300(true)));

	// COLUMBINA:
	public static final class_1792 NOCTURNES_CURTAIN_CALL = new NocturnesCurtainCallItem(
			NOCTURNES_CURTAIN_CALL_MATERIAL,
			new class_1792.class_1793()
					.method_57348(
							class_1829.method_57394(
									NOCTURNES_CURTAIN_CALL_MATERIAL, 3, -2.2f))
					.method_57349(class_9334.field_49630, new class_9300(true)));

	/*==========================
	COMPLEX BLOCK DECLARATIONS:
	==========================*/

	// MOON FIRE:
	public static final class_2248 MOON_TORCH = new MoonTorchBlock(
			class_4970.class_2251.method_9637()
					.method_9634()
					.method_9618()
					.method_9631(state -> 10)
					.method_9626(net.minecraft.class_2498.field_11547)
					.method_50012(class_3619.field_15971));
	public static final class_2248 MOON_WALL_TORCH = new MoonWallTorchBlock(
			class_4970.class_2251.method_9637()
					.method_9634()
					.method_9618()
					.method_9631(state -> 10)
					.method_9626(net.minecraft.class_2498.field_11547)
					.method_50012(class_3619.field_15971));
	public static class_1792 MOON_TORCH_ITEM;
	public static final class_2248 MOON_LANTERN = new class_3749(
			class_4970.class_2251.method_9637()
					.method_29292()
					.method_9631(state -> 10)
					.method_9632(3.5f)
					.method_22488()
					.method_50012(class_3619.field_15971)
					.method_26243((state, world, pos) -> false)
					.method_26245((state, world, pos) -> false));
	public static class_1792 MOON_LANTERN_ITEM;
	public static final class_2248 MOON_CAMPFIRE = class_2378.method_10230(
			class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_campfire"),
			new MoonCampfireBlock(class_4970.class_2251.method_9630(class_2246.field_17350)));
	public static final class_1792 MOON_CAMPFIRE_ITEM = new class_1747(MOON_CAMPFIRE, new class_1792.class_1793());
	public static final class_2248 MOON_FIRE = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655(MOD_ID, "moon_fire"),
			new MoonFireBlock(class_4970.class_2251.method_9637()
					.method_31710(class_3620.field_15998)
					.method_51371()
					.method_9634()
					.method_9618()
					.method_9631(state -> 12) // Slightly eerie, dimmer light
					.method_9626(class_2498.field_11543)
					.method_50012(class_3619.field_15971)));

	// PLANTS:
	public static final class_2248 MOON_FLOWER = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655(MOD_ID, "moon_flower"),
			new MoonFlowerBlock(
					class_1294.field_5902, 7,
					class_4970.class_2251.method_9637()
							.method_9634().method_9618()
							.method_9626(class_2498.field_11535).method_22488()
							.method_50012(class_3619.field_15971)));
	public static final class_1792 MOON_FLOWER_ITEM = new class_1747(MOON_FLOWER, new class_1792.class_1793());
	public static final class_2248 POTTED_MOON_FLOWER = new class_2362(
			MOON_FLOWER, class_4970.class_2251.method_9630(class_2246.field_10354)
					.method_22488().method_50012(class_3619.field_15971));
	public static final class_2248 GLOOMY_FLOWER = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655(MOD_ID, "gloomy_flower"),
			new MoonFlowerBlock(
					class_1294.field_38092, 8,
					class_4970.class_2251.method_9637()
							.method_9634().method_9618()
							.method_9626(class_2498.field_11535).method_22488()
							.method_50012(class_3619.field_15971)));
	public static final class_1792 GLOOMY_FLOWER_ITEM = new class_1747(GLOOMY_FLOWER, new class_1792.class_1793());
	public static final class_2248 POTTED_GLOOMY_FLOWER = new class_2362(
			GLOOMY_FLOWER, class_4970.class_2251.method_9630(class_2246.field_10354)
			.method_22488().method_50012(class_3619.field_15971));
	public static final class_2248 DRY_FLOWER = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655(MOD_ID, "dry_flower"),
			new MoonFlowerBlock(
					class_1294.field_5920, 6,
					class_4970.class_2251.method_9637()
							.method_9634().method_9618()
							.method_9626(class_2498.field_11535).method_22488()
							.method_50012(class_3619.field_15971)));
	public static final class_1792 DRY_FLOWER_ITEM = new class_1747(DRY_FLOWER, new class_1792.class_1793());
	public static final class_2248 POTTED_DRY_FLOWER = new class_2362(
			DRY_FLOWER, class_4970.class_2251.method_9630(class_2246.field_10354)
			.method_22488().method_50012(class_3619.field_15971));
	public static final class_2248 END_GRASS = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655(MOD_ID, "end_grass"),
			new EndGrass(class_4970.class_2251.method_9637()
							.method_9634().method_9618()
							.method_9626(class_2498.field_11535).method_22488()
							.method_50012(class_3619.field_15971)));
	public static final class_1792 END_GRASS_ITEM = new class_1747(END_GRASS, new class_1792.class_1793());
	public static final class_2248 TALL_END_GRASS = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655(MOD_ID, "tall_end_grass"),
			new TallEndGrass(class_4970.class_2251.method_9637()
							.method_9634().method_9618()
							.method_9626(class_2498.field_11535).method_22488()
							.method_50012(class_3619.field_15971)));
	public static final class_1792 TALL_END_GRASS_ITEM = new class_1747(TALL_END_GRASS, new class_1792.class_1793());

	public static final class_2591<MoonCampfireBlockEntity> MOON_CAMPFIRE_ENTITY =
			class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(GileMod.MOD_ID, "moon_campfire"),
					FabricBlockEntityTypeBuilder.create(MoonCampfireBlockEntity::new, MOON_CAMPFIRE).build());

	// MISCELLANEOUS:
	public static final class_2248 PEARLESCENT_CHAIN = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655(MOD_ID, "pearlescent_chain"),
			new class_5172(class_4970.class_2251.method_9637()
					.method_29292().method_9632(5.0f)
					.method_9626(class_2498.field_24119).method_22488()));
	public static final class_1792 PEARLESCENT_CHAIN_ITEM = class_2378.method_10230(
			class_7923.field_41178,
			class_2960.method_60655(MOD_ID, "pearlescent_chain"),
			new class_1747(GileMod.PEARLESCENT_CHAIN, new class_1792.class_1793()));
	public static final class_2248 END_GRASS_BLOCK = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655("gilemod", "end_grass_block"),
			new EndGrassBlock(class_4970.class_2251.method_9630(class_2246.field_10471).method_9640().method_31710(class_3620.field_16014)));
	public static final class_1792 END_GRASS_BLOCK_ITEM = new class_1747(END_GRASS_BLOCK, new class_1792.class_1793());
	public static final class_2248 END_CLOUD = new class_2248(
			class_4970.class_2251.method_9637()
					.method_9634()
					.method_9618().method_9626(class_2498.field_27884)
					.method_50012(class_3619.field_15971)
					.method_26243((state, world, pos) -> false)
					.method_26245((state, world, pos) -> false)) {
		@Override
		public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
			// Apply cobweb slowing effect
			entity.method_5844(state, new net.minecraft.class_243(0.8, 0.6, 0.8));}
		@Override
		public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
			return true;}
		@Override
		public boolean method_9522(class_2680 state, class_2680 stateFrom, class_2350 direction) {
			if (stateFrom.method_27852(this)) {
				return true;}
			return super.method_9522(state, stateFrom, direction);}};
	public static final class_1792 END_CLOUD_ITEM = new class_1747(END_CLOUD, new class_1792.class_1793());
	public static final class_2248 STAR = new class_2248(
			class_4970.class_2251.method_9637()
					.method_9629(0.5f, 0.5f)
					.method_9631(state -> 15).method_22488()
					.method_9626(class_2498.field_27197)) {
		@Override
		public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
			return class_2248.method_9541(4, 4, 4, 12, 12, 12);}
		@Override
		public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
			return class_2248.method_9541(4, 4, 4, 12, 12, 12);}};
	public static final class_1792 STAR_ITEM = new class_1747(STAR, new class_1792.class_1793());

	/*==============================
	FEATURES DECLARATIONS:
	==============================*/

	// GHOSTLY THICKETS:
	public static final class_5321<class_1959> GHOSTLY_THICKETS = class_5321.method_29179(
			class_7924.field_41236, class_2960.method_60655("gilemod", "ghostly_thickets"));

	public static final class_3031<class_3175> GHOSTLY_SURFACE_FEATURE = class_2378.method_10230(
			class_7923.field_41144,
			class_2960.method_60655("gilemod", "ghostly_surface"),
			new EndSurfaceFeature(class_3175.field_24909));
	public static final class_5321<class_6796> GHOSTLY_SURFACE_PLACED_KEY = class_5321.method_29179(
			class_7924.field_41245, class_2960.method_60655("gilemod", "ghostly_thickets_surface"));
	public static final class_5321<class_2975<?, ?>> GHOSTLY_TREE_CONFIGURED = class_5321.method_29179(
			class_7924.field_41239, class_2960.method_60655("gilemod", "ghostly_tree"));
	public static final class_5321<class_2975<?, ?>> GHOSTLY_THICKETS_CONFIGURED = class_5321.method_29179(
			class_7924.field_41239, class_2960.method_60655("gilemod", "ghostly_thickets_surface_conf"));

	public static final class_5321<class_6796> GHOSTLY_TREE_PLACED_KEY = class_5321.method_29179(
			class_7924.field_41245,
			class_2960.method_60655("gilemod", "ghostly_tree"));
	public static final class_8813 GHOSTLY_SAPLING_GENERATOR = new class_8813(
			"ghostly_tree", // An ID for the generator
			Optional.empty(), // Rare variant (none)
			Optional.of(GHOSTLY_TREE_CONFIGURED), // The key we made for your alien tree
			Optional.empty());
	public static final class_2248 GHOSTLY_SAPLING = class_2378.method_10230(
			class_7923.field_41175,
			class_2960.method_60655("gilemod", "ghostly_sapling"),
			new GhostlySaplingBlock(GHOSTLY_SAPLING_GENERATOR, class_4970.class_2251.method_9630(class_2246.field_10394)));
	public static final class_1792 GHOSTLY_SAPLING_ITEM = new class_1747(GHOSTLY_SAPLING, new class_1792.class_1793());
	public static final class_2248 POTTED_GHOSTLY_SAPLING = new class_2362(
			GHOSTLY_SAPLING, class_4970.class_2251.method_9630(class_2246.field_10354)
			.method_22488().method_50012(class_3619.field_15971));

	public static final class_3031<class_3175> CLOUD_BLOB = class_2378.method_10230(
			class_7923.field_41144,
			class_2960.method_60655(MOD_ID, "cloud_blob"),
			new CloudBlobFeature(class_3175.field_24909));
	public static final class_3031<class_3175> STAR_FEATURE = class_2378.method_10230(
			class_7923.field_41144,
			class_2960.method_60655(MOD_ID, "star"),
			new StarFeature(class_3175.field_24909));

	// MOON DESERT:
	public static final class_5321<class_1959> MOON_DESERT = class_5321.method_29179(
			class_7924.field_41236,
			class_2960.method_60655("gilemod", "moon_desert"));

	public static final class_5321<class_6796> MOON_DESERT_SURFACE_PLACED_KEY = class_5321.method_29179(
			class_7924.field_41245,
			class_2960.method_60655("gilemod", "moon_desert_surface"));
	public static final class_5321<class_2975<?, ?>> MOON_DESERT_SURFACE_CONFIGURED = class_5321.method_29179(
			class_7924.field_41239,
			class_2960.method_60655("gilemod", "moon_desert_surface_conf"));
	public static final class_5321<class_6796> DRY_FLOWER_PLACED_KEY = class_5321.method_29179(
			class_7924.field_41245,
			class_2960.method_60655("gilemod", "dry_flower"));
	public static final class_5321<class_2975<?, ?>> DRY_FLOWER_CONFIGURED = class_5321.method_29179(
			class_7924.field_41239,
			class_2960.method_60655("gilemod", "dry_flower"));
	public static final class_3031<class_3175> MOON_DESERT_SURFACE_FEATURE = class_2378.method_10230(
			class_7923.field_41144,
			class_2960.method_60655("gilemod", "moon_desert_surface"),
			new MoonDesertSurfaceFeature(class_3175.field_24909));

	/*=================
	OTHER DECLARATIONS:
	==================*/

	// SOUNDS:
	public static final class_3414 LUMINOUS_AMBIENT = class_2378.method_10230(
			class_7923.field_41172,
			class_2960.method_60655("gilemod", "entity.luminous.ambient"),
			class_3414.method_47908(class_2960.method_60655("gilemod", "entity.luminous.ambient")));
	public static final class_3414 LUMINOUS_HURT = class_2378.method_10230(
			class_7923.field_41172,
			class_2960.method_60655("gilemod", "entity.luminous.hurt"),
			class_3414.method_47908(class_2960.method_60655("gilemod", "entity.luminous.hurt")));
	public static final class_3414 WEASEL_THIEF_AMBIENT = class_2378.method_10230(
			class_7923.field_41172,
			class_2960.method_60655("gilemod", "entity.weasel_thief.ambient"),
			class_3414.method_47908(class_2960.method_60655("gilemod", "entity.weasel_thief.ambient")));
	public static final class_3414 HOVERING_GHOST_NYAN_AMBIENT = class_2378.method_10230(
			class_7923.field_41172,
			class_2960.method_60655("gilemod", "entity.hovering_ghost.nyan_ambient"),
			class_3414.method_47908(class_2960.method_60655("gilemod", "entity.hovering_ghost.nyan_ambient")));

	// EFFECTS:
	public static final class_6880<class_1291> SHRINK_EFFECT = class_2378.method_47985(
			class_7923.field_41174, class_2960.method_60655(MOD_ID, "shrink"), new ShrinkStatusEffect());
	public static final class_6880<class_1291> ENLARGE_EFFECT = class_2378.method_47985(
			class_7923.field_41174, class_2960.method_60655(MOD_ID, "enlarge"), new EnlargeStatusEffect());

	// KEYBINDS:
	public static final Map<UUID, Long> STOMP_COOLDOWNS = new HashMap<>();

//======================================================================================================================

	@Override
	public void onInitialize() {

		ModWoodTypes.init();
		class_174.method_767(NamedEntityCriterion.ID.toString(), NamedEntityCriterion.CRITERION);
		class_174.method_767(UsedScepterCriterion.ID.toString(), UsedScepterCriterion.CRITERION);

		/*====================
		KEYBIND REGISTRATIONS:
		===================**/

		PayloadTypeRegistry.playC2S().register(ActiveAbilityPayload.ID, ActiveAbilityPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ActiveAbilityPayload.ID, (payload, context) -> {
			context.server().execute(() -> {
				var player = context.player();
				var world = player.method_51469();
				// === ABILITY 1: SHRINK (INVISIBILITY TOGGLE) ===
				if (player.method_6059(GileMod.SHRINK_EFFECT)) {
					if (player.method_6059(class_1294.field_5905)) {player.method_6016(class_1294.field_5905);
					} else {
						player.method_6092(new class_1293(class_1294.field_5905, class_1293.field_42106, 0, false, false, true));}}
				// === ABILITY 2: ENLARGE (LUNAR STOMP) ===
				if (player.method_6059(GileMod.ENLARGE_EFFECT)) {
					long currentTime = System.currentTimeMillis();
					long cooldownEnd = STOMP_COOLDOWNS.getOrDefault(player.method_5667(), 0L);
					// Check if the 3-second (3000ms) cooldown is over
					if (currentTime >= cooldownEnd) {
						STOMP_COOLDOWNS.put(player.method_5667(), currentTime + 3000L);
						// Play a heavy slam sound (Iron Golem hurt sounds like heavy stone)
						world.method_8396(null, player.method_24515(), class_3417.field_14959, class_3419.field_15248, 1.0f, 0.5f);
						// Spawn a ring of smoke particles
						for (int i = 0; i < 360; i += 15) {
							double x = player.method_23317() + Math.cos(Math.toRadians(i)) * 4.0;
							double z = player.method_23321() + Math.sin(Math.toRadians(i)) * 4.0;
							world.method_14199(class_2398.field_11237, x, player.method_23318() + 0.1, z, 2, 0, 0, 0, 0.05);}
						// Get all living entities within 5 blocks
						class_238 area = player.method_5829().method_1009(5.0, 2.0, 5.0);
						List<class_1309> targets = world.method_8390(class_1309.class, area, e -> e != player && e.method_5805());
						for (class_1309 target : targets) {
							// Deal 4 damage (2 hearts)
							target.method_5643(world.method_48963().method_48802(player), 4.0f);
							// Apply Slowness II for 5 seconds (100 ticks)
							target.method_6092(new class_1293(class_1294.field_5909, 100, 1));
							// Violent Knockback away from the player
							double dx = target.method_23317() - player.method_23317();
							double dz = target.method_23321() - player.method_23321();
							target.method_6005(1.5, -dx, -dz);}
					} else {
						// Let the player know it's on cooldown
						player.method_7353(class_2561.method_43471("message.gilemod.stomp_cooldown").method_27692(class_124.field_1061), true);}}});});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (var player : server.method_3760().method_14571()) {
				// If the player DOES NOT have the shrink effect...
				if (!player.method_6059(GileMod.SHRINK_EFFECT)) {
					class_1293 invis = player.method_6112(class_1294.field_5905);
					// ...and they have an INFINITE invisibility effect (which means we gave it to them)
					if (invis != null && invis.method_48559()) {
						// Strip the invisibility
						player.method_6016(class_1294.field_5905);}}}});

		/*====================
		ENTITY REGISTRATIONS:
		====================*/

		// ARROWS:
		FATE_ARROW_TYPE = class_2378.method_10230(
				class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "fate_arrow"),
				class_1299.class_1300.<FateArrowEntity>method_5903(FateArrowEntity::new, class_1311.field_17715)
						.method_17687(0.5f, 0.5f).build());
		VENTI_ARROW_TYPE = class_2378.method_10230(
				class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "venti_arrow"),
				class_1299.class_1300.<VentiArrowEntity>method_5903(VentiArrowEntity::new, class_1311.field_17715)
						.method_17687(0.5f, 0.5f).method_27299(4).method_27300(20).build());

		// VOID SLIME:
		VOID_SLIME = class_2378.method_10230(class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "void_slime"),
				class_1299.class_1300.method_5903(VoidSlimeEntity::new, class_1311.field_6302)
						.method_17687(0.8f, 0.8f)
						.method_27299(8).method_27300(2).build());
		class_1317.method_20637(VOID_SLIME,
				class_9169.field_48745,
				class_2902.class_2903.field_13203,
				(type, world, reason, pos, random) -> {
					class_2680 below = world.method_8320(pos.method_10074());
					return below.method_27852(class_2246.field_10471) ||
							below.method_27852(END_GRASS_BLOCK);});
		VOID_SLIME_SPAWN_EGG = new class_1826(VOID_SLIME,
				0x4E218C, 0xBDAFCF, new class_1792.class_1793());
		FabricDefaultAttributeRegistry.register(VOID_SLIME, VoidSlimeEntity.createVoidSlimeAttributes());

		// MOTH:
		MOTH = class_2378.method_10230(class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "moth"),
				class_1299.class_1300.method_5903(MothEntity::new, class_1311.field_6294)
						.method_17687(0.8f, 0.5f)
						.method_27299(8).method_27300(2).build());
		class_1317.method_20637(MOTH,
				class_9169.field_48745,
				class_2902.class_2903.field_13203,
				(type, world, reason, pos, random) -> {
					class_2680 below = world.method_8320(pos.method_10074());
					return below.method_27852(class_2246.field_10471) ||
							below.method_27852(GileMod.MOON_SAND) ||
							below.method_27852(class_2246.field_10219) ||
							below.method_27852(class_2246.field_10402);});
		MOTH_SPAWN_EGG = new class_1826(MOTH,
				0x8B7355, 0xC4B090, new class_1792.class_1793());
		FabricDefaultAttributeRegistry.register(MOTH, MothEntity.createMothAttributes());

		// LUMINOUS:
		LUMINOUS = class_2378.method_10230(class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "luminous"),
				class_1299.class_1300.method_5903(LuminousEntity::new, class_1311.field_6303)
						.method_17687(0.85f, 0.85f)
						.method_27299(8).method_27300(2).build());
		class_1317.method_20637(LUMINOUS,
				class_9169.field_48745,
				class_2902.class_2903.field_13203,
				(type, world, reason, pos, random) -> {
					class_2680 below = world.method_8320(pos.method_10074());
					return	below.method_27852(END_GRASS_BLOCK);});
		LUMINOUS_SPAWN_EGG = new class_1826(LUMINOUS,
				0xFFFA85, 0xFF97F7, new class_1792.class_1793());
		FabricDefaultAttributeRegistry.register(LUMINOUS, LuminousEntity.createLuminousAttributes());

		// HOVERING GHOST:
		HOVERING_GHOST = class_2378.method_10230(class_7923.field_41177,
				class_2960.method_60655("gilemod", "hovering_ghost"),
				class_1299.class_1300.method_5903(HoveringGhostEntity::new, class_1311.field_6303)
						.method_17687(1.5F, 0.75F).build());
		class_1317.method_20637(HOVERING_GHOST,
				class_9169.field_48745,
				class_2902.class_2903.field_13203,
				(type, world, reason, pos, random) -> {
					class_2680 below = world.method_8320(pos.method_10074());
					return	below.method_27852(END_GRASS_BLOCK);});
		HOVERING_GHOST_SPAWN_EGG = new class_1826(HOVERING_GHOST,
				0xA899B3, 0x7E738C, new class_1792.class_1793());
		FabricDefaultAttributeRegistry.register(HOVERING_GHOST, HoveringGhostEntity.createHoveringGhostAttributes());

		// JERBOA:
		JERBOA = class_2378.method_10230(class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "jerboa"),
				class_1299.class_1300.method_5903(JerboaEntity::new, class_1311.field_6294)
						.method_17687(0.4f, 0.4f)
						.method_27299(8).method_27300(2).build());
		class_1317.method_20637(
				GileMod.JERBOA,
				class_9169.field_48745,
				class_2902.class_2903.field_13203,
				(type, world, reason, pos, random) -> {
					class_2680 below = world.method_8320(pos.method_10074());
					return below.method_27852(GileMod.MOON_SAND) || below.method_27852(class_2246.field_10102) || below.method_27852(class_2246.field_10534);});
		JERBOA_SPAWN_EGG = new class_1826(JERBOA,
				0xFDDC66, 0xFDEF99, new class_1792.class_1793());
		FabricDefaultAttributeRegistry.register(JERBOA, JerboaEntity.createJerboaAttributes());

		// GLOOMY LYNX:
		GLOOMY_LYNX = class_2378.method_10230(
				class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "gloomy_lynx"),
				class_1299.class_1300.method_5903(GloomyLynxEntity::new, class_1311.field_6294)
						.method_17687(0.8f, 1.2f)
						.method_27299(8).method_27300(2).build());
		class_1317.method_20637(GLOOMY_LYNX,
				class_9169.field_48745,
				class_2902.class_2903.field_13203,
				(type, world, reason, pos, random) -> {
					class_2680 below = world.method_8320(pos.method_10074());
					return	below.method_27852(END_GRASS_BLOCK);});
		GLOOMY_LYNX_SPAWN_EGG = new class_1826(GLOOMY_LYNX,
				0x3A5F79, 0x2CCDB1, new class_1792.class_1793());
		FabricDefaultAttributeRegistry.register(GLOOMY_LYNX, GloomyLynxEntity.createLynxAttributes());

		// WEASEL THIEF:
		WEASEL_THIEF = class_2378.method_10230(
				class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "weasel_thief"),
				class_1299.class_1300.method_5903(WeaselThiefEntity::new, class_1311.field_6294)
						.method_17687(0.6f, 0.5f).build());
		class_1317.method_20637(WEASEL_THIEF,
				class_9169.field_48745,
				class_2902.class_2903.field_13203,
				(type, world, reason, pos, random) -> {
					class_2680 below = world.method_8320(pos.method_10074());
					return	below.method_27852(class_2246.field_10219) ||
							below.method_27852(class_2246.field_10253) ||
							below.method_27852(class_2246.field_10402) ||
							below.method_27852(class_2246.field_28681) ||
							below.method_27852(class_2246.field_10102) ||
							below.method_27852(class_2246.field_10255) ||
							below.method_27852(class_2246.field_10340) ||
							below.method_27852(class_2246.field_28888) ||
							below.method_27852(class_2246.field_10415)||
							below.method_27852(class_2246.field_10477);});
		WEASEL_THIEF_SPAWN_EGG = new class_1826(WEASEL_THIEF,
				0x6C635A, 0x6C4B3F, new class_1792.class_1793());
		FabricDefaultAttributeRegistry.register(WEASEL_THIEF, WeaselThiefEntity.createWeaselAttributes());

		/*=================
		ITEM REGISTRATIONS:
		==================*/

		// SIGILS:
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "primogem"), PRIMOGEM);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "anemo_sigil"), ANEMO_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "geo_sigil"), GEO_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "electro_sigil"), ELECTRO_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "dendro_sigil"), DENDRO_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "hydro_sigil"), HYDRO_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "pyro_sigil"), PYRO_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "cryo_sigil"), CRYO_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "luna_sigil"), LUNA_SIGIL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "mora"), MORA);

		// MATERIALS:
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "wish_ingot"), WISH_INGOT);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "wish_nugget"), WISH_NUGGET);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "crystal"), CRYSTAL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moth_wing"), MOTH_WING);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "void_slimeball"), VOID_SLIMEBALL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "jelly"), JELLY);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "jam"), JAM);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "phasma"), PHASMA);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "cooked_phasma"), COOKED_PHASMA);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "star_fragment"), STAR_FRAGMENT);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "chrono_gear"), CHRONO_GEAR);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "jerboas_tail"), JERBOAS_TAIL);

		//SPAWN EGGS:
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "void_slime_spawn_egg"), VOID_SLIME_SPAWN_EGG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moth_spawn_egg"), MOTH_SPAWN_EGG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "luminous_spawn_egg"), LUMINOUS_SPAWN_EGG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "hovering_ghost_spawn_egg"), HOVERING_GHOST_SPAWN_EGG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "jerboa_spawn_egg"), JERBOA_SPAWN_EGG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "gloomy_lynx_spawn_egg"), GLOOMY_LYNX_SPAWN_EGG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "weasel_thief_spawn_egg"), WEASEL_THIEF_SPAWN_EGG);

		// FOOD & TOOLS:
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "offering"), OFFERING);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "fate_upgrade_smithing_template"), FATE_UPGRADE_SMITHING_TEMPLATE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "fate_sword"), FATE_SWORD);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "fate_bow"), FATE_BOW);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "fate_arrow"), FATE_ARROW);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "heart_of_healing"), HEART_OF_HEALING);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "shadow_clock"), SHADOW_CLOCK);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "grappling_hook"), GRAPPLING_HOOK);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "shrinker"), SHRINKER);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "enlarger"), ENLARGER);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "daybreak_chronicles"), DAYBREAK_CHRONICLES);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "vortex_vanquisher"), VORTEX_VANQUISHER);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "engulfing_lightning"), ENGULFING_LIGHTNING);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "thousand_blazing_suns"), THOUSAND_BLAZING_SUNS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "splendor_of_tranquil_waters"), SPLENDOR_OF_TRANQUIL_WATERS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "tsaritsas_scepter"), TSARITSAS_SCEPTER);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "thousand_floating_dreams"), THOUSAND_FLOATING_DREAMS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "nocturnes_curtain_call"), NOCTURNES_CURTAIN_CALL);

		/*==================
		BLOCK REGISTRATIONS:
		===================*/

		// PRIMOGEM/PEARLESCENT:
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "primogem_ore"), PRIMOGEM_ORE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "primogem_ore"), PRIMOGEM_ORE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "deepslate_primogem_ore"), DEEPSLATE_PRIMOGEM_ORE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "deepslate_primogem_ore"), DEEPSLATE_PRIMOGEM_ORE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "end_primogem_ore"), END_PRIMOGEM_ORE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "end_primogem_ore"), END_PRIMOGEM_ORE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "wish"), WISH);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "wish"), WISH_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "pearlescent_block"), PEARLESCENT_BLOCK);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "pearlescent_block"), PEARLESCENT_BLOCK_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "pearlescent_bricks"), PEARLESCENT_BRICKS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "pearlescent_bricks"), PEARLESCENT_BRICKS_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "pearlescent_stairs"), PEARLESCENT_STAIRS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "pearlescent_stairs"), PEARLESCENT_STAIRS_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "pearlescent_slab"), PEARLESCENT_SLAB);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "pearlescent_slab"), PEARLESCENT_SLAB_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "pearlescent_wall"), PEARLESCENT_WALL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "pearlescent_wall"), PEARLESCENT_WALL_ITEM);

		// MOON SAND(STONE):
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_sand"), MOON_SAND);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_sand"), MOON_SAND_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_sandstone"), MOON_SANDSTONE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_sandstone"), MOON_SANDSTONE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_sandstone_stairs"), MOON_SANDSTONE_STAIRS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_sandstone_stairs"), MOON_SANDSTONE_STAIRS_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_sandstone_slab"), MOON_SANDSTONE_SLAB);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_sandstone_slab"), MOON_SANDSTONE_SLAB_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_sandstone_wall"), MOON_SANDSTONE_WALL);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_sandstone_wall"), MOON_SANDSTONE_WALL_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_chiseled_sandstone"), MOON_CHISELED_SANDSTONE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_chiseled_sandstone"), MOON_CHISELED_SANDSTONE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_smooth_sandstone"), MOON_SMOOTH_SANDSTONE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_smooth_sandstone"), MOON_SMOOTH_SANDSTONE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_smooth_sandstone_stairs"), MOON_SMOOTH_SANDSTONE_STAIRS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_smooth_sandstone_stairs"), MOON_SMOOTH_SANDSTONE_STAIRS_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_smooth_sandstone_slab"), MOON_SMOOTH_SANDSTONE_SLAB);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_smooth_sandstone_slab"), MOON_SMOOTH_SANDSTONE_SLAB_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_cut_sandstone"), MOON_CUT_SANDSTONE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_cut_sandstone"), MOON_CUT_SANDSTONE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_cut_sandstone_slab"), MOON_CUT_SANDSTONE_SLAB);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_cut_sandstone_slab"), MOON_CUT_SANDSTONE_SLAB_ITEM);

		// FIRE & OTHER:
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_torch"), MOON_TORCH);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_wall_torch"), MOON_WALL_TORCH);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "moon_lantern"), MOON_LANTERN);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_campfire"), MOON_CAMPFIRE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "end_cloud"), END_CLOUD);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "end_cloud"), END_CLOUD_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "star"), STAR);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "star"), STAR_ITEM);

		// PLANTS:
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "moon_flower"), MOON_FLOWER_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "potted_moon_flower"), POTTED_MOON_FLOWER);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "gloomy_flower"), GLOOMY_FLOWER_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "potted_gloomy_flower"), POTTED_GLOOMY_FLOWER);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "dry_flower"), DRY_FLOWER_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "potted_dry_flower"), POTTED_DRY_FLOWER);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "end_grass_block"), END_GRASS_BLOCK_ITEM);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "end_grass"), END_GRASS_ITEM);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "tall_end_grass"), TALL_END_GRASS_ITEM);

		// GHOSTLY WOOD TYPE:
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_leaves"), GHOSTLY_LEAVES_ITEM);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_sapling"), GHOSTLY_SAPLING_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "potted_ghostly_sapling"), POTTED_GHOSTLY_SAPLING);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_log"), GHOSTLY_LOG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_log"), GHOSTLY_LOG_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "stripped_ghostly_log"), STRIPPED_GHOSTLY_LOG);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "stripped_ghostly_log"), STRIPPED_GHOSTLY_LOG_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_wood"), GHOSTLY_WOOD);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_wood"), GHOSTLY_WOOD_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "stripped_ghostly_wood"), STRIPPED_GHOSTLY_WOOD);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "stripped_ghostly_wood"), STRIPPED_GHOSTLY_WOOD_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_planks"), GHOSTLY_PLANKS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_planks"), GHOSTLY_PLANKS_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_stairs"), GHOSTLY_STAIRS);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_stairs"), GHOSTLY_STAIRS_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_slab"), GHOSTLY_SLAB);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_slab"), GHOSTLY_SLAB_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_fence"), GHOSTLY_FENCE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_fence"), GHOSTLY_FENCE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_fence_gate"), GHOSTLY_FENCE_GATE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_fence_gate"), GHOSTLY_FENCE_GATE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_door"), GHOSTLY_DOOR);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_door"), GHOSTLY_DOOR_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_trapdoor"), GHOSTLY_TRAPDOOR);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_trapdoor"), GHOSTLY_TRAPDOOR_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_pressure_plate"), GHOSTLY_PRESSURE_PLATE);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_pressure_plate"), GHOSTLY_PRESSURE_PLATE_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_button"), GHOSTLY_BUTTON);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_button"), GHOSTLY_BUTTON_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_sign"), GHOSTLY_SIGN);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_wall_sign"), GHOSTLY_WALL_SIGN);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_sign"), GHOSTLY_SIGN_ITEM);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_hanging_sign"), GHOSTLY_HANGING_SIGN);
		class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(MOD_ID, "ghostly_wall_hanging_sign"), GHOSTLY_WALL_HANGING_SIGN);
		class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "ghostly_hanging_sign"), GHOSTLY_HANGING_SIGN_ITEM);

		/*=====================
		COMPLEX REGISTRATIONS:
		=====================*/

		// BLOCK-ENTITIES:
		GHOSTLY_SIGN_BLOCK_ENTITY = class_2378.method_10230(
				class_7923.field_41181,
				class_2960.method_60655(MOD_ID, "ghostly_sign_entity"),
				FabricBlockEntityTypeBuilder.create(GhostlySignBlockEntity::new, GHOSTLY_SIGN, GHOSTLY_WALL_SIGN).build());
		GHOSTLY_HANGING_SIGN_BLOCK_ENTITY = class_2378.method_10230(
				class_7923.field_41181,
				class_2960.method_60655(MOD_ID, "ghostly_hanging_sign_entity"),
				FabricBlockEntityTypeBuilder.create(GhostlyHangingSignBlockEntity::new, GHOSTLY_HANGING_SIGN, GHOSTLY_WALL_HANGING_SIGN).build());

		// PLACEMENT LOGIC:
		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
			class_2338 clickedPos = hitResult.method_17777();
			class_2350 face = hitResult.method_17780();
			class_2338 firePos = clickedPos.method_10093(face);
			class_1799 stack = player.method_5998(hand);
			if (stack.method_31574(class_1802.field_8884) || stack.method_31574(class_1802.field_8814)) {
				class_2680 clickedState = world.method_8320(clickedPos);
				// If they click moon sand, and the space above is empty
				if (clickedState.method_27852(GileMod.MOON_SAND) && world.method_8320(firePos).method_26215()) {
					world.method_8396(player, firePos, class_3417.field_15145, class_3419.field_15245, 1.0F, world.method_8409().method_43057() * 0.4F + 0.8F);
					// Only place the block and damage the item on the server
					if (!world.method_8608()) {
						world.method_8652(firePos, MOON_FIRE.method_9564(), 11);
						if (!player.method_7337()) {
							if (stack.method_31574(class_1802.field_8884)) {
								stack.method_7970(1, player, class_1304.field_6173);
							} else {
								stack.method_7934(1);
							}}}return class_1269.method_29236(world.method_8608());}}return class_1269.field_5811;});

		MOON_TORCH_ITEM = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655(MOD_ID, "moon_torch"),
				new class_1827(
						MOON_TORCH, MOON_WALL_TORCH,
						new class_1792.class_1793(), class_2350.field_11033));
		MOON_LANTERN_ITEM = class_2378.method_10230(class_7923.field_41178,
				class_2960.method_60655(MOD_ID, "moon_lantern"),
				new class_1747(MOON_LANTERN, new class_1792.class_1793()));

		// NAMING LOGIC:
		UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			if (!world.field_9236 && player instanceof class_3222 serverPlayer) {
				class_1799 stack = player.method_5998(hand);
				// Check if the player is holding a Name Tag that has a custom name
				if (stack.method_31574(class_1802.field_8448) && stack.method_57826(net.minecraft.class_9334.field_49631)) {
					String appliedName = stack.method_7964().getString();
					// Trigger your custom advancement criterion
					com.gile.advancement.NamedEntityCriterion.CRITERION.trigger(serverPlayer, entity, appliedName);
				}}return class_1269.field_5811;});

		// STRIPPABLE:
		StrippableBlockRegistry.register(GHOSTLY_LOG, STRIPPED_GHOSTLY_LOG);
		StrippableBlockRegistry.register(GHOSTLY_WOOD, STRIPPED_GHOSTLY_WOOD);

		// COMPOSTER:
		class_3962.field_17566.put(GHOSTLY_LEAVES_ITEM, 0.3f);
		class_3962.field_17566.put(GHOSTLY_SAPLING_ITEM, 0.3f);
		class_3962.field_17566.put(TALL_END_GRASS_ITEM, 0.3f);
		class_3962.field_17566.put(END_GRASS_ITEM, 0.3f);
		class_3962.field_17566.put(DRY_FLOWER_ITEM, 0.3f);
		class_3962.field_17566.put(MOON_FLOWER_ITEM, 0.65f);
		class_3962.field_17566.put(GLOOMY_FLOWER_ITEM, 0.65f);
		class_3962.field_17566.put(JELLY, 0.65f);

		// FUEL:
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_LOG, 300);
		FuelRegistry.INSTANCE.add(GileMod.STRIPPED_GHOSTLY_LOG, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_WOOD, 300);
		FuelRegistry.INSTANCE.add(GileMod.STRIPPED_GHOSTLY_WOOD, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_PLANKS, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_STAIRS, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_SLAB, 150);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_FENCE, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_FENCE_GATE, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_DOOR, 200);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_PRESSURE_PLATE, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_BUTTON, 100);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_TRAPDOOR, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_SAPLING, 100);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_SIGN, 200);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_HANGING_SIGN, 800);
		FuelRegistry.INSTANCE.add(GileMod.STAR, 3200);

		/*===========================
		CREATIVE TABS REGISTRATIONS:
		===========================*/

		class_2378.method_10230(class_7923.field_44687,
				class_2960.method_60655(MOD_ID, "gile"),
				FabricItemGroup.builder()
						.method_47320(() -> new class_1799(PRIMOGEM))
						.method_47321(class_2561.method_43471("itemGroup.gilemod.gile"))
						.method_47317((displayContext, entries) -> {

							entries.method_45421(MORA); entries.method_45421(ANEMO_SIGIL); entries.method_45421(GEO_SIGIL);
							entries.method_45421(ELECTRO_SIGIL); entries.method_45421(DENDRO_SIGIL); entries.method_45421(HYDRO_SIGIL);
							entries.method_45421(PYRO_SIGIL); entries.method_45421(CRYO_SIGIL); entries.method_45421(LUNA_SIGIL);
							entries.method_45421(PRIMOGEM);
							entries.method_45421(DAYBREAK_CHRONICLES); entries.method_45421(VORTEX_VANQUISHER);
							entries.method_45421(ENGULFING_LIGHTNING); entries.method_45421(THOUSAND_FLOATING_DREAMS);
							entries.method_45421(SPLENDOR_OF_TRANQUIL_WATERS); entries.method_45421(THOUSAND_BLAZING_SUNS);
							entries.method_45421(TSARITSAS_SCEPTER); entries.method_45421(NOCTURNES_CURTAIN_CALL);

							entries.method_45421(PRIMOGEM_ORE_ITEM); entries.method_45421(DEEPSLATE_PRIMOGEM_ORE_ITEM);
							entries.method_45421(END_PRIMOGEM_ORE_ITEM); entries.method_45421(END_GRASS_BLOCK_ITEM);
							entries.method_45421(MOON_SAND_ITEM); entries.method_45421(MOON_SANDSTONE);
							entries.method_45421(MOON_SANDSTONE_STAIRS); entries.method_45421(MOON_SANDSTONE_SLAB);
							entries.method_45421(MOON_SANDSTONE_WALL);

							entries.method_45421(MOON_CHISELED_SANDSTONE); entries.method_45421(MOON_SMOOTH_SANDSTONE);
							entries.method_45421(MOON_SMOOTH_SANDSTONE_STAIRS); entries.method_45421(MOON_SMOOTH_SANDSTONE_SLAB);
							entries.method_45421(MOON_CUT_SANDSTONE); entries.method_45421(MOON_CUT_SANDSTONE_SLAB);
							entries.method_45421(PEARLESCENT_BRICKS_ITEM); entries.method_45421(WISH);
							entries.method_45421(PEARLESCENT_BLOCK_ITEM);

							entries.method_45421(PEARLESCENT_STAIRS_ITEM);
							entries.method_45421(PEARLESCENT_SLAB_ITEM); entries.method_45421(PEARLESCENT_WALL_ITEM);
							entries.method_45421(END_CLOUD_ITEM); entries.method_45421(STAR_ITEM);
							entries.method_45421(MOON_TORCH_ITEM); entries.method_45421(MOON_LANTERN_ITEM);
							entries.method_45421(PEARLESCENT_CHAIN_ITEM); entries.method_45421(MOON_CAMPFIRE_ITEM);

							entries.method_45421(GHOSTLY_LOG_ITEM);
							entries.method_45421(GHOSTLY_WOOD_ITEM); entries.method_45421(STRIPPED_GHOSTLY_LOG_ITEM);
							entries.method_45421(STRIPPED_GHOSTLY_WOOD_ITEM); entries.method_45421(GHOSTLY_PLANKS_ITEM);
							entries.method_45421(GHOSTLY_STAIRS_ITEM); entries.method_45421(GHOSTLY_SLAB_ITEM);
							entries.method_45421(GHOSTLY_FENCE_ITEM); entries.method_45421(GHOSTLY_FENCE_GATE_ITEM);
							entries.method_45421(GHOSTLY_DOOR_ITEM);
							entries.method_45421(GHOSTLY_TRAPDOOR_ITEM); entries.method_45421(GHOSTLY_PRESSURE_PLATE_ITEM);
							entries.method_45421(GHOSTLY_BUTTON_ITEM); entries.method_45421(GHOSTLY_SIGN_ITEM);
							entries.method_45421(GHOSTLY_HANGING_SIGN_ITEM); entries.method_45421(GHOSTLY_LEAVES_ITEM);
							entries.method_45421(TALL_END_GRASS_ITEM); entries.method_45421(END_GRASS_ITEM);

							entries.method_45421(GHOSTLY_SAPLING_ITEM); entries.method_45421(DRY_FLOWER_ITEM);
							entries.method_45421(GLOOMY_FLOWER_ITEM); entries.method_45421(MOON_FLOWER_ITEM);
							entries.method_45421(STAR_FRAGMENT); entries.method_45421(CRYSTAL);
							entries.method_45421(WISH_INGOT); entries.method_45421(WISH_NUGGET);
							entries.method_45421(FATE_UPGRADE_SMITHING_TEMPLATE);

							entries.method_45421(OFFERING); entries.method_45421(JAM); entries.method_45421(JELLY);
							entries.method_45421(VOID_SLIMEBALL); entries.method_45421(MOTH_WING);
							entries.method_45421(JERBOAS_TAIL); entries.method_45421(PHASMA);
							entries.method_45421(COOKED_PHASMA); entries.method_45421(CHRONO_GEAR);

							entries.method_45421(JELLY_ON_A_STICK); entries.method_45421(GRAPPLING_HOOK);
							entries.method_45421(FATE_SWORD); entries.method_45421(FATE_BOW); entries.method_45421(FATE_ARROW);
							entries.method_45421(SHRINKER); entries.method_45421(ENLARGER);
							entries.method_45421(HEART_OF_HEALING); entries.method_45421(SHADOW_CLOCK);

							entries.method_45421(VOID_SLIME_SPAWN_EGG); entries.method_45421(MOTH_SPAWN_EGG);
							entries.method_45421(HOVERING_GHOST_SPAWN_EGG); entries.method_45421(LUMINOUS_SPAWN_EGG);
							entries.method_45421(JERBOA_SPAWN_EGG); entries.method_45421(GLOOMY_LYNX_SPAWN_EGG);
							entries.method_45421(WEASEL_THIEF_SPAWN_EGG);

						}).method_47324());

		/*===================
		BIOME MODIFICATIONS:
		====================*/

		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37393),
				class_2893.class_2895.field_13176,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "primogem_ore")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37394),
				class_2893.class_2895.field_13176,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "end_primogem_ore")));
		BiomeModifications.addFeature(
				context -> {
					if (!context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37394)) {
						return false;}
					return !context.getBiomeRegistryEntry().method_40225(class_1972.field_9411);},
				class_2893.class_2895.field_13178,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "moon_sand")));
		BiomeModifications.addFeature(
				context -> {
					if (!context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37394)) {
						return false;}
					// Exclude THE_END AND MOON_DESERT
					return !context.getBiomeRegistryEntry().method_40225(class_1972.field_9411)
							&& !context.getBiomeRegistryEntry().method_40225(MOON_DESERT);
				},
				class_2893.class_2895.field_13179,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "moon_flower")));

		/*============================
		ENTITY SPAWNING REGISTRATIONS:
		============================*/

		BiomeModifications.addSpawn(
				context -> {
					// Only in End biomes
					if (!context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37394)) {
						return false;}
					// Exclude the main End island
					return !context.getBiomeRegistryEntry().method_40225(class_1972.field_9411);},
				class_1311.field_6302, VOID_SLIME, // Weight, min/max group size
				15, 1, 3);
		BiomeModifications.addSpawn(
				context -> {
					if (!context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37394)) {
						return false;}
					return !context.getBiomeRegistryEntry().method_40225(class_1972.field_9411);},
				class_1311.field_6294,  MOTH,
				30,    1, 3);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().method_40225(class_1972.field_9475),
				class_1311.field_6294, MOTH,
				20, 1, 3);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().method_40225(class_1972.field_9462),
				class_1311.field_6294, MOTH,
				10, 1, 3);
		BiomeModifications.addSpawn(
				context -> {
					if (!context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37394)) {
						return false;}
					return !context.getBiomeRegistryEntry().method_40225(class_1972.field_9411);},
				class_1311.field_6303,  LUMINOUS,
				10,    1, 3);
		BiomeModifications.addSpawn(
				context -> {
					if (!context.getBiomeRegistryEntry().method_40220(net.minecraft.class_6908.field_37394)) {
						return false;}
					return !context.getBiomeRegistryEntry().method_40225(class_1972.field_9411);},
				class_1311.field_6303,  HOVERING_GHOST,
				5,    1, 2);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().method_40225(MOON_DESERT),
				class_1311.field_6303, JERBOA,
				5, 2, 3);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().method_40225(class_1972.field_9424),
				class_1311.field_6294, JERBOA,
				20, 2, 5);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().method_40225(GHOSTLY_THICKETS),
				class_1311.field_6294, GLOOMY_LYNX,
				10, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
				class_1311.field_6294, WEASEL_THIEF,
				5, 1, 1);

		/*=====================
		WORLDGEN REGISTRATIONS:
		======================*/

		TheEndBiomes.addHighlandsBiome(GHOSTLY_THICKETS, 0.3);
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40225(GHOSTLY_THICKETS),
				class_2893.class_2895.field_13179,
				GHOSTLY_SURFACE_PLACED_KEY);
		TheEndBiomes.addHighlandsBiome(MOON_DESERT, 1.5);
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40225(MOON_DESERT),
				class_2893.class_2895.field_13179,
				MOON_DESERT_SURFACE_PLACED_KEY);

		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40225(GHOSTLY_THICKETS),
				class_2893.class_2895.field_13179,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "end_cloud_blob")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40225(GHOSTLY_THICKETS),
				class_2893.class_2895.field_13179,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "star")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40225(GHOSTLY_THICKETS),
				class_2893.class_2895.field_13178,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "end_grass")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40225(GHOSTLY_THICKETS),
				class_2893.class_2895.field_13178,
				class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(MOD_ID, "tall_end_grass")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().method_40225(GHOSTLY_THICKETS),
				class_2893.class_2895.field_13178,
				GHOSTLY_TREE_PLACED_KEY);

	}
}