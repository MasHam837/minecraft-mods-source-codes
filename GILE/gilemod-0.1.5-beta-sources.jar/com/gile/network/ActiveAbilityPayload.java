package com.gile.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ActiveAbilityPayload() implements class_8710 {
    public static final class_8710.class_9154<ActiveAbilityPayload> ID = new class_8710.class_9154<>(class_2960.method_60655("gile", "active_ability"));
    public static final class_9139<class_9129, ActiveAbilityPayload> CODEC = class_9139.method_56431(new ActiveAbilityPayload());

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}