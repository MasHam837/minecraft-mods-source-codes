package com.gile.client.model;

import com.gile.entity.WeaselThiefEntity;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class WeaselThiefModel<T extends WeaselThiefEntity> extends class_5597<T> {
    private final class_630 root;
    private final class_630 head;
    private final class_630 legs;

    public WeaselThiefModel(class_630 root) {
        this.root = root;
        this.head = root.method_32086("head");
        this.legs = root.method_32086("legs");
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();

        // Head
        modelPartData.method_32117("head", class_5606.method_32108().method_32101(0, 0).method_32097(-2.0F, -2.0F, -3.0F, 4.0F, 4.0F, 5.0F), class_5603.method_32090(0.0F, 19.0F, -5.0F));

        // Body (Long)
        modelPartData.method_32117("body", class_5606.method_32108().method_32101(18, 0).method_32097(-2.5F, -2.5F, -5.0F, 5.0F, 4.0F, 10.0F), class_5603.method_32090(0.0F, 20.0F, 0.0F));

        // Big Coin Backpack / Sack
        modelPartData.method_32117("sack", class_5606.method_32108().method_32101(0, 14).method_32097(-3.5F, -6.0F, -3.0F, 7.0F, 6.0F, 8.0F), class_5603.method_32090(0.0F, 18.0F, 0.0F));

        // Tail
        modelPartData.method_32117("tail", class_5606.method_32108().method_32101(30, 14).method_32097(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 6.0F), class_5603.method_32090(0.0F, 19.5F, 5.0F));

        // 4 Legs grouped
        class_5610 legsData = modelPartData.method_32117("legs", class_5606.method_32108(), class_5603.method_32090(0.0F, 24.0F, 0.0F));
        legsData.method_32117("leg1", class_5606.method_32108().method_32101(0, 28).method_32097(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), class_5603.method_32090(-1.5F, 0.0F, -4.0F));
        legsData.method_32117("leg2", class_5606.method_32108().method_32101(0, 28).method_32097(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), class_5603.method_32090(1.5F, 0.0F, -4.0F));
        legsData.method_32117("leg3", class_5606.method_32108().method_32101(0, 28).method_32097(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), class_5603.method_32090(-1.5F, 0.0F, 4.0F));
        legsData.method_32117("leg4", class_5606.method_32108().method_32101(0, 28).method_32097(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), class_5603.method_32090(1.5F, 0.0F, 4.0F));

        return class_5607.method_32110(modelData, 64, 32);
    }

    @Override
    public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.head.field_3654 = headPitch * ((float)Math.PI / 180F);
        this.head.field_3675 = headYaw * ((float)Math.PI / 180F);

        // Simple leg wiggling when running
        this.legs.method_32086("leg1").field_3654 = (float)Math.cos(limbAngle * 0.6662F) * 1.4F * limbDistance;
        this.legs.method_32086("leg2").field_3654 = (float)Math.cos(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
        this.legs.method_32086("leg3").field_3654 = (float)Math.cos(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
        this.legs.method_32086("leg4").field_3654 = (float)Math.cos(limbAngle * 0.6662F) * 1.4F * limbDistance;
    }

    @Override
    public class_630 method_32008() {
        return this.root;
    }
}