package com.gile.client.mixin;

import com.gile.GileMod;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297> {

    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    protected void hideShrinkLabel(T entity, CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof class_1309 livingEntity) {
            // If the entity is shrunk, tell the game it does not have a label
            if (livingEntity.method_6059(GileMod.SHRINK_EFFECT)) {
                cir.setReturnValue(false);
            }
        }
    }
}