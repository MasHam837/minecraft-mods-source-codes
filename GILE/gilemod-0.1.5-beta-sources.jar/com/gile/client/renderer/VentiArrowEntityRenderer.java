package com.gile.client.renderer;

import com.gile.entity.VentiArrowEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_876;

public class VentiArrowEntityRenderer extends class_876<VentiArrowEntity> {
    private static final class_2960 TEXTURE = class_2960.method_60655("gilemod", "textures/entity/venti_arrow.png");

    public VentiArrowEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public class_2960 getTexture(VentiArrowEntity entity) {
        return TEXTURE;
    }
}