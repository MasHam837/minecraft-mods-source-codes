package com.gile.client.renderer;

import com.gile.GileMod;
import com.gile.entity.GloomyLynxEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_927;
import net.minecraft.client.model.*;

public class GloomyLynxEntityRenderer extends class_927<GloomyLynxEntity, GloomyLynxEntityRenderer.LynxModel> {

    public static final class_5601 LYNX_LAYER = new class_5601(class_2960.method_60655(GileMod.MOD_ID, "gloomy_lynx"), "main");
    private static final class_2960 TEXTURE = class_2960.method_60655(GileMod.MOD_ID, "textures/entity/gloomy_lynx.png");

    public GloomyLynxEntityRenderer(class_5617.class_5618 context) {
        super(context, new LynxModel(context.method_32167(LYNX_LAYER)), 0.5F);
    }

    @Override
    public class_2960 getTexture(GloomyLynxEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(GloomyLynxEntity entity, class_4587 matrices, float amount) {
        super.method_4042(entity, matrices, amount);
        if (entity.method_6109()) {
            matrices.method_22905(0.5F, 0.5F, 0.5F);
        }
    }

    // INTERNAL MODEL CLASS
    public static class LynxModel extends class_5597<GloomyLynxEntity> {
        private final class_630 root;
        private final class_630 headNormal;
        private final class_630 headAngry;
        private final class_630 body;
        private final class_630 frontLeftLeg;
        private final class_630 frontRightLeg;
        private final class_630 backLeftLeg;
        private final class_630 backRightLeg;
        private final class_630 tail;

        public LynxModel(class_630 root) {
            this.root = root;
            this.headNormal = root.method_32086("head_normal");
            this.headAngry = root.method_32086("head_angry");
            this.body = root.method_32086("body");
            this.frontLeftLeg = root.method_32086("front_left_leg");
            this.frontRightLeg = root.method_32086("front_right_leg");
            this.backLeftLeg = root.method_32086("back_left_leg");
            this.backRightLeg = root.method_32086("back_right_leg");
            this.tail = root.method_32086("tail");
        }

        public static class_5607 getTexturedModelData() {
            class_5609 modelData = new class_5609();
            class_5610 modelPartData = modelData.method_32111();

            modelPartData.method_32117("head_normal", class_5606.method_32108()
                            .method_32101(0, 0).method_32097(-3.0F, -4.0F, -4.0F, 6.0F, 6.0F, 5.0F)
                            .method_32101(0, 11).method_32097(-4.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                            .method_32101(0, 11).method_32097(2.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F),
                    class_5603.method_32090(0.0F, 13.0F, -8.0F));

            // Fixed: Ear coordinates now mirror head_normal exactly, retaining only the angry UV mapping
            modelPartData.method_32117("head_angry", class_5606.method_32108()
                            .method_32101(32, 0).method_32097(-3.0F, -4.0F, -4.0F, 6.0F, 6.0F, 5.0F)
                            .method_32101(32, 11).method_32097(-4.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                            .method_32101(32, 11).method_32097(2.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F),
                    class_5603.method_32090(0.0F, 13.0F, -8.0F));

            modelPartData.method_32117("body", class_5606.method_32108()
                            .method_32101(0, 16).method_32097(-4.0F, -8.0F, -4.0F, 8.0F, 18.0F, 8.0F),
                    class_5603.method_32091(0.0F, 14.0F, 0.0F, 1.5708F, 0.0F, 0.0F));

            modelPartData.method_32117("front_left_leg", class_5606.method_32108()
                            .method_32101(32, 16).method_32097(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    class_5603.method_32090(2.0F, 14.0F, -6.0F));

            modelPartData.method_32117("front_right_leg", class_5606.method_32108()
                            .method_32101(32, 16).method_32097(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    class_5603.method_32090(-2.0F, 14.0F, -6.0F));

            modelPartData.method_32117("back_left_leg", class_5606.method_32108()
                            .method_32101(44, 16).method_32097(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    class_5603.method_32090(2.0F, 14.0F, 7.0F));

            modelPartData.method_32117("back_right_leg", class_5606.method_32108()
                            .method_32101(44, 16).method_32097(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    class_5603.method_32090(-2.0F, 14.0F, 7.0F));

            modelPartData.method_32117("tail", class_5606.method_32108()
                            .method_32101(0, 42).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                    class_5603.method_32091(0.0F, 13.0F, 8.0F, 0.7854F, 0.0F, 0.0F));

            return class_5607.method_32110(modelData, 64, 64);
        }

        @Override
        public void setAngles(GloomyLynxEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
            this.root.method_32088().forEach(class_630::method_41923);

            boolean angry = entity.isAngry();
            this.headNormal.field_3665 = !angry;
            this.headAngry.field_3665 = angry;

            float yaw = headYaw * ((float)Math.PI / 180F);
            float pitch = headPitch * ((float)Math.PI / 180F);
            this.headNormal.field_3675 = yaw;
            this.headNormal.field_3654 = pitch;
            this.headAngry.field_3675 = yaw;
            this.headAngry.field_3654 = pitch;

            this.frontRightLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F) * 1.4F * limbDistance;
            this.frontLeftLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
            this.backRightLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
            this.backLeftLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F) * 1.4F * limbDistance;

            if (angry) {
                this.tail.field_3675 = class_3532.method_15362(animationProgress * 0.5F) * 0.5F;
                this.tail.field_3654 = 1.0F;
            } else {
                this.tail.field_3675 = class_3532.method_15362(limbAngle * 0.6662F) * 0.3F * limbDistance;
                this.tail.field_3654 = 0.7854F;
            }
        }

        @Override
        public class_630 method_32008() {
            return this.root;
        }
    }
}