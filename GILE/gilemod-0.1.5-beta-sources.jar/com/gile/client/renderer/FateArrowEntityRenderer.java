package com.gile.client.renderer;

import com.gile.entity.FateArrowEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_876;

public class FateArrowEntityRenderer extends class_876<FateArrowEntity> {
    private static final class_2960 TEXTURE = class_2960.method_60655("gilemod", "textures/entity/fate_arrow.png");

    public FateArrowEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public class_2960 getTexture(FateArrowEntity entity) {
        return TEXTURE;
    }
}