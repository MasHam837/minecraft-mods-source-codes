package com.gile.client.renderer;

import com.gile.GileMod;
import com.gile.entity.VoidSlimeEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_609;
import net.minecraft.class_927;
import net.minecraft.class_997;

public class VoidSlimeEntityRenderer extends class_927<VoidSlimeEntity, class_609<VoidSlimeEntity>> {
    private static final class_2960 TEXTURE = class_2960.method_60655(GileMod.MOD_ID, "textures/entity/void_slime.png");

    public VoidSlimeEntityRenderer(class_5617.class_5618 context) {
        super(context, new class_609<>(context.method_32167(class_5602.field_27654)), 0.25F);
        // Add the overlay feature renderer for the semi-transparent outer layer
        this.method_4046(new class_997<>(this, context.method_32170()));}

    @Override
    protected void scale(VoidSlimeEntity slime, class_4587 matrices, float amount) {
        matrices.method_22905(1.5F, 1.5F, 1.5F);}

    @Override
    public class_2960 getTexture(VoidSlimeEntity entity) {
        return TEXTURE;
    }
}