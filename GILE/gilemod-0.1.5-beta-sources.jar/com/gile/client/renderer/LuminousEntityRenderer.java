package com.gile.client.renderer;

import com.gile.entity.LuminousEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_927;
import net.minecraft.client.model.*;

public class LuminousEntityRenderer extends class_927<LuminousEntity, LuminousEntityRenderer.LuminousModel> {
    public static final class_5601 LUMINOUS_LAYER = new class_5601(class_2960.method_60655("gilemod", "luminous"), "main");

    private static final class_2960 YELLOW_TEXTURE = class_2960.method_60655("gilemod", "textures/entity/luminous/yellow.png");
    private static final class_2960 LIGHT_BLUE_TEXTURE = class_2960.method_60655("gilemod", "textures/entity/luminous/light_blue.png");
    private static final class_2960 PINK_TEXTURE = class_2960.method_60655("gilemod", "textures/entity/luminous/pink.png");

    public LuminousEntityRenderer(class_5617.class_5618 context) {
        super(context, new LuminousModel(context.method_32167(LUMINOUS_LAYER)), 0.4f);
        this.method_4046(new LuminousGlowFeatureRenderer(this));
    }

    // Add this method anywhere inside your LuminousEntityRenderer class
    @Override
    protected void scale(LuminousEntity entity, class_4587 matrices, float amount) {
        if (entity.method_6109()) {
            // Shrinks the model to 0.5x size (half size) in X, Y, and Z axes
            matrices.method_22905(0.5F, 0.5F, 0.5F);
        } else {
            matrices.method_22905(1.0F, 1.0F, 1.0F);
        }
    }

    @Override
    public class_2960 getTexture(LuminousEntity entity) {
        return switch (entity.getVariant()) {
            case 1 -> LIGHT_BLUE_TEXTURE;
            case 2 -> PINK_TEXTURE;
            default -> YELLOW_TEXTURE;
        };
    }

    // --- INTERNAL MODEL CLASS ---
    public static class LuminousModel extends class_5597<LuminousEntity> {
        private final class_630 root;
        private final class_630 body;
        private final class_630 leftEar;
        private final class_630 rightEar;
        private final class_630[] feet = new class_630[8];

        public LuminousModel(class_630 root) {
            this.root = root;
            this.body = root.method_32086("body");
            this.leftEar = body.method_32086("left_ear");
            this.rightEar = body.method_32086("right_ear");

            for (int i = 0; i < 8; i++) {
                this.feet[i] = body.method_32086("foot_" + i);
            }
        }

        public static class_5607 getTexturedModelData() {
            class_5609 modelData = new class_5609();
            class_5610 modelPartData = modelData.method_32111();

            // Cubic body: 12x12x12 size (0.75 of a block).
            // Positioned so it sits exactly on the floor plane (Y=24)
            class_5610 bodyData = modelPartData.method_32117("body", class_5606.method_32108()
                            .method_32101(0, 0)
                            .method_32097(-6.0F, -13.5F, -6.0F, 12.0F, 12.0F, 12.0F),
                    class_5603.method_32090(0.0F, 24.0F, 0.0F));

            // Dumbo Ear Fins (Rotated 90 degrees on Y axis)
            bodyData.method_32117("left_ear", class_5606.method_32108()
                            .method_32101(0, 24)
                            .method_32097(0.0F, 0.0F, 0.0F, 4.0F, 4.0F, 1.0F),
                    // X, Y, Z, Pitch (X), Yaw (Y) changed to 1.5708F, Roll (Z)
                    class_5603.method_32091(6.0F, -10.0F, 0.0F, 0.0F, 1.5708F, -0.2F));

            bodyData.method_32117("right_ear", class_5606.method_32108()
                            .method_32101(0, 24)
                            .method_32096()
                            .method_32097(-4.0F, 0.0F, 0.0F, 4.0F, 4.0F, 1.0F),
                    // X, Y, Z, Pitch (X), Yaw (Y) changed to -1.5708F, Roll (Z)
                    class_5603.method_32091(-6.0F, -10.0F, 0.0F, 0.0F, -1.5708F, 0.2F));

            // 8 Flat Feet radiating along the base edges
            float[][] footPositions = {
                    {4.0F, -5.0F}, {4.0F, 0.0F}, {4.0F, 5.0F},
                    {-4.0F, -5.0F}, {-4.0F, 0.0F}, {-4.0F, 5.0F},
                    {0.0F, -5.0F}, {0.0F, 5.0F}
            };

            for (int i = 0; i < 8; i++) {
                bodyData.method_32117("foot_" + i, class_5606.method_32108()
                                .method_32101(0, 30)
                                .method_32097(-1.5F, -1.5F, -1.5F, 3.0F, 1.0F, 3.0F),
                        class_5603.method_32090(footPositions[i][0], 0.0F, footPositions[i][1]));
            }

            return class_5607.method_32110(modelData, 64, 64);
        }

        @Override
        public void setAngles(LuminousEntity entity, float limbAngle, float limbDistance,
                              float animationProgress, float headYaw, float headPitch) {
            this.root.method_41923();

            // 1. Piglin-like Ear animation (gentle floating/flapping)
            float idleSpeed = animationProgress * 0.1F;
            this.leftEar.field_3674 = -0.2F - (class_3532.method_15374(idleSpeed) * 0.08F);
            this.rightEar.field_3674 = 0.2F + (class_3532.method_15374(idleSpeed) * 0.08F);

            this.leftEar.field_3654 = class_3532.method_15362(idleSpeed) * 0.05F;
            this.rightEar.field_3654 = class_3532.method_15362(idleSpeed) * 0.05F;

            // 2. Octopus Feet Ripple Animation
            for (int i = 0; i < 8; i++) {
                // Phase offsets make the tentacles ripple sequentially instead of all at once
                float phaseOffset = i * 0.4F;
                this.feet[i].field_3654 = class_3532.method_15374(animationProgress * 0.2F + phaseOffset) * 0.15F;
                this.feet[i].field_3674 = class_3532.method_15362(animationProgress * 0.2F + phaseOffset) * 0.1F;
            }
        }

        @Override
        public class_630 method_32008() {
            return this.root;
        }
    }
}