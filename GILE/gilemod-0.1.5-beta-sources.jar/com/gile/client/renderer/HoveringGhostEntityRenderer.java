package com.gile.client.renderer;

import com.gile.entity.HoveringGhostEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_927;
import net.minecraft.client.model.*;

public class HoveringGhostEntityRenderer extends class_927<HoveringGhostEntity, HoveringGhostEntityRenderer.HoveringGhostModel> {
    // 1. Register distinct layers for the normal layout and the Nyan Cat easter egg variant
    public static final class_5601 GHOST_LAYER = new class_5601(class_2960.method_60655("gilemod", "hovering_ghost"), "main");
    public static final class_5601 GHOST_NYAN_LAYER = new class_5601(class_2960.method_60655("gilemod", "hovering_ghost_nyan"), "main");

    // Single texture image sheet (expanded height to 128 to accommodate the +52 V shift)
    private static final class_2960 TEXTURE = class_2960.method_60655("gilemod", "textures/entity/hovering_ghost.png");

    private final HoveringGhostModel normalModel;
    private final HoveringGhostModel nyanModel;

    public HoveringGhostEntityRenderer(class_5617.class_5618 context) {
        super(context, new HoveringGhostModel(context.method_32167(GHOST_LAYER)), 0.6f);
        this.normalModel = new HoveringGhostModel(context.method_32167(GHOST_LAYER));
        this.nyanModel = new HoveringGhostModel(context.method_32167(GHOST_NYAN_LAYER));
    }

    @Override
    public class_2960 getTexture(HoveringGhostEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(HoveringGhostEntity entity, float f, float g, class_4587 matrixStack,
                       class_4597 vertexConsumerProvider, int i) {
        // 2. Dynamically hot-swap active model instances depending on name tag configuration
        if (entity.method_16914() && "Nyan Cat".equalsIgnoreCase(entity.method_5477().getString())) {
            this.field_4737 = this.nyanModel;
        } else {
            this.field_4737 = this.normalModel;
        }
        super.method_4054(entity, f, g, matrixStack, vertexConsumerProvider, i);
    }

    @Override
    protected void scale(HoveringGhostEntity entity, class_4587 matrices, float amount) {
        if (entity.method_6109()) {
            matrices.method_22905(0.5F, 0.5F, 0.5F);
        } else {
            matrices.method_22905(1.0F, 1.0F, 1.0F);
        }
    }

    // --- INTERNAL MODEL CLASS ---
    public static class HoveringGhostModel extends class_5597<HoveringGhostEntity> {
        private final class_630 root;
        private final class_630 cleanBody;
        private final class_630 saddledBody;
        private final class_630 ears;

        public HoveringGhostModel(class_630 root) {
            this.root = root;
            this.cleanBody = root.method_32086("clean_body");
            this.saddledBody = root.method_32086("saddled_body");
            this.ears = root.method_32086("ears");
        }

        public static class_5607 getTexturedModelData() {
            return createModelData(false);
        }

        public static class_5607 getNyanTexturedModelData() {
            return createModelData(true);
        }

        // 3. Centralized compilation builder that injects a V-offset when processing Nyan variants
        private static class_5607 createModelData(boolean isNyanCat) {
            class_5609 modelData = new class_5609();
            class_5610 root = modelData.method_32111();

            // Shift V coordinate downward by 52 pixels if this instance is for Nyan Cat
            int vOffset = isNyanCat ? 58 : 0;

            // Part 1: Clean Variant mapping
            root.method_32117("clean_body", class_5606.method_32108()
                            .method_32101(0, vOffset + 0)
                            .method_32097(-12.0F, -12.0F, -20.0F, 24.0F, 12.0F, 40.0F),
                    class_5603.method_32090(0.0F, 24.0F, 0.0F));

            // Part 2: Saddled Variant mapping shifted 128 pixels right
            root.method_32117("saddled_body", class_5606.method_32108()
                            .method_32101(128, vOffset + 0)
                            .method_32097(-12.0F, -12.0F, -20.0F, 24.0F, 12.0F, 40.0F),
                    class_5603.method_32090(0.0F, 24.0F, 0.0F));

            root.method_32117("ears", class_5606.method_32108()
                            .method_32101(0, vOffset + 52)
                            .method_32097(-12.0F,-18.0F,-19.99F,24.0F,6.0F,0.0F),
                    class_5603.method_32090(0.0F, 24.0F, 0.0F)
            );

            // Expanded texture canvas boundaries to 256x128 to clean up extra mapping rows safely
            return class_5607.method_32110(modelData, 256, 128);
        }

        @Override
        public void setAngles(HoveringGhostEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
            this.root.method_41923();

            float pivotY = 24.0F + class_3532.method_15374(animationProgress * 0.15F) * 1.5F;
            this.cleanBody.field_3656 = pivotY;
            this.saddledBody.field_3656 = pivotY;
            this.ears.field_3656 = pivotY;

            boolean saddled = entity.isSaddled();

            this.cleanBody.field_3665 = !saddled;
            this.saddledBody.field_3665 = saddled;
            this.ears.field_3665 = true;
        }

        @Override
        public class_630 method_32008() {
            return this.root;
        }
    }
}