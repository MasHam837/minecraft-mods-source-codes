package com.gile.client.renderer;

import com.gile.GileMod;
import com.gile.entity.JerboaEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_927;
import net.minecraft.client.model.*;

public class JerboaEntityRenderer extends class_927<JerboaEntity, JerboaEntityRenderer.JerboaModel> {

    public static final class_5601 JERBOA_LAYER = new class_5601(class_2960.method_60655(GileMod.MOD_ID, "jerboa"), "main");
    private static final class_2960 TEXTURE = class_2960.method_60655(GileMod.MOD_ID, "textures/entity/jerboa.png");

    public JerboaEntityRenderer(class_5617.class_5618 context) {
        super(context, new JerboaModel(context.method_32167(JERBOA_LAYER)), 0.3F);
    }

    @Override
    public class_2960 getTexture(JerboaEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(JerboaEntity entity, class_4587 matrices, float amount) {
        if (entity.isHiding()) {
            matrices.method_22905(1.0f, 0.15f, 1.0f);
        }
        if (entity.method_6109()) {
            matrices.method_22905(0.5F, 0.5F, 0.5F);
        }
        super.method_4042(entity, matrices, amount);
    }

    public static class JerboaModel extends class_5597<JerboaEntity> {
        private final class_630 root;

        // Normal Parts
        private final class_630 bodyNormal, headNormal, leftEarNormal, rightEarNormal, tailNormal;
        // Desert Parts
        private final class_630 bodyDesert, headDesert, leftEarDesert, rightEarDesert, tailDesert;

        public JerboaModel(class_630 root) {
            this.root = root;

            this.bodyNormal = root.method_32086("body");
            this.headNormal = root.method_32086("head");
            this.leftEarNormal = headNormal.method_32086("left_ear");
            this.rightEarNormal = headNormal.method_32086("right_ear");
            this.tailNormal = root.method_32086("tail");

            this.bodyDesert = root.method_32086("body_desert");
            this.headDesert = root.method_32086("head_desert");
            this.leftEarDesert = headDesert.method_32086("left_ear_desert");
            this.rightEarDesert = headDesert.method_32086("right_ear_desert");
            this.tailDesert = root.method_32086("tail_desert");
        }

        public static class_5607 getTexturedModelData() {
            class_5609 modelData = new class_5609();
            class_5610 root = modelData.method_32111();

            // --- NORMAL VARIANT (UVs mapped to top half of texture) ---
            root.method_32117("body", class_5606.method_32108().method_32101(0, 0).method_32097(-2.5F, -3.0F, -3.5F, 5.0F, 4.0F, 7.0F), class_5603.method_32090(0.0F, 22.0F, 0.0F));
            class_5610 head = root.method_32117("head", class_5606.method_32108().method_32101(0, 11).method_32097(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 4.0F), class_5603.method_32090(0.0F, 20.5F, -2.5F));
            head.method_32117("left_ear", class_5606.method_32108().method_32101(17, 0).method_32097(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), class_5603.method_32090(1.0F, -2.0F, -1.0F));
            head.method_32117("right_ear", class_5606.method_32108().method_32101(21, 0).method_32097(-1.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), class_5603.method_32090(-1.0F, -2.0F, -1.0F));
            root.method_32117("tail", class_5606.method_32108().method_32101(16, 12).method_32097(-0.5F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F), class_5603.method_32091(0.0F, 20.0F, 3.0F, 0.8F, 0.0F, 0.0F));

            // --- DESERT VARIANT (UVs shifted down by 24 pixels) ---
            root.method_32117("body_desert", class_5606.method_32108().method_32101(0, 24).method_32097(-2.5F, -3.0F, -3.5F, 5.0F, 4.0F, 7.0F), class_5603.method_32090(0.0F, 22.0F, 0.0F));
            class_5610 headDesert = root.method_32117("head_desert", class_5606.method_32108().method_32101(0, 35).method_32097(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 4.0F), class_5603.method_32090(0.0F, 20.5F, -2.5F));
            headDesert.method_32117("left_ear_desert", class_5606.method_32108().method_32101(17, 24).method_32097(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), class_5603.method_32090(1.0F, -2.0F, -1.0F));
            headDesert.method_32117("right_ear_desert", class_5606.method_32108().method_32101(21, 24).method_32097(-1.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), class_5603.method_32090(-1.0F, -2.0F, -1.0F));
            root.method_32117("tail_desert", class_5606.method_32108().method_32101(16, 36).method_32097(-0.5F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F), class_5603.method_32091(0.0F, 20.0F, 3.0F, 0.8F, 0.0F, 0.0F));

            // Expanding texture height to fit both models seamlessly
            return class_5607.method_32110(modelData, 32, 48);
        }

        @Override
        public void setAngles(JerboaEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
            boolean isDesert = entity.isDesertVariant();

            // Toggle visibility of the geometry
            this.bodyNormal.field_3665 = !isDesert;
            this.headNormal.field_3665 = !isDesert;
            this.tailNormal.field_3665 = !isDesert;

            this.bodyDesert.field_3665 = isDesert;
            this.headDesert.field_3665 = isDesert;
            this.tailDesert.field_3665 = isDesert;

            // Fetch active geometry to apply animations seamlessly
            class_630 body = isDesert ? this.bodyDesert : this.bodyNormal;
            class_630 head = isDesert ? this.headDesert : this.headNormal;
            class_630 leftEar = isDesert ? this.leftEarDesert : this.leftEarNormal;
            class_630 rightEar = isDesert ? this.rightEarDesert : this.rightEarNormal;
            class_630 tail = isDesert ? this.tailDesert : this.tailNormal;

            body.method_41923();
            head.method_41923();
            leftEar.method_41923();
            rightEar.method_41923();
            tail.method_41923();

            if (entity.isHiding()) {
                body.field_3656 += 4.0F;
                head.field_3656 += 4.0F;
                leftEar.field_3654 = -1.2f;
                rightEar.field_3654 = -1.2f;
                return;
            }

            float hop = class_3532.method_15362(limbAngle * 1.4f) * 1.2f * limbDistance;

            body.field_3654 = hop * 0.15f;
            head.field_3675 = headYaw * 0.017453292F;
            head.field_3654 = headPitch * 0.017453292F;
            tail.field_3675 = class_3532.method_15362(animationProgress * 0.2f) * 0.15f;
            leftEar.field_3674 = class_3532.method_15362(animationProgress * 0.15f) * 0.05f;
            rightEar.field_3674 = -leftEar.field_3674;
        }

        @Override
        public class_630 method_32008() {
            return this.root;
        }

        @Override
        public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
            root.method_22699(matrices, vertices, light, overlay, color);
        }
    }
}