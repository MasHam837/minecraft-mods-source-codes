package com.gile.client.renderer;

import com.gile.block.entity.MoonCampfireBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;

public class MoonCampfireBlockEntityRenderer implements class_827<MoonCampfireBlockEntity> {
    private final class_918 itemRenderer;

    public MoonCampfireBlockEntityRenderer(class_5614.class_5615 ctx) {
        this.itemRenderer = ctx.method_43335();
    }

    @Override
    public void render(MoonCampfireBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        class_2350 direction = entity.method_11010().method_11654(net.minecraft.class_3922.field_17564);
        class_2371<class_1799> items = entity.getItems();
        int seed = (int) entity.method_11016().method_10063();

        for (int i = 0; i < items.size(); i++) {
            class_1799 itemStack = items.get(i);
            if (!itemStack.method_7960()) {
                matrices.method_22903();
                // Position above the campfire base
                matrices.method_22904(0.5, 0.44921875, 0.5);
                class_2350 rotationDir = class_2350.method_10139((i + direction.method_10161()) % 4);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-rotationDir.method_10144()));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
                matrices.method_22904(-0.3125, -0.3125, 0.0);
                matrices.method_22905(0.375F, 0.375F, 0.375F);

                this.itemRenderer.method_23178(itemStack, class_811.field_4319, light, overlay, matrices, vertexConsumers, entity.method_10997(), seed + i);
                matrices.method_22909();
            }
        }
    }
}