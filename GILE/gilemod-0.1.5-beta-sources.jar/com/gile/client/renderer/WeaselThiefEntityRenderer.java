package com.gile.client.renderer;

import com.gile.client.GileModClient;
import com.gile.client.model.WeaselThiefModel;
import com.gile.entity.WeaselThiefEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class WeaselThiefEntityRenderer extends class_927<WeaselThiefEntity, WeaselThiefModel<WeaselThiefEntity>> {

    public WeaselThiefEntityRenderer(class_5617.class_5618 context) {
        // 0.4f is the shadow radius
        super(context, new WeaselThiefModel<>(context.method_32167(GileModClient.WEASEL_MODEL_LAYER)), 0.4f);
    }

    @Override
    public class_2960 getTexture(WeaselThiefEntity entity) {
        // Loads from: assets/gilemod/textures/entity/weasel/amateur.png (or hoarder.png / golden.png)
        return class_2960.method_60655("gilemod", "textures/entity/weasel/" + entity.getVariant().method_15434() + ".png");
    }
}