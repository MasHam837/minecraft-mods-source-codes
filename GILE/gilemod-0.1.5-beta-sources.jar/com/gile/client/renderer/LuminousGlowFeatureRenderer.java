package com.gile.client.renderer;

import com.gile.entity.LuminousEntity;
import net.minecraft.class_1921;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;

public class LuminousGlowFeatureRenderer extends class_3887<LuminousEntity, LuminousEntityRenderer.LuminousModel> {

    public LuminousGlowFeatureRenderer(class_3883<LuminousEntity, LuminousEntityRenderer.LuminousModel> context) {
        super(context);
    }

    @Override
    public void render(class_4587 matrices, class_4597 vertexConsumers, int light, LuminousEntity entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        // RenderLayer.getEyes() makes it immune to block lighting (glows in the dark)
        class_4588 vertexConsumer = vertexConsumers.getBuffer(class_1921.method_23026(this.method_23194(entity)));

        // 15728640 is the maximum light value map used for emissive rendering in Vanilla Minecraft
        this.method_17165().method_2828(matrices, vertexConsumer, 15728640, class_4608.field_21444, 0xFFFFFFFF);
    }
}