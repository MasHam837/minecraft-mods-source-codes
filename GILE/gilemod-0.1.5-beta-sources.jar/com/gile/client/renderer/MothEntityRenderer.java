package com.gile.client.renderer;

import com.gile.entity.MothEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_927;
import net.minecraft.client.model.*;

public class MothEntityRenderer extends class_927<MothEntity, MothEntityRenderer.MothModel> {
    public static final class_5601 MOTH_LAYER = new class_5601(class_2960.method_60655("gilemod", "moth"), "main");
    public static final class_5601 MOTH_RADIANCE_LAYER = new class_5601(class_2960.method_60655("gilemod", "moth_radiance"), "main");
    private static final class_2960 TEXTURE = class_2960.method_60655("gilemod", "textures/entity/moth.png");

    private final MothModel normalModel;
    private final MothModel radianceModel;

    public MothEntityRenderer(class_5617.class_5618 context) {
        super(context, new MothModel(context.method_32167(MOTH_LAYER), false), 0.3f);
        this.normalModel = new MothModel(context.method_32167(MOTH_LAYER), false);
        this.radianceModel = new MothModel(context.method_32167(MOTH_RADIANCE_LAYER), true);}

    @Override
    public class_2960 getTexture(MothEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(MothEntity entity, float f, float g, class_4587 matrixStack,
                       class_4597 vertexConsumerProvider, int i) {
        // Swap model based on name
        if (entity.method_16914() && entity.method_5477().getString().equalsIgnoreCase("Radiance")) {
            this.field_4737 = this.radianceModel;}
        else {
            this.field_4737 = this.normalModel;}
        super.method_4054(entity, f, g, matrixStack, vertexConsumerProvider, i);}

    @Override
    protected void scale(MothEntity entity, class_4587 matrices, float amount) {
        boolean isRadiance = entity.method_16914() && entity.method_5477().getString().equalsIgnoreCase("Radiance");
        if (entity.method_6109()) {
            matrices.method_22905(0.5F, 0.5F, 0.5F);}
        else if (isRadiance) {
            matrices.method_22905(1.2F, 1.2F, 1.2F);}
        else {
            matrices.method_22905(1.0F, 1.0F, 1.0F);}}

    // --- INTERNAL MODEL CLASS ---
    public static class MothModel extends class_5597<MothEntity> {
        private final class_630 root;
        private final class_630 body;
        private final class_630 head;
        private final class_630 leftWingFront, leftWingBack;
        private final class_630 rightWingFront, rightWingBack;
        private final boolean isRadiance;

        public MothModel(class_630 root, boolean isRadiance) {
            this.root = root;
            this.isRadiance = isRadiance;
            this.body = root.method_32086("body");
            this.head = root.method_32086("head");
            this.leftWingFront = root.method_32086("left_wing_front");
            this.leftWingBack = root.method_32086("left_wing_back");
            this.rightWingFront = root.method_32086("right_wing_front");
            this.rightWingBack = root.method_32086("right_wing_back");}

        public static class_5607 getTexturedModelData() {
            return createModelData(false);
        }

        public static class_5607 getRadianceTexturedModelData() {
            return createModelData(true);
        }

        private static class_5607 createModelData(boolean isRadiance) {
            class_5609 modelData = new class_5609();
            class_5610 modelPartData = modelData.method_32111();

            int uvOffset = isRadiance ? 32 : 0;

            // ===== BODY =====
            modelPartData.method_32117("body", class_5606.method_32108()
                            .method_32101(uvOffset + 0, 17)
                            .method_32097(-2.5F, -1.0F, -2.5F, 5.0F, 1.5F, 6.0F),
                    class_5603.method_32090(0.0F, 21.5F, -1.0F));

            // ===== HEAD =====
            class_5610 headData = modelPartData.method_32117("head", class_5606.method_32108()
                            .method_32101(uvOffset + 0, 11)
                            .method_32097(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 3.0F),
                    class_5603.method_32090(0.0F, 21.5F, -2.5F));

            // Eyes
            headData.method_32117("eye_left", class_5606.method_32108()
                            .method_32101(uvOffset + 11, 11)
                            .method_32097(0.5F, -1.5F, -3.3F, 2.0F, 2.0F, 1.0F),
                    class_5603.field_27701);

            headData.method_32117("eye_right", class_5606.method_32108()
                            .method_32101(uvOffset + 11, 11)
                            .method_32096()
                            .method_32097(-2.5F, -1.5F, -3.3F, 2.0F, 2.0F, 1.0F),
                    class_5603.field_27701);

            // Antennae
            headData.method_32117("antenna_left", class_5606.method_32108()
                            .method_32101(uvOffset + 14, 14)
                            .method_32097(-1.0F, -3.0F, 0.0F, 2.0F, 3.0F, 0.0F),
                    class_5603.method_32091(1.3F, -1.5F, -2.5F, 0.3F, 0.2F, 0.3F));

            headData.method_32117("antenna_right", class_5606.method_32108()
                            .method_32101(uvOffset + 14, 14)
                            .method_32096()
                            .method_32097(-1.0F, -3.0F, 0.0F, 2.0F, 3.0F, 0.0F),
                    class_5603.method_32091(-1.3F, -1.5F, -2.5F, 0.3F, -0.2F, -0.3F));

            // ===== FRONT WINGS =====
            modelPartData.method_32117("left_wing_front", class_5606.method_32108()
                            .method_32101(uvOffset + 0, 0)
                            .method_32097(0.0F, 0.0F, -3.0F, 10.0F, 0.0F, 6.0F),
                    class_5603.method_32091(2.0F, 21.0F, -1.0F, 0.0F, 0.0F, 0.15F));

            modelPartData.method_32117("right_wing_front", class_5606.method_32108()
                            .method_32101(uvOffset + 0, 0)
                            .method_32096()
                            .method_32097(-10.0F, 0.0F, -3.0F, 10.0F, 0.0F, 6.0F),
                    class_5603.method_32091(-2.0F, 21.0F, -1.0F, 0.0F, 0.0F, -0.15F));

            // ===== BACK WINGS =====
            modelPartData.method_32117("left_wing_back", class_5606.method_32108()
                            .method_32101(uvOffset + 0, 6)
                            .method_32097(0.0F, 0.0F, -2.0F, 8.0F, 0.0F, 5.0F),
                    class_5603.method_32091(2.0F, 21.0F, 1.0F, 0.0F, 0.0F, 0.1F));

            modelPartData.method_32117("right_wing_back", class_5606.method_32108()
                            .method_32101(uvOffset + 0, 6)
                            .method_32096()
                            .method_32097(-8.0F, 0.0F, -2.0F, 8.0F, 0.0F, 5.0F),
                    class_5603.method_32091(-2.0F, 21.0F, 1.0F, 0.0F, 0.0F, -0.1F));

            // ===== LEGS =====
            for (int i = 0; i < 3; i++) {
                modelPartData.method_32117("leg_left_" + i, class_5606.method_32108()
                                .method_32101(uvOffset + 0, 21)
                                .method_32097(0.0F, 0.0F, 0.0F, 2.0F, 1.0F, 1.0F),
                        class_5603.method_32090(2.0F, 22.5F, -2.0F + (i * 2.0F)));

                modelPartData.method_32117("leg_right_" + i, class_5606.method_32108()
                                .method_32101(uvOffset + 0, 21)
                                .method_32096()
                                .method_32097(-2.0F, 0.0F, 0.0F, 2.0F, 1.0F, 1.0F),
                        class_5603.method_32090(-2.0F, 22.5F, -2.0F + (i * 2.0F)));
            }
            return class_5607.method_32110(modelData, 64, 64);
        }

        @Override
        public void setAngles(MothEntity entity, float limbAngle, float limbDistance,
                              float animationProgress, float headYaw, float headPitch) {
            float flapSpeed = isRadiance ? 0.5F : 0.7F;
            float flapAmount = isRadiance ? 0.7F : 0.9F;

            float flap = class_3532.method_15374(animationProgress * flapSpeed) * flapAmount;

            this.leftWingFront.field_3674 = flap;
            this.rightWingFront.field_3674 = -flap;

            float backFlap = class_3532.method_15374(animationProgress * flapSpeed + 0.3F) * flapAmount * 0.8F;
            this.leftWingBack.field_3674 = backFlap;
            this.rightWingBack.field_3674 = -backFlap;

            this.head.field_3675 = headYaw * 0.017453292F;
            this.head.field_3654 = headPitch * 0.017453292F;}

        @Override
        public class_630 method_32008() {
            return this.root;
        }

    }
}