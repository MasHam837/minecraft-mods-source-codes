package com.gile.client;

import com.gile.GileMod;
import com.gile.block.ModWoodTypes;
import com.gile.client.model.WeaselThiefModel;
import com.gile.client.renderer.*;
import com.gile.network.ActiveAbilityPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.object.builder.v1.client.model.FabricModelPredicateProviderRegistry;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import net.minecraft.class_5601;
import net.minecraft.class_5616;
import net.minecraft.class_7761;
import net.minecraft.class_837;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;

public class GileModClient implements ClientModInitializer {

	public static final class_5601 WEASEL_MODEL_LAYER = new class_5601(class_2960.method_60655(GileMod.MOD_ID, "weasel_thief"), "main");

	@Override
	public void onInitializeClient() {

		// Translucent blocks rendering registrations:
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_FLOWER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_MOON_FLOWER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GLOOMY_FLOWER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_GLOOMY_FLOWER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.DRY_FLOWER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_DRY_FLOWER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GHOSTLY_SAPLING, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_GHOSTLY_SAPLING, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.END_GRASS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.TALL_END_GRASS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.PEARLESCENT_CHAIN, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_LANTERN, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GHOSTLY_DOOR, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GHOSTLY_TRAPDOOR, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.END_CLOUD, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.STAR, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_FIRE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_CAMPFIRE, class_1921.method_23581());

		// MEGA ULTRA STRANGE BLOCK-ENTITY registrations:
		class_4722.field_21712.put(ModWoodTypes.GHOSTLY_WOOD_TYPE,
				new class_4730(class_4722.field_21708,
						class_2960.method_60655("gilemod", "entity/signs/ghostly")));

		class_4722.field_40515.put(ModWoodTypes.GHOSTLY_WOOD_TYPE,
				new class_4730(class_4722.field_21708,
						class_2960.method_60655("gilemod", "entity/signs/hanging/ghostly")));

		// Block Entity Renderer Factories
		class_5616.method_32144(GileMod.GHOSTLY_SIGN_BLOCK_ENTITY, class_837::new);
		class_5616.method_32144(GileMod.GHOSTLY_HANGING_SIGN_BLOCK_ENTITY, class_7761::new);
		class_5616.method_32144(GileMod.MOON_CAMPFIRE_ENTITY, MoonCampfireBlockEntityRenderer::new);

		// Entity rendering registrations:
		EntityRendererRegistry.register(GileMod.FATE_ARROW_TYPE, FateArrowEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.VOID_SLIME, VoidSlimeEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.MOTH, MothEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.VENTI_ARROW_TYPE, VentiArrowEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.LUMINOUS, LuminousEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.HOVERING_GHOST, HoveringGhostEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.JERBOA, JerboaEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.GLOOMY_LYNX, GloomyLynxEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.WEASEL_THIEF, WeaselThiefEntityRenderer::new);

		// Model layer of complex entities registrations:
		EntityModelLayerRegistry.registerModelLayer(MothEntityRenderer.MOTH_LAYER, MothEntityRenderer.MothModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(MothEntityRenderer.MOTH_RADIANCE_LAYER, MothEntityRenderer.MothModel::getRadianceTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(LuminousEntityRenderer.LUMINOUS_LAYER, LuminousEntityRenderer.LuminousModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(HoveringGhostEntityRenderer.GHOST_LAYER, HoveringGhostEntityRenderer.HoveringGhostModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(HoveringGhostEntityRenderer.GHOST_NYAN_LAYER, HoveringGhostEntityRenderer.HoveringGhostModel::getNyanTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(JerboaEntityRenderer.JERBOA_LAYER, JerboaEntityRenderer.JerboaModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(GloomyLynxEntityRenderer.LYNX_LAYER, GloomyLynxEntityRenderer.LynxModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(WEASEL_MODEL_LAYER, WeaselThiefModel::getTexturedModelData);

		// Bow pulling animations:
		FabricModelPredicateProviderRegistry.register(GileMod.FATE_BOW, class_2960.method_60654("pull"),
				(stack, world, entity, seed) -> {
					if (entity == null) return 0.0F;
					if (entity.method_6030() != stack) return 0.0F;
					return (stack.method_7935(entity) - entity.method_6014()) / 20.0F;
				});
		FabricModelPredicateProviderRegistry.register(GileMod.FATE_BOW, class_2960.method_60654("pulling"),
				(stack, world, entity, seed) -> {
					return entity != null && entity.method_6115() && entity.method_6030() == stack ? 1.0F : 0.0F;
				});

		FabricModelPredicateProviderRegistry.register(GileMod.DAYBREAK_CHRONICLES, class_2960.method_60654("pull"),
				(stack, world, entity, seed) -> {
					if (entity == null) return 0.0F;
					if (entity.method_6030() != stack) return 0.0F;
					return (stack.method_7935(entity) - entity.method_6014()) / 20.0F;
				});
		FabricModelPredicateProviderRegistry.register(GileMod.DAYBREAK_CHRONICLES, class_2960.method_60654("pulling"),
				(stack, world, entity, seed) -> {
					return entity != null && entity.method_6115() && entity.method_6030() == stack ? 1.0F : 0.0F;
				});

		// Keybinds:
		class_304 activeAbilityKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.gilemod.active_ability", // Update this in your en_us.json too!
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_V,
				"category.gilemod.keys"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (activeAbilityKey.method_1436()) {
				if (client.field_1724 != null) {
					// Send the signal to the server
					ClientPlayNetworking.send(new ActiveAbilityPayload());
				}
			}
		});

	}
}