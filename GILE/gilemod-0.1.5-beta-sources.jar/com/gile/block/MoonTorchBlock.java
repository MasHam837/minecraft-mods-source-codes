package com.gile.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2527;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class MoonTorchBlock extends class_2527 {
    public MoonTorchBlock(class_2251 settings) {
        super(class_2398.field_23190, settings);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        double x = (double)pos.method_10263() + 0.5;
        double y = (double)pos.method_10264() + 0.5;
        double z = (double)pos.method_10260() + 0.5;
        for (int i = 0; i < 6; i++) { world.method_8406(class_2398.field_23190,
                x + (random.method_43058() - 0.5) * 0.2,
                y + random.method_43058() * 0.2,
                z + (random.method_43058() - 0.5) * 0.2,
                0.0, 0.0, 0.0);
        }
    }
}