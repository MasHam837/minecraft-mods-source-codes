package com.gile.block;

import com.gile.GileMod;
import net.minecraft.class_1291;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2356;
import net.minecraft.class_2680;
import net.minecraft.class_6880;

public class MoonFlowerBlock extends class_2356 {

    public MoonFlowerBlock(class_6880<class_1291> effect, int duration, class_2251 settings) {
        super(effect, duration, settings);
    }

    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_27852(class_2246.field_10219)
                || floor.method_27852(class_2246.field_10566)
                || floor.method_27852(GileMod.MOON_SAND)
                || floor.method_27852(GileMod.END_GRASS_BLOCK);
    }
}