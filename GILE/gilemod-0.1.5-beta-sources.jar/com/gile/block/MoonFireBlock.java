package com.gile.block;

import com.gile.GileMod;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_4538;
import net.minecraft.class_4770;

import static net.minecraft.class_2358.*;

public class MoonFireBlock extends class_4770 {

    public static final MapCodec<MoonFireBlock> CODEC = method_54094(MoonFireBlock::new);

    public MoonFireBlock(class_2251 settings) {
        // Damage is measured in half-hearts. 3.0F deals exactly 1.5 hearts.
        super(settings, 3.0F);

        this.method_9590(
                this.field_10647.method_11664()
                        .method_11657(field_11096, false)
                        .method_11657(field_11094, false)
                        .method_11657(field_11089, false)
                        .method_11657(field_11088, false)
                        .method_11657(field_11093, false)
        );
    }

    @Override
    protected MapCodec<? extends class_4770> method_53969() {
        return field_46280;
    }

    @Override
    protected boolean method_10195(class_2680 state) {
        // Vanilla FireBlock and SoulFireBlock return true here.
        return true;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11096, field_11094, field_11089, field_11088, field_11093);
    }

    @Override
    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        // 1. It can survive if placed directly on Moon Sand
        if (world.method_8320(pos.method_10074()).method_27852(GileMod.MOON_SAND)) {
            return true;
        }

        // 2. Since you have directional properties, it should also survive if attached
        // to the side or bottom of any valid burnable block (vanilla standard fire behavior).
        class_2680 updatedState = this.updateState(world, pos);
        return updatedState.method_11654(field_11096) || updatedState.method_11654(field_11094) ||
                updatedState.method_11654(field_11089) || updatedState.method_11654(field_11088) ||
                updatedState.method_11654(field_11093);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_2350 direction,
            class_2680 neighborState,
            class_1936 world,
            class_2338 pos,
            class_2338 neighborPos
    ) {
        // CRITICAL FIX: If the support block is broken, turn the fire into Air.
        if (!this.method_9558(state, world, pos)) {
            return class_2246.field_10124.method_9564();
        }

        // Otherwise, just update its connection properties
        return updateState(world, pos);
    }

    // You can safely use this method instead of overriding getPlacementState if desired.
    public class_2680 getPlacementState(class_1922 world, class_2338 pos) {
        return updateState(world, pos);
    }

    private class_2680 updateState(class_1922 world, class_2338 pos) {
        return this.method_9564()
                .method_11657(field_11093, isValidFireBase(world.method_8320(pos.method_10084())))
                .method_11657(field_11096, isValidFireBase(world.method_8320(pos.method_10095())))
                .method_11657(field_11089, isValidFireBase(world.method_8320(pos.method_10072())))
                .method_11657(field_11094, isValidFireBase(world.method_8320(pos.method_10078())))
                .method_11657(field_11088, isValidFireBase(world.method_8320(pos.method_10067())));
    }

    private boolean isValidFireBase(class_2680 state) {
        return state.method_50011();
    }
}