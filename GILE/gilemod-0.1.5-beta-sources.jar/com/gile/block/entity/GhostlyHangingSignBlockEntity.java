package com.gile.block.entity;

import com.gile.GileMod;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2625;
import net.minecraft.class_2680;

public class GhostlyHangingSignBlockEntity extends class_2625 {

    public GhostlyHangingSignBlockEntity(class_2338 pos, class_2680 state) {
        super(GileMod.GHOSTLY_HANGING_SIGN_BLOCK_ENTITY, pos, state);
    }

    @Override
    public int method_45469() {
        return 9;
    }

    @Override
    public int method_45470() {
        return 60;
    }

    @Override
    public class_2591<?> method_11017() {
        return GileMod.GHOSTLY_HANGING_SIGN_BLOCK_ENTITY;
    }
}