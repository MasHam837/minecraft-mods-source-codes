package com.gile.block.entity;

import com.gile.GileMod;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2625;
import net.minecraft.class_2680;

public class GhostlySignBlockEntity extends class_2625 {
    public GhostlySignBlockEntity(class_2338 pos, class_2680 state) {
        super(GileMod.GHOSTLY_SIGN_BLOCK_ENTITY, pos, state);
    }

    @Override
    public class_2591<?> method_11017() {
        return GileMod.GHOSTLY_SIGN_BLOCK_ENTITY;
    }

}