package com.gile.block.entity;

import com.gile.GileMod;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1264;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3829;
import net.minecraft.class_3920;
import net.minecraft.class_3922;
import net.minecraft.class_3956;
import net.minecraft.class_5819;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import net.minecraft.class_9696;

public class MoonCampfireBlockEntity extends class_2586 implements class_3829 {
    private final class_2371<class_1799> items;
    private final int[] cookingTimes;
    private final int[] cookingTotalTimes;

    public MoonCampfireBlockEntity(class_2338 pos, class_2680 state) {
        super(GileMod.MOON_CAMPFIRE_ENTITY, pos, state);
        this.items = class_2371.method_10213(4, class_1799.field_8037);
        this.cookingTimes = new int[4];
        this.cookingTotalTimes = new int[4];
    }

    public static void clientTick(class_1937 world, class_2338 pos, class_2680 state, MoonCampfireBlockEntity blockEntity) {
        // Only spawn particles if the campfire is lit
        if (!state.method_11654(class_3922.field_17352)) {
            return;
        }

        class_5819 random = world.field_9229;

        // Check if placed on a hay block (vanilla handles this block state automatically)
        boolean isSignalFire = state.method_11654(class_3922.field_17353);
        net.minecraft.class_2394 smokeParticle = isSignalFire ? class_2398.field_17431 : class_2398.field_17430;
        double yVelocity = isSignalFire ? 0.07 : 0.07; // Double the upward velocity for signal fires

        // Spawn campfire smoke particles
        if (random.method_43057() < 0.11F) {
            for (int i = 0; i < random.method_43048(2) + 2; i++) {
                world.method_8466(
                        smokeParticle,
                        true,
                        pos.method_10263() + 0.5 + random.method_43058() / 3.0 * (random.method_43056() ? 1 : -1),
                        pos.method_10264() + random.method_43058() + random.method_43058(),
                        pos.method_10260() + 0.5 + random.method_43058() / 3.0 * (random.method_43056() ? 1 : -1),
                        0.0,
                        yVelocity,
                        0.0
                );
            }
        }

        // Spawn particles for items cooking
        for (int i = 0; i < blockEntity.items.size(); i++) {
            if (!blockEntity.items.get(i).method_7960() && random.method_43057() < 0.2F) {
                class_2350 direction = class_2350.method_10139(Math.floorMod(i, 4));
                float f = 0.3125F;
                double d = pos.method_10263() + 0.5 - (double)(direction.method_10148() * f) + (double)(direction.method_10170().method_10148() * f);
                double e = pos.method_10264() + 0.5;
                double g = pos.method_10260() + 0.5 - (double)(direction.method_10165() * f) + (double)(direction.method_10170().method_10165() * f);

                world.method_8406(class_2398.field_11251, d, e, g, 0.0, 5.0E-4, 0.0);
            }
        }
    }

    public static void serverTick(class_1937 world, class_2338 pos, class_2680 state, MoonCampfireBlockEntity blockEntity) {
        if (!state.method_11654(class_3922.field_17352)) {
            return;
        }

        boolean hasItems = false;

        for (int i = 0; i < blockEntity.items.size(); i++) {
            class_1799 itemStack = blockEntity.items.get(i);
            if (!itemStack.method_7960()) {
                hasItems = true;
                blockEntity.cookingTimes[i]++;

                if (blockEntity.cookingTimes[i] >= blockEntity.cookingTotalTimes[i]) {
                    class_9696 input = new class_9696(itemStack);
                    class_1799 result = world.method_8433()
                            .method_8132(class_3956.field_17549, input, world)
                            .map(entry -> entry.comp_1933().method_59982(input, world.method_30349()))
                            .orElse(itemStack);

                    class_1264.method_5449(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), result);
                    blockEntity.items.set(i, class_1799.field_8037);
                    blockEntity.updateListeners(); // Sync removal to client
                }
            }
        }

        if (hasItems) {
            blockEntity.method_5431();
        }
    }

    public boolean addItem(@Nullable class_1309 livingEntity, class_1799 stack) {
        for (int i = 0; i < this.items.size(); i++) {
            class_1799 itemStack = this.items.get(i);
            if (itemStack.method_7960()) {
                class_9696 input = new class_9696(stack);
                Optional<class_8786<class_3920>> optional = this.field_11863.method_8433()
                        .method_8132(class_3956.field_17549, input, this.field_11863);

                if (optional.isPresent()) {
                    this.cookingTotalTimes[i] = optional.get().comp_1933().method_8167();
                    this.cookingTimes[i] = 0;
                    this.items.set(i, stack.method_60504(1, livingEntity));
                    this.updateListeners(); // Sync addition to client
                    return true;
                }
            }
        }
        return false;
    }

    public boolean interact(class_1657 player) {
        for (int i = 0; i < this.items.size(); i++) {
            class_1799 itemStack = this.items.get(i);
            if (!itemStack.method_7960()) {
                if (!this.field_11863.field_9236) {
                    class_1264.method_5449(this.field_11863, this.field_11867.method_10263(), this.field_11867.method_10264(), this.field_11867.method_10260(), itemStack);
                }
                this.items.set(i, class_1799.field_8037);
                this.updateListeners(); // Sync clearing to client
                return true;
            }
        }
        return false;
    }

    // Dynamic synchronization helper
    private void updateListeners() {
        this.method_5431();
        if (this.field_11863 != null) {
            this.field_11863.method_8413(this.field_11867, this.method_11010(), this.method_11010(), 3);
        }
    }

    @Override
    @Nullable
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return this.method_38244(registryLookup);
    }

    public class_2371<class_1799> getItems() {
        return this.items;
    }

    @Override
    public void method_5448() {
        this.items.clear();
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11014(nbt, registryLookup);
        this.items.clear();
        net.minecraft.class_1262.method_5429(nbt, this.items, registryLookup);
        if (nbt.method_10573("CookingTimes", 11)) {
            int[] is = nbt.method_10561("CookingTimes");
            System.arraycopy(is, 0, this.cookingTimes, 0, Math.min(this.cookingTotalTimes.length, is.length));
        }
        if (nbt.method_10573("CookingTotalTimes", 11)) {
            int[] is = nbt.method_10561("CookingTotalTimes");
            System.arraycopy(is, 0, this.cookingTotalTimes, 0, Math.min(this.cookingTotalTimes.length, is.length));
        }
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        net.minecraft.class_1262.method_5427(nbt, this.items, true, registryLookup);
        nbt.method_10539("CookingTimes", this.cookingTimes);
        nbt.method_10539("CookingTotalTimes", this.cookingTotalTimes);
    }
}