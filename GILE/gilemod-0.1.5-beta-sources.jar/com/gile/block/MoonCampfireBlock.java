package com.gile.block;

import com.gile.GileMod;
import com.gile.block.entity.MoonCampfireBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3922;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9062;
import org.jetbrains.annotations.Nullable;

public class MoonCampfireBlock extends class_3922 {

    public MoonCampfireBlock(class_2251 settings) {
        super(true, 2, settings);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof MoonCampfireBlockEntity moonCampfire) {
            // Try cooking the item
            if (moonCampfire.addItem(player, stack)) {
                return class_9062.field_47728;
            }
        }

        // Pass to super so Shovels, Water Bottles, and Flint & Steel can run their default logic
        return super.method_55765(stack, state, world, pos, player, hand, hit);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof MoonCampfireBlockEntity moonCampfire) {
            // Try to extract cooked/cooking items when right-clicking with an empty hand
            if (moonCampfire.interact(player)) {
                return class_1269.field_5812;
            }
        }
        return super.method_55766(state, world, pos, player, hit);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MoonCampfireBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.field_9236) {
            return method_31618(type, GileMod.MOON_CAMPFIRE_ENTITY, MoonCampfireBlockEntity::clientTick);
        } else {
            return method_31618(type, GileMod.MOON_CAMPFIRE_ENTITY, MoonCampfireBlockEntity::serverTick);
        }
    }
}