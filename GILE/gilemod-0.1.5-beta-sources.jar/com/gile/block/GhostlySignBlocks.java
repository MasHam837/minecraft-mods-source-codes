package com.gile.block;

import com.gile.GileMod;
import com.gile.block.entity.GhostlyHangingSignBlockEntity;
import com.gile.block.entity.GhostlySignBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2508;
import net.minecraft.class_2551;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4719;
import net.minecraft.class_7713;
import net.minecraft.class_7715;

public class GhostlySignBlocks {
    public static class GhostlySignBlock extends class_2508 {
        public GhostlySignBlock(class_4719 type, class_2251 settings) { super(type, settings); }

        @Override
        public class_2586 method_10123(class_2338 pos, class_2680 state) {
            return new GhostlySignBlockEntity(pos, state);
        }

        @Override
        public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
            if (!world.field_9236 && !player.method_7337()) {
                method_9577(world, pos, new class_1799(GileMod.GHOSTLY_SIGN_ITEM));
            }
            // Remove block entity to prevent onStateReplaced from dropping again
            world.method_8544(pos);
            return super.method_9576(world, pos, state, player);
        }

        @Override
        public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
            if (!state.method_27852(newState.method_26204())) {
                if (!world.field_9236 && world.method_8321(pos) != null) {
                    method_9577(world, pos, new class_1799(GileMod.GHOSTLY_SIGN_ITEM));
                }
                super.method_9536(state, world, pos, newState, moved);
            }
        }
    }

    public static class GhostlyWallSignBlock extends class_2551 {
        public GhostlyWallSignBlock(class_4719 type, class_2251 settings) { super(type, settings); }

        @Override
        public class_2586 method_10123(class_2338 pos, class_2680 state) {
            return new GhostlySignBlockEntity(pos, state);
        }

        @Override
        public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
            if (!world.field_9236 && !player.method_7337()) {
                method_9577(world, pos, new class_1799(GileMod.GHOSTLY_SIGN_ITEM));
            }
            world.method_8544(pos);
            return super.method_9576(world, pos, state, player);
        }

        @Override
        public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
            if (!state.method_27852(newState.method_26204())) {
                if (!world.field_9236 && world.method_8321(pos) != null) {
                    method_9577(world, pos, new class_1799(GileMod.GHOSTLY_SIGN_ITEM));
                }
                super.method_9536(state, world, pos, newState, moved);
            }
        }
    }

    public static class GhostlyHangingSignBlock extends class_7713 {
        public GhostlyHangingSignBlock(class_4719 type, class_2251 settings) { super(type, settings); }

        @Override
        public class_2586 method_10123(class_2338 pos, class_2680 state) {
            return new GhostlyHangingSignBlockEntity(pos, state);
        }

        @Override
        public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
            if (!world.field_9236 && !player.method_7337()) {
                method_9577(world, pos, new class_1799(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
            }
            world.method_8544(pos);
            return super.method_9576(world, pos, state, player);
        }

        @Override
        public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
            if (!state.method_27852(newState.method_26204())) {
                if (!world.field_9236 && world.method_8321(pos) != null) {
                    method_9577(world, pos, new class_1799(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
                }
                super.method_9536(state, world, pos, newState, moved);
            }
        }

        @Override
        public class_4719 method_24025() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }

        public class_4719 getSignType() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }
    }

    public static class GhostlyWallHangingSignBlock extends class_7715 {
        public GhostlyWallHangingSignBlock(class_4719 type, class_2251 settings) { super(type, settings); }

        @Override
        public class_2586 method_10123(class_2338 pos, class_2680 state) {
            return new GhostlyHangingSignBlockEntity(pos, state);
        }

        @Override
        public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
            if (!world.field_9236 && !player.method_7337()) {
                method_9577(world, pos, new class_1799(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
            }
            world.method_8544(pos);
            return super.method_9576(world, pos, state, player);
        }

        @Override
        public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
            if (!state.method_27852(newState.method_26204())) {
                if (!world.field_9236 && world.method_8321(pos) != null) {
                    method_9577(world, pos, new class_1799(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
                }
                super.method_9536(state, world, pos, newState, moved);
            }
        }

        @Override
        public class_4719 method_24025() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }

        public class_4719 getSignType() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }
    }
}