package com.gile.block;

import com.gile.GileMod;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class EndGrass extends class_2261 {
    public static final MapCodec<EndGrass> CODEC = method_54094(EndGrass::new);

    protected static final class_265 SHAPE = class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 13.0, 14.0);

    public EndGrass(class_2251 settings) {
        super(settings);
    }

    @Override
    public MapCodec<EndGrass> method_53969() {
        return field_46280;
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_27852(GileMod.END_GRASS_BLOCK);
    }

    @Override
    public boolean method_9616(class_2680 state, class_1750 context) {
        return true; // This makes it replaceable when placing blocks on it
    }
}