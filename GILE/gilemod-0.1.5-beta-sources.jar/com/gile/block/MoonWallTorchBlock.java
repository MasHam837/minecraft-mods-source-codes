package com.gile.block;

import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2555;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class MoonWallTorchBlock extends class_2555 {
    public MoonWallTorchBlock(class_2251 settings) {
        super(class_2398.field_23190, settings);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2350 dir = state.method_11654(field_11731);
        class_2338 offset = pos.method_10093(dir.method_10153());
        return class_2248.method_20044(world, offset, dir);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        class_2350 direction = state.method_11654(field_11731);
        double x = (double)pos.method_10263() + 0.5;
        double y = (double)pos.method_10264() + 0.7;
        double z = (double)pos.method_10260() + 0.5;
        double offset = -0.27;
        x += direction.method_10148() * offset;
        z += direction.method_10165() * offset;
        for (int i = 0; i < 6; i++) { world.method_8406(class_2398.field_23190,
                x + (random.method_43058() - 0.5) * 0.2,
                y + random.method_43058() * 0.2,
                z + (random.method_43058() - 0.5) * 0.2,
                0.0, 0.0, 0.0);
        }
    }
}