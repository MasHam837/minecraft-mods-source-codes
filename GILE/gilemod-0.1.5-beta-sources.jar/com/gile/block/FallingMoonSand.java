package com.gile.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_2346;

public class FallingMoonSand extends class_2346 {
    public FallingMoonSand(class_2251 settings) {
        super(settings);
    }

    @Override
    public MapCodec<? extends class_2346> method_53969() {
        return method_54094(FallingMoonSand::new);
    }
}