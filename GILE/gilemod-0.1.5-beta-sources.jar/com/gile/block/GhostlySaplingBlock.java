package com.gile.block;

import com.gile.GileMod;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2473;
import net.minecraft.class_2680;
import net.minecraft.class_8813;

public class GhostlySaplingBlock extends class_2473 {

    public GhostlySaplingBlock(class_8813 generator, class_2251 settings) {
        super(generator, settings);
    }

    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_27852(GileMod.END_GRASS_BLOCK) || floor.method_27852(class_2246.field_10471) || floor.method_27852(class_2246.field_10219) || floor.method_27852(class_2246.field_10566);
    }
}