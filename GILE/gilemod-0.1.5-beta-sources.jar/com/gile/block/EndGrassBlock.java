package com.gile.block;

import com.gile.GileMod;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class EndGrassBlock extends class_2248 implements class_2256 {

    public EndGrassBlock(class_2251 settings) {
        super(settings);
    }

    /**
     * Handles the dying behavior. If a solid, opaque block is placed directly
     * on top of this grass, it suffocates and turns back into basic End Stone.
     */
    @Override
    protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_2338 abovePos = pos.method_10084();
        class_2680 aboveState = world.method_8320(abovePos);

        // If the block above is opaque and not air, suffocate the grass
        if (!aboveState.method_26215() && aboveState.method_26212(world, abovePos)) {
            world.method_8501(pos, class_2246.field_10471.method_9564());
        }
    }

    // --- BONE MEAL (FERTILIZABLE) LOGIC ---

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state) {
        // Players can only apply bone meal if there is open air space above the block
        return world.method_8320(pos.method_10084()).method_26215();
    }

    @Override
    public boolean method_9650(class_1937 world, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    /**
     * Executes when bone meal is successfully applied.
     * Spreads grass blocks to nearby End Stone and sprouts custom plants on top.
     */
    @Override
    public void method_9652(class_3218 world, class_5819 random, class_2338 pos, class_2680 state) {
        // 1. SPROUT VEGETATION DIRECTLY ABOVE
        class_2338 directlyAbove = pos.method_10084();
        if (world.method_8320(directlyAbove).method_26215()) {
            if (random.method_43057() < 0.30f) {
                world.method_8501(directlyAbove, GileMod.TALL_END_GRASS.method_9564());
            } else {
                world.method_8501(directlyAbove, GileMod.END_GRASS.method_9564());
            }
        }

        // 2. SPREAD GRASS TO NEIGHBORING END STONE
        // We run a loop to simulate a burst spread radius (similar to moss or nylium)
        for (int i = 0; i < 16; i++) {
            class_2338 targetPos = pos.method_10069(
                    random.method_43048(7) - 3, // X radius: -3 to +3 blocks away
                    random.method_43048(3) - 1, // Y radius: -1 to +1 block vertical shift
                    random.method_43048(7) - 3  // Z radius: -3 to +3 blocks away
            );
            class_2338 targetAbove = targetPos.method_10084();

            // If the picked spot is plain vanilla End Stone with open air above it...
            if (world.method_8320(targetPos).method_27852(class_2246.field_10471) && world.method_8320(targetAbove).method_26215()) {
                // Convert it to your custom End Grass Block!
                world.method_8501(targetPos, this.method_9564());

                // Give it a random chance to instantly sprout your custom grass/tall grass on top
                float plantRoll = random.method_43057();
                if (plantRoll < 0.15f) {
                    world.method_8501(targetAbove, GileMod.TALL_END_GRASS.method_9564());
                } else if (plantRoll < 0.45f) {
                    world.method_8501(targetAbove, GileMod.END_GRASS.method_9564());
                }
            }
        }
    }
}