package com.gile.block;

import com.gile.GileMod;
import net.fabricmc.fabric.api.object.builder.v1.block.type.BlockSetTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.block.type.WoodTypeBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_8177;

public class ModWoodTypes {

    public static final class_8177 GHOSTLY_BLOCK_SET =
            BlockSetTypeBuilder.copyOf(class_8177.field_42823)
                    .register(class_2960.method_60655(GileMod.MOD_ID, "ghostly"));

    public static final class_4719 GHOSTLY_WOOD_TYPE =
            WoodTypeBuilder.copyOf(class_4719.field_21676)
                    .register(class_2960.method_60655(GileMod.MOD_ID, "ghostly"), GHOSTLY_BLOCK_SET);

    public static void init() {
        // No manual registration needed in 1.21.1
    }
}