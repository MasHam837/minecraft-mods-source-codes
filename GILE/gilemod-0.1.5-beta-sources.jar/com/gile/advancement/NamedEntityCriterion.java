package com.gile.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import net.minecraft.class_7923;

public class NamedEntityCriterion extends class_4558<NamedEntityCriterion.Conditions> {
    public static final class_2960 ID = class_2960.method_60655("gilemod", "named_entity");

    // Add this static field
    public static final NamedEntityCriterion CRITERION = new NamedEntityCriterion();

    @Override
    public Codec<Conditions> method_54937() {
        return Conditions.CODEC;
    }

    public void trigger(class_3222 player, class_1297 entity, String name) {
        this.method_22510(player, conditions -> conditions.matches(entity, name));
    }

    public record Conditions(
            Optional<class_5258> player,
            Optional<String> entityType,
            Optional<String> name
    ) implements class_4558.class_8788 {

        public static final Codec<Conditions> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        class_5258.field_47234.optionalFieldOf("player").forGetter(Conditions::comp_2029),
                        Codec.STRING.optionalFieldOf("entity_type").forGetter(Conditions::entityType),
                        Codec.STRING.optionalFieldOf("name").forGetter(Conditions::name)
                ).apply(instance, Conditions::new)
        );

        public boolean matches(class_1297 entity, String entityName) {
            // 1. Check entity type if present
            if (this.entityType.isPresent()) {
                String expectedType = class_7923.field_41177.method_10221(entity.method_5864()).toString();
                // If the type is provided but doesn't match the entity being named, return false
                if (!expectedType.equals(this.entityType.get())) {
                    return false;
                }
            }

            // 2. Check name if present
            if (this.name.isPresent()) {
                // If the name is provided but doesn't match the name given, return false
                if (!this.name.get().equalsIgnoreCase(entityName)) {
                    return false;
                }
            }

            // 3. If both provided checks passed (or were absent), it's a match
            return true;
        }
    }
}