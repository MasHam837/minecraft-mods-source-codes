package com.gile.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import net.minecraft.class_7923;

public class UsedScepterCriterion extends class_4558<UsedScepterCriterion.Conditions> {
    public static final class_2960 ID = class_2960.method_60655("gilemod", "used_scepter");

    // The singleton instance we will call from our items
    public static final UsedScepterCriterion CRITERION = new UsedScepterCriterion();

    @Override
    public Codec<Conditions> method_54937() {
        return Conditions.CODEC;
    }

    // This public method bridges the gap to the protected AbstractCriterion.trigger()
    public void trigger(class_3222 player, class_1799 stack) {
        this.method_22510(player, conditions -> conditions.matches(stack));
    }

    public record Conditions(
            Optional<class_5258> player,
            Optional<String> itemId
    ) implements class_4558.class_8788 {

        public static final Codec<Conditions> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        class_5258.field_47234.optionalFieldOf("player").forGetter(Conditions::comp_2029),
                        Codec.STRING.optionalFieldOf("item_id").forGetter(Conditions::itemId)
                ).apply(instance, Conditions::new)
        );

        public boolean matches(class_1799 stack) {
            if (this.itemId.isPresent()) {
                String expectedType = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                if (!expectedType.equals(this.itemId.get())) {
                    return false;
                }
            }
            return true;
        }
    }
}