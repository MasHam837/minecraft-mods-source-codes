package mh837.gile.client.renderer;

import mh837.gile.entity.HoveringGhostEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class HoveringGhostEntityRenderer extends MobEntityRenderer<HoveringGhostEntity, HoveringGhostEntityRenderer.HoveringGhostModel> {
    // 1. Register distinct layers for the normal layout and the Nyan Cat easter egg variant
    public static final EntityModelLayer GHOST_LAYER = new EntityModelLayer(Identifier.of("gilemod", "hovering_ghost"), "main");
    public static final EntityModelLayer GHOST_NYAN_LAYER = new EntityModelLayer(Identifier.of("gilemod", "hovering_ghost_nyan"), "main");

    // Single texture image sheet (expanded height to 128 to accommodate the +52 V shift)
    private static final Identifier TEXTURE = Identifier.of("gilemod", "textures/entity/hovering_ghost.png");

    private final HoveringGhostModel normalModel;
    private final HoveringGhostModel nyanModel;

    public HoveringGhostEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new HoveringGhostModel(context.getPart(GHOST_LAYER)), 0.6f);
        this.normalModel = new HoveringGhostModel(context.getPart(GHOST_LAYER));
        this.nyanModel = new HoveringGhostModel(context.getPart(GHOST_NYAN_LAYER));
    }

    @Override
    public Identifier getTexture(HoveringGhostEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(HoveringGhostEntity entity, float f, float g, MatrixStack matrixStack,
                       VertexConsumerProvider vertexConsumerProvider, int i) {
        // 2. Dynamically hot-swap active model instances depending on name tag configuration
        if (entity.hasCustomName() && "Nyan Cat".equalsIgnoreCase(entity.getName().getString())) {
            this.model = this.nyanModel;
        } else {
            this.model = this.normalModel;
        }
        super.render(entity, f, g, matrixStack, vertexConsumerProvider, i);
    }

    @Override
    protected void scale(HoveringGhostEntity entity, MatrixStack matrices, float amount) {
        if (entity.isBaby()) {
            matrices.scale(0.5F, 0.5F, 0.5F);
        } else {
            matrices.scale(1.0F, 1.0F, 1.0F);
        }
    }

    // --- INTERNAL MODEL CLASS ---
    public static class HoveringGhostModel extends SinglePartEntityModel<HoveringGhostEntity> {
        private final ModelPart root;
        private final ModelPart cleanBody;
        private final ModelPart saddledBody;
        private final ModelPart ears;

        public HoveringGhostModel(ModelPart root) {
            this.root = root;
            this.cleanBody = root.getChild("clean_body");
            this.saddledBody = root.getChild("saddled_body");
            this.ears = root.getChild("ears");
        }

        public static TexturedModelData getTexturedModelData() {
            return createModelData(false);
        }

        public static TexturedModelData getNyanTexturedModelData() {
            return createModelData(true);
        }

        // 3. Centralized compilation builder that injects a V-offset when processing Nyan variants
        private static TexturedModelData createModelData(boolean isNyanCat) {
            ModelData modelData = new ModelData();
            ModelPartData root = modelData.getRoot();

            // Shift V coordinate downward by 52 pixels if this instance is for Nyan Cat
            int vOffset = isNyanCat ? 58 : 0;

            // Part 1: Clean Variant mapping
            root.addChild("clean_body", ModelPartBuilder.create()
                            .uv(0, vOffset + 0)
                            .cuboid(-12.0F, -12.0F, -20.0F, 24.0F, 12.0F, 40.0F),
                    ModelTransform.pivot(0.0F, 24.0F, 0.0F));

            // Part 2: Saddled Variant mapping shifted 128 pixels right
            root.addChild("saddled_body", ModelPartBuilder.create()
                            .uv(128, vOffset + 0)
                            .cuboid(-12.0F, -12.0F, -20.0F, 24.0F, 12.0F, 40.0F),
                    ModelTransform.pivot(0.0F, 24.0F, 0.0F));

            root.addChild("ears", ModelPartBuilder.create()
                            .uv(0, vOffset + 52)
                            .cuboid(-12.0F,-18.0F,-19.99F,24.0F,6.0F,0.0F),
                    ModelTransform.pivot(0.0F, 24.0F, 0.0F)
            );

            // Expanded texture canvas boundaries to 256x128 to clean up extra mapping rows safely
            return TexturedModelData.of(modelData, 256, 128);
        }

        @Override
        public void setAngles(HoveringGhostEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
            this.root.resetTransform();

            float pivotY = 24.0F + MathHelper.sin(animationProgress * 0.15F) * 1.5F;
            this.cleanBody.pivotY = pivotY;
            this.saddledBody.pivotY = pivotY;
            this.ears.pivotY = pivotY;

            boolean saddled = entity.isSaddled();

            this.cleanBody.visible = !saddled;
            this.saddledBody.visible = saddled;
            this.ears.visible = true;
        }

        @Override
        public ModelPart getPart() {
            return this.root;
        }
    }
}