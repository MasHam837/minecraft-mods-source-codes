package mh837.gile.client.renderer;

import mh837.gile.entity.MothEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class MothEntityRenderer extends MobEntityRenderer<MothEntity, MothEntityRenderer.MothModel> {
    public static final EntityModelLayer MOTH_LAYER = new EntityModelLayer(Identifier.of("gilemod", "moth"), "main");
    public static final EntityModelLayer MOTH_RADIANCE_LAYER = new EntityModelLayer(Identifier.of("gilemod", "moth_radiance"), "main");
    private static final Identifier TEXTURE = Identifier.of("gilemod", "textures/entity/moth.png");

    private final MothModel normalModel;
    private final MothModel radianceModel;

    public MothEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new MothModel(context.getPart(MOTH_LAYER), false), 0.3f);
        this.normalModel = new MothModel(context.getPart(MOTH_LAYER), false);
        this.radianceModel = new MothModel(context.getPart(MOTH_RADIANCE_LAYER), true);}

    @Override
    public Identifier getTexture(MothEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(MothEntity entity, float f, float g, MatrixStack matrixStack,
                       VertexConsumerProvider vertexConsumerProvider, int i) {
        // Swap model based on name
        if (entity.hasCustomName() && entity.getName().getString().equalsIgnoreCase("Radiance")) {
            this.model = this.radianceModel;}
        else {
            this.model = this.normalModel;}
        super.render(entity, f, g, matrixStack, vertexConsumerProvider, i);}

    @Override
    protected void scale(MothEntity entity, MatrixStack matrices, float amount) {
        boolean isRadiance = entity.hasCustomName() && entity.getName().getString().equalsIgnoreCase("Radiance");
        if (entity.isBaby()) {
            matrices.scale(0.5F, 0.5F, 0.5F);}
        else if (isRadiance) {
            matrices.scale(1.2F, 1.2F, 1.2F);}
        else {
            matrices.scale(1.0F, 1.0F, 1.0F);}}

    // --- INTERNAL MODEL CLASS ---
    public static class MothModel extends SinglePartEntityModel<MothEntity> {
        private final ModelPart root;
        private final ModelPart body;
        private final ModelPart head;
        private final ModelPart leftWingFront, leftWingBack;
        private final ModelPart rightWingFront, rightWingBack;
        private final boolean isRadiance;

        public MothModel(ModelPart root, boolean isRadiance) {
            this.root = root;
            this.isRadiance = isRadiance;
            this.body = root.getChild("body");
            this.head = root.getChild("head");
            this.leftWingFront = root.getChild("left_wing_front");
            this.leftWingBack = root.getChild("left_wing_back");
            this.rightWingFront = root.getChild("right_wing_front");
            this.rightWingBack = root.getChild("right_wing_back");}

        public static TexturedModelData getTexturedModelData() {
            return createModelData(false);
        }

        public static TexturedModelData getRadianceTexturedModelData() {
            return createModelData(true);
        }

        private static TexturedModelData createModelData(boolean isRadiance) {
            ModelData modelData = new ModelData();
            ModelPartData modelPartData = modelData.getRoot();

            int uvOffset = isRadiance ? 32 : 0;

            // ===== BODY =====
            modelPartData.addChild("body", ModelPartBuilder.create()
                            .uv(uvOffset + 0, 17)
                            .cuboid(-2.5F, -1.0F, -2.5F, 5.0F, 1.5F, 6.0F),
                    ModelTransform.pivot(0.0F, 21.5F, -1.0F));

            // ===== HEAD =====
            ModelPartData headData = modelPartData.addChild("head", ModelPartBuilder.create()
                            .uv(uvOffset + 0, 11)
                            .cuboid(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 3.0F),
                    ModelTransform.pivot(0.0F, 21.5F, -2.5F));

            // Eyes
            headData.addChild("eye_left", ModelPartBuilder.create()
                            .uv(uvOffset + 11, 11)
                            .cuboid(0.5F, -1.5F, -3.3F, 2.0F, 2.0F, 1.0F),
                    ModelTransform.NONE);

            headData.addChild("eye_right", ModelPartBuilder.create()
                            .uv(uvOffset + 11, 11)
                            .mirrored()
                            .cuboid(-2.5F, -1.5F, -3.3F, 2.0F, 2.0F, 1.0F),
                    ModelTransform.NONE);

            // Antennae
            headData.addChild("antenna_left", ModelPartBuilder.create()
                            .uv(uvOffset + 14, 14)
                            .cuboid(-1.0F, -3.0F, 0.0F, 2.0F, 3.0F, 0.0F),
                    ModelTransform.of(1.3F, -1.5F, -2.5F, 0.3F, 0.2F, 0.3F));

            headData.addChild("antenna_right", ModelPartBuilder.create()
                            .uv(uvOffset + 14, 14)
                            .mirrored()
                            .cuboid(-1.0F, -3.0F, 0.0F, 2.0F, 3.0F, 0.0F),
                    ModelTransform.of(-1.3F, -1.5F, -2.5F, 0.3F, -0.2F, -0.3F));

            // ===== FRONT WINGS =====
            modelPartData.addChild("left_wing_front", ModelPartBuilder.create()
                            .uv(uvOffset + 0, 0)
                            .cuboid(0.0F, 0.0F, -3.0F, 10.0F, 0.0F, 6.0F),
                    ModelTransform.of(2.0F, 21.0F, -1.0F, 0.0F, 0.0F, 0.15F));

            modelPartData.addChild("right_wing_front", ModelPartBuilder.create()
                            .uv(uvOffset + 0, 0)
                            .mirrored()
                            .cuboid(-10.0F, 0.0F, -3.0F, 10.0F, 0.0F, 6.0F),
                    ModelTransform.of(-2.0F, 21.0F, -1.0F, 0.0F, 0.0F, -0.15F));

            // ===== BACK WINGS =====
            modelPartData.addChild("left_wing_back", ModelPartBuilder.create()
                            .uv(uvOffset + 0, 6)
                            .cuboid(0.0F, 0.0F, -2.0F, 8.0F, 0.0F, 5.0F),
                    ModelTransform.of(2.0F, 21.0F, 1.0F, 0.0F, 0.0F, 0.1F));

            modelPartData.addChild("right_wing_back", ModelPartBuilder.create()
                            .uv(uvOffset + 0, 6)
                            .mirrored()
                            .cuboid(-8.0F, 0.0F, -2.0F, 8.0F, 0.0F, 5.0F),
                    ModelTransform.of(-2.0F, 21.0F, 1.0F, 0.0F, 0.0F, -0.1F));

            // ===== LEGS =====
            for (int i = 0; i < 3; i++) {
                modelPartData.addChild("leg_left_" + i, ModelPartBuilder.create()
                                .uv(uvOffset + 0, 21)
                                .cuboid(0.0F, 0.0F, 0.0F, 2.0F, 1.0F, 1.0F),
                        ModelTransform.pivot(2.0F, 22.5F, -2.0F + (i * 2.0F)));

                modelPartData.addChild("leg_right_" + i, ModelPartBuilder.create()
                                .uv(uvOffset + 0, 21)
                                .mirrored()
                                .cuboid(-2.0F, 0.0F, 0.0F, 2.0F, 1.0F, 1.0F),
                        ModelTransform.pivot(-2.0F, 22.5F, -2.0F + (i * 2.0F)));
            }
            return TexturedModelData.of(modelData, 64, 64);
        }

        @Override
        public void setAngles(MothEntity entity, float limbAngle, float limbDistance,
                              float animationProgress, float headYaw, float headPitch) {
            float flapSpeed = isRadiance ? 0.5F : 0.7F;
            float flapAmount = isRadiance ? 0.7F : 0.9F;

            float flap = MathHelper.sin(animationProgress * flapSpeed) * flapAmount;

            this.leftWingFront.roll = flap;
            this.rightWingFront.roll = -flap;

            float backFlap = MathHelper.sin(animationProgress * flapSpeed + 0.3F) * flapAmount * 0.8F;
            this.leftWingBack.roll = backFlap;
            this.rightWingBack.roll = -backFlap;

            this.head.yaw = headYaw * 0.017453292F;
            this.head.pitch = headPitch * 0.017453292F;}

        @Override
        public ModelPart getPart() {
            return this.root;
        }

    }
}