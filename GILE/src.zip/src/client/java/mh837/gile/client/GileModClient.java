package mh837.gile.client;

import mh837.gile.GileMod;
import mh837.gile.block.ModWoodTypes;
import mh837.gile.client.model.WeaselThiefModel;
import mh837.gile.client.renderer.*;
import mh837.gile.network.ActiveAbilityPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.object.builder.v1.client.model.FabricModelPredicateProviderRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;
import net.minecraft.client.render.block.entity.HangingSignBlockEntityRenderer;
import net.minecraft.client.render.block.entity.SignBlockEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class GileModClient implements ClientModInitializer {

	public static final EntityModelLayer WEASEL_MODEL_LAYER = new EntityModelLayer(Identifier.of(GileMod.MOD_ID, "weasel_thief"), "main");

	@Override
	public void onInitializeClient() {

		// Translucent blocks rendering registrations:
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_FLOWER, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_MOON_FLOWER, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GLOOMY_FLOWER, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_GLOOMY_FLOWER, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.DRY_FLOWER, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_DRY_FLOWER, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GHOSTLY_SAPLING, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.POTTED_GHOSTLY_SAPLING, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.END_GRASS, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.TALL_END_GRASS, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.PEARLESCENT_CHAIN, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_LANTERN, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GHOSTLY_DOOR, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.GHOSTLY_TRAPDOOR, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.END_CLOUD, RenderLayer.getTranslucent());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.STAR, RenderLayer.getTranslucent());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_FIRE, RenderLayer.getCutout());
		BlockRenderLayerMap.INSTANCE.putBlock(GileMod.MOON_CAMPFIRE, RenderLayer.getCutout());

		// MEGA ULTRA STRANGE BLOCK-ENTITY registrations:
		TexturedRenderLayers.SIGN_TYPE_TEXTURES.put(ModWoodTypes.GHOSTLY_WOOD_TYPE,
				new SpriteIdentifier(TexturedRenderLayers.SIGNS_ATLAS_TEXTURE,
						Identifier.of("gilemod", "entity/signs/ghostly")));

		TexturedRenderLayers.HANGING_SIGN_TYPE_TEXTURES.put(ModWoodTypes.GHOSTLY_WOOD_TYPE,
				new SpriteIdentifier(TexturedRenderLayers.SIGNS_ATLAS_TEXTURE,
						Identifier.of("gilemod", "entity/signs/hanging/ghostly")));

		// Block Entity Renderer Factories
		BlockEntityRendererFactories.register(GileMod.GHOSTLY_SIGN_BLOCK_ENTITY, SignBlockEntityRenderer::new);
		BlockEntityRendererFactories.register(GileMod.GHOSTLY_HANGING_SIGN_BLOCK_ENTITY, HangingSignBlockEntityRenderer::new);
		BlockEntityRendererFactories.register(GileMod.MOON_CAMPFIRE_ENTITY, MoonCampfireBlockEntityRenderer::new);

		// Entity rendering registrations:
		EntityRendererRegistry.register(GileMod.FATE_ARROW_TYPE, FateArrowEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.VOID_SLIME, VoidSlimeEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.MOTH, MothEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.VENTI_ARROW_TYPE, VentiArrowEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.LUMINOUS, LuminousEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.HOVERING_GHOST, HoveringGhostEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.JERBOA, JerboaEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.GLOOMY_LYNX, GloomyLynxEntityRenderer::new);
		EntityRendererRegistry.register(GileMod.WEASEL_THIEF, WeaselThiefEntityRenderer::new);

		// Model layer of complex entities registrations:
		EntityModelLayerRegistry.registerModelLayer(MothEntityRenderer.MOTH_LAYER, MothEntityRenderer.MothModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(MothEntityRenderer.MOTH_RADIANCE_LAYER, MothEntityRenderer.MothModel::getRadianceTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(LuminousEntityRenderer.LUMINOUS_LAYER, LuminousEntityRenderer.LuminousModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(HoveringGhostEntityRenderer.GHOST_LAYER, HoveringGhostEntityRenderer.HoveringGhostModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(HoveringGhostEntityRenderer.GHOST_NYAN_LAYER, HoveringGhostEntityRenderer.HoveringGhostModel::getNyanTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(JerboaEntityRenderer.JERBOA_LAYER, JerboaEntityRenderer.JerboaModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(GloomyLynxEntityRenderer.LYNX_LAYER, GloomyLynxEntityRenderer.LynxModel::getTexturedModelData);
		EntityModelLayerRegistry.registerModelLayer(WEASEL_MODEL_LAYER, WeaselThiefModel::getTexturedModelData);

		// Bow pulling animations:
		FabricModelPredicateProviderRegistry.register(GileMod.FATE_BOW, Identifier.of("pull"),
				(stack, world, entity, seed) -> {
					if (entity == null) return 0.0F;
					if (entity.getActiveItem() != stack) return 0.0F;
					return (stack.getMaxUseTime(entity) - entity.getItemUseTimeLeft()) / 20.0F;
				});
		FabricModelPredicateProviderRegistry.register(GileMod.FATE_BOW, Identifier.of("pulling"),
				(stack, world, entity, seed) -> {
					return entity != null && entity.isUsingItem() && entity.getActiveItem() == stack ? 1.0F : 0.0F;
				});

		FabricModelPredicateProviderRegistry.register(GileMod.DAYBREAK_CHRONICLES, Identifier.of("pull"),
				(stack, world, entity, seed) -> {
					if (entity == null) return 0.0F;
					if (entity.getActiveItem() != stack) return 0.0F;
					return (stack.getMaxUseTime(entity) - entity.getItemUseTimeLeft()) / 20.0F;
				});
		FabricModelPredicateProviderRegistry.register(GileMod.DAYBREAK_CHRONICLES, Identifier.of("pulling"),
				(stack, world, entity, seed) -> {
					return entity != null && entity.isUsingItem() && entity.getActiveItem() == stack ? 1.0F : 0.0F;
				});

		// Keybinds:
		KeyBinding activeAbilityKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.gilemod.active_ability", // Update this in your en_us.json too!
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_V,
				"category.gilemod.keys"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (activeAbilityKey.wasPressed()) {
				if (client.player != null) {
					// Send the signal to the server
					ClientPlayNetworking.send(new ActiveAbilityPayload());
				}
			}
		});

	}
}