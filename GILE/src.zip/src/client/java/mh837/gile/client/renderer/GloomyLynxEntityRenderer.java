package mh837.gile.client.renderer;

import mh837.gile.GileMod;
import mh837.gile.entity.GloomyLynxEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class GloomyLynxEntityRenderer extends MobEntityRenderer<GloomyLynxEntity, GloomyLynxEntityRenderer.LynxModel> {

    public static final EntityModelLayer LYNX_LAYER = new EntityModelLayer(Identifier.of(GileMod.MOD_ID, "gloomy_lynx"), "main");
    private static final Identifier TEXTURE = Identifier.of(GileMod.MOD_ID, "textures/entity/gloomy_lynx.png");

    public GloomyLynxEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new LynxModel(context.getPart(LYNX_LAYER)), 0.5F);
    }

    @Override
    public Identifier getTexture(GloomyLynxEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(GloomyLynxEntity entity, MatrixStack matrices, float amount) {
        super.scale(entity, matrices, amount);
        if (entity.isBaby()) {
            matrices.scale(0.5F, 0.5F, 0.5F);
        }
    }

    // INTERNAL MODEL CLASS
    public static class LynxModel extends SinglePartEntityModel<GloomyLynxEntity> {
        private final ModelPart root;
        private final ModelPart headNormal;
        private final ModelPart headAngry;
        private final ModelPart body;
        private final ModelPart frontLeftLeg;
        private final ModelPart frontRightLeg;
        private final ModelPart backLeftLeg;
        private final ModelPart backRightLeg;
        private final ModelPart tail;

        public LynxModel(ModelPart root) {
            this.root = root;
            this.headNormal = root.getChild("head_normal");
            this.headAngry = root.getChild("head_angry");
            this.body = root.getChild("body");
            this.frontLeftLeg = root.getChild("front_left_leg");
            this.frontRightLeg = root.getChild("front_right_leg");
            this.backLeftLeg = root.getChild("back_left_leg");
            this.backRightLeg = root.getChild("back_right_leg");
            this.tail = root.getChild("tail");
        }

        public static TexturedModelData getTexturedModelData() {
            ModelData modelData = new ModelData();
            ModelPartData modelPartData = modelData.getRoot();

            modelPartData.addChild("head_normal", ModelPartBuilder.create()
                            .uv(0, 0).cuboid(-3.0F, -4.0F, -4.0F, 6.0F, 6.0F, 5.0F)
                            .uv(0, 11).cuboid(-4.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                            .uv(0, 11).cuboid(2.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F),
                    ModelTransform.pivot(0.0F, 13.0F, -8.0F));

            // Fixed: Ear coordinates now mirror head_normal exactly, retaining only the angry UV mapping
            modelPartData.addChild("head_angry", ModelPartBuilder.create()
                            .uv(32, 0).cuboid(-3.0F, -4.0F, -4.0F, 6.0F, 6.0F, 5.0F)
                            .uv(32, 11).cuboid(-4.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                            .uv(32, 11).cuboid(2.0F, -5.0F, -2.0F, 2.0F, 3.0F, 1.0F),
                    ModelTransform.pivot(0.0F, 13.0F, -8.0F));

            modelPartData.addChild("body", ModelPartBuilder.create()
                            .uv(0, 16).cuboid(-4.0F, -8.0F, -4.0F, 8.0F, 18.0F, 8.0F),
                    ModelTransform.of(0.0F, 14.0F, 0.0F, 1.5708F, 0.0F, 0.0F));

            modelPartData.addChild("front_left_leg", ModelPartBuilder.create()
                            .uv(32, 16).cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    ModelTransform.pivot(2.0F, 14.0F, -6.0F));

            modelPartData.addChild("front_right_leg", ModelPartBuilder.create()
                            .uv(32, 16).cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    ModelTransform.pivot(-2.0F, 14.0F, -6.0F));

            modelPartData.addChild("back_left_leg", ModelPartBuilder.create()
                            .uv(44, 16).cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    ModelTransform.pivot(2.0F, 14.0F, 7.0F));

            modelPartData.addChild("back_right_leg", ModelPartBuilder.create()
                            .uv(44, 16).cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F),
                    ModelTransform.pivot(-2.0F, 14.0F, 7.0F));

            modelPartData.addChild("tail", ModelPartBuilder.create()
                            .uv(0, 42).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F),
                    ModelTransform.of(0.0F, 13.0F, 8.0F, 0.7854F, 0.0F, 0.0F));

            return TexturedModelData.of(modelData, 64, 64);
        }

        @Override
        public void setAngles(GloomyLynxEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
            this.root.traverse().forEach(ModelPart::resetTransform);

            boolean angry = entity.isAngry();
            this.headNormal.visible = !angry;
            this.headAngry.visible = angry;

            float yaw = headYaw * ((float)Math.PI / 180F);
            float pitch = headPitch * ((float)Math.PI / 180F);
            this.headNormal.yaw = yaw;
            this.headNormal.pitch = pitch;
            this.headAngry.yaw = yaw;
            this.headAngry.pitch = pitch;

            this.frontRightLeg.pitch = MathHelper.cos(limbAngle * 0.6662F) * 1.4F * limbDistance;
            this.frontLeftLeg.pitch = MathHelper.cos(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
            this.backRightLeg.pitch = MathHelper.cos(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
            this.backLeftLeg.pitch = MathHelper.cos(limbAngle * 0.6662F) * 1.4F * limbDistance;

            if (angry) {
                this.tail.yaw = MathHelper.cos(animationProgress * 0.5F) * 0.5F;
                this.tail.pitch = 1.0F;
            } else {
                this.tail.yaw = MathHelper.cos(limbAngle * 0.6662F) * 0.3F * limbDistance;
                this.tail.pitch = 0.7854F;
            }
        }

        @Override
        public ModelPart getPart() {
            return this.root;
        }
    }
}