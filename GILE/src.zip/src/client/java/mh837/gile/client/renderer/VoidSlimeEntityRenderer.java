package mh837.gile.client.renderer;

import mh837.gile.GileMod;
import mh837.gile.entity.VoidSlimeEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.SlimeOverlayFeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.SlimeEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class VoidSlimeEntityRenderer extends MobEntityRenderer<VoidSlimeEntity, SlimeEntityModel<VoidSlimeEntity>> {
    private static final Identifier TEXTURE = Identifier.of(GileMod.MOD_ID, "textures/entity/void_slime.png");

    public VoidSlimeEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new SlimeEntityModel<>(context.getPart(EntityModelLayers.SLIME)), 0.25F);
        // Add the overlay feature renderer for the semi-transparent outer layer
        this.addFeature(new SlimeOverlayFeatureRenderer<>(this, context.getModelLoader()));}

    @Override
    protected void scale(VoidSlimeEntity slime, MatrixStack matrices, float amount) {
        matrices.scale(1.5F, 1.5F, 1.5F);}

    @Override
    public Identifier getTexture(VoidSlimeEntity entity) {
        return TEXTURE;
    }
}