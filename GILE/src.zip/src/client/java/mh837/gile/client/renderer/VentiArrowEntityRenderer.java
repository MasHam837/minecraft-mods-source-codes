package mh837.gile.client.renderer;

import mh837.gile.entity.VentiArrowEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ProjectileEntityRenderer;
import net.minecraft.util.Identifier;

public class VentiArrowEntityRenderer extends ProjectileEntityRenderer<VentiArrowEntity> {
    private static final Identifier TEXTURE = Identifier.of("gilemod", "textures/entity/venti_arrow.png");

    public VentiArrowEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public Identifier getTexture(VentiArrowEntity entity) {
        return TEXTURE;
    }
}