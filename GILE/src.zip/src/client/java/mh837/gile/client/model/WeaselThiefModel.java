package mh837.gile.client.model;

import mh837.gile.entity.WeaselThiefEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;

public class WeaselThiefModel<T extends WeaselThiefEntity> extends SinglePartEntityModel<T> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart legs;

    public WeaselThiefModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.legs = root.getChild("legs");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData modelPartData = modelData.getRoot();

        // Head
        modelPartData.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-2.0F, -2.0F, -3.0F, 4.0F, 4.0F, 5.0F), ModelTransform.pivot(0.0F, 19.0F, -5.0F));

        // Body (Long)
        modelPartData.addChild("body", ModelPartBuilder.create().uv(18, 0).cuboid(-2.5F, -2.5F, -5.0F, 5.0F, 4.0F, 10.0F), ModelTransform.pivot(0.0F, 20.0F, 0.0F));

        // Big Coin Backpack / Sack
        modelPartData.addChild("sack", ModelPartBuilder.create().uv(0, 14).cuboid(-3.5F, -6.0F, -3.0F, 7.0F, 6.0F, 8.0F), ModelTransform.pivot(0.0F, 18.0F, 0.0F));

        // Tail
        modelPartData.addChild("tail", ModelPartBuilder.create().uv(30, 14).cuboid(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 6.0F), ModelTransform.pivot(0.0F, 19.5F, 5.0F));

        // 4 Legs grouped
        ModelPartData legsData = modelPartData.addChild("legs", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 24.0F, 0.0F));
        legsData.addChild("leg1", ModelPartBuilder.create().uv(0, 28).cuboid(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), ModelTransform.pivot(-1.5F, 0.0F, -4.0F));
        legsData.addChild("leg2", ModelPartBuilder.create().uv(0, 28).cuboid(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), ModelTransform.pivot(1.5F, 0.0F, -4.0F));
        legsData.addChild("leg3", ModelPartBuilder.create().uv(0, 28).cuboid(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), ModelTransform.pivot(-1.5F, 0.0F, 4.0F));
        legsData.addChild("leg4", ModelPartBuilder.create().uv(0, 28).cuboid(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F), ModelTransform.pivot(1.5F, 0.0F, 4.0F));

        return TexturedModelData.of(modelData, 64, 32);
    }

    @Override
    public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.head.pitch = headPitch * ((float)Math.PI / 180F);
        this.head.yaw = headYaw * ((float)Math.PI / 180F);

        // Simple leg wiggling when running
        this.legs.getChild("leg1").pitch = (float)Math.cos(limbAngle * 0.6662F) * 1.4F * limbDistance;
        this.legs.getChild("leg2").pitch = (float)Math.cos(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
        this.legs.getChild("leg3").pitch = (float)Math.cos(limbAngle * 0.6662F + (float)Math.PI) * 1.4F * limbDistance;
        this.legs.getChild("leg4").pitch = (float)Math.cos(limbAngle * 0.6662F) * 1.4F * limbDistance;
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }
}