package mh837.gile.client.renderer;

import mh837.gile.block.entity.MoonCampfireBlockEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;

public class MoonCampfireBlockEntityRenderer implements BlockEntityRenderer<MoonCampfireBlockEntity> {
    private final ItemRenderer itemRenderer;

    public MoonCampfireBlockEntityRenderer(BlockEntityRendererFactory.Context ctx) {
        this.itemRenderer = ctx.getItemRenderer();
    }

    @Override
    public void render(MoonCampfireBlockEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
        Direction direction = entity.getCachedState().get(net.minecraft.block.CampfireBlock.FACING);
        DefaultedList<ItemStack> items = entity.getItems();
        int seed = (int) entity.getPos().asLong();

        for (int i = 0; i < items.size(); i++) {
            ItemStack itemStack = items.get(i);
            if (!itemStack.isEmpty()) {
                matrices.push();
                // Position above the campfire base
                matrices.translate(0.5, 0.44921875, 0.5);
                Direction rotationDir = Direction.fromHorizontal((i + direction.getHorizontal()) % 4);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-rotationDir.asRotation()));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
                matrices.translate(-0.3125, -0.3125, 0.0);
                matrices.scale(0.375F, 0.375F, 0.375F);

                this.itemRenderer.renderItem(itemStack, ModelTransformationMode.FIXED, light, overlay, matrices, vertexConsumers, entity.getWorld(), seed + i);
                matrices.pop();
            }
        }
    }
}