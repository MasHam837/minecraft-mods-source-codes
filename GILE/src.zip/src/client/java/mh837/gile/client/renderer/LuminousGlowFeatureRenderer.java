package mh837.gile.client.renderer;

import mh837.gile.entity.LuminousEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.util.math.MatrixStack;

public class LuminousGlowFeatureRenderer extends FeatureRenderer<LuminousEntity, LuminousEntityRenderer.LuminousModel> {

    public LuminousGlowFeatureRenderer(FeatureRendererContext<LuminousEntity, LuminousEntityRenderer.LuminousModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, LuminousEntity entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        // RenderLayer.getEyes() makes it immune to block lighting (glows in the dark)
        VertexConsumer vertexConsumer = vertexConsumers.getBuffer(RenderLayer.getEyes(this.getTexture(entity)));

        // 15728640 is the maximum light value map used for emissive rendering in Vanilla Minecraft
        this.getContextModel().render(matrices, vertexConsumer, 15728640, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
    }
}