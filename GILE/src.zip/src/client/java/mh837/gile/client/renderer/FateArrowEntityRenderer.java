package mh837.gile.client.renderer;

import mh837.gile.entity.FateArrowEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ProjectileEntityRenderer;
import net.minecraft.util.Identifier;

public class FateArrowEntityRenderer extends ProjectileEntityRenderer<FateArrowEntity> {
    private static final Identifier TEXTURE = Identifier.of("gilemod", "textures/entity/fate_arrow.png");

    public FateArrowEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public Identifier getTexture(FateArrowEntity entity) {
        return TEXTURE;
    }
}