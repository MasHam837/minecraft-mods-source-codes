package mh837.gile.client.renderer;

import mh837.gile.client.GileModClient;
import mh837.gile.client.model.WeaselThiefModel;
import mh837.gile.entity.WeaselThiefEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class WeaselThiefEntityRenderer extends MobEntityRenderer<WeaselThiefEntity, WeaselThiefModel<WeaselThiefEntity>> {

    public WeaselThiefEntityRenderer(EntityRendererFactory.Context context) {
        // 0.4f is the shadow radius
        super(context, new WeaselThiefModel<>(context.getPart(GileModClient.WEASEL_MODEL_LAYER)), 0.4f);
    }

    @Override
    public Identifier getTexture(WeaselThiefEntity entity) {
        // Loads from: assets/gilemod/textures/entity/weasel/amateur.png (or hoarder.png / golden.png)
        return Identifier.of("gilemod", "textures/entity/weasel/" + entity.getVariant().asString() + ".png");
    }
}