package mh837.gile.client.renderer;

import mh837.gile.GileMod;
import mh837.gile.entity.JerboaEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class JerboaEntityRenderer extends MobEntityRenderer<JerboaEntity, JerboaEntityRenderer.JerboaModel> {

    public static final EntityModelLayer JERBOA_LAYER = new EntityModelLayer(Identifier.of(GileMod.MOD_ID, "jerboa"), "main");
    private static final Identifier TEXTURE = Identifier.of(GileMod.MOD_ID, "textures/entity/jerboa.png");

    public JerboaEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new JerboaModel(context.getPart(JERBOA_LAYER)), 0.3F);
    }

    @Override
    public Identifier getTexture(JerboaEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(JerboaEntity entity, MatrixStack matrices, float amount) {
        if (entity.isHiding()) {
            matrices.scale(1.0f, 0.15f, 1.0f);
        }
        if (entity.isBaby()) {
            matrices.scale(0.5F, 0.5F, 0.5F);
        }
        super.scale(entity, matrices, amount);
    }

    public static class JerboaModel extends SinglePartEntityModel<JerboaEntity> {
        private final ModelPart root;

        // Normal Parts
        private final ModelPart bodyNormal, headNormal, leftEarNormal, rightEarNormal, tailNormal;
        // Desert Parts
        private final ModelPart bodyDesert, headDesert, leftEarDesert, rightEarDesert, tailDesert;

        public JerboaModel(ModelPart root) {
            this.root = root;

            this.bodyNormal = root.getChild("body");
            this.headNormal = root.getChild("head");
            this.leftEarNormal = headNormal.getChild("left_ear");
            this.rightEarNormal = headNormal.getChild("right_ear");
            this.tailNormal = root.getChild("tail");

            this.bodyDesert = root.getChild("body_desert");
            this.headDesert = root.getChild("head_desert");
            this.leftEarDesert = headDesert.getChild("left_ear_desert");
            this.rightEarDesert = headDesert.getChild("right_ear_desert");
            this.tailDesert = root.getChild("tail_desert");
        }

        public static TexturedModelData getTexturedModelData() {
            ModelData modelData = new ModelData();
            ModelPartData root = modelData.getRoot();

            // --- NORMAL VARIANT (UVs mapped to top half of texture) ---
            root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-2.5F, -3.0F, -3.5F, 5.0F, 4.0F, 7.0F), ModelTransform.pivot(0.0F, 22.0F, 0.0F));
            ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(0, 11).cuboid(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 4.0F), ModelTransform.pivot(0.0F, 20.5F, -2.5F));
            head.addChild("left_ear", ModelPartBuilder.create().uv(17, 0).cuboid(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), ModelTransform.pivot(1.0F, -2.0F, -1.0F));
            head.addChild("right_ear", ModelPartBuilder.create().uv(21, 0).cuboid(-1.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), ModelTransform.pivot(-1.0F, -2.0F, -1.0F));
            root.addChild("tail", ModelPartBuilder.create().uv(16, 12).cuboid(-0.5F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F), ModelTransform.of(0.0F, 20.0F, 3.0F, 0.8F, 0.0F, 0.0F));

            // --- DESERT VARIANT (UVs shifted down by 24 pixels) ---
            root.addChild("body_desert", ModelPartBuilder.create().uv(0, 24).cuboid(-2.5F, -3.0F, -3.5F, 5.0F, 4.0F, 7.0F), ModelTransform.pivot(0.0F, 22.0F, 0.0F));
            ModelPartData headDesert = root.addChild("head_desert", ModelPartBuilder.create().uv(0, 35).cuboid(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 4.0F), ModelTransform.pivot(0.0F, 20.5F, -2.5F));
            headDesert.addChild("left_ear_desert", ModelPartBuilder.create().uv(17, 24).cuboid(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), ModelTransform.pivot(1.0F, -2.0F, -1.0F));
            headDesert.addChild("right_ear_desert", ModelPartBuilder.create().uv(21, 24).cuboid(-1.0F, -4.0F, 0.0F, 1.0F, 4.0F, 1.0F), ModelTransform.pivot(-1.0F, -2.0F, -1.0F));
            root.addChild("tail_desert", ModelPartBuilder.create().uv(16, 36).cuboid(-0.5F, 0.0F, 0.0F, 1.0F, 5.0F, 1.0F), ModelTransform.of(0.0F, 20.0F, 3.0F, 0.8F, 0.0F, 0.0F));

            // Expanding texture height to fit both models seamlessly
            return TexturedModelData.of(modelData, 32, 48);
        }

        @Override
        public void setAngles(JerboaEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
            boolean isDesert = entity.isDesertVariant();

            // Toggle visibility of the geometry
            this.bodyNormal.visible = !isDesert;
            this.headNormal.visible = !isDesert;
            this.tailNormal.visible = !isDesert;

            this.bodyDesert.visible = isDesert;
            this.headDesert.visible = isDesert;
            this.tailDesert.visible = isDesert;

            // Fetch active geometry to apply animations seamlessly
            ModelPart body = isDesert ? this.bodyDesert : this.bodyNormal;
            ModelPart head = isDesert ? this.headDesert : this.headNormal;
            ModelPart leftEar = isDesert ? this.leftEarDesert : this.leftEarNormal;
            ModelPart rightEar = isDesert ? this.rightEarDesert : this.rightEarNormal;
            ModelPart tail = isDesert ? this.tailDesert : this.tailNormal;

            body.resetTransform();
            head.resetTransform();
            leftEar.resetTransform();
            rightEar.resetTransform();
            tail.resetTransform();

            if (entity.isHiding()) {
                body.pivotY += 4.0F;
                head.pivotY += 4.0F;
                leftEar.pitch = -1.2f;
                rightEar.pitch = -1.2f;
                return;
            }

            float hop = MathHelper.cos(limbAngle * 1.4f) * 1.2f * limbDistance;

            body.pitch = hop * 0.15f;
            head.yaw = headYaw * 0.017453292F;
            head.pitch = headPitch * 0.017453292F;
            tail.yaw = MathHelper.cos(animationProgress * 0.2f) * 0.15f;
            leftEar.roll = MathHelper.cos(animationProgress * 0.15f) * 0.05f;
            rightEar.roll = -leftEar.roll;
        }

        @Override
        public ModelPart getPart() {
            return this.root;
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, int color) {
            root.render(matrices, vertices, light, overlay, color);
        }
    }
}