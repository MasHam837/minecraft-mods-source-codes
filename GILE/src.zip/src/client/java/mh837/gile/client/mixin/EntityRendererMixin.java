package mh837.gile.client.mixin;

import mh837.gile.GileMod;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity> {

    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    protected void hideShrinkLabel(T entity, CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof LivingEntity livingEntity) {
            // If the entity is shrunk, tell the game it does not have a label
            if (livingEntity.hasStatusEffect(GileMod.SHRINK_EFFECT)) {
                cir.setReturnValue(false);
            }
        }
    }
}