package mh837.gile.client.renderer;

import mh837.gile.entity.LuminousEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class LuminousEntityRenderer extends MobEntityRenderer<LuminousEntity, LuminousEntityRenderer.LuminousModel> {
    public static final EntityModelLayer LUMINOUS_LAYER = new EntityModelLayer(Identifier.of("gilemod", "luminous"), "main");

    private static final Identifier YELLOW_TEXTURE = Identifier.of("gilemod", "textures/entity/luminous/yellow.png");
    private static final Identifier LIGHT_BLUE_TEXTURE = Identifier.of("gilemod", "textures/entity/luminous/light_blue.png");
    private static final Identifier PINK_TEXTURE = Identifier.of("gilemod", "textures/entity/luminous/pink.png");

    public LuminousEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new LuminousModel(context.getPart(LUMINOUS_LAYER)), 0.4f);
        this.addFeature(new LuminousGlowFeatureRenderer(this));
    }

    // Add this method anywhere inside your LuminousEntityRenderer class
    @Override
    protected void scale(LuminousEntity entity, MatrixStack matrices, float amount) {
        if (entity.isBaby()) {
            // Shrinks the model to 0.5x size (half size) in X, Y, and Z axes
            matrices.scale(0.5F, 0.5F, 0.5F);
        } else {
            matrices.scale(1.0F, 1.0F, 1.0F);
        }
    }

    @Override
    public Identifier getTexture(LuminousEntity entity) {
        return switch (entity.getVariant()) {
            case 1 -> LIGHT_BLUE_TEXTURE;
            case 2 -> PINK_TEXTURE;
            default -> YELLOW_TEXTURE;
        };
    }

    // --- INTERNAL MODEL CLASS ---
    public static class LuminousModel extends SinglePartEntityModel<LuminousEntity> {
        private final ModelPart root;
        private final ModelPart body;
        private final ModelPart leftEar;
        private final ModelPart rightEar;
        private final ModelPart[] feet = new ModelPart[8];

        public LuminousModel(ModelPart root) {
            this.root = root;
            this.body = root.getChild("body");
            this.leftEar = body.getChild("left_ear");
            this.rightEar = body.getChild("right_ear");

            for (int i = 0; i < 8; i++) {
                this.feet[i] = body.getChild("foot_" + i);
            }
        }

        public static TexturedModelData getTexturedModelData() {
            ModelData modelData = new ModelData();
            ModelPartData modelPartData = modelData.getRoot();

            // Cubic body: 12x12x12 size (0.75 of a block).
            // Positioned so it sits exactly on the floor plane (Y=24)
            ModelPartData bodyData = modelPartData.addChild("body", ModelPartBuilder.create()
                            .uv(0, 0)
                            .cuboid(-6.0F, -13.5F, -6.0F, 12.0F, 12.0F, 12.0F),
                    ModelTransform.pivot(0.0F, 24.0F, 0.0F));

            // Dumbo Ear Fins (Rotated 90 degrees on Y axis)
            bodyData.addChild("left_ear", ModelPartBuilder.create()
                            .uv(0, 24)
                            .cuboid(0.0F, 0.0F, 0.0F, 4.0F, 4.0F, 1.0F),
                    // X, Y, Z, Pitch (X), Yaw (Y) changed to 1.5708F, Roll (Z)
                    ModelTransform.of(6.0F, -10.0F, 0.0F, 0.0F, 1.5708F, -0.2F));

            bodyData.addChild("right_ear", ModelPartBuilder.create()
                            .uv(0, 24)
                            .mirrored()
                            .cuboid(-4.0F, 0.0F, 0.0F, 4.0F, 4.0F, 1.0F),
                    // X, Y, Z, Pitch (X), Yaw (Y) changed to -1.5708F, Roll (Z)
                    ModelTransform.of(-6.0F, -10.0F, 0.0F, 0.0F, -1.5708F, 0.2F));

            // 8 Flat Feet radiating along the base edges
            float[][] footPositions = {
                    {4.0F, -5.0F}, {4.0F, 0.0F}, {4.0F, 5.0F},
                    {-4.0F, -5.0F}, {-4.0F, 0.0F}, {-4.0F, 5.0F},
                    {0.0F, -5.0F}, {0.0F, 5.0F}
            };

            for (int i = 0; i < 8; i++) {
                bodyData.addChild("foot_" + i, ModelPartBuilder.create()
                                .uv(0, 30)
                                .cuboid(-1.5F, -1.5F, -1.5F, 3.0F, 1.0F, 3.0F),
                        ModelTransform.pivot(footPositions[i][0], 0.0F, footPositions[i][1]));
            }

            return TexturedModelData.of(modelData, 64, 64);
        }

        @Override
        public void setAngles(LuminousEntity entity, float limbAngle, float limbDistance,
                              float animationProgress, float headYaw, float headPitch) {
            this.root.resetTransform();

            // 1. Piglin-like Ear animation (gentle floating/flapping)
            float idleSpeed = animationProgress * 0.1F;
            this.leftEar.roll = -0.2F - (MathHelper.sin(idleSpeed) * 0.08F);
            this.rightEar.roll = 0.2F + (MathHelper.sin(idleSpeed) * 0.08F);

            this.leftEar.pitch = MathHelper.cos(idleSpeed) * 0.05F;
            this.rightEar.pitch = MathHelper.cos(idleSpeed) * 0.05F;

            // 2. Octopus Feet Ripple Animation
            for (int i = 0; i < 8; i++) {
                // Phase offsets make the tentacles ripple sequentially instead of all at once
                float phaseOffset = i * 0.4F;
                this.feet[i].pitch = MathHelper.sin(animationProgress * 0.2F + phaseOffset) * 0.15F;
                this.feet[i].roll = MathHelper.cos(animationProgress * 0.2F + phaseOffset) * 0.1F;
            }
        }

        @Override
        public ModelPart getPart() {
            return this.root;
        }
    }
}