package mh837.gile;

import mh837.gile.advancement.NamedEntityCriterion;
import mh837.gile.advancement.UsedScepterCriterion;
import mh837.gile.block.*;
import mh837.gile.block.entity.GhostlyHangingSignBlockEntity;
import mh837.gile.block.entity.GhostlySignBlockEntity;
import mh837.gile.block.entity.MoonCampfireBlockEntity;
import mh837.gile.effect.EnlargeStatusEffect;
import mh837.gile.effect.ShrinkStatusEffect;
import mh837.gile.entity.*;
import mh837.gile.network.ActiveAbilityPayload;
import mh837.gile.tool.FateUpgradeSmithingTemplateItem;
import mh837.gile.tool.item.*;
import mh837.gile.tool.material.LightningToolMaterials;
import mh837.gile.worldgen.CloudBlobFeature;
import mh837.gile.worldgen.EndSurfaceFeature;
import mh837.gile.worldgen.MoonDesertSurfaceFeature;
import mh837.gile.worldgen.StarFeature;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.TheEndBiomes;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.*;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;

import java.util.*;
import java.util.function.Predicate;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import net.minecraft.util.UseAction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.intprovider.UniformIntProvider;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.*;
import net.minecraft.item.Items;
import net.minecraft.component.type.UnbreakableComponent;
import org.joml.Vector3f;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static mh837.gile.tool.material.BlazingToolMaterials.THOUSAND_BLAZING_SUNS_MATERIAL;
import static mh837.gile.tool.material.FloatingToolMaterials.THOUSAND_FLOATING_DREAMS_MATERIAL;
import static mh837.gile.tool.material.ModToolMaterials.FATE_SWORD_MATERIAL;
import static mh837.gile.tool.material.NocturneToolMaterials.NOCTURNES_CURTAIN_CALL_MATERIAL;
import static mh837.gile.tool.material.SplendorToolMaterials.SPLENDOR_OF_TRANQUIL_WATERS_MATERIAL;
import static mh837.gile.tool.material.TsaritsaToolMaterials.TSARITSAS_SCEPTER_MATERIAL;
import static mh837.gile.tool.material.VortexToolMaterials.VORTEX_VANQUISHER_MATERIAL;

public class GileMod implements ModInitializer {
	public static final String MOD_ID = "gilemod";
	public static final Logger LOGGER = LoggerFactory.getLogger("gile");

	/*=================
	ITEM DECLARATIONS:
	=================*/

	public static final Item PRIMOGEM = new Item(new Item.Settings());
	public static final Item ANEMO_SIGIL = new Item(new Item.Settings());
	public static final Item GEO_SIGIL = new Item(new Item.Settings());
	public static final Item ELECTRO_SIGIL = new Item(new Item.Settings());
	public static final Item DENDRO_SIGIL = new Item(new Item.Settings());
	public static final Item HYDRO_SIGIL = new Item(new Item.Settings());
	public static final Item PYRO_SIGIL = new Item(new Item.Settings());
	public static final Item CRYO_SIGIL = new Item(new Item.Settings());
	public static final Item LUNA_SIGIL = new Item(new Item.Settings());
	public static final Item MORA = new Item(new Item.Settings());
	public static final Item WISH_INGOT = new Item(new Item.Settings());
	public static final Item WISH_NUGGET = new Item(new Item.Settings());
	public static final Item CRYSTAL = new Item(new Item.Settings());
	public static final Item FATE_UPGRADE_SMITHING_TEMPLATE = new FateUpgradeSmithingTemplateItem();
	public static final Item MOTH_WING = new Item(new Item.Settings());
	public static final Item VOID_SLIMEBALL = new Item(new Item.Settings());
	public static final Item PHASMA = new Item(new Item.Settings());
	public static final Item CHRONO_GEAR = new Item(new Item.Settings());
	public static final Item STAR_FRAGMENT = new Item(new Item.Settings());
	public static final Item JERBOAS_TAIL = new Item(new Item.Settings());
	public static final Item HEART_OF_HEALING = new HeartOfHealingItem(new Item.Settings().maxCount(1));
	public static final Item SHADOW_CLOCK = new ShadowClockItem(new Item.Settings());
	public static final Item GRAPPLING_HOOK = new GrapplingHookItem(new Item.Settings().maxCount(1).maxDamage(374));
	public static final Item SHRINKER = new ShrinkerItem(new Item.Settings().maxDamage(191));
	public static final Item ENLARGER = new EnlargerItem(new Item.Settings().maxDamage(191));

	/*==================
	BLOCK DECLARATIONS:
	==================*/

	// PRIMOGEM/PEARLESCENT:
	public static final Block PRIMOGEM_ORE = new ExperienceDroppingBlock(
			UniformIntProvider.create(2, 6),
			AbstractBlock.Settings.create()
					.requiresTool()
					.strength(3.0f, 3.0f));
	public static final Item PRIMOGEM_ORE_ITEM = new BlockItem(PRIMOGEM_ORE, new Item.Settings());
	public static final Block DEEPSLATE_PRIMOGEM_ORE = new ExperienceDroppingBlock(
			UniformIntProvider.create(2, 6),
			AbstractBlock.Settings.create()
					.requiresTool()
					.strength(3.5f, 3.5f));
	public static final Item DEEPSLATE_PRIMOGEM_ORE_ITEM = new BlockItem(DEEPSLATE_PRIMOGEM_ORE, new Item.Settings());
	public static final Block END_PRIMOGEM_ORE = new ExperienceDroppingBlock(
			UniformIntProvider.create(2, 6),
			AbstractBlock.Settings.create()
					.requiresTool()
					.strength(4.0f, 4.0f));
	public static final Item END_PRIMOGEM_ORE_ITEM = new BlockItem(END_PRIMOGEM_ORE, new Item.Settings());
	public static final Block WISH = new Block(
			AbstractBlock.Settings.create()
					.strength(2.0f, 2.0f)
					.sounds(net.minecraft.sound.BlockSoundGroup.AMETHYST_BLOCK));
	public static final Item WISH_ITEM = new BlockItem(WISH, new Item.Settings());
	public static final Block PEARLESCENT_BLOCK = new Block(
			AbstractBlock.Settings.create()
					.requiresTool().strength(2.0f, 2.0f)
					.sounds(net.minecraft.sound.BlockSoundGroup.COPPER_BULB));
	public static final Item PEARLESCENT_BLOCK_ITEM = new BlockItem(PEARLESCENT_BLOCK, new Item.Settings());
	public static final Block PEARLESCENT_BRICKS = new Block(
			AbstractBlock.Settings.copy(PEARLESCENT_BLOCK));
	public static final Item PEARLESCENT_BRICKS_ITEM = new BlockItem(PEARLESCENT_BRICKS, new Item.Settings());
	public static final Block PEARLESCENT_STAIRS = new StairsBlock(
			PEARLESCENT_BLOCK.getDefaultState(),
			AbstractBlock.Settings.copy(PEARLESCENT_BLOCK));
	public static final Item PEARLESCENT_STAIRS_ITEM = new BlockItem(PEARLESCENT_STAIRS, new Item.Settings());
	public static final Block PEARLESCENT_SLAB = new SlabBlock(
			AbstractBlock.Settings.copy(PEARLESCENT_BLOCK));
	public static final Item PEARLESCENT_SLAB_ITEM = new BlockItem(PEARLESCENT_SLAB, new Item.Settings());
	public static final Block PEARLESCENT_WALL = new WallBlock(
			AbstractBlock.Settings.copy(PEARLESCENT_BLOCK));
	public static final Item PEARLESCENT_WALL_ITEM = new BlockItem(PEARLESCENT_WALL, new Item.Settings());

	// GHOSTLY LOG:
	public static final Block GHOSTLY_LOG = new PillarBlock(
			AbstractBlock.Settings.copy(Blocks.OAK_LOG));
	public static final Item GHOSTLY_LOG_ITEM = new BlockItem(GHOSTLY_LOG, new Item.Settings());
	public static final Block STRIPPED_GHOSTLY_LOG = new PillarBlock(
			AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_LOG));
	public static final Item STRIPPED_GHOSTLY_LOG_ITEM = new BlockItem(STRIPPED_GHOSTLY_LOG, new Item.Settings());
	public static final Block GHOSTLY_WOOD = new PillarBlock(
			AbstractBlock.Settings.copy(Blocks.OAK_WOOD));
	public static final Item GHOSTLY_WOOD_ITEM = new BlockItem(GHOSTLY_WOOD, new Item.Settings());
	public static final Block STRIPPED_GHOSTLY_WOOD = new PillarBlock(
			AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_WOOD));
	public static final Item STRIPPED_GHOSTLY_WOOD_ITEM = new BlockItem(STRIPPED_GHOSTLY_WOOD, new Item.Settings());
	public static final Block GHOSTLY_PLANKS = new Block(
			AbstractBlock.Settings.copy(Blocks.OAK_PLANKS));
	public static final Item GHOSTLY_PLANKS_ITEM = new BlockItem(GHOSTLY_PLANKS, new Item.Settings());
	public static final Block GHOSTLY_STAIRS = new StairsBlock(GHOSTLY_PLANKS.getDefaultState(),
			AbstractBlock.Settings.copy(GHOSTLY_PLANKS));
	public static final Item GHOSTLY_STAIRS_ITEM = new BlockItem(GHOSTLY_STAIRS, new Item.Settings());
	public static final Block GHOSTLY_SLAB = new SlabBlock(
			AbstractBlock.Settings.copy(GHOSTLY_PLANKS));
	public static final Item GHOSTLY_SLAB_ITEM = new BlockItem(GHOSTLY_SLAB, new Item.Settings());
	public static final Block GHOSTLY_FENCE = new FenceBlock(
			AbstractBlock.Settings.copy(GHOSTLY_PLANKS));
	public static final Item GHOSTLY_FENCE_ITEM = new BlockItem(GHOSTLY_FENCE, new Item.Settings());
	public static final Block GHOSTLY_FENCE_GATE = new FenceGateBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE, AbstractBlock.Settings.copy(GHOSTLY_PLANKS));
	public static final Item GHOSTLY_FENCE_GATE_ITEM = new BlockItem(GHOSTLY_FENCE_GATE, new Item.Settings());
	public static final Block GHOSTLY_DOOR = new DoorBlock(
			ModWoodTypes.GHOSTLY_BLOCK_SET, AbstractBlock.Settings.copy(GHOSTLY_PLANKS).nonOpaque());
	public static final Item GHOSTLY_DOOR_ITEM = new BlockItem(GHOSTLY_DOOR, new Item.Settings());
	public static final Block GHOSTLY_TRAPDOOR = new TrapdoorBlock(
			ModWoodTypes.GHOSTLY_BLOCK_SET, AbstractBlock.Settings.copy(GHOSTLY_PLANKS).nonOpaque());
	public static final Item GHOSTLY_TRAPDOOR_ITEM = new BlockItem(GHOSTLY_TRAPDOOR, new Item.Settings());
	public static final Block GHOSTLY_PRESSURE_PLATE = new PressurePlateBlock(
			ModWoodTypes.GHOSTLY_BLOCK_SET, AbstractBlock.Settings.copy(GHOSTLY_PLANKS).noCollision());
	public static final Item GHOSTLY_PRESSURE_PLATE_ITEM = new BlockItem(GHOSTLY_PRESSURE_PLATE, new Item.Settings());
	public static final Block GHOSTLY_BUTTON = new ButtonBlock(
			ModWoodTypes.GHOSTLY_BLOCK_SET, 30, AbstractBlock.Settings.copy(GHOSTLY_PLANKS).noCollision());
	public static final Item GHOSTLY_BUTTON_ITEM = new BlockItem(GHOSTLY_BUTTON, new Item.Settings());
	public static final Block GHOSTLY_SIGN = new GhostlySignBlocks.GhostlySignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			AbstractBlock.Settings.copy(Blocks.OAK_SIGN).noCollision());
	public static final Block GHOSTLY_WALL_SIGN = new GhostlySignBlocks.GhostlyWallSignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			AbstractBlock.Settings.copy(Blocks.OAK_WALL_SIGN).noCollision().dropsLike(GHOSTLY_SIGN));
	public static final Block GHOSTLY_HANGING_SIGN = new GhostlySignBlocks.GhostlyHangingSignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			AbstractBlock.Settings.copy(Blocks.OAK_HANGING_SIGN).noCollision());
	public static final Block GHOSTLY_WALL_HANGING_SIGN = new GhostlySignBlocks.GhostlyWallHangingSignBlock(
			ModWoodTypes.GHOSTLY_WOOD_TYPE,
			AbstractBlock.Settings.copy(Blocks.OAK_WALL_HANGING_SIGN).noCollision().dropsLike(GHOSTLY_HANGING_SIGN));
	public static final Item GHOSTLY_SIGN_ITEM = new SignItem(
			new Item.Settings().maxCount(16), GHOSTLY_SIGN, GHOSTLY_WALL_SIGN);
	public static final Item GHOSTLY_HANGING_SIGN_ITEM = new HangingSignItem(
			GHOSTLY_HANGING_SIGN, GHOSTLY_WALL_HANGING_SIGN, new Item.Settings().maxCount(16));
	public static final Block GHOSTLY_LEAVES = Registry.register(
			Registries.BLOCK, Identifier.of("gilemod", "ghostly_leaves"),
			new LeavesBlock(AbstractBlock.Settings.copy(Blocks.OAK_LEAVES).mapColor(MapColor.PINK)));
	public static final Item GHOSTLY_LEAVES_ITEM = new BlockItem(GHOSTLY_LEAVES, new Item.Settings());

	// MOON SAND(STONE)
	public static final Block MOON_SAND = new FallingMoonSand(
			AbstractBlock.Settings.create()
					.requiresTool().strength(1.2f, 1.2f)
					.sounds(net.minecraft.sound.BlockSoundGroup.SAND).mapColor(MapColor.TERRACOTTA_LIGHT_BLUE));
	public static final Item MOON_SAND_ITEM = new BlockItem(MOON_SAND, new Item.Settings());

	public static final Block MOON_SANDSTONE = new Block(
			AbstractBlock.Settings.copy(Blocks.SANDSTONE).requiresTool());
	public static final Item MOON_SANDSTONE_ITEM = new BlockItem(MOON_SANDSTONE, new Item.Settings());
	public static final Block MOON_SANDSTONE_STAIRS = new StairsBlock(MOON_SANDSTONE.getDefaultState(),
			AbstractBlock.Settings.copy(MOON_SANDSTONE));
	public static final Item MOON_SANDSTONE_STAIRS_ITEM = new BlockItem(MOON_SANDSTONE_STAIRS, new Item.Settings());
	public static final Block MOON_SANDSTONE_SLAB = new SlabBlock(
			AbstractBlock.Settings.copy(MOON_SANDSTONE));
	public static final Item MOON_SANDSTONE_SLAB_ITEM = new BlockItem(MOON_SANDSTONE_SLAB, new Item.Settings());
	public static final Block MOON_SANDSTONE_WALL = new WallBlock(
			AbstractBlock.Settings.copy(MOON_SANDSTONE));
	public static final Item MOON_SANDSTONE_WALL_ITEM = new BlockItem(MOON_SANDSTONE_WALL, new Item.Settings());
	public static final Block MOON_CHISELED_SANDSTONE = new Block(
			AbstractBlock.Settings.copy(Blocks.SANDSTONE).requiresTool());
	public static final Item MOON_CHISELED_SANDSTONE_ITEM = new BlockItem(MOON_CHISELED_SANDSTONE, new Item.Settings());
	public static final Block MOON_SMOOTH_SANDSTONE = new Block(
			AbstractBlock.Settings.copy(Blocks.SANDSTONE).requiresTool());
	public static final Item MOON_SMOOTH_SANDSTONE_ITEM = new BlockItem(MOON_SMOOTH_SANDSTONE, new Item.Settings());
	public static final Block MOON_SMOOTH_SANDSTONE_STAIRS = new StairsBlock(MOON_SMOOTH_SANDSTONE.getDefaultState(),
			AbstractBlock.Settings.copy(MOON_SMOOTH_SANDSTONE));
	public static final Item MOON_SMOOTH_SANDSTONE_STAIRS_ITEM = new BlockItem(MOON_SMOOTH_SANDSTONE_STAIRS, new Item.Settings());
	public static final Block MOON_SMOOTH_SANDSTONE_SLAB = new SlabBlock(
			AbstractBlock.Settings.copy(MOON_SMOOTH_SANDSTONE));
	public static final Item MOON_SMOOTH_SANDSTONE_SLAB_ITEM = new BlockItem(MOON_SMOOTH_SANDSTONE_SLAB, new Item.Settings());
	public static final Block MOON_CUT_SANDSTONE = new Block(
			AbstractBlock.Settings.copy(Blocks.SANDSTONE).requiresTool());
	public static final Item MOON_CUT_SANDSTONE_ITEM = new BlockItem(MOON_CUT_SANDSTONE, new Item.Settings());
	public static final Block MOON_CUT_SANDSTONE_SLAB = new SlabBlock(
			AbstractBlock.Settings.copy(MOON_CUT_SANDSTONE));
	public static final Item MOON_CUT_SANDSTONE_SLAB_ITEM = new BlockItem(MOON_CUT_SANDSTONE_SLAB, new Item.Settings());

	/*=========================
	(BLOCK)ENTITY DECLARATIONS:
	=========================*/

	public static final Item FATE_ARROW = new Item(new Item.Settings());
	public static EntityType<FateArrowEntity> FATE_ARROW_TYPE;
	public static EntityType<VentiArrowEntity> VENTI_ARROW_TYPE;
	public static EntityType<VoidSlimeEntity> VOID_SLIME;
	public static Item VOID_SLIME_SPAWN_EGG;
	public static EntityType<MothEntity> MOTH;
	public static Item MOTH_SPAWN_EGG;
	public static EntityType<LuminousEntity> LUMINOUS;
	public static Item LUMINOUS_SPAWN_EGG;
	public static EntityType<HoveringGhostEntity> HOVERING_GHOST;
	public static Item HOVERING_GHOST_SPAWN_EGG;
	public static EntityType<JerboaEntity> JERBOA;
	public static Item JERBOA_SPAWN_EGG;
	public static EntityType<GloomyLynxEntity> GLOOMY_LYNX;
	public static Item GLOOMY_LYNX_SPAWN_EGG;
	public static EntityType<WeaselThiefEntity> WEASEL_THIEF;
	public static Item WEASEL_THIEF_SPAWN_EGG;
	public static BlockEntityType<GhostlySignBlockEntity> GHOSTLY_SIGN_BLOCK_ENTITY;
	public static BlockEntityType<GhostlyHangingSignBlockEntity> GHOSTLY_HANGING_SIGN_BLOCK_ENTITY;

	/*========================
	COMPLEX ITEM DECLARATIONS:
	========================*/

	public static final Item OFFERING = new Item(new Item.Settings()
			.maxCount(1).food(
					new FoodComponent.Builder().nutrition(8).saturationModifier(1.2f).alwaysEdible().build())) {
		@Override
		public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
			if (!world.isClient) {
				user.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 1200, 0));}
			ItemStack result = super.finishUsing(stack, world, user); //Applies effects
			if (user instanceof PlayerEntity player && !player.getAbilities().creativeMode) {
				return new ItemStack(Items.BOWL);} //Returns bowl after eating if not Creative Mode
			return result;}};

	public static final Item JELLY = new Item(new Item.Settings()
			.food(new FoodComponent.Builder().nutrition(1).saturationModifier(0.6f).build()));

	public static final Item JELLY_ON_A_STICK = Registry.register(Registries.ITEM,
			Identifier.of("gilemod", "jelly_on_a_stick"),
			new JellyOnAStickItem(new Item.Settings().maxDamage(25)));

	public static final Item JAM = new Item(new Item.Settings()
			.food(new FoodComponent.Builder().nutrition(6).saturationModifier(0.4f).build()));

	public static final Item COOKED_PHASMA = new Item(new Item.Settings()
			.food(new FoodComponent.Builder().nutrition(6).saturationModifier(0.5f).build()));

	public static final Item FATE_SWORD = new FateSwordItem(
			FATE_SWORD_MATERIAL, new Item.Settings().attributeModifiers(
							SwordItem.createAttributeModifiers(FATE_SWORD_MATERIAL, 3, -2.4f)));

	// FATE BOW:
	public static final Item FATE_BOW = new BowItem(new Item.Settings().maxDamage(1536)) {
		// Prevents pulling bow without arrows
		public boolean isSuitableFor(ItemStack stack, LivingEntity user) {
			if (user instanceof net.minecraft.entity.player.PlayerEntity player) {
				// Check if player has any fate arrows in creative OR survival
				if (player.isCreative()) return true;
				// In survival, check for arrows
				for (int i = 0; i < player.getInventory().size(); i++) {
					if (player.getInventory().getStack(i).getItem() == FATE_ARROW) {
						return true;}} return false;} return true;}

		@Override
		// Arrow amount decreases by 1 if shot
		public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
			if (user instanceof net.minecraft.entity.player.PlayerEntity player) {
				int arrowSlot = -1;
				for (int i = 0; i < player.getInventory().size(); i++) {
					if (player.getInventory().getStack(i).getItem() == FATE_ARROW) {
						arrowSlot = i; break;}}
				// Creative mode: always shoot even without arrows in inventory
				boolean hasArrow = player.isCreative() || arrowSlot != -1;
				boolean hasInfinity = EnchantmentHelper.getLevel(world.getRegistryManager()
						.get(RegistryKeys.ENCHANTMENT).getEntry(Enchantments.INFINITY).get(), stack) > 0;
				if (!world.isClient && hasArrow) {
					// Remove arrow from inventory (unless creative)
					if (!player.isCreative() && !hasInfinity && arrowSlot != -1) {
						player.getInventory().removeStack(arrowSlot, 1);}
					// Create the custom arrow
					FateArrowEntity arrow = new FateArrowEntity(world, player, new ItemStack(FATE_ARROW));
					// For creative mode, mark arrow as picked up immediately
					if (player.isCreative() || hasInfinity) {
						arrow.pickupType = PersistentProjectileEntity.PickupPermission.CREATIVE_ONLY;}
					// Optionalize created arrow
					int useTime = this.getMaxUseTime(stack, user) - remainingUseTicks;
					float velocity = BowItem.getPullProgress(useTime);
					arrow.refreshPositionAndAngles(
							player.getX(), player.getEyeY() - 0.1, player.getZ(),
							player.getYaw(), player.getPitch());
					net.minecraft.util.math.Vec3d rotation = player.getRotationVector();
					arrow.setVelocity(rotation.x, rotation.y, rotation.z, velocity * 3.0F, 1.0F);
					// Enchantments simulating:
					// 1. Power Enchantment (Increases Damage)
					var enchantmentRegistry = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
					int powerLevel = EnchantmentHelper.getLevel(enchantmentRegistry.getEntry(Enchantments.POWER).get(), stack);
					if (powerLevel > 0) {arrow.setDamage(arrow.getDamage() + (double)powerLevel * 0.5 + 0.5);}
					// 2. Punch Enchantment (Try setPunch first, then setKnockback)
					int punchLevel = EnchantmentHelper.getLevel(enchantmentRegistry.getEntry(Enchantments.PUNCH).get(), stack);
					if (punchLevel > 0) {arrow.setPunch(punchLevel);}
					// 3. Flame Enchantment
					int flameLevel = EnchantmentHelper.getLevel(enchantmentRegistry.getEntry(Enchantments.FLAME).get(), stack);
					if (flameLevel > 0) {arrow.setOnFireFor(100);}
					// Summon custom arrow
					world.spawnEntity(arrow);
					world.playSound(null, player.getBlockX(), player.getBlockY(), player.getBlockZ(),
							SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F);
					// Stack damage to the bow
					if (!player.isCreative()) {
						stack.damage(1, player, EquipmentSlot.MAINHAND);}}}}
		//Pulling max time, use action & projectile
		@Override
		public int getMaxUseTime(ItemStack stack, LivingEntity user) {
			return 72000;}
		@Override
		public UseAction getUseAction(ItemStack stack) {
			return UseAction.BOW;}
		@Override
		public Predicate<ItemStack> getProjectiles() {
			return (stack) -> stack.getItem() == FATE_ARROW;}};

	// VENTI:
	public static final Item DAYBREAK_CHRONICLES = new BowItem(new Item.Settings().maxDamage(1)
			.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true))) {
		// Always allow pulling the bow since we don't need arrows
		public boolean isSuitableFor(ItemStack stack, LivingEntity user) {
			return true;}

		@Override
		public Text getName(ItemStack stack) {
			return Text.translatable(this.getTranslationKey(stack)).styled(style ->
					style.withColor(net.minecraft.util.Formatting.YELLOW));}
		private static final ParticleEffect FEET_PARTICLE = new DustParticleEffect(
				new Vector3f(0.1f, 1.0f, 0.9f),
				1.0f);
		private static final ParticleEffect CLOUD_PARTICLE = new DustParticleEffect(
				new Vector3f(1.0f, 1.0f, 1.0f),
				1.5f);

		@Override
		public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
			super.inventoryTick(stack, world, entity, slot, selected);
			if (entity instanceof LivingEntity livingEntity) {
				// Spawn particles at feet when selected in main hand
				if (selected && world instanceof ServerWorld serverWorld) {
					if (world.getTime() % 2 == 0) { // Every other tick
						double x = livingEntity.getX();
						double y = livingEntity.getY() + 0.1; // Feet level
						double z = livingEntity.getZ();

						for (int i = 0; i < 3; i++) {
							double offsetX = (world.random.nextDouble() - 0.5) * 0.6;
							double offsetZ = (world.random.nextDouble() - 0.5) * 0.6;
							serverWorld.spawnParticles(CLOUD_PARTICLE,
									x + offsetX, y, z + offsetZ,
									1, 0.0, 0.05, 0.0, 0.02);}

						serverWorld.spawnParticles(
								FEET_PARTICLE,
								x, y, z,
								1, 0.3, 0.05, 0.3, 0.01);}}}}

		@Override
		public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
			if (user instanceof net.minecraft.entity.player.PlayerEntity player) {
				if (!world.isClient) {
					// Create the custom arrow entity directly without any arrow item
					VentiArrowEntity arrow = new VentiArrowEntity(world, player);
					// Arrow can never be picked up
					arrow.pickupType = PersistentProjectileEntity.PickupPermission.CREATIVE_ONLY;
					// Calculate velocity
					int useTime = this.getMaxUseTime(stack, user) - remainingUseTicks;
					float velocity = BowItem.getPullProgress(useTime);
					arrow.refreshPositionAndAngles(
							player.getX(), player.getEyeY() - 0.1, player.getZ(),
							player.getYaw(), player.getPitch());
					net.minecraft.util.math.Vec3d rotation = player.getRotationVector();
					arrow.setVelocity(rotation.x, rotation.y, rotation.z, velocity * 3.0F, 1.0F);
					// Enchantments
					var enchantmentRegistry = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
					// Power Enchantment
					int powerLevel = EnchantmentHelper.getLevel(enchantmentRegistry.getEntry(Enchantments.POWER).get(), stack);
					if (powerLevel > 0) {
						arrow.setDamage(arrow.getDamage() + (double)powerLevel * 0.5 + 0.5);}
					// Punch Enchantment
					int punchLevel = EnchantmentHelper.getLevel(enchantmentRegistry.getEntry(Enchantments.PUNCH).get(), stack);
					if (punchLevel > 0) {
						arrow.setPunch(punchLevel);}
					// Flame Enchantment
					int flameLevel = EnchantmentHelper.getLevel(enchantmentRegistry.getEntry(Enchantments.FLAME).get(), stack);
					if (flameLevel > 0) {
						arrow.setOnFireFor(100);}
					// Spawn the arrow entity
					world.spawnEntity(arrow);
					world.playSound(null, player.getBlockX(), player.getBlockY(), player.getBlockZ(),
							SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F);}}}

		@Override
		public int getMaxUseTime(ItemStack stack, LivingEntity user) {
			return 54000;}

		@Override
		public UseAction getUseAction(ItemStack stack) {
			return UseAction.BOW;}

		@Override
		public Predicate<ItemStack> getProjectiles() {
			// Return a predicate that always returns true since we don't need arrows
			return (stack) -> true;}};

	// ZHONG LI:
	public static final Item VORTEX_VANQUISHER = new VortexVanquisherItem(
			VORTEX_VANQUISHER_MATERIAL,
			new Item.Settings()
					.attributeModifiers(
							SwordItem.createAttributeModifiers(
									VORTEX_VANQUISHER_MATERIAL, 3, -2.6f))
					.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)));

	// RAIDEN:
	public static final Item ENGULFING_LIGHTNING = new EngulfingLightningItem(
			LightningToolMaterials.ENGULFING_LIGHTNING_MATERIAL,
			new Item.Settings()
					.attributeModifiers(
							SwordItem.createAttributeModifiers(
									LightningToolMaterials.ENGULFING_LIGHTNING_MATERIAL, 3, -2.9f))
					.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)));

	// MAVUIKA:
	public static final Item THOUSAND_BLAZING_SUNS = new ThousandBlazingSunsItem(
			THOUSAND_BLAZING_SUNS_MATERIAL,
			new Item.Settings()
					.attributeModifiers(
							SwordItem.createAttributeModifiers(
									THOUSAND_BLAZING_SUNS_MATERIAL, 3, -2.6f))
					.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)));

	// FURINA:
	public static final Item SPLENDOR_OF_TRANQUIL_WATERS = new SplendorOfTranquilWatersItem(
			SPLENDOR_OF_TRANQUIL_WATERS_MATERIAL,
			new Item.Settings()
					.attributeModifiers(
							SwordItem.createAttributeModifiers(
									SPLENDOR_OF_TRANQUIL_WATERS_MATERIAL, 3, -2.6f))
					.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)));

	// TSARITSA:
	public static final Item TSARITSAS_SCEPTER = new TsaritsasScepterItem(
			TSARITSAS_SCEPTER_MATERIAL,
			new Item.Settings()
					.attributeModifiers(
							SwordItem.createAttributeModifiers(
									TSARITSAS_SCEPTER_MATERIAL, 3, -2.6f))
					.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)));

	// NAHIDA:
	public static final Item THOUSAND_FLOATING_DREAMS = new ThousandFloatingDreamsItem(
			THOUSAND_FLOATING_DREAMS_MATERIAL,
			new Item.Settings()
					.attributeModifiers(
							SwordItem.createAttributeModifiers(
									THOUSAND_FLOATING_DREAMS_MATERIAL, 3, -2.2f))
					.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)));

	// COLUMBINA:
	public static final Item NOCTURNES_CURTAIN_CALL = new NocturnesCurtainCallItem(
			NOCTURNES_CURTAIN_CALL_MATERIAL,
			new Item.Settings()
					.attributeModifiers(
							SwordItem.createAttributeModifiers(
									NOCTURNES_CURTAIN_CALL_MATERIAL, 3, -2.2f))
					.component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(true)));

	/*==========================
	COMPLEX BLOCK DECLARATIONS:
	==========================*/

	// MOON FIRE:
	public static final Block MOON_TORCH = new MoonTorchBlock(
			AbstractBlock.Settings.create()
					.noCollision()
					.breakInstantly()
					.luminance(state -> 10)
					.sounds(net.minecraft.sound.BlockSoundGroup.WOOD)
					.pistonBehavior(PistonBehavior.DESTROY));
	public static final Block MOON_WALL_TORCH = new MoonWallTorchBlock(
			AbstractBlock.Settings.create()
					.noCollision()
					.breakInstantly()
					.luminance(state -> 10)
					.sounds(net.minecraft.sound.BlockSoundGroup.WOOD)
					.pistonBehavior(PistonBehavior.DESTROY));
	public static Item MOON_TORCH_ITEM;
	public static final Block MOON_LANTERN = new LanternBlock(
			AbstractBlock.Settings.create()
					.requiresTool()
					.luminance(state -> 10)
					.strength(3.5f)
					.nonOpaque()
					.pistonBehavior(PistonBehavior.DESTROY)
					.suffocates((state, world, pos) -> false)
					.blockVision((state, world, pos) -> false));
	public static Item MOON_LANTERN_ITEM;
	public static final Block MOON_CAMPFIRE = Registry.register(
			Registries.BLOCK, Identifier.of(MOD_ID, "moon_campfire"),
			new MoonCampfireBlock(AbstractBlock.Settings.copy(Blocks.CAMPFIRE)));
	public static final Item MOON_CAMPFIRE_ITEM = new BlockItem(MOON_CAMPFIRE, new Item.Settings());
	public static final Block MOON_FIRE = Registry.register(
			Registries.BLOCK,
			Identifier.of(MOD_ID, "moon_fire"),
			new MoonFireBlock(AbstractBlock.Settings.create()
					.mapColor(MapColor.MAGENTA)
					.replaceable()
					.noCollision()
					.breakInstantly()
					.luminance(state -> 12) // Slightly eerie, dimmer light
					.sounds(BlockSoundGroup.WOOL)
					.pistonBehavior(PistonBehavior.DESTROY)));

	// PLANTS:
	public static final Block MOON_FLOWER = Registry.register(
			Registries.BLOCK,
			Identifier.of(MOD_ID, "moon_flower"),
			new MoonFlowerBlock(
					StatusEffects.LEVITATION, 7,
					AbstractBlock.Settings.create()
							.noCollision().breakInstantly()
							.sounds(BlockSoundGroup.GRASS).nonOpaque()
							.pistonBehavior(PistonBehavior.DESTROY)));
	public static final Item MOON_FLOWER_ITEM = new BlockItem(MOON_FLOWER, new Item.Settings());
	public static final Block POTTED_MOON_FLOWER = new FlowerPotBlock(
			MOON_FLOWER, AbstractBlock.Settings.copy(Blocks.POTTED_DANDELION)
					.nonOpaque().pistonBehavior(PistonBehavior.DESTROY));
	public static final Block GLOOMY_FLOWER = Registry.register(
			Registries.BLOCK,
			Identifier.of(MOD_ID, "gloomy_flower"),
			new MoonFlowerBlock(
					StatusEffects.DARKNESS, 8,
					AbstractBlock.Settings.create()
							.noCollision().breakInstantly()
							.sounds(BlockSoundGroup.GRASS).nonOpaque()
							.pistonBehavior(PistonBehavior.DESTROY)));
	public static final Item GLOOMY_FLOWER_ITEM = new BlockItem(GLOOMY_FLOWER, new Item.Settings());
	public static final Block POTTED_GLOOMY_FLOWER = new FlowerPotBlock(
			GLOOMY_FLOWER, AbstractBlock.Settings.copy(Blocks.POTTED_DANDELION)
			.nonOpaque().pistonBehavior(PistonBehavior.DESTROY));
	public static final Block DRY_FLOWER = Registry.register(
			Registries.BLOCK,
			Identifier.of(MOD_ID, "dry_flower"),
			new MoonFlowerBlock(
					StatusEffects.WITHER, 6,
					AbstractBlock.Settings.create()
							.noCollision().breakInstantly()
							.sounds(BlockSoundGroup.GRASS).nonOpaque()
							.pistonBehavior(PistonBehavior.DESTROY)));
	public static final Item DRY_FLOWER_ITEM = new BlockItem(DRY_FLOWER, new Item.Settings());
	public static final Block POTTED_DRY_FLOWER = new FlowerPotBlock(
			DRY_FLOWER, AbstractBlock.Settings.copy(Blocks.POTTED_DANDELION)
			.nonOpaque().pistonBehavior(PistonBehavior.DESTROY));
	public static final Block END_GRASS = Registry.register(
			Registries.BLOCK,
			Identifier.of(MOD_ID, "end_grass"),
			new EndGrass(AbstractBlock.Settings.create()
							.noCollision().breakInstantly()
							.sounds(BlockSoundGroup.GRASS).nonOpaque()
							.pistonBehavior(PistonBehavior.DESTROY)));
	public static final Item END_GRASS_ITEM = new BlockItem(END_GRASS, new Item.Settings());
	public static final Block TALL_END_GRASS = Registry.register(
			Registries.BLOCK,
			Identifier.of(MOD_ID, "tall_end_grass"),
			new TallEndGrass(AbstractBlock.Settings.create()
							.noCollision().breakInstantly()
							.sounds(BlockSoundGroup.GRASS).nonOpaque()
							.pistonBehavior(PistonBehavior.DESTROY)));
	public static final Item TALL_END_GRASS_ITEM = new BlockItem(TALL_END_GRASS, new Item.Settings());

	public static final BlockEntityType<MoonCampfireBlockEntity> MOON_CAMPFIRE_ENTITY =
			Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(GileMod.MOD_ID, "moon_campfire"),
					FabricBlockEntityTypeBuilder.create(MoonCampfireBlockEntity::new, MOON_CAMPFIRE).build());

	// MISCELLANEOUS:
	public static final Block PEARLESCENT_CHAIN = Registry.register(
			Registries.BLOCK,
			Identifier.of(MOD_ID, "pearlescent_chain"),
			new ChainBlock(AbstractBlock.Settings.create()
					.requiresTool().strength(5.0f)
					.sounds(BlockSoundGroup.CHAIN).nonOpaque()));
	public static final Item PEARLESCENT_CHAIN_ITEM = Registry.register(
			Registries.ITEM,
			Identifier.of(MOD_ID, "pearlescent_chain"),
			new BlockItem(GileMod.PEARLESCENT_CHAIN, new Item.Settings()));
	public static final Block END_GRASS_BLOCK = Registry.register(
			Registries.BLOCK,
			Identifier.of("gilemod", "end_grass_block"),
			new EndGrassBlock(AbstractBlock.Settings.copy(Blocks.END_STONE).ticksRandomly().mapColor(MapColor.PURPLE)));
	public static final Item END_GRASS_BLOCK_ITEM = new BlockItem(END_GRASS_BLOCK, new Item.Settings());
	public static final Block END_CLOUD = new Block(
			AbstractBlock.Settings.create()
					.noCollision()
					.breakInstantly().sounds(BlockSoundGroup.POWDER_SNOW)
					.pistonBehavior(PistonBehavior.DESTROY)
					.suffocates((state, world, pos) -> false)
					.blockVision((state, world, pos) -> false)) {
		@Override
		public void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
			// Apply cobweb slowing effect
			entity.slowMovement(state, new net.minecraft.util.math.Vec3d(0.8, 0.6, 0.8));}
		@Override
		public boolean isTransparent(BlockState state, BlockView world, BlockPos pos) {
			return true;}
		@Override
		public boolean isSideInvisible(BlockState state, BlockState stateFrom, Direction direction) {
			if (stateFrom.isOf(this)) {
				return true;}
			return super.isSideInvisible(state, stateFrom, direction);}};
	public static final Item END_CLOUD_ITEM = new BlockItem(END_CLOUD, new Item.Settings());
	public static final Block STAR = new Block(
			AbstractBlock.Settings.create()
					.strength(0.5f, 0.5f)
					.luminance(state -> 15).nonOpaque()
					.sounds(BlockSoundGroup.AMETHYST_BLOCK)) {
		@Override
		public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
			return Block.createCuboidShape(4, 4, 4, 12, 12, 12);}
		@Override
		public VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
			return Block.createCuboidShape(4, 4, 4, 12, 12, 12);}};
	public static final Item STAR_ITEM = new BlockItem(STAR, new Item.Settings());

	/*==============================
	FEATURES DECLARATIONS:
	==============================*/

	// GHOSTLY THICKETS:
	public static final RegistryKey<Biome> GHOSTLY_THICKETS = RegistryKey.of(
			RegistryKeys.BIOME, Identifier.of("gilemod", "ghostly_thickets"));

	public static final Feature<SimpleBlockFeatureConfig> GHOSTLY_SURFACE_FEATURE = Registry.register(
			Registries.FEATURE,
			Identifier.of("gilemod", "ghostly_surface"),
			new EndSurfaceFeature(SimpleBlockFeatureConfig.CODEC));
	public static final RegistryKey<PlacedFeature> GHOSTLY_SURFACE_PLACED_KEY = RegistryKey.of(
			RegistryKeys.PLACED_FEATURE, Identifier.of("gilemod", "ghostly_thickets_surface"));
	public static final RegistryKey<ConfiguredFeature<?, ?>> GHOSTLY_TREE_CONFIGURED = RegistryKey.of(
			RegistryKeys.CONFIGURED_FEATURE, Identifier.of("gilemod", "ghostly_tree"));
	public static final RegistryKey<ConfiguredFeature<?, ?>> GHOSTLY_THICKETS_CONFIGURED = RegistryKey.of(
			RegistryKeys.CONFIGURED_FEATURE, Identifier.of("gilemod", "ghostly_thickets_surface_conf"));

	public static final RegistryKey<PlacedFeature> GHOSTLY_TREE_PLACED_KEY = RegistryKey.of(
			RegistryKeys.PLACED_FEATURE,
			Identifier.of("gilemod", "ghostly_tree"));
	public static final SaplingGenerator GHOSTLY_SAPLING_GENERATOR = new SaplingGenerator(
			"ghostly_tree", // An ID for the generator
			Optional.empty(), // Rare variant (none)
			Optional.of(GHOSTLY_TREE_CONFIGURED), // The key we made for your alien tree
			Optional.empty());
	public static final Block GHOSTLY_SAPLING = Registry.register(
			Registries.BLOCK,
			Identifier.of("gilemod", "ghostly_sapling"),
			new GhostlySaplingBlock(GHOSTLY_SAPLING_GENERATOR, AbstractBlock.Settings.copy(Blocks.OAK_SAPLING)));
	public static final Item GHOSTLY_SAPLING_ITEM = new BlockItem(GHOSTLY_SAPLING, new Item.Settings());
	public static final Block POTTED_GHOSTLY_SAPLING = new FlowerPotBlock(
			GHOSTLY_SAPLING, AbstractBlock.Settings.copy(Blocks.POTTED_DANDELION)
			.nonOpaque().pistonBehavior(PistonBehavior.DESTROY));

	public static final Feature<SimpleBlockFeatureConfig> CLOUD_BLOB = Registry.register(
			Registries.FEATURE,
			Identifier.of(MOD_ID, "cloud_blob"),
			new CloudBlobFeature(SimpleBlockFeatureConfig.CODEC));
	public static final Feature<SimpleBlockFeatureConfig> STAR_FEATURE = Registry.register(
			Registries.FEATURE,
			Identifier.of(MOD_ID, "star"),
			new StarFeature(SimpleBlockFeatureConfig.CODEC));

	// MOON DESERT:
	public static final RegistryKey<Biome> MOON_DESERT = RegistryKey.of(
			RegistryKeys.BIOME,
			Identifier.of("gilemod", "moon_desert"));

	public static final RegistryKey<PlacedFeature> MOON_DESERT_SURFACE_PLACED_KEY = RegistryKey.of(
			RegistryKeys.PLACED_FEATURE,
			Identifier.of("gilemod", "moon_desert_surface"));
	public static final RegistryKey<ConfiguredFeature<?, ?>> MOON_DESERT_SURFACE_CONFIGURED = RegistryKey.of(
			RegistryKeys.CONFIGURED_FEATURE,
			Identifier.of("gilemod", "moon_desert_surface_conf"));
	public static final RegistryKey<PlacedFeature> DRY_FLOWER_PLACED_KEY = RegistryKey.of(
			RegistryKeys.PLACED_FEATURE,
			Identifier.of("gilemod", "dry_flower"));
	public static final RegistryKey<ConfiguredFeature<?, ?>> DRY_FLOWER_CONFIGURED = RegistryKey.of(
			RegistryKeys.CONFIGURED_FEATURE,
			Identifier.of("gilemod", "dry_flower"));
	public static final Feature<SimpleBlockFeatureConfig> MOON_DESERT_SURFACE_FEATURE = Registry.register(
			Registries.FEATURE,
			Identifier.of("gilemod", "moon_desert_surface"),
			new MoonDesertSurfaceFeature(SimpleBlockFeatureConfig.CODEC));

	/*=================
	OTHER DECLARATIONS:
	==================*/

	// SOUNDS:
	public static final SoundEvent LUMINOUS_AMBIENT = Registry.register(
			Registries.SOUND_EVENT,
			Identifier.of("gilemod", "entity.luminous.ambient"),
			SoundEvent.of(Identifier.of("gilemod", "entity.luminous.ambient")));
	public static final SoundEvent LUMINOUS_HURT = Registry.register(
			Registries.SOUND_EVENT,
			Identifier.of("gilemod", "entity.luminous.hurt"),
			SoundEvent.of(Identifier.of("gilemod", "entity.luminous.hurt")));
	public static final SoundEvent WEASEL_THIEF_AMBIENT = Registry.register(
			Registries.SOUND_EVENT,
			Identifier.of("gilemod", "entity.weasel_thief.ambient"),
			SoundEvent.of(Identifier.of("gilemod", "entity.weasel_thief.ambient")));
	public static final SoundEvent HOVERING_GHOST_NYAN_AMBIENT = Registry.register(
			Registries.SOUND_EVENT,
			Identifier.of("gilemod", "entity.hovering_ghost.nyan_ambient"),
			SoundEvent.of(Identifier.of("gilemod", "entity.hovering_ghost.nyan_ambient")));

	// EFFECTS:
	public static final RegistryEntry<StatusEffect> SHRINK_EFFECT = Registry.registerReference(
			Registries.STATUS_EFFECT, Identifier.of(MOD_ID, "shrink"), new ShrinkStatusEffect());
	public static final RegistryEntry<StatusEffect> ENLARGE_EFFECT = Registry.registerReference(
			Registries.STATUS_EFFECT, Identifier.of(MOD_ID, "enlarge"), new EnlargeStatusEffect());

	// KEYBINDS:
	public static final Map<UUID, Long> STOMP_COOLDOWNS = new HashMap<>();

//======================================================================================================================

	@Override
	public void onInitialize() {

		ModWoodTypes.init();
		Criteria.register(NamedEntityCriterion.ID.toString(), NamedEntityCriterion.CRITERION);
		Criteria.register(UsedScepterCriterion.ID.toString(), UsedScepterCriterion.CRITERION);

		/*====================
		KEYBIND REGISTRATIONS:
		===================**/

		PayloadTypeRegistry.playC2S().register(ActiveAbilityPayload.ID, ActiveAbilityPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ActiveAbilityPayload.ID, (payload, context) -> {
			context.server().execute(() -> {
				var player = context.player();
				var world = player.getServerWorld();
				// === ABILITY 1: SHRINK (INVISIBILITY TOGGLE) ===
				if (player.hasStatusEffect(GileMod.SHRINK_EFFECT)) {
					if (player.hasStatusEffect(StatusEffects.INVISIBILITY)) {player.removeStatusEffect(StatusEffects.INVISIBILITY);
					} else {
						player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, StatusEffectInstance.INFINITE, 0, false, false, true));}}
				// === ABILITY 2: ENLARGE (LUNAR STOMP) ===
				if (player.hasStatusEffect(GileMod.ENLARGE_EFFECT)) {
					long currentTime = System.currentTimeMillis();
					long cooldownEnd = STOMP_COOLDOWNS.getOrDefault(player.getUuid(), 0L);
					// Check if the 3-second (3000ms) cooldown is over
					if (currentTime >= cooldownEnd) {
						STOMP_COOLDOWNS.put(player.getUuid(), currentTime + 3000L);
						// Play a heavy slam sound (Iron Golem hurt sounds like heavy stone)
						world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_HURT, SoundCategory.PLAYERS, 1.0f, 0.5f);
						// Spawn a ring of smoke particles
						for (int i = 0; i < 360; i += 15) {
							double x = player.getX() + Math.cos(Math.toRadians(i)) * 4.0;
							double z = player.getZ() + Math.sin(Math.toRadians(i)) * 4.0;
							world.spawnParticles(ParticleTypes.LARGE_SMOKE, x, player.getY() + 0.1, z, 2, 0, 0, 0, 0.05);}
						// Get all living entities within 5 blocks
						Box area = player.getBoundingBox().expand(5.0, 2.0, 5.0);
						List<LivingEntity> targets = world.getEntitiesByClass(LivingEntity.class, area, e -> e != player && e.isAlive());
						for (LivingEntity target : targets) {
							// Deal 4 damage (2 hearts)
							target.damage(world.getDamageSources().playerAttack(player), 4.0f);
							// Apply Slowness II for 5 seconds (100 ticks)
							target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
							// Violent Knockback away from the player
							double dx = target.getX() - player.getX();
							double dz = target.getZ() - player.getZ();
							target.takeKnockback(1.5, -dx, -dz);}
					} else {
						// Let the player know it's on cooldown
						player.sendMessage(Text.translatable("message.gilemod.stomp_cooldown").formatted(Formatting.RED), true);}}});});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (var player : server.getPlayerManager().getPlayerList()) {
				// If the player DOES NOT have the shrink effect...
				if (!player.hasStatusEffect(GileMod.SHRINK_EFFECT)) {
					StatusEffectInstance invis = player.getStatusEffect(StatusEffects.INVISIBILITY);
					// ...and they have an INFINITE invisibility effect (which means we gave it to them)
					if (invis != null && invis.isInfinite()) {
						// Strip the invisibility
						player.removeStatusEffect(StatusEffects.INVISIBILITY);}}}});

		/*====================
		ENTITY REGISTRATIONS:
		====================*/

		// ARROWS:
		FATE_ARROW_TYPE = Registry.register(
				Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "fate_arrow"),
				EntityType.Builder.<FateArrowEntity>create(FateArrowEntity::new, SpawnGroup.MISC)
						.dimensions(0.5f, 0.5f).build());
		VENTI_ARROW_TYPE = Registry.register(
				Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "venti_arrow"),
				EntityType.Builder.<VentiArrowEntity>create(VentiArrowEntity::new, SpawnGroup.MISC)
						.dimensions(0.5f, 0.5f).maxTrackingRange(4).trackingTickInterval(20).build());

		// VOID SLIME:
		VOID_SLIME = Registry.register(Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "void_slime"),
				EntityType.Builder.create(VoidSlimeEntity::new, SpawnGroup.MONSTER)
						.dimensions(0.8f, 0.8f)
						.maxTrackingRange(8).trackingTickInterval(2).build());
		SpawnRestriction.register(VOID_SLIME,
				SpawnLocationTypes.ON_GROUND,
				Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
				(type, world, reason, pos, random) -> {
					BlockState below = world.getBlockState(pos.down());
					return below.isOf(Blocks.END_STONE) ||
							below.isOf(END_GRASS_BLOCK);});
		VOID_SLIME_SPAWN_EGG = new SpawnEggItem(VOID_SLIME,
				0x4E218C, 0xBDAFCF, new Item.Settings());
		FabricDefaultAttributeRegistry.register(VOID_SLIME, VoidSlimeEntity.createVoidSlimeAttributes());

		// MOTH:
		MOTH = Registry.register(Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "moth"),
				EntityType.Builder.create(MothEntity::new, SpawnGroup.CREATURE)
						.dimensions(0.8f, 0.5f)
						.maxTrackingRange(8).trackingTickInterval(2).build());
		SpawnRestriction.register(MOTH,
				SpawnLocationTypes.ON_GROUND,
				Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
				(type, world, reason, pos, random) -> {
					BlockState below = world.getBlockState(pos.down());
					return below.isOf(Blocks.END_STONE) ||
							below.isOf(GileMod.MOON_SAND) ||
							below.isOf(Blocks.GRASS_BLOCK) ||
							below.isOf(Blocks.MYCELIUM);});
		MOTH_SPAWN_EGG = new SpawnEggItem(MOTH,
				0x8B7355, 0xC4B090, new Item.Settings());
		FabricDefaultAttributeRegistry.register(MOTH, MothEntity.createMothAttributes());

		// LUMINOUS:
		LUMINOUS = Registry.register(Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "luminous"),
				EntityType.Builder.create(LuminousEntity::new, SpawnGroup.AMBIENT)
						.dimensions(0.85f, 0.85f)
						.maxTrackingRange(8).trackingTickInterval(2).build());
		SpawnRestriction.register(LUMINOUS,
				SpawnLocationTypes.ON_GROUND,
				Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
				(type, world, reason, pos, random) -> {
					BlockState below = world.getBlockState(pos.down());
					return	below.isOf(END_GRASS_BLOCK);});
		LUMINOUS_SPAWN_EGG = new SpawnEggItem(LUMINOUS,
				0xFFFA85, 0xFF97F7, new Item.Settings());
		FabricDefaultAttributeRegistry.register(LUMINOUS, LuminousEntity.createLuminousAttributes());

		// HOVERING GHOST:
		HOVERING_GHOST = Registry.register(Registries.ENTITY_TYPE,
				Identifier.of("gilemod", "hovering_ghost"),
				EntityType.Builder.create(HoveringGhostEntity::new, SpawnGroup.AMBIENT)
						.dimensions(1.5F, 0.75F).build());
		SpawnRestriction.register(HOVERING_GHOST,
				SpawnLocationTypes.ON_GROUND,
				Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
				(type, world, reason, pos, random) -> {
					BlockState below = world.getBlockState(pos.down());
					return	below.isOf(END_GRASS_BLOCK);});
		HOVERING_GHOST_SPAWN_EGG = new SpawnEggItem(HOVERING_GHOST,
				0xA899B3, 0x7E738C, new Item.Settings());
		FabricDefaultAttributeRegistry.register(HOVERING_GHOST, HoveringGhostEntity.createHoveringGhostAttributes());

		// JERBOA:
		JERBOA = Registry.register(Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "jerboa"),
				EntityType.Builder.create(JerboaEntity::new, SpawnGroup.CREATURE)
						.dimensions(0.4f, 0.4f)
						.maxTrackingRange(8).trackingTickInterval(2).build());
		SpawnRestriction.register(
				GileMod.JERBOA,
				SpawnLocationTypes.ON_GROUND,
				Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
				(type, world, reason, pos, random) -> {
					BlockState below = world.getBlockState(pos.down());
					return below.isOf(GileMod.MOON_SAND) || below.isOf(Blocks.SAND) || below.isOf(Blocks.RED_SAND);});
		JERBOA_SPAWN_EGG = new SpawnEggItem(JERBOA,
				0xFDDC66, 0xFDEF99, new Item.Settings());
		FabricDefaultAttributeRegistry.register(JERBOA, JerboaEntity.createJerboaAttributes());

		// GLOOMY LYNX:
		GLOOMY_LYNX = Registry.register(
				Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "gloomy_lynx"),
				EntityType.Builder.create(GloomyLynxEntity::new, SpawnGroup.CREATURE)
						.dimensions(0.8f, 1.2f)
						.maxTrackingRange(8).trackingTickInterval(2).build());
		SpawnRestriction.register(GLOOMY_LYNX,
				SpawnLocationTypes.ON_GROUND,
				Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
				(type, world, reason, pos, random) -> {
					BlockState below = world.getBlockState(pos.down());
					return	below.isOf(END_GRASS_BLOCK);});
		GLOOMY_LYNX_SPAWN_EGG = new SpawnEggItem(GLOOMY_LYNX,
				0x3A5F79, 0x2CCDB1, new Item.Settings());
		FabricDefaultAttributeRegistry.register(GLOOMY_LYNX, GloomyLynxEntity.createLynxAttributes());

		// WEASEL THIEF:
		WEASEL_THIEF = Registry.register(
				Registries.ENTITY_TYPE,
				Identifier.of(MOD_ID, "weasel_thief"),
				EntityType.Builder.create(WeaselThiefEntity::new, SpawnGroup.CREATURE)
						.dimensions(0.6f, 0.5f).build());
		SpawnRestriction.register(WEASEL_THIEF,
				SpawnLocationTypes.ON_GROUND,
				Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
				(type, world, reason, pos, random) -> {
					BlockState below = world.getBlockState(pos.down());
					return	below.isOf(Blocks.GRASS_BLOCK) ||
							below.isOf(Blocks.COARSE_DIRT) ||
							below.isOf(Blocks.MYCELIUM) ||
							below.isOf(Blocks.MOSS_BLOCK) ||
							below.isOf(Blocks.SAND) ||
							below.isOf(Blocks.GRAVEL) ||
							below.isOf(Blocks.STONE) ||
							below.isOf(Blocks.DEEPSLATE) ||
							below.isOf(Blocks.TERRACOTTA)||
							below.isOf(Blocks.SNOW);});
		WEASEL_THIEF_SPAWN_EGG = new SpawnEggItem(WEASEL_THIEF,
				0x6C635A, 0x6C4B3F, new Item.Settings());
		FabricDefaultAttributeRegistry.register(WEASEL_THIEF, WeaselThiefEntity.createWeaselAttributes());

		/*=================
		ITEM REGISTRATIONS:
		==================*/

		// SIGILS:
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "primogem"), PRIMOGEM);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "anemo_sigil"), ANEMO_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "geo_sigil"), GEO_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "electro_sigil"), ELECTRO_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "dendro_sigil"), DENDRO_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "hydro_sigil"), HYDRO_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "pyro_sigil"), PYRO_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "cryo_sigil"), CRYO_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "luna_sigil"), LUNA_SIGIL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "mora"), MORA);

		// MATERIALS:
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "wish_ingot"), WISH_INGOT);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "wish_nugget"), WISH_NUGGET);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "crystal"), CRYSTAL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moth_wing"), MOTH_WING);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "void_slimeball"), VOID_SLIMEBALL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "jelly"), JELLY);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "jam"), JAM);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "phasma"), PHASMA);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "cooked_phasma"), COOKED_PHASMA);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "star_fragment"), STAR_FRAGMENT);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "chrono_gear"), CHRONO_GEAR);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "jerboas_tail"), JERBOAS_TAIL);

		//SPAWN EGGS:
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "void_slime_spawn_egg"), VOID_SLIME_SPAWN_EGG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moth_spawn_egg"), MOTH_SPAWN_EGG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "luminous_spawn_egg"), LUMINOUS_SPAWN_EGG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "hovering_ghost_spawn_egg"), HOVERING_GHOST_SPAWN_EGG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "jerboa_spawn_egg"), JERBOA_SPAWN_EGG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "gloomy_lynx_spawn_egg"), GLOOMY_LYNX_SPAWN_EGG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "weasel_thief_spawn_egg"), WEASEL_THIEF_SPAWN_EGG);

		// FOOD & TOOLS:
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "offering"), OFFERING);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "fate_upgrade_smithing_template"), FATE_UPGRADE_SMITHING_TEMPLATE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "fate_sword"), FATE_SWORD);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "fate_bow"), FATE_BOW);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "fate_arrow"), FATE_ARROW);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "heart_of_healing"), HEART_OF_HEALING);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "shadow_clock"), SHADOW_CLOCK);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "grappling_hook"), GRAPPLING_HOOK);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "shrinker"), SHRINKER);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "enlarger"), ENLARGER);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "daybreak_chronicles"), DAYBREAK_CHRONICLES);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "vortex_vanquisher"), VORTEX_VANQUISHER);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "engulfing_lightning"), ENGULFING_LIGHTNING);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "thousand_blazing_suns"), THOUSAND_BLAZING_SUNS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "splendor_of_tranquil_waters"), SPLENDOR_OF_TRANQUIL_WATERS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "tsaritsas_scepter"), TSARITSAS_SCEPTER);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "thousand_floating_dreams"), THOUSAND_FLOATING_DREAMS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "nocturnes_curtain_call"), NOCTURNES_CURTAIN_CALL);

		/*==================
		BLOCK REGISTRATIONS:
		===================*/

		// PRIMOGEM/PEARLESCENT:
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "primogem_ore"), PRIMOGEM_ORE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "primogem_ore"), PRIMOGEM_ORE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "deepslate_primogem_ore"), DEEPSLATE_PRIMOGEM_ORE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "deepslate_primogem_ore"), DEEPSLATE_PRIMOGEM_ORE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "end_primogem_ore"), END_PRIMOGEM_ORE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "end_primogem_ore"), END_PRIMOGEM_ORE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "wish"), WISH);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "wish"), WISH_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "pearlescent_block"), PEARLESCENT_BLOCK);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "pearlescent_block"), PEARLESCENT_BLOCK_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "pearlescent_bricks"), PEARLESCENT_BRICKS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "pearlescent_bricks"), PEARLESCENT_BRICKS_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "pearlescent_stairs"), PEARLESCENT_STAIRS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "pearlescent_stairs"), PEARLESCENT_STAIRS_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "pearlescent_slab"), PEARLESCENT_SLAB);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "pearlescent_slab"), PEARLESCENT_SLAB_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "pearlescent_wall"), PEARLESCENT_WALL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "pearlescent_wall"), PEARLESCENT_WALL_ITEM);

		// MOON SAND(STONE):
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_sand"), MOON_SAND);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_sand"), MOON_SAND_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_sandstone"), MOON_SANDSTONE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_sandstone"), MOON_SANDSTONE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_sandstone_stairs"), MOON_SANDSTONE_STAIRS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_sandstone_stairs"), MOON_SANDSTONE_STAIRS_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_sandstone_slab"), MOON_SANDSTONE_SLAB);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_sandstone_slab"), MOON_SANDSTONE_SLAB_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_sandstone_wall"), MOON_SANDSTONE_WALL);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_sandstone_wall"), MOON_SANDSTONE_WALL_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_chiseled_sandstone"), MOON_CHISELED_SANDSTONE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_chiseled_sandstone"), MOON_CHISELED_SANDSTONE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_smooth_sandstone"), MOON_SMOOTH_SANDSTONE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_smooth_sandstone"), MOON_SMOOTH_SANDSTONE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_smooth_sandstone_stairs"), MOON_SMOOTH_SANDSTONE_STAIRS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_smooth_sandstone_stairs"), MOON_SMOOTH_SANDSTONE_STAIRS_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_smooth_sandstone_slab"), MOON_SMOOTH_SANDSTONE_SLAB);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_smooth_sandstone_slab"), MOON_SMOOTH_SANDSTONE_SLAB_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_cut_sandstone"), MOON_CUT_SANDSTONE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_cut_sandstone"), MOON_CUT_SANDSTONE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_cut_sandstone_slab"), MOON_CUT_SANDSTONE_SLAB);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_cut_sandstone_slab"), MOON_CUT_SANDSTONE_SLAB_ITEM);

		// FIRE & OTHER:
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_torch"), MOON_TORCH);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_wall_torch"), MOON_WALL_TORCH);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "moon_lantern"), MOON_LANTERN);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_campfire"), MOON_CAMPFIRE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "end_cloud"), END_CLOUD);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "end_cloud"), END_CLOUD_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "star"), STAR);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "star"), STAR_ITEM);

		// PLANTS:
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "moon_flower"), MOON_FLOWER_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "potted_moon_flower"), POTTED_MOON_FLOWER);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "gloomy_flower"), GLOOMY_FLOWER_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "potted_gloomy_flower"), POTTED_GLOOMY_FLOWER);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "dry_flower"), DRY_FLOWER_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "potted_dry_flower"), POTTED_DRY_FLOWER);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "end_grass_block"), END_GRASS_BLOCK_ITEM);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "end_grass"), END_GRASS_ITEM);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "tall_end_grass"), TALL_END_GRASS_ITEM);

		// GHOSTLY WOOD TYPE:
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_leaves"), GHOSTLY_LEAVES_ITEM);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_sapling"), GHOSTLY_SAPLING_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "potted_ghostly_sapling"), POTTED_GHOSTLY_SAPLING);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_log"), GHOSTLY_LOG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_log"), GHOSTLY_LOG_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "stripped_ghostly_log"), STRIPPED_GHOSTLY_LOG);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "stripped_ghostly_log"), STRIPPED_GHOSTLY_LOG_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_wood"), GHOSTLY_WOOD);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_wood"), GHOSTLY_WOOD_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "stripped_ghostly_wood"), STRIPPED_GHOSTLY_WOOD);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "stripped_ghostly_wood"), STRIPPED_GHOSTLY_WOOD_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_planks"), GHOSTLY_PLANKS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_planks"), GHOSTLY_PLANKS_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_stairs"), GHOSTLY_STAIRS);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_stairs"), GHOSTLY_STAIRS_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_slab"), GHOSTLY_SLAB);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_slab"), GHOSTLY_SLAB_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_fence"), GHOSTLY_FENCE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_fence"), GHOSTLY_FENCE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_fence_gate"), GHOSTLY_FENCE_GATE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_fence_gate"), GHOSTLY_FENCE_GATE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_door"), GHOSTLY_DOOR);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_door"), GHOSTLY_DOOR_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_trapdoor"), GHOSTLY_TRAPDOOR);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_trapdoor"), GHOSTLY_TRAPDOOR_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_pressure_plate"), GHOSTLY_PRESSURE_PLATE);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_pressure_plate"), GHOSTLY_PRESSURE_PLATE_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_button"), GHOSTLY_BUTTON);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_button"), GHOSTLY_BUTTON_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_sign"), GHOSTLY_SIGN);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_wall_sign"), GHOSTLY_WALL_SIGN);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_sign"), GHOSTLY_SIGN_ITEM);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_hanging_sign"), GHOSTLY_HANGING_SIGN);
		Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ghostly_wall_hanging_sign"), GHOSTLY_WALL_HANGING_SIGN);
		Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ghostly_hanging_sign"), GHOSTLY_HANGING_SIGN_ITEM);

		/*=====================
		COMPLEX REGISTRATIONS:
		=====================*/

		// BLOCK-ENTITIES:
		GHOSTLY_SIGN_BLOCK_ENTITY = Registry.register(
				Registries.BLOCK_ENTITY_TYPE,
				Identifier.of(MOD_ID, "ghostly_sign_entity"),
				FabricBlockEntityTypeBuilder.create(GhostlySignBlockEntity::new, GHOSTLY_SIGN, GHOSTLY_WALL_SIGN).build());
		GHOSTLY_HANGING_SIGN_BLOCK_ENTITY = Registry.register(
				Registries.BLOCK_ENTITY_TYPE,
				Identifier.of(MOD_ID, "ghostly_hanging_sign_entity"),
				FabricBlockEntityTypeBuilder.create(GhostlyHangingSignBlockEntity::new, GHOSTLY_HANGING_SIGN, GHOSTLY_WALL_HANGING_SIGN).build());

		// PLACEMENT LOGIC:
		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
			BlockPos clickedPos = hitResult.getBlockPos();
			Direction face = hitResult.getSide();
			BlockPos firePos = clickedPos.offset(face);
			ItemStack stack = player.getStackInHand(hand);
			if (stack.isOf(Items.FLINT_AND_STEEL) || stack.isOf(Items.FIRE_CHARGE)) {
				BlockState clickedState = world.getBlockState(clickedPos);
				// If they click moon sand, and the space above is empty
				if (clickedState.isOf(GileMod.MOON_SAND) && world.getBlockState(firePos).isAir()) {
					world.playSound(player, firePos, SoundEvents.ITEM_FLINTANDSTEEL_USE, SoundCategory.BLOCKS, 1.0F, world.getRandom().nextFloat() * 0.4F + 0.8F);
					// Only place the block and damage the item on the server
					if (!world.isClient()) {
						world.setBlockState(firePos, MOON_FIRE.getDefaultState(), 11);
						if (!player.isCreative()) {
							if (stack.isOf(Items.FLINT_AND_STEEL)) {
								stack.damage(1, player, EquipmentSlot.MAINHAND);
							} else {
								stack.decrement(1);
							}}}return ActionResult.success(world.isClient());}}return ActionResult.PASS;});

		MOON_TORCH_ITEM = Registry.register(Registries.ITEM,
				Identifier.of(MOD_ID, "moon_torch"),
				new VerticallyAttachableBlockItem(
						MOON_TORCH, MOON_WALL_TORCH,
						new Item.Settings(), Direction.DOWN));
		MOON_LANTERN_ITEM = Registry.register(Registries.ITEM,
				Identifier.of(MOD_ID, "moon_lantern"),
				new BlockItem(MOON_LANTERN, new Item.Settings()));

		// NAMING LOGIC:
		UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
				ItemStack stack = player.getStackInHand(hand);
				// Check if the player is holding a Name Tag that has a custom name
				if (stack.isOf(Items.NAME_TAG) && stack.contains(net.minecraft.component.DataComponentTypes.CUSTOM_NAME)) {
					String appliedName = stack.getName().getString();
					// Trigger your custom advancement criterion
					mh837.gile.advancement.NamedEntityCriterion.CRITERION.trigger(serverPlayer, entity, appliedName);
				}}return ActionResult.PASS;});

		// STRIPPABLE:
		StrippableBlockRegistry.register(GHOSTLY_LOG, STRIPPED_GHOSTLY_LOG);
		StrippableBlockRegistry.register(GHOSTLY_WOOD, STRIPPED_GHOSTLY_WOOD);

		// COMPOSTER:
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(GHOSTLY_LEAVES_ITEM, 0.3f);
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(GHOSTLY_SAPLING_ITEM, 0.3f);
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(TALL_END_GRASS_ITEM, 0.3f);
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(END_GRASS_ITEM, 0.3f);
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(DRY_FLOWER_ITEM, 0.3f);
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(MOON_FLOWER_ITEM, 0.65f);
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(GLOOMY_FLOWER_ITEM, 0.65f);
		ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.put(JELLY, 0.65f);

		// FUEL:
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_LOG, 300);
		FuelRegistry.INSTANCE.add(GileMod.STRIPPED_GHOSTLY_LOG, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_WOOD, 300);
		FuelRegistry.INSTANCE.add(GileMod.STRIPPED_GHOSTLY_WOOD, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_PLANKS, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_STAIRS, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_SLAB, 150);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_FENCE, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_FENCE_GATE, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_DOOR, 200);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_PRESSURE_PLATE, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_BUTTON, 100);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_TRAPDOOR, 300);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_SAPLING, 100);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_SIGN, 200);
		FuelRegistry.INSTANCE.add(GileMod.GHOSTLY_HANGING_SIGN, 800);
		FuelRegistry.INSTANCE.add(GileMod.STAR, 3200);

		/*===========================
		CREATIVE TABS REGISTRATIONS:
		===========================*/

		Registry.register(Registries.ITEM_GROUP,
				Identifier.of(MOD_ID, "gile"),
				FabricItemGroup.builder()
						.icon(() -> new ItemStack(PRIMOGEM))
						.displayName(Text.translatable("itemGroup.gilemod.gile"))
						.entries((displayContext, entries) -> {

							entries.add(MORA); entries.add(ANEMO_SIGIL); entries.add(GEO_SIGIL);
							entries.add(ELECTRO_SIGIL); entries.add(DENDRO_SIGIL); entries.add(HYDRO_SIGIL);
							entries.add(PYRO_SIGIL); entries.add(CRYO_SIGIL); entries.add(LUNA_SIGIL);
							entries.add(PRIMOGEM);
							entries.add(DAYBREAK_CHRONICLES); entries.add(VORTEX_VANQUISHER);
							entries.add(ENGULFING_LIGHTNING); entries.add(THOUSAND_FLOATING_DREAMS);
							entries.add(SPLENDOR_OF_TRANQUIL_WATERS); entries.add(THOUSAND_BLAZING_SUNS);
							entries.add(TSARITSAS_SCEPTER); entries.add(NOCTURNES_CURTAIN_CALL);

							entries.add(PRIMOGEM_ORE_ITEM); entries.add(DEEPSLATE_PRIMOGEM_ORE_ITEM);
							entries.add(END_PRIMOGEM_ORE_ITEM); entries.add(END_GRASS_BLOCK_ITEM);
							entries.add(MOON_SAND_ITEM); entries.add(MOON_SANDSTONE);
							entries.add(MOON_SANDSTONE_STAIRS); entries.add(MOON_SANDSTONE_SLAB);
							entries.add(MOON_SANDSTONE_WALL);

							entries.add(MOON_CHISELED_SANDSTONE); entries.add(MOON_SMOOTH_SANDSTONE);
							entries.add(MOON_SMOOTH_SANDSTONE_STAIRS); entries.add(MOON_SMOOTH_SANDSTONE_SLAB);
							entries.add(MOON_CUT_SANDSTONE); entries.add(MOON_CUT_SANDSTONE_SLAB);
							entries.add(PEARLESCENT_BRICKS_ITEM); entries.add(WISH);
							entries.add(PEARLESCENT_BLOCK_ITEM);

							entries.add(PEARLESCENT_STAIRS_ITEM);
							entries.add(PEARLESCENT_SLAB_ITEM); entries.add(PEARLESCENT_WALL_ITEM);
							entries.add(END_CLOUD_ITEM); entries.add(STAR_ITEM);
							entries.add(MOON_TORCH_ITEM); entries.add(MOON_LANTERN_ITEM);
							entries.add(PEARLESCENT_CHAIN_ITEM); entries.add(MOON_CAMPFIRE_ITEM);

							entries.add(GHOSTLY_LOG_ITEM);
							entries.add(GHOSTLY_WOOD_ITEM); entries.add(STRIPPED_GHOSTLY_LOG_ITEM);
							entries.add(STRIPPED_GHOSTLY_WOOD_ITEM); entries.add(GHOSTLY_PLANKS_ITEM);
							entries.add(GHOSTLY_STAIRS_ITEM); entries.add(GHOSTLY_SLAB_ITEM);
							entries.add(GHOSTLY_FENCE_ITEM); entries.add(GHOSTLY_FENCE_GATE_ITEM);
							entries.add(GHOSTLY_DOOR_ITEM);
							entries.add(GHOSTLY_TRAPDOOR_ITEM); entries.add(GHOSTLY_PRESSURE_PLATE_ITEM);
							entries.add(GHOSTLY_BUTTON_ITEM); entries.add(GHOSTLY_SIGN_ITEM);
							entries.add(GHOSTLY_HANGING_SIGN_ITEM); entries.add(GHOSTLY_LEAVES_ITEM);
							entries.add(TALL_END_GRASS_ITEM); entries.add(END_GRASS_ITEM);

							entries.add(GHOSTLY_SAPLING_ITEM); entries.add(DRY_FLOWER_ITEM);
							entries.add(GLOOMY_FLOWER_ITEM); entries.add(MOON_FLOWER_ITEM);
							entries.add(STAR_FRAGMENT); entries.add(CRYSTAL);
							entries.add(WISH_INGOT); entries.add(WISH_NUGGET);
							entries.add(FATE_UPGRADE_SMITHING_TEMPLATE);

							entries.add(OFFERING); entries.add(JAM); entries.add(JELLY);
							entries.add(VOID_SLIMEBALL); entries.add(MOTH_WING);
							entries.add(JERBOAS_TAIL); entries.add(PHASMA);
							entries.add(COOKED_PHASMA); entries.add(CHRONO_GEAR);

							entries.add(JELLY_ON_A_STICK); entries.add(GRAPPLING_HOOK);
							entries.add(FATE_SWORD); entries.add(FATE_BOW); entries.add(FATE_ARROW);
							entries.add(SHRINKER); entries.add(ENLARGER);
							entries.add(HEART_OF_HEALING); entries.add(SHADOW_CLOCK);

							entries.add(VOID_SLIME_SPAWN_EGG); entries.add(MOTH_SPAWN_EGG);
							entries.add(HOVERING_GHOST_SPAWN_EGG); entries.add(LUMINOUS_SPAWN_EGG);
							entries.add(JERBOA_SPAWN_EGG); entries.add(GLOOMY_LYNX_SPAWN_EGG);
							entries.add(WEASEL_THIEF_SPAWN_EGG);

						}).build());

		/*===================
		BIOME MODIFICATIONS:
		====================*/

		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_OVERWORLD),
				GenerationStep.Feature.UNDERGROUND_ORES,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "primogem_ore")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_END),
				GenerationStep.Feature.UNDERGROUND_ORES,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "end_primogem_ore")));
		BiomeModifications.addFeature(
				context -> {
					if (!context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_END)) {
						return false;}
					return !context.getBiomeRegistryEntry().matchesKey(BiomeKeys.THE_END);},
				GenerationStep.Feature.VEGETAL_DECORATION,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "moon_sand")));
		BiomeModifications.addFeature(
				context -> {
					if (!context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_END)) {
						return false;}
					// Exclude THE_END AND MOON_DESERT
					return !context.getBiomeRegistryEntry().matchesKey(BiomeKeys.THE_END)
							&& !context.getBiomeRegistryEntry().matchesKey(MOON_DESERT);
				},
				GenerationStep.Feature.TOP_LAYER_MODIFICATION,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "moon_flower")));

		/*============================
		ENTITY SPAWNING REGISTRATIONS:
		============================*/

		BiomeModifications.addSpawn(
				context -> {
					// Only in End biomes
					if (!context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_END)) {
						return false;}
					// Exclude the main End island
					return !context.getBiomeRegistryEntry().matchesKey(BiomeKeys.THE_END);},
				SpawnGroup.MONSTER, VOID_SLIME, // Weight, min/max group size
				15, 1, 3);
		BiomeModifications.addSpawn(
				context -> {
					if (!context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_END)) {
						return false;}
					return !context.getBiomeRegistryEntry().matchesKey(BiomeKeys.THE_END);},
				SpawnGroup.CREATURE,  MOTH,
				30,    1, 3);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().matchesKey(BiomeKeys.DARK_FOREST),
				SpawnGroup.CREATURE, MOTH,
				20, 1, 3);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().matchesKey(BiomeKeys.MUSHROOM_FIELDS),
				SpawnGroup.CREATURE, MOTH,
				10, 1, 3);
		BiomeModifications.addSpawn(
				context -> {
					if (!context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_END)) {
						return false;}
					return !context.getBiomeRegistryEntry().matchesKey(BiomeKeys.THE_END);},
				SpawnGroup.AMBIENT,  LUMINOUS,
				10,    1, 3);
		BiomeModifications.addSpawn(
				context -> {
					if (!context.getBiomeRegistryEntry().isIn(net.minecraft.registry.tag.BiomeTags.IS_END)) {
						return false;}
					return !context.getBiomeRegistryEntry().matchesKey(BiomeKeys.THE_END);},
				SpawnGroup.AMBIENT,  HOVERING_GHOST,
				5,    1, 2);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().matchesKey(MOON_DESERT),
				SpawnGroup.AMBIENT, JERBOA,
				5, 2, 3);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().matchesKey(BiomeKeys.DESERT),
				SpawnGroup.CREATURE, JERBOA,
				20, 2, 5);
		BiomeModifications.addSpawn(
				context -> context.getBiomeRegistryEntry().matchesKey(GHOSTLY_THICKETS),
				SpawnGroup.CREATURE, GLOOMY_LYNX,
				10, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
				SpawnGroup.CREATURE, WEASEL_THIEF,
				5, 1, 1);

		/*=====================
		WORLDGEN REGISTRATIONS:
		======================*/

		TheEndBiomes.addHighlandsBiome(GHOSTLY_THICKETS, 0.3);
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().matchesKey(GHOSTLY_THICKETS),
				GenerationStep.Feature.TOP_LAYER_MODIFICATION,
				GHOSTLY_SURFACE_PLACED_KEY);
		TheEndBiomes.addHighlandsBiome(MOON_DESERT, 1.5);
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().matchesKey(MOON_DESERT),
				GenerationStep.Feature.TOP_LAYER_MODIFICATION,
				MOON_DESERT_SURFACE_PLACED_KEY);

		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().matchesKey(GHOSTLY_THICKETS),
				GenerationStep.Feature.TOP_LAYER_MODIFICATION,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "end_cloud_blob")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().matchesKey(GHOSTLY_THICKETS),
				GenerationStep.Feature.TOP_LAYER_MODIFICATION,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "star")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().matchesKey(GHOSTLY_THICKETS),
				GenerationStep.Feature.VEGETAL_DECORATION,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "end_grass")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().matchesKey(GHOSTLY_THICKETS),
				GenerationStep.Feature.VEGETAL_DECORATION,
				RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.of(MOD_ID, "tall_end_grass")));
		BiomeModifications.addFeature(
				context -> context.getBiomeRegistryEntry().matchesKey(GHOSTLY_THICKETS),
				GenerationStep.Feature.VEGETAL_DECORATION,
				GHOSTLY_TREE_PLACED_KEY);

	}
}