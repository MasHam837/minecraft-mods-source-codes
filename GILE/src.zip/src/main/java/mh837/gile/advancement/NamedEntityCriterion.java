package mh837.gile.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancement.criterion.AbstractCriterion;
import net.minecraft.entity.Entity;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.Optional;

public class NamedEntityCriterion extends AbstractCriterion<NamedEntityCriterion.Conditions> {
    public static final Identifier ID = Identifier.of("gilemod", "named_entity");

    // Add this static field
    public static final NamedEntityCriterion CRITERION = new NamedEntityCriterion();

    @Override
    public Codec<Conditions> getConditionsCodec() {
        return Conditions.CODEC;
    }

    public void trigger(ServerPlayerEntity player, Entity entity, String name) {
        this.trigger(player, conditions -> conditions.matches(entity, name));
    }

    public record Conditions(
            Optional<LootContextPredicate> player,
            Optional<String> entityType,
            Optional<String> name
    ) implements AbstractCriterion.Conditions {

        public static final Codec<Conditions> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        LootContextPredicate.CODEC.optionalFieldOf("player").forGetter(Conditions::player),
                        Codec.STRING.optionalFieldOf("entity_type").forGetter(Conditions::entityType),
                        Codec.STRING.optionalFieldOf("name").forGetter(Conditions::name)
                ).apply(instance, Conditions::new)
        );

        public boolean matches(Entity entity, String entityName) {
            // 1. Check entity type if present
            if (this.entityType.isPresent()) {
                String expectedType = Registries.ENTITY_TYPE.getId(entity.getType()).toString();
                // If the type is provided but doesn't match the entity being named, return false
                if (!expectedType.equals(this.entityType.get())) {
                    return false;
                }
            }

            // 2. Check name if present
            if (this.name.isPresent()) {
                // If the name is provided but doesn't match the name given, return false
                if (!this.name.get().equalsIgnoreCase(entityName)) {
                    return false;
                }
            }

            // 3. If both provided checks passed (or were absent), it's a match
            return true;
        }
    }
}