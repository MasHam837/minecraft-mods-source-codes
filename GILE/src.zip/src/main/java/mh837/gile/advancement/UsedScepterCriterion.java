package mh837.gile.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancement.criterion.AbstractCriterion;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.Optional;

public class UsedScepterCriterion extends AbstractCriterion<UsedScepterCriterion.Conditions> {
    public static final Identifier ID = Identifier.of("gilemod", "used_scepter");

    // The singleton instance we will call from our items
    public static final UsedScepterCriterion CRITERION = new UsedScepterCriterion();

    @Override
    public Codec<Conditions> getConditionsCodec() {
        return Conditions.CODEC;
    }

    // This public method bridges the gap to the protected AbstractCriterion.trigger()
    public void trigger(ServerPlayerEntity player, ItemStack stack) {
        this.trigger(player, conditions -> conditions.matches(stack));
    }

    public record Conditions(
            Optional<LootContextPredicate> player,
            Optional<String> itemId
    ) implements AbstractCriterion.Conditions {

        public static final Codec<Conditions> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        LootContextPredicate.CODEC.optionalFieldOf("player").forGetter(Conditions::player),
                        Codec.STRING.optionalFieldOf("item_id").forGetter(Conditions::itemId)
                ).apply(instance, Conditions::new)
        );

        public boolean matches(ItemStack stack) {
            if (this.itemId.isPresent()) {
                String expectedType = Registries.ITEM.getId(stack.getItem()).toString();
                if (!expectedType.equals(this.itemId.get())) {
                    return false;
                }
            }
            return true;
        }
    }
}