package mh837.gile.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.SimpleBlockFeatureConfig;
import net.minecraft.world.gen.feature.util.FeatureContext;

public class StarFeature extends Feature<SimpleBlockFeatureConfig> {
    public StarFeature(Codec<SimpleBlockFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean generate(FeatureContext<SimpleBlockFeatureConfig> context) {
        StructureWorldAccess world = context.getWorld();
        BlockPos origin = context.getOrigin();
        Random random = context.getRandom();
        SimpleBlockFeatureConfig config = context.getConfig();

        // 1. Calculate the exact same height as your clouds: 15-25 blocks above the surface
        int heightOffset = random.nextInt(6) + 20;
        BlockPos targetPos = origin.up(heightOffset);

        // 2. Check if the spot is empty, then place exactly ONE block
        if (world.getBlockState(targetPos).isAir()) {
            world.setBlockState(targetPos, config.toPlace().get(random, targetPos), 3);
            return true; // Successfully placed a star
        }

        return false; // Did not place anything (wasn't air)
    }
}