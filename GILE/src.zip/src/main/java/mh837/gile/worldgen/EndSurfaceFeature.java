package mh837.gile.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.SimpleBlockFeatureConfig;
import net.minecraft.world.gen.feature.util.FeatureContext;

public class EndSurfaceFeature extends Feature<SimpleBlockFeatureConfig> {

    public EndSurfaceFeature(Codec<SimpleBlockFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean generate(FeatureContext<SimpleBlockFeatureConfig> context) {

        StructureWorldAccess world = context.getWorld();
        BlockPos origin = context.getOrigin();
        var random = context.getRandom();

        boolean placed = false;

        /*
         * Medium-large radius
         * big enough to merge naturally
         * small enough to avoid chunk squares
         */
        int radius = 18;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {

                /*
                 * TRUE circular mask
                 */
                double distSq = dx * dx + dz * dz;

                if (distSq > radius * radius)
                    continue;

                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;

                /*
                 * Circular distance
                 */
                double dist = Math.sqrt(distSq);

                /*
                 * Organic edge warping
                 */
                double noise =
                        Math.sin(x * 0.09)
                                + Math.cos(z * 0.09)
                                + Math.sin((x + z) * 0.05);

                noise *= 2.2;

                /*
                 * Distorted circular biome edge
                 */
                double warpedDist = dist + noise;

                /*
                 * Smooth edge fade
                 */
                double edge = 1.0 - (warpedDist / radius);

                edge = MathHelper.clamp(edge, 0.0, 1.0);

                /*
                 * IMPORTANT:
                 * only reject VERY outer edge
                 * prevents holes everywhere else
                 */
                if (edge <= 0.08)
                    continue;

                int y = world.getTopY(
                        Heightmap.Type.MOTION_BLOCKING,
                        x,
                        z
                );

                BlockPos groundPos = new BlockPos(x, y - 1, z);
                BlockPos topPos = groundPos.up();

                if (!world.getBlockState(groundPos).isOf(Blocks.END_STONE))
                    continue;

                /*
                 * FULL terrain coverage
                 */
                world.setBlockState(
                        groundPos,
                        mh837.gile.GileMod.END_GRASS_BLOCK.getDefaultState(),
                        2
                );

                placed = true;

                /*
                 * Vegetation density
                 * strongest toward center
                 */
                if (world.isAir(topPos)) {

                    double plantDensity =
                            edge
                                    + (random.nextDouble() * 0.25);

                    if (plantDensity > 0.78 &&
                            random.nextFloat() < 0.45f) {

                        world.setBlockState(
                                topPos,
                                mh837.gile.GileMod.TALL_END_GRASS.getDefaultState(),
                                2
                        );

                    } else if (plantDensity > 0.45 &&
                            random.nextFloat() < 0.75f) {

                        world.setBlockState(
                                topPos,
                                mh837.gile.GileMod.END_GRASS.getDefaultState(),
                                2
                        );
                    }
                }
            }
        }

        return placed;
    }
}