package mh837.gile.worldgen;

import mh837.gile.GileMod;
import com.mojang.serialization.Codec;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.SimpleBlockFeatureConfig;
import net.minecraft.world.gen.feature.util.FeatureContext;

public class MoonDesertSurfaceFeature extends Feature<SimpleBlockFeatureConfig> {

    public MoonDesertSurfaceFeature(Codec<SimpleBlockFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean generate(FeatureContext<SimpleBlockFeatureConfig> context) {

        StructureWorldAccess world = context.getWorld();
        BlockPos origin = context.getOrigin();

        boolean placed = false;

        int radius = 18;

        Block moonSand = GileMod.MOON_SAND;
        Block moonSandstone = GileMod.MOON_SANDSTONE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {

                double distSq = dx * dx + dz * dz;

                if (distSq > radius * radius)
                    continue;

                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;

                int topY = world.getTopY(
                        Heightmap.Type.MOTION_BLOCKING,
                        x,
                        z
                );

                BlockPos topPos = new BlockPos(x, topY - 1, z);

                if (!world.getBlockState(topPos).isOf(Blocks.END_STONE))
                    continue;

                for (int depth = 0; depth < 3; depth++) {

                    BlockPos replacePos = topPos.down(depth);

                    if (world.getBlockState(replacePos).isOf(Blocks.END_STONE)) {

                        world.setBlockState(
                                replacePos,
                                moonSand.getDefaultState(),
                                2
                        );
                    }
                }

                BlockPos sandstonePos = topPos.down(3);

                if (world.getBlockState(sandstonePos).isOf(Blocks.END_STONE)) {

                    world.setBlockState(sandstonePos,moonSandstone.getDefaultState(),2);
                }

                placed = true;
            }
        }

        return placed;
    }
}