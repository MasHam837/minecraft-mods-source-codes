package mh837.gile.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.SimpleBlockFeatureConfig;
import net.minecraft.world.gen.feature.util.FeatureContext;

public class CloudBlobFeature extends Feature<SimpleBlockFeatureConfig> {
    public CloudBlobFeature(Codec<SimpleBlockFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean generate(FeatureContext<SimpleBlockFeatureConfig> context) {
        StructureWorldAccess world = context.getWorld();
        BlockPos origin = context.getOrigin();
        Random random = context.getRandom();
        SimpleBlockFeatureConfig config = context.getConfig();

        // Rise 15-25 blocks above surface
        int heightOffset = random.nextInt(11) + 15;
        BlockPos center = origin.up(heightOffset);

        // Rectangular dimensions: wider than tall, always 1 block high
        int radiusX = 3 + random.nextInt(3);  // 3-5 blocks in X
        int radiusZ = 3 + random.nextInt(3);  // 3-5 blocks in Z
        // Y is always 0 (single layer)

        BlockPos.Mutable mutable = new BlockPos.Mutable();

        // Generate a single flat layer with rectangular shape
        for (int dx = -radiusX; dx <= radiusX; dx++) {
            for (int dz = -radiusZ; dz <= radiusZ; dz++) {
                // Rectangular shape with rough edges (optional noise)
                double edgeFactor = 1.0;

                // Add some randomness to edges for natural look
                if (Math.abs(dx) == radiusX || Math.abs(dz) == radiusZ) {
                    // 60% chance to place blocks at the edges (makes it slightly irregular)
                    if (random.nextFloat() > 0.6f) {
                        continue;
                    }
                }

                // Corner blocks have even lower chance (rounded corners)
                if (Math.abs(dx) == radiusX && Math.abs(dz) == radiusZ) {
                    if (random.nextFloat() > 0.3f) {
                        continue;
                    }
                }

                mutable.set(center, dx, 0, dz);

                // Only replace air
                if (world.getBlockState(mutable).isAir()) {
                    world.setBlockState(mutable, config.toPlace().get(random, mutable), 3);
                }
            }
        }

        return true;
    }
}