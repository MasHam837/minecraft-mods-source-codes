package mh837.gile.effect;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.AttributeContainer;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public class ShrinkStatusEffect extends StatusEffect {

    private static final Identifier SCALE_ID = Identifier.of("gilemod", "shrink.scale");
    private static final Identifier HEALTH_ID = Identifier.of("gilemod", "shrink.health");
    private static final Identifier SPEED_ID = Identifier.of("gilemod", "shrink.speed");
    private static final Identifier JUMP_ID = Identifier.of("gilemod", "shrink.jump");
    private static final Identifier STRENGTH_ID = Identifier.of("gilemod", "shrink.strength");
    private static final Identifier REACH_ENTITY_ID = Identifier.of("gilemod", "shrink.reach_entity");
    private static final Identifier REACH_BLOCK_ID = Identifier.of("gilemod", "shrink.reach_block");
    private static final Identifier GRAVITY_ID = Identifier.of("gilemod", "shrink.gravity");
    private static final Identifier STEP_HEIGHT_ID = Identifier.of("gilemod", "shrink.step_height");
    private static final Identifier FALL_DIST_ID = Identifier.of("gilemod", "shrink.fall_distance");

    public ShrinkStatusEffect() {
        super(StatusEffectCategory.NEUTRAL, 0x6743CA);
    }

    @Override
    public void onApplied(AttributeContainer attributes, int amplifier) {
        super.onApplied(attributes, amplifier);

        // Scale shrinks by 20% (0.2) per level
        double scaleShrink = 0.2 * (amplifier + 1);
        if (scaleShrink > 0.95) {
            scaleShrink = 0.95;
        }

        // Other stats shrink by 10% (0.1) per level
        double statsShrink = 0.1 * (amplifier + 1);
        if (statsShrink > 0.95) { // Critical: MUST remain below 1.0 to avoid 0 Max Health instadeath
            statsShrink = 0.95;
        }

        // Apply -20% scaling exclusively to GENERIC_SCALE
        applyModifier(attributes, EntityAttributes.GENERIC_SCALE, SCALE_ID, -scaleShrink);

        // Apply -10% scaling to everything else
        applyModifier(attributes, EntityAttributes.GENERIC_MAX_HEALTH, HEALTH_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.GENERIC_JUMP_STRENGTH, JUMP_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.GENERIC_ATTACK_DAMAGE, STRENGTH_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.PLAYER_BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.GENERIC_GRAVITY, GRAVITY_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.GENERIC_STEP_HEIGHT, STEP_HEIGHT_ID, -statsShrink);
        applyModifier(attributes, EntityAttributes.GENERIC_SAFE_FALL_DISTANCE, FALL_DIST_ID, -statsShrink);
    }

    @Override
    public void onRemoved(AttributeContainer attributes) {
        super.onRemoved(attributes);

        removeModifier(attributes, EntityAttributes.GENERIC_SCALE, SCALE_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_MAX_HEALTH, HEALTH_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_JUMP_STRENGTH, JUMP_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_ATTACK_DAMAGE, STRENGTH_ID);
        removeModifier(attributes, EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID);
        removeModifier(attributes, EntityAttributes.PLAYER_BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_GRAVITY, GRAVITY_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_STEP_HEIGHT, STEP_HEIGHT_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_SAFE_FALL_DISTANCE, FALL_DIST_ID);
    }

    // --- ADDED WATCHDOG LOGIC HERE ---

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        // Return true every tick so the game constantly validates the effect
        return true;
    }

    @Override
    public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
        EntityAttributeInstance scaleInstance = entity.getAttributeInstance(EntityAttributes.GENERIC_SCALE);

        // Double-check: If the entity has this effect active, but our custom scale modifier is missing (e.g., after reloading the world)
        if (scaleInstance != null && !scaleInstance.hasModifier(SCALE_ID)) {
            // Reapply all custom attributes safely
            this.onApplied(entity.getAttributes(), amplifier);
        }

        return true;
    }

    // ---------------------------------

    private void applyModifier(AttributeContainer attributes, RegistryEntry<EntityAttribute> attribute, Identifier id, double value) {
        EntityAttributeInstance instance = attributes.getCustomInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id); // Safely ensures no duplicate stacking
            instance.addTemporaryModifier(new EntityAttributeModifier(
                    id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
            ));
        }
    }

    private void removeModifier(AttributeContainer attributes, RegistryEntry<EntityAttribute> attribute, Identifier id) {
        EntityAttributeInstance instance = attributes.getCustomInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id);
        }
    }
}