package mh837.gile.effect;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.AttributeContainer;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public class EnlargeStatusEffect extends StatusEffect {

    private static final Identifier SCALE_ID = Identifier.of("gilemod", "enlarge.scale");
    private static final Identifier HEALTH_ID = Identifier.of("gilemod", "enlarge.health");
    private static final Identifier SPEED_ID = Identifier.of("gilemod", "enlarge.speed");
    private static final Identifier JUMP_ID = Identifier.of("gilemod", "enlarge.jump");
    private static final Identifier STRENGTH_ID = Identifier.of("gilemod", "enlarge.strength");
    private static final Identifier REACH_ENTITY_ID = Identifier.of("gilemod", "enlarge.reach_entity");
    private static final Identifier REACH_BLOCK_ID = Identifier.of("gilemod", "enlarge.reach_block");
    private static final Identifier GRAVITY_ID = Identifier.of("gilemod", "enlarge.gravity");
    private static final Identifier STEP_HEIGHT_ID = Identifier.of("gilemod", "enlarge.step_height");
    private static final Identifier FALL_DIST_ID = Identifier.of("gilemod", "enlarge.fall_distance");

    public EnlargeStatusEffect() {
        super(StatusEffectCategory.NEUTRAL, 0x98BC35);
    }

    @Override
    public void onApplied(AttributeContainer attributes, int amplifier) {
        super.onApplied(attributes, amplifier);

        // Scale grows by 20% (0.2) per level
        double scaleGrowth = 0.2 * (amplifier + 1);
        if (scaleGrowth > 16.0) {
            scaleGrowth = 16.0;
        }

        // Other stats grow by 10% (0.1) per level
        double statsGrowth = 0.1 * (amplifier + 1);
        if (statsGrowth > 8.0) { // Capped proportionally to the scale cap
            statsGrowth = 8.0;
        }

        // Apply 20% scaling exclusively to GENERIC_SCALE
        applyModifier(attributes, EntityAttributes.GENERIC_SCALE, SCALE_ID, scaleGrowth);

        // Apply 10% scaling to everything else
        applyModifier(attributes, EntityAttributes.GENERIC_MAX_HEALTH, HEALTH_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.GENERIC_JUMP_STRENGTH, JUMP_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.GENERIC_ATTACK_DAMAGE, STRENGTH_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.PLAYER_BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.GENERIC_GRAVITY, GRAVITY_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.GENERIC_STEP_HEIGHT, STEP_HEIGHT_ID, statsGrowth);
        applyModifier(attributes, EntityAttributes.GENERIC_SAFE_FALL_DISTANCE, FALL_DIST_ID, statsGrowth);
    }

    @Override
    public void onRemoved(AttributeContainer attributes) {
        super.onRemoved(attributes);

        removeModifier(attributes, EntityAttributes.GENERIC_SCALE, SCALE_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_MAX_HEALTH, HEALTH_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_JUMP_STRENGTH, JUMP_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_ATTACK_DAMAGE, STRENGTH_ID);
        removeModifier(attributes, EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE, REACH_ENTITY_ID);
        removeModifier(attributes, EntityAttributes.PLAYER_BLOCK_INTERACTION_RANGE, REACH_BLOCK_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_GRAVITY, GRAVITY_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_STEP_HEIGHT, STEP_HEIGHT_ID);
        removeModifier(attributes, EntityAttributes.GENERIC_SAFE_FALL_DISTANCE, FALL_DIST_ID);
    }

    // --- WATCHDOG LOGIC (Handles World Reloads) ---
    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        return true;
    }

    @Override
    public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
        EntityAttributeInstance scaleInstance = entity.getAttributeInstance(EntityAttributes.GENERIC_SCALE);

        if (scaleInstance != null && !scaleInstance.hasModifier(SCALE_ID)) {
            this.onApplied(entity.getAttributes(), amplifier);
        }

        return true;
    }
    // ----------------------------------------------

    private void applyModifier(AttributeContainer attributes, RegistryEntry<EntityAttribute> attribute, Identifier id, double value) {
        EntityAttributeInstance instance = attributes.getCustomInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id);
            instance.addTemporaryModifier(new EntityAttributeModifier(
                    id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
            ));
        }
    }

    private void removeModifier(AttributeContainer attributes, RegistryEntry<EntityAttribute> attribute, Identifier id) {
        EntityAttributeInstance instance = attributes.getCustomInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id);
        }
    }
}