package mh837.gile.block;

import mh837.gile.GileMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.SaplingGenerator;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public class GhostlySaplingBlock extends SaplingBlock {

    public GhostlySaplingBlock(SaplingGenerator generator, Settings settings) {
        super(generator, settings);
    }

    @Override
    protected boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
        return floor.isOf(GileMod.END_GRASS_BLOCK) || floor.isOf(Blocks.END_STONE) || floor.isOf(Blocks.GRASS_BLOCK) || floor.isOf(Blocks.DIRT);
    }
}