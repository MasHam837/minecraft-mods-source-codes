package mh837.gile.block.entity;

import mh837.gile.GileMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.CampfireCookingRecipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Clearable;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class MoonCampfireBlockEntity extends BlockEntity implements Clearable {
    private final DefaultedList<ItemStack> items;
    private final int[] cookingTimes;
    private final int[] cookingTotalTimes;

    public MoonCampfireBlockEntity(BlockPos pos, BlockState state) {
        super(GileMod.MOON_CAMPFIRE_ENTITY, pos, state);
        this.items = DefaultedList.ofSize(4, ItemStack.EMPTY);
        this.cookingTimes = new int[4];
        this.cookingTotalTimes = new int[4];
    }

    public static void clientTick(World world, BlockPos pos, BlockState state, MoonCampfireBlockEntity blockEntity) {
        // Only spawn particles if the campfire is lit
        if (!state.get(CampfireBlock.LIT)) {
            return;
        }

        Random random = world.random;

        // Check if placed on a hay block (vanilla handles this block state automatically)
        boolean isSignalFire = state.get(CampfireBlock.SIGNAL_FIRE);
        net.minecraft.particle.ParticleEffect smokeParticle = isSignalFire ? ParticleTypes.CAMPFIRE_SIGNAL_SMOKE : ParticleTypes.CAMPFIRE_COSY_SMOKE;
        double yVelocity = isSignalFire ? 0.07 : 0.07; // Double the upward velocity for signal fires

        // Spawn campfire smoke particles
        if (random.nextFloat() < 0.11F) {
            for (int i = 0; i < random.nextInt(2) + 2; i++) {
                world.addParticle(
                        smokeParticle,
                        true,
                        pos.getX() + 0.5 + random.nextDouble() / 3.0 * (random.nextBoolean() ? 1 : -1),
                        pos.getY() + random.nextDouble() + random.nextDouble(),
                        pos.getZ() + 0.5 + random.nextDouble() / 3.0 * (random.nextBoolean() ? 1 : -1),
                        0.0,
                        yVelocity,
                        0.0
                );
            }
        }

        // Spawn particles for items cooking
        for (int i = 0; i < blockEntity.items.size(); i++) {
            if (!blockEntity.items.get(i).isEmpty() && random.nextFloat() < 0.2F) {
                Direction direction = Direction.fromHorizontal(Math.floorMod(i, 4));
                float f = 0.3125F;
                double d = pos.getX() + 0.5 - (double)(direction.getOffsetX() * f) + (double)(direction.rotateYClockwise().getOffsetX() * f);
                double e = pos.getY() + 0.5;
                double g = pos.getZ() + 0.5 - (double)(direction.getOffsetZ() * f) + (double)(direction.rotateYClockwise().getOffsetZ() * f);

                world.addParticle(ParticleTypes.SMOKE, d, e, g, 0.0, 5.0E-4, 0.0);
            }
        }
    }

    public static void serverTick(World world, BlockPos pos, BlockState state, MoonCampfireBlockEntity blockEntity) {
        if (!state.get(CampfireBlock.LIT)) {
            return;
        }

        boolean hasItems = false;

        for (int i = 0; i < blockEntity.items.size(); i++) {
            ItemStack itemStack = blockEntity.items.get(i);
            if (!itemStack.isEmpty()) {
                hasItems = true;
                blockEntity.cookingTimes[i]++;

                if (blockEntity.cookingTimes[i] >= blockEntity.cookingTotalTimes[i]) {
                    SingleStackRecipeInput input = new SingleStackRecipeInput(itemStack);
                    ItemStack result = world.getRecipeManager()
                            .getFirstMatch(RecipeType.CAMPFIRE_COOKING, input, world)
                            .map(entry -> entry.value().craft(input, world.getRegistryManager()))
                            .orElse(itemStack);

                    ItemScatterer.spawn(world, pos.getX(), pos.getY(), pos.getZ(), result);
                    blockEntity.items.set(i, ItemStack.EMPTY);
                    blockEntity.updateListeners(); // Sync removal to client
                }
            }
        }

        if (hasItems) {
            blockEntity.markDirty();
        }
    }

    public boolean addItem(@Nullable LivingEntity livingEntity, ItemStack stack) {
        for (int i = 0; i < this.items.size(); i++) {
            ItemStack itemStack = this.items.get(i);
            if (itemStack.isEmpty()) {
                SingleStackRecipeInput input = new SingleStackRecipeInput(stack);
                Optional<RecipeEntry<CampfireCookingRecipe>> optional = this.world.getRecipeManager()
                        .getFirstMatch(RecipeType.CAMPFIRE_COOKING, input, this.world);

                if (optional.isPresent()) {
                    this.cookingTotalTimes[i] = optional.get().value().getCookingTime();
                    this.cookingTimes[i] = 0;
                    this.items.set(i, stack.splitUnlessCreative(1, livingEntity));
                    this.updateListeners(); // Sync addition to client
                    return true;
                }
            }
        }
        return false;
    }

    public boolean interact(PlayerEntity player) {
        for (int i = 0; i < this.items.size(); i++) {
            ItemStack itemStack = this.items.get(i);
            if (!itemStack.isEmpty()) {
                if (!this.world.isClient) {
                    ItemScatterer.spawn(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ(), itemStack);
                }
                this.items.set(i, ItemStack.EMPTY);
                this.updateListeners(); // Sync clearing to client
                return true;
            }
        }
        return false;
    }

    // Dynamic synchronization helper
    private void updateListeners() {
        this.markDirty();
        if (this.world != null) {
            this.world.updateListeners(this.pos, this.getCachedState(), this.getCachedState(), 3);
        }
    }

    @Override
    @Nullable
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup registryLookup) {
        return this.createNbt(registryLookup);
    }

    public DefaultedList<ItemStack> getItems() {
        return this.items;
    }

    @Override
    public void clear() {
        this.items.clear();
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.readNbt(nbt, registryLookup);
        this.items.clear();
        net.minecraft.inventory.Inventories.readNbt(nbt, this.items, registryLookup);
        if (nbt.contains("CookingTimes", 11)) {
            int[] is = nbt.getIntArray("CookingTimes");
            System.arraycopy(is, 0, this.cookingTimes, 0, Math.min(this.cookingTotalTimes.length, is.length));
        }
        if (nbt.contains("CookingTotalTimes", 11)) {
            int[] is = nbt.getIntArray("CookingTotalTimes");
            System.arraycopy(is, 0, this.cookingTotalTimes, 0, Math.min(this.cookingTotalTimes.length, is.length));
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        super.writeNbt(nbt, registryLookup);
        net.minecraft.inventory.Inventories.writeNbt(nbt, this.items, true, registryLookup);
        nbt.putIntArray("CookingTimes", this.cookingTimes);
        nbt.putIntArray("CookingTotalTimes", this.cookingTotalTimes);
    }
}