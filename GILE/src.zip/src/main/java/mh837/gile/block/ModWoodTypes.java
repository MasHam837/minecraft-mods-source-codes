package mh837.gile.block;

import mh837.gile.GileMod;
import net.fabricmc.fabric.api.object.builder.v1.block.type.BlockSetTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.block.type.WoodTypeBuilder;
import net.minecraft.block.BlockSetType;
import net.minecraft.block.WoodType;
import net.minecraft.util.Identifier;

public class ModWoodTypes {

    public static final BlockSetType GHOSTLY_BLOCK_SET =
            BlockSetTypeBuilder.copyOf(BlockSetType.OAK)
                    .register(Identifier.of(GileMod.MOD_ID, "ghostly"));

    public static final WoodType GHOSTLY_WOOD_TYPE =
            WoodTypeBuilder.copyOf(WoodType.OAK)
                    .register(Identifier.of(GileMod.MOD_ID, "ghostly"), GHOSTLY_BLOCK_SET);

    public static void init() {
        // No manual registration needed in 1.21.1
    }
}