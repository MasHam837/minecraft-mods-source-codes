package mh837.gile.block;

import mh837.gile.GileMod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Fertilizable;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class EndGrassBlock extends Block implements Fertilizable {

    public EndGrassBlock(Settings settings) {
        super(settings);
    }

    /**
     * Handles the dying behavior. If a solid, opaque block is placed directly
     * on top of this grass, it suffocates and turns back into basic End Stone.
     */
    @Override
    protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        BlockPos abovePos = pos.up();
        BlockState aboveState = world.getBlockState(abovePos);

        // If the block above is opaque and not air, suffocate the grass
        if (!aboveState.isAir() && aboveState.isSolidBlock(world, abovePos)) {
            world.setBlockState(pos, Blocks.END_STONE.getDefaultState());
        }
    }

    // --- BONE MEAL (FERTILIZABLE) LOGIC ---

    @Override
    public boolean isFertilizable(WorldView world, BlockPos pos, BlockState state) {
        // Players can only apply bone meal if there is open air space above the block
        return world.getBlockState(pos.up()).isAir();
    }

    @Override
    public boolean canGrow(World world, Random random, BlockPos pos, BlockState state) {
        return true;
    }

    /**
     * Executes when bone meal is successfully applied.
     * Spreads grass blocks to nearby End Stone and sprouts custom plants on top.
     */
    @Override
    public void grow(ServerWorld world, Random random, BlockPos pos, BlockState state) {
        // 1. SPROUT VEGETATION DIRECTLY ABOVE
        BlockPos directlyAbove = pos.up();
        if (world.getBlockState(directlyAbove).isAir()) {
            if (random.nextFloat() < 0.30f) {
                world.setBlockState(directlyAbove, GileMod.TALL_END_GRASS.getDefaultState());
            } else {
                world.setBlockState(directlyAbove, GileMod.END_GRASS.getDefaultState());
            }
        }

        // 2. SPREAD GRASS TO NEIGHBORING END STONE
        // We run a loop to simulate a burst spread radius (similar to moss or nylium)
        for (int i = 0; i < 16; i++) {
            BlockPos targetPos = pos.add(
                    random.nextInt(7) - 3, // X radius: -3 to +3 blocks away
                    random.nextInt(3) - 1, // Y radius: -1 to +1 block vertical shift
                    random.nextInt(7) - 3  // Z radius: -3 to +3 blocks away
            );
            BlockPos targetAbove = targetPos.up();

            // If the picked spot is plain vanilla End Stone with open air above it...
            if (world.getBlockState(targetPos).isOf(Blocks.END_STONE) && world.getBlockState(targetAbove).isAir()) {
                // Convert it to your custom End Grass Block!
                world.setBlockState(targetPos, this.getDefaultState());

                // Give it a random chance to instantly sprout your custom grass/tall grass on top
                float plantRoll = random.nextFloat();
                if (plantRoll < 0.15f) {
                    world.setBlockState(targetAbove, GileMod.TALL_END_GRASS.getDefaultState());
                } else if (plantRoll < 0.45f) {
                    world.setBlockState(targetAbove, GileMod.END_GRASS.getDefaultState());
                }
            }
        }
    }
}