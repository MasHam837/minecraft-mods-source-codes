package mh837.gile.block;

import mh837.gile.GileMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FlowerBlock;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public class MoonFlowerBlock extends FlowerBlock {

    public MoonFlowerBlock(RegistryEntry<StatusEffect> effect, int duration, Settings settings) {
        super(effect, duration, settings);
    }

    @Override
    protected boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
        return floor.isOf(Blocks.GRASS_BLOCK)
                || floor.isOf(Blocks.DIRT)
                || floor.isOf(GileMod.MOON_SAND)
                || floor.isOf(GileMod.END_GRASS_BLOCK);
    }
}