package mh837.gile.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.FallingBlock;

public class FallingMoonSand extends FallingBlock {
    public FallingMoonSand(Settings settings) {
        super(settings);
    }

    @Override
    public MapCodec<? extends FallingBlock> getCodec() {
        return createCodec(FallingMoonSand::new);
    }
}