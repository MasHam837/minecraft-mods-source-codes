package mh837.gile.block.entity;

import mh837.gile.GileMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.util.math.BlockPos;

public class GhostlyHangingSignBlockEntity extends SignBlockEntity {

    public GhostlyHangingSignBlockEntity(BlockPos pos, BlockState state) {
        super(GileMod.GHOSTLY_HANGING_SIGN_BLOCK_ENTITY, pos, state);
    }

    @Override
    public int getTextLineHeight() {
        return 9;
    }

    @Override
    public int getMaxTextWidth() {
        return 60;
    }

    @Override
    public BlockEntityType<?> getType() {
        return GileMod.GHOSTLY_HANGING_SIGN_BLOCK_ENTITY;
    }
}