package mh837.gile.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.WallTorchBlock;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

public class MoonWallTorchBlock extends WallTorchBlock {
    public MoonWallTorchBlock(Settings settings) {
        super(ParticleTypes.REVERSE_PORTAL, settings);
    }

    @Override
    public boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        Direction dir = state.get(FACING);
        BlockPos offset = pos.offset(dir.getOpposite());
        return Block.sideCoversSmallSquare(world, offset, dir);
    }

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        Direction direction = state.get(FACING);
        double x = (double)pos.getX() + 0.5;
        double y = (double)pos.getY() + 0.7;
        double z = (double)pos.getZ() + 0.5;
        double offset = -0.27;
        x += direction.getOffsetX() * offset;
        z += direction.getOffsetZ() * offset;
        for (int i = 0; i < 6; i++) { world.addParticle(ParticleTypes.REVERSE_PORTAL,
                x + (random.nextDouble() - 0.5) * 0.2,
                y + random.nextDouble() * 0.2,
                z + (random.nextDouble() - 0.5) * 0.2,
                0.0, 0.0, 0.0);
        }
    }
}