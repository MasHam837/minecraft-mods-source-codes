package mh837.gile.block;

import mh837.gile.GileMod;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

public class TallEndGrass extends PlantBlock {
    public static final MapCodec<TallEndGrass> CODEC = createCodec(TallEndGrass::new);

    protected static final VoxelShape SHAPE = Block.createCuboidShape(2.0, 0.0, 2.0, 14.0, 13.0, 14.0);

    public TallEndGrass(Settings settings) {
        super(settings);
    }

    @Override
    public MapCodec<TallEndGrass> getCodec() {
        return CODEC;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    protected boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
        return floor.isOf(GileMod.END_GRASS_BLOCK);
    }

    @Override
    public boolean canReplace(BlockState state, ItemPlacementContext context) {
        return true; // This makes it replaceable when placing blocks on it
    }
}