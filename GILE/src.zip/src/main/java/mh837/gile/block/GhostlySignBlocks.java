package mh837.gile.block;

import mh837.gile.GileMod;
import mh837.gile.block.entity.GhostlyHangingSignBlockEntity;
import mh837.gile.block.entity.GhostlySignBlockEntity;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class GhostlySignBlocks {
    public static class GhostlySignBlock extends SignBlock {
        public GhostlySignBlock(WoodType type, Settings settings) { super(type, settings); }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            return new GhostlySignBlockEntity(pos, state);
        }

        @Override
        public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
            if (!world.isClient && !player.isCreative()) {
                dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_SIGN_ITEM));
            }
            // Remove block entity to prevent onStateReplaced from dropping again
            world.removeBlockEntity(pos);
            return super.onBreak(world, pos, state, player);
        }

        @Override
        public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.isOf(newState.getBlock())) {
                if (!world.isClient && world.getBlockEntity(pos) != null) {
                    dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_SIGN_ITEM));
                }
                super.onStateReplaced(state, world, pos, newState, moved);
            }
        }
    }

    public static class GhostlyWallSignBlock extends WallSignBlock {
        public GhostlyWallSignBlock(WoodType type, Settings settings) { super(type, settings); }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            return new GhostlySignBlockEntity(pos, state);
        }

        @Override
        public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
            if (!world.isClient && !player.isCreative()) {
                dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_SIGN_ITEM));
            }
            world.removeBlockEntity(pos);
            return super.onBreak(world, pos, state, player);
        }

        @Override
        public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.isOf(newState.getBlock())) {
                if (!world.isClient && world.getBlockEntity(pos) != null) {
                    dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_SIGN_ITEM));
                }
                super.onStateReplaced(state, world, pos, newState, moved);
            }
        }
    }

    public static class GhostlyHangingSignBlock extends HangingSignBlock {
        public GhostlyHangingSignBlock(WoodType type, Settings settings) { super(type, settings); }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            return new GhostlyHangingSignBlockEntity(pos, state);
        }

        @Override
        public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
            if (!world.isClient && !player.isCreative()) {
                dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
            }
            world.removeBlockEntity(pos);
            return super.onBreak(world, pos, state, player);
        }

        @Override
        public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.isOf(newState.getBlock())) {
                if (!world.isClient && world.getBlockEntity(pos) != null) {
                    dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
                }
                super.onStateReplaced(state, world, pos, newState, moved);
            }
        }

        @Override
        public WoodType getWoodType() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }

        public WoodType getSignType() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }
    }

    public static class GhostlyWallHangingSignBlock extends WallHangingSignBlock {
        public GhostlyWallHangingSignBlock(WoodType type, Settings settings) { super(type, settings); }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            return new GhostlyHangingSignBlockEntity(pos, state);
        }

        @Override
        public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
            if (!world.isClient && !player.isCreative()) {
                dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
            }
            world.removeBlockEntity(pos);
            return super.onBreak(world, pos, state, player);
        }

        @Override
        public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
            if (!state.isOf(newState.getBlock())) {
                if (!world.isClient && world.getBlockEntity(pos) != null) {
                    dropStack(world, pos, new ItemStack(GileMod.GHOSTLY_HANGING_SIGN_ITEM));
                }
                super.onStateReplaced(state, world, pos, newState, moved);
            }
        }

        @Override
        public WoodType getWoodType() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }

        public WoodType getSignType() {
            return ModWoodTypes.GHOSTLY_WOOD_TYPE;
        }
    }
}