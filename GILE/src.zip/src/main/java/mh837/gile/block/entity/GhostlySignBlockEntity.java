package mh837.gile.block.entity;

import mh837.gile.GileMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.util.math.BlockPos;

public class GhostlySignBlockEntity extends SignBlockEntity {
    public GhostlySignBlockEntity(BlockPos pos, BlockState state) {
        super(GileMod.GHOSTLY_SIGN_BLOCK_ENTITY, pos, state);
    }

    @Override
    public BlockEntityType<?> getType() {
        return GileMod.GHOSTLY_SIGN_BLOCK_ENTITY;
    }

}