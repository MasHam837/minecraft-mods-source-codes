package mh837.gile.block;

import mh837.gile.GileMod;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

import static net.minecraft.block.FireBlock.*;

public class MoonFireBlock extends AbstractFireBlock {

    public static final MapCodec<MoonFireBlock> CODEC = createCodec(MoonFireBlock::new);

    public MoonFireBlock(Settings settings) {
        // Damage is measured in half-hearts. 3.0F deals exactly 1.5 hearts.
        super(settings, 3.0F);

        this.setDefaultState(
                this.stateManager.getDefaultState()
                        .with(NORTH, false)
                        .with(EAST, false)
                        .with(SOUTH, false)
                        .with(WEST, false)
                        .with(UP, false)
        );
    }

    @Override
    protected MapCodec<? extends AbstractFireBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected boolean isFlammable(BlockState state) {
        // Vanilla FireBlock and SoulFireBlock return true here.
        return true;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST, UP);
    }

    @Override
    protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        // 1. It can survive if placed directly on Moon Sand
        if (world.getBlockState(pos.down()).isOf(GileMod.MOON_SAND)) {
            return true;
        }

        // 2. Since you have directional properties, it should also survive if attached
        // to the side or bottom of any valid burnable block (vanilla standard fire behavior).
        BlockState updatedState = this.updateState(world, pos);
        return updatedState.get(NORTH) || updatedState.get(EAST) ||
                updatedState.get(SOUTH) || updatedState.get(WEST) ||
                updatedState.get(UP);
    }

    @Override
    protected BlockState getStateForNeighborUpdate(
            BlockState state,
            Direction direction,
            BlockState neighborState,
            WorldAccess world,
            BlockPos pos,
            BlockPos neighborPos
    ) {
        // CRITICAL FIX: If the support block is broken, turn the fire into Air.
        if (!this.canPlaceAt(state, world, pos)) {
            return Blocks.AIR.getDefaultState();
        }

        // Otherwise, just update its connection properties
        return updateState(world, pos);
    }

    // You can safely use this method instead of overriding getPlacementState if desired.
    public BlockState getPlacementState(BlockView world, BlockPos pos) {
        return updateState(world, pos);
    }

    private BlockState updateState(BlockView world, BlockPos pos) {
        return this.getDefaultState()
                .with(UP, isValidFireBase(world.getBlockState(pos.up())))
                .with(NORTH, isValidFireBase(world.getBlockState(pos.north())))
                .with(SOUTH, isValidFireBase(world.getBlockState(pos.south())))
                .with(EAST, isValidFireBase(world.getBlockState(pos.east())))
                .with(WEST, isValidFireBase(world.getBlockState(pos.west())));
    }

    private boolean isValidFireBase(BlockState state) {
        return state.isBurnable();
    }
}