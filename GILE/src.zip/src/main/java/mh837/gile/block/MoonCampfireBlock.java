package mh837.gile.block;

import mh837.gile.GileMod;
import mh837.gile.block.entity.MoonCampfireBlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class MoonCampfireBlock extends CampfireBlock {

    public MoonCampfireBlock(Settings settings) {
        super(true, 2, settings);
    }

    @Override
    protected ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (blockEntity instanceof MoonCampfireBlockEntity moonCampfire) {
            // Try cooking the item
            if (moonCampfire.addItem(player, stack)) {
                return ItemActionResult.SUCCESS;
            }
        }

        // Pass to super so Shovels, Water Bottles, and Flint & Steel can run their default logic
        return super.onUseWithItem(stack, state, world, pos, player, hand, hit);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (blockEntity instanceof MoonCampfireBlockEntity moonCampfire) {
            // Try to extract cooked/cooking items when right-clicking with an empty hand
            if (moonCampfire.interact(player)) {
                return ActionResult.SUCCESS;
            }
        }
        return super.onUse(state, world, pos, player, hit);
    }

    @Nullable
    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new MoonCampfireBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        if (world.isClient) {
            return validateTicker(type, GileMod.MOON_CAMPFIRE_ENTITY, MoonCampfireBlockEntity::clientTick);
        } else {
            return validateTicker(type, GileMod.MOON_CAMPFIRE_ENTITY, MoonCampfireBlockEntity::serverTick);
        }
    }
}