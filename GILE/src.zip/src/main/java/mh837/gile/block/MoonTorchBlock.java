package mh837.gile.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.TorchBlock;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class MoonTorchBlock extends TorchBlock {
    public MoonTorchBlock(Settings settings) {
        super(ParticleTypes.REVERSE_PORTAL, settings);
    }

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        double x = (double)pos.getX() + 0.5;
        double y = (double)pos.getY() + 0.5;
        double z = (double)pos.getZ() + 0.5;
        for (int i = 0; i < 6; i++) { world.addParticle(ParticleTypes.REVERSE_PORTAL,
                x + (random.nextDouble() - 0.5) * 0.2,
                y + random.nextDouble() * 0.2,
                z + (random.nextDouble() - 0.5) * 0.2,
                0.0, 0.0, 0.0);
        }
    }
}