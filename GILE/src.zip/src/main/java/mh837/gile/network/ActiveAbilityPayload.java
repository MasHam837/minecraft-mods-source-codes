package mh837.gile.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record ActiveAbilityPayload() implements CustomPayload {
    public static final CustomPayload.Id<ActiveAbilityPayload> ID = new CustomPayload.Id<>(Identifier.of("gile", "active_ability"));
    public static final PacketCodec<RegistryByteBuf, ActiveAbilityPayload> CODEC = PacketCodec.unit(new ActiveAbilityPayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}