package mh837.gile.entity;

import mh837.gile.GileMod;
import mh837.gile.advancement.NamedEntityCriterion;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.Flutterer;
import net.minecraft.entity.ItemSteerable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SaddledComponent;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class HoveringGhostEntity extends TameableEntity implements ItemSteerable, Flutterer {

    private static final TrackedData<Boolean> SADDLED =
            DataTracker.registerData(HoveringGhostEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    private static final TrackedData<Integer> BOOST_TIME =
            DataTracker.registerData(HoveringGhostEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private final SaddledComponent saddledComponent;

    public HoveringGhostEntity(EntityType<? extends TameableEntity> entityType, World world) {
        super(entityType, world);
        this.moveControl = new FlightMoveControl(this, 10, false);
        this.saddledComponent = new SaddledComponent(this.dataTracker, BOOST_TIME, SADDLED);
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengerList().size() < 2;
    }

    @Override
    protected void updatePassengerPosition(Entity passenger, Entity.PositionUpdater positionUpdater) {
        if (this.hasPassenger(passenger)) {
            int seatIndex = this.getPassengerList().indexOf(passenger);
            float zOffset = (seatIndex == 0) ? 0.0F : -1.2F;
            float yawRad = this.bodyYaw * ((float)Math.PI / 180F);
            double offsetX = -Math.sin(yawRad) * zOffset;
            double offsetZ = Math.cos(yawRad) * zOffset;

            positionUpdater.accept(passenger, this.getX() + offsetX, this.getY() + 0.35D, this.getZ() + offsetZ);
        } else {
            super.updatePassengerPosition(passenger, positionUpdater);
        }
    }

    @Override
    protected void dropLoot(DamageSource source, boolean causedByPlayer) {
        super.dropLoot(source, causedByPlayer);
        if (this.isSaddled()) {
            this.dropStack(new ItemStack(Items.SADDLE));
        }

        int looting = 0;
        if (source.getAttacker() instanceof LivingEntity attacker) {
            RegistryEntry<Enchantment> lootingEnchant = attacker.getWorld()
                    .getRegistryManager()
                    .get(RegistryKeys.ENCHANTMENT)
                    .getEntry(Enchantments.LOOTING)
                    .orElse(null);

            if (lootingEnchant != null) {
                looting = EnchantmentHelper.getEquipmentLevel(lootingEnchant, attacker);
            }
        }

        int dropCount = 1 + this.random.nextInt(2 + looting);
        this.dropStack(new ItemStack(GileMod.PHASMA, dropCount));
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new EscapeDangerGoal(this, 1.25));
        this.goalSelector.add(2, new AnimalMateGoal(this, 1.0));
        this.goalSelector.add(3, new TemptGoal(this, 1.1, Ingredient.ofItems(GileMod.JELLY, GileMod.JELLY_ON_A_STICK), false));
        this.goalSelector.add(4, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));
        this.goalSelector.add(6, new LookAroundGoal(this));
    }

    public static DefaultAttributeContainer.Builder createHoveringGhostAttributes() {
        return TameableEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.2)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.2)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 10.0);
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        BirdNavigation birdNavigation = new BirdNavigation(this, world);
        birdNavigation.setCanPathThroughDoors(false);
        birdNavigation.setCanSwim(true);
        birdNavigation.setCanEnterOpenDoors(true);
        return birdNavigation;
    }

    @Override
    public boolean isInAir() {
        return !this.isOnGround();
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    @Override
    public boolean bypassesLandingEffects() {
        return true;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return stack.isOf(GileMod.JELLY);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(SADDLED, false);
        builder.add(BOOST_TIME, 0);
    }

    @Override
    public float getPathfindingFavor(BlockPos pos, WorldView world) {
        return 10.0F;
    }

    @Override
    public void tick() {
        super.tick();

        if (this.isAlive()) {
            // FIX: Treat BOOST_TIME as a countdown timer. This completely removes the need
            // to call any methods on SaddledComponent, sidestepping the error entirely.
            if (!this.getWorld().isClient) {
                int currentBoost = this.dataTracker.get(BOOST_TIME);
                if (currentBoost > 0) {
                    this.dataTracker.set(BOOST_TIME, currentBoost - 1);
                }
            }

            boolean isNyanCat = this.hasCustomName() && "Nyan Cat".equalsIgnoreCase(this.getCustomName().getString());
            boolean shouldTrail = false;

            if (this.hasPassengers() && this.getControllingPassenger() instanceof PlayerEntity player) {
                ItemStack mainHand = player.getStackInHand(Hand.MAIN_HAND);
                ItemStack offHand = player.getStackInHand(Hand.OFF_HAND);
                shouldTrail = mainHand.isOf(GileMod.JELLY_ON_A_STICK) || offHand.isOf(GileMod.JELLY_ON_A_STICK);
            }

            if (this.getWorld().isClient && isNyanCat && shouldTrail) {

                float yawRad = this.bodyYaw * ((float)Math.PI / 180F);
                double trailLength = 1.3;
                double spawnX = this.getX() + Math.sin(yawRad) * trailLength;
                double spawnZ = this.getZ() - Math.cos(yawRad) * trailLength;
                double spawnY = this.getY() + (this.getHeight() * 0.4);

                org.joml.Vector3f[] rainbowColors = new org.joml.Vector3f[]{
                        new org.joml.Vector3f(1.0F, 0.0F, 0.0F),
                        new org.joml.Vector3f(1.0F, 0.5F, 0.0F),
                        new org.joml.Vector3f(1.0F, 1.0F, 0.0F),
                        new org.joml.Vector3f(0.0F, 1.0F, 0.0F),
                        new org.joml.Vector3f(0.0F, 0.5F, 1.0F),
                        new org.joml.Vector3f(0.3F, 0.0F, 0.8F),
                        new org.joml.Vector3f(0.5F, 0.0F, 0.5F)
                };

                double totalSpread = 1.2;

                for (int i = 0; i < 7; i++) {
                    double lateralOffset = ((double)i / 6.0 - 0.5) * totalSpread;
                    double particleX = spawnX + Math.cos(yawRad) * lateralOffset;
                    double particleZ = spawnZ + Math.sin(yawRad) * lateralOffset;

                    net.minecraft.particle.DustParticleEffect dustOptions =
                            new net.minecraft.particle.DustParticleEffect(rainbowColors[i], 1.2F);

                    this.getWorld().addParticle(dustOptions, particleX, spawnY, particleZ, 0.0, 0.0, 0.0);
                }
            }
        }

        if (!this.isOnGround() && this.getVelocity().y < 0.0 && !this.hasPassengers()) {
            this.setVelocity(this.getVelocity().multiply(1.0, 0.6, 1.0));
        }
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack itemStack = player.getStackInHand(hand);

        if (!this.isTamed() && itemStack.isOf(GileMod.JELLY)) {
            if (!this.getWorld().isClient) {
                this.eat(player, hand, itemStack);
                if (this.random.nextInt(3) == 0) {
                    this.setOwner(player);
                    this.setTamed(true, true);
                    this.getWorld().sendEntityStatus(this, (byte)7);
                } else {
                    this.getWorld().sendEntityStatus(this, (byte)6);
                }
            }
            return ActionResult.success(this.getWorld().isClient);
        }

        if (this.isTamed() && !this.isSaddled() && !this.isBaby() && itemStack.isOf(Items.SADDLE)) {
            if (!this.getWorld().isClient) {
                itemStack.decrementUnlessCreative(1, player);
                this.saddledComponent.setSaddled(true);
            }
            return ActionResult.success(this.getWorld().isClient);
        }

        boolean isBreedingItem = this.isBreedingItem(itemStack);
        if (!isBreedingItem && this.isSaddled() && !this.isBaby() && this.getPassengerList().size() < 2 && !player.hasVehicle()) {
            if (!this.getWorld().isClient) {
                player.startRiding(this);
            }
            return ActionResult.success(this.getWorld().isClient);
        }

        return super.interactMob(player, hand);
    }

    @Override
    public void travel(Vec3d movementInput) {
        if (this.isAlive()) {
            if (this.hasPassengers() && this.getControllingPassenger() instanceof PlayerEntity player) {
                ItemStack itemStack = player.getStackInHand(Hand.MAIN_HAND);
                ItemStack offHandStack = player.getStackInHand(Hand.OFF_HAND);

                if (itemStack.isOf(GileMod.JELLY_ON_A_STICK) || offHandStack.isOf(GileMod.JELLY_ON_A_STICK)) {
                    this.setYaw(player.getYaw());
                    this.prevYaw = this.getYaw();
                    this.setPitch(player.getPitch() * 0.5F);
                    this.setRotation(this.getYaw(), this.getPitch());
                    this.bodyYaw = this.getYaw();
                    this.headYaw = this.bodyYaw;

                    Vec3d lookVec = player.getRotationVec(1.0F);
                    double baseSpeed = this.getAttributeValue(EntityAttributes.GENERIC_FLYING_SPEED);

                    // Because BOOST_TIME ticks down to 0 now, this naturally resets and allows re-boosting!
                    boolean isBoosting = this.dataTracker.get(BOOST_TIME) > 0;
                    double speedMultiplier = 1.5;

                    double finalSpeed = isBoosting ? (baseSpeed * 2.5) : (baseSpeed * speedMultiplier);

                    this.setVelocity(lookVec.multiply(finalSpeed));
                    this.move(net.minecraft.entity.MovementType.SELF, this.getVelocity());
                    return;
                } else {
                    this.setVelocity(this.getVelocity().multiply(0.7));
                    this.move(net.minecraft.entity.MovementType.SELF, this.getVelocity());
                    return;
                }
            }
            super.travel(movementInput);
        }
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        Entity entity = this.getFirstPassenger();
        return entity instanceof PlayerEntity ? (PlayerEntity)entity : null;
    }

    @Override
    public boolean consumeOnAStickItem() {
        // FIX: If already boosting, ignore.
        if (this.dataTracker.get(BOOST_TIME) > 0) {
            return false;
        }

        // Start the boost timer natively by updating the tracker.
        if (!this.getWorld().isClient) {
            // Set the countdown duration (140 to 981 ticks, similar to vanilla pigs)
            this.dataTracker.set(BOOST_TIME, 140 + this.random.nextInt(841));

            boolean isNyanCat = this.hasCustomName() && "Nyan Cat".equalsIgnoreCase(this.getCustomName().getString());
            if (isNyanCat) {
                // Play the Nyan Cat sound
                this.getWorld().playSound(
                        null,
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        GileMod.HOVERING_GHOST_NYAN_AMBIENT,
                        SoundCategory.NEUTRAL,
                        1.0F,    // Volume
                        1.0F     // Pitch (normal)
                );
            }
        }

        return true;
    }

    public boolean isSaddled() {
        return this.saddledComponent.isSaddled();
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {return SoundEvents.ENTITY_VEX_AMBIENT;}

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_VEX_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_VEX_DEATH;
    }

    @Nullable
    @Override
    public HoveringGhostEntity createChild(ServerWorld world, PassiveEntity entity) {
        HoveringGhostEntity child = GileMod.HOVERING_GHOST.create(world);
        if (child != null) {
            child.setBaby(true);
            child.setTamed(false, false);
        }
        return child;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        this.saddledComponent.writeNbt(nbt);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.saddledComponent.readNbt(nbt);
    }

    @Override
    public void setCustomName(@Nullable Text name) {
        super.setCustomName(name);
        if (name != null && !this.getWorld().isClient && this.getWorld() instanceof ServerWorld) {
            // Get the owner or nearby players
            this.getWorld().getPlayers().forEach(player -> {
                if (player instanceof ServerPlayerEntity serverPlayer &&
                        player.squaredDistanceTo(this) < 100) { // Within 10 blocks
                    NamedEntityCriterion.CRITERION.trigger(serverPlayer, this, name.getString());
                }
            });
        }
    }
}