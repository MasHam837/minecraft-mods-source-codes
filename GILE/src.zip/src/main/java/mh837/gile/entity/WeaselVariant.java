package mh837.gile.entity;

import net.minecraft.util.StringIdentifiable;

public enum WeaselVariant implements StringIdentifiable {
    AMATEUR(0, "amateur"),
    HOARDER(1, "hoarder"),
    GOLDEN(2, "golden");

    private final int id;
    private final String name;

    WeaselVariant(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return this.id;
    }

    @Override
    public String asString() {
        return this.name;
    }

    public static WeaselVariant byId(int id) {
        if (id < 0 || id >= values().length) {
            id = 0;
        }
        return values()[id];
    }
}