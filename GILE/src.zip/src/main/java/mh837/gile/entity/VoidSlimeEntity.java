package mh837.gile.entity;

import mh837.gile.GileMod;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.LookControl;
import net.minecraft.entity.ai.control.MoveControl;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Vector3f;

import java.util.EnumSet;

public class VoidSlimeEntity extends HostileEntity {
    private static final TrackedData<Integer> SLIME_SIZE = DataTracker.registerData(VoidSlimeEntity.class, TrackedDataHandlerRegistry.INTEGER);
    public float targetStretch;
    public float stretch;
    public float lastStretch;
    private boolean onGroundLastTick;

    public VoidSlimeEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.onGroundLastTick = false;
        this.moveControl = new MoveControl(this);
        this.lookControl = new LookControl(this);}

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new VoidSlimeAttackGoal(this));
        this.goalSelector.add(3, new VoidSlimeFaceTargetGoal(this));
        this.goalSelector.add(4, new VoidSlimeRandomLookGoal(this));
        this.goalSelector.add(5, new VoidSlimeMoveGoal(this));

        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));}

    public static DefaultAttributeContainer.Builder createVoidSlimeAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_GRAVITY, 0.04);}

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(SLIME_SIZE, 1);}

    public void setSize(int size, boolean heal) {
        this.dataTracker.set(SLIME_SIZE, size);
        this.refreshPosition();
        this.calculateDimensions();
        this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(10.0);
        this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.3 + 0.1 * size);
        this.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(4.0);
        if (heal) {
            this.setHealth(this.getMaxHealth());}}

    public int getSize() {
        return this.dataTracker.get(SLIME_SIZE);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Size", this.getSize() - 1);
        nbt.putBoolean("wasOnGround", this.onGroundLastTick);}

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        this.setSize(nbt.getInt("Size") + 1, false);
        super.readCustomDataFromNbt(nbt);
        this.onGroundLastTick = nbt.getBoolean("wasOnGround");}

    @Override
    public void tick() {
        // Force face target if it has one
        if (this.getTarget() != null) {
            this.lookAtEntity(this.getTarget(), 30.0F, 30.0F);
            this.bodyYaw = this.getYaw();
            this.headYaw = this.getYaw();}

        this.stretch += (this.targetStretch - this.stretch) * 0.5F;
        this.lastStretch = this.stretch;
        super.tick();

        if (this.isOnGround() && !this.onGroundLastTick) {
            this.targetStretch = -0.5F;
            // Spawn particles when landing
            if (this.getWorld().isClient) {
                for (int i = 0; i < 8; i++) {
                    this.getWorld().addParticle(
                            new DustParticleEffect(new Vector3f(0.22f, 0.16f, 0.36f), 1.0F),
                            this.getX() + (this.random.nextDouble() - 0.5) * 0.8,
                            this.getY() + 0.1,
                            this.getZ() + (this.random.nextDouble() - 0.5) * 0.8,
                            (this.random.nextDouble() - 0.5) * 0.1,
                            0.05,
                            (this.random.nextDouble() - 0.5) * 0.1 );}}
        } else if (!this.isOnGround() && this.onGroundLastTick) {
            this.targetStretch = 1.0F;}

        this.onGroundLastTick = this.isOnGround();
        if (this.isOnGround()) {this.targetStretch *= 0.6F;}

        // Constant subtle particles while on ground
        if (this.getWorld().isClient && this.isOnGround() && this.random.nextInt(2) == 0) {
            for (int i = 0; i < 3; i++) {
                this.getWorld().addParticle(
                        new DustParticleEffect(new Vector3f(0.22f, 0.16f, 0.36f), 1.0F),
                        this.getParticleX(0.5),
                        this.getRandomBodyY(),
                        this.getParticleZ(0.5),
                        (this.random.nextDouble() - 0.5) * 0.02,
                        0.01,
                        (this.random.nextDouble() - 0.5) * 0.02 );}
        }
    }

    @Override
    public void onPlayerCollision(PlayerEntity player) {
        // Only damage if close enough (matches attack range)
        double distance = this.squaredDistanceTo(player);
        double hitboxRange = 1.5; // Match entity dimensions

        if (distance <= hitboxRange * hitboxRange && this.isAlive() && !player.isCreative() && player.isAlive()) {
            player.damage(this.getDamageSources().mobAttack(this),
                    (float)this.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE));
            this.pushPlayerAway(player);}
    }

    private void pushPlayerAway(PlayerEntity player) {
        double dX = player.getX() - this.getX();
        double dZ = player.getZ() - this.getZ();
        double distance = Math.max(Math.sqrt(dX * dX + dZ * dZ), 0.001);
        double pushStrength = 0.5; // Stronger push
        player.addVelocity(dX / distance * pushStrength, 0.15, dZ / distance * pushStrength);
        player.velocityModified = true;
    }

    @Override
    public void lookAtEntity(Entity targetEntity, float maxYawChange, float maxPitchChange) {
        double dX = targetEntity.getX() - this.getX();
        double dZ = targetEntity.getZ() - this.getZ();
        double dY;

        if (targetEntity instanceof LivingEntity livingEntity) {
            dY = livingEntity.getEyeY() - this.getEyeY();}
        else {
            dY = (targetEntity.getBoundingBox().minY + targetEntity.getBoundingBox().maxY) / 2.0 - this.getEyeY();}

        double distance = Math.sqrt(dX * dX + dZ * dZ);
        float targetYaw = (float)(Math.atan2(dZ, dX) * 57.2957763671875) - 90.0F;
        float targetPitch = (float)(-(Math.atan2(dY, distance) * 57.2957763671875));

        this.setPitch(this.changeAngle(this.getPitch(), targetPitch, maxPitchChange));
        this.setYaw(this.changeAngle(this.getYaw(), targetYaw, maxYawChange));
        this.bodyYaw = this.getYaw();
        this.headYaw = this.getYaw();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SLIME_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.4F;
    }

    @Override
    public float getSoundPitch() {
        return 1.0F;
    }

    @Override
    protected void dropLoot(DamageSource source, boolean causedByPlayer) {
        super.dropLoot(source, causedByPlayer);
        // Get looting level
        int looting = 0;
        if (source.getAttacker() instanceof LivingEntity attacker) {
            RegistryEntry<Enchantment> lootingEnchant = attacker.getWorld()
                    .getRegistryManager()
                    .get(RegistryKeys.ENCHANTMENT)
                    .getEntry(Enchantments.LOOTING)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = EnchantmentHelper.getEquipmentLevel(lootingEnchant, attacker);}}
        // Drop 1-2 slimeballs, +1 extra per looting level
        int dropCount = 1 + this.random.nextInt(2 + looting);
        this.dropStack(new ItemStack(GileMod.VOID_SLIMEBALL, dropCount));
    }

    static class VoidSlimeMoveGoal extends Goal {
        private final VoidSlimeEntity slime;

        public VoidSlimeMoveGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setControls(EnumSet.of(Goal.Control.JUMP, Goal.Control.MOVE));}

        @Override
        public boolean canStart() {
            return this.slime.getTarget() != null && this.slime.isOnGround();
        }

        @Override
        public void tick() {
            LivingEntity target = this.slime.getTarget();
            if (target != null) {
                this.slime.lookAtEntity(target, 30.0F, 30.0F);
                this.slime.bodyYaw = this.slime.getYaw();
                this.slime.headYaw = this.slime.getYaw();}}
    }

    static class VoidSlimeFaceTargetGoal extends Goal {
        private final VoidSlimeEntity slime;

        public VoidSlimeFaceTargetGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setControls(EnumSet.of(Goal.Control.LOOK));}

        @Override
        public boolean canStart() {
            return this.slime.getTarget() != null;
        }

        @Override
        public boolean shouldContinue() {
            return this.slime.getTarget() != null && this.slime.getTarget().isAlive();
        }

        @Override
        public void tick() {
            LivingEntity target = this.slime.getTarget();
            if (target != null) {
                this.slime.lookAtEntity(target, 30.0F, 30.0F);
                this.slime.bodyYaw = this.slime.getYaw();
                this.slime.headYaw = this.slime.getYaw();}}
    }

    static class VoidSlimeAttackGoal extends Goal {
        private final VoidSlimeEntity slime;
        private int timer;

        public VoidSlimeAttackGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setControls(EnumSet.of(Goal.Control.JUMP, Goal.Control.MOVE));
            this.timer = this.slime.getRandom().nextInt(20);}

        @Override
        public boolean canStart() {
            return this.slime.getTarget() != null;
        }

        @Override
        public void tick() {
            LivingEntity target = this.slime.getTarget();
            if (target != null && this.slime.isOnGround()) {
                if (--this.timer <= 0) {
                    this.timer = 15 + this.slime.getRandom().nextInt(15);

                    if (this.slime.getWorld().isClient) {
                        for (int i = 0; i < 5; i++) {
                            this.slime.getWorld().addParticle(
                                    new DustParticleEffect(new Vector3f(0.22f, 0.16f, 0.36f), 1.0F),
                                    this.slime.getX() + (this.slime.random.nextDouble() - 0.5) * 0.5,
                                    this.slime.getY() + 0.1,
                                    this.slime.getZ() + (this.slime.random.nextDouble() - 0.5) * 0.5,
                                    (this.slime.random.nextDouble() - 0.5) * 0.2,
                                    0.1,
                                    (this.slime.random.nextDouble() - 0.5) * 0.2);}}

                    double dX = target.getX() - this.slime.getX();
                    double dZ = target.getZ() - this.slime.getZ();
                    double distance = Math.sqrt(dX * dX + dZ * dZ);

                    if (distance > 0.01) {
                        Vec3d velocity = this.slime.getVelocity();
                        // Cap jump so it lands on target, not past it
                        double jumpStrength = Math.min(distance, 0.8) * 0.5;
                        this.slime.setVelocity(
                                velocity.x + (dX / distance) * jumpStrength,
                                0.4,
                                velocity.z + (dZ / distance) * jumpStrength);
                        this.slime.velocityModified = true;}

                    this.slime.lookAtEntity(target, 30.0F, 30.0F);
                    this.slime.bodyYaw = this.slime.getYaw();
                    this.slime.headYaw = this.slime.getYaw();}}}
    }

    static class VoidSlimeRandomLookGoal extends Goal {
        private final VoidSlimeEntity slime;
        private float targetYaw;
        private int timer;
        private int jumpTimer;

        public VoidSlimeRandomLookGoal(VoidSlimeEntity slime) {
            this.slime = slime;
            this.setControls(EnumSet.of(Goal.Control.LOOK, Goal.Control.JUMP));}

        @Override
        public boolean canStart() {
            return this.slime.getTarget() == null && this.slime.isOnGround();
        }

        @Override
        public boolean shouldContinue() {
            return this.slime.getTarget() == null;
        }

        @Override
        public void start() {
            // Random initial timers so each slime is out of sync
            this.timer = this.slime.getRandom().nextInt(40);
            this.jumpTimer = 20 + this.slime.getRandom().nextInt(60);
            // Pick initial random look direction
            if (this.slime.getRandom().nextInt(3) == 0) {
                this.targetYaw = this.slime.getYaw() + (this.slime.getRandom().nextFloat() - 0.5F) * 180.0F;}}

        @Override
        public void tick() {
            // Random looking around occasionally
            if (--this.timer <= 0) {
                this.timer = 30 + this.slime.getRandom().nextInt(70); // Varied interval
                this.targetYaw = this.slime.getRandom().nextFloat() * 360.0F;}
            // Smoothly turn towards target yaw
            this.slime.setYaw(this.slime.changeAngle(this.slime.getYaw(), this.targetYaw, 10.0F));
            this.slime.bodyYaw = this.slime.getYaw();
            this.slime.headYaw = this.slime.getYaw();
            // Random idle jumping in the direction it's looking
            if (--this.jumpTimer <= 0 && this.slime.isOnGround()) {
                this.jumpTimer = 40 + this.slime.getRandom().nextInt(120); // Varied timing
                float yaw = this.slime.getYaw() * ((float)Math.PI / 180F);
                double jumpStrength = 0.2 + this.slime.getRandom().nextDouble() * 0.2; // Varied strength
                double dX = -Math.sin(yaw) * jumpStrength;
                double dZ = Math.cos(yaw) * jumpStrength;
                this.slime.setVelocity(dX, 0.2 + this.slime.getRandom().nextDouble() * 0.2, dZ);
                this.slime.velocityModified = true; }}
    }

    public float changeAngle(float from, float to, float max) {
        float f = MathHelper.wrapDegrees(to - from);
        if (f > max) {
            f = max;}
        if (f < -max) {
            f = -max;}
        return from + f;}
}