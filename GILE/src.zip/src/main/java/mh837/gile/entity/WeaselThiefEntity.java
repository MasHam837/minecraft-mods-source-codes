package mh837.gile.entity;

import mh837.gile.GileMod;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;
import net.minecraft.village.TradedItem;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class WeaselThiefEntity extends MerchantEntity {

    private static final TrackedData<Integer> VARIANT = DataTracker.registerData(WeaselThiefEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private int dropCooldown = 0;

    public WeaselThiefEntity(EntityType<? extends MerchantEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createWeaselAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.4); // Very fast!
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        // Flee from players within 16 blocks, runs at 1.2x speed near, 1.5x speed far
        this.goalSelector.add(1, new FleeEntityGoal<>(this, PlayerEntity.class, 16.0F, 1.2, 1.5));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(4, new LookAroundGoal(this));
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, 0);
    }

    public WeaselVariant getVariant() {
        return WeaselVariant.byId(this.dataTracker.get(VARIANT));
    }

    public void setVariant(WeaselVariant variant) {
        this.dataTracker.set(VARIANT, variant.getId());
    }

    @Override
    protected void dropLoot(DamageSource source, boolean causedByPlayer) {
        super.dropLoot(source, causedByPlayer);
        int looting = 0;
        if (source.getAttacker() instanceof LivingEntity attacker) {
            RegistryEntry<Enchantment> lootingEnchant = attacker.getWorld()
                    .getRegistryManager()
                    .get(RegistryKeys.ENCHANTMENT)
                    .getEntry(Enchantments.LOOTING)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = EnchantmentHelper.getEquipmentLevel(lootingEnchant, attacker);}}
        int dropCount = 1 + this.random.nextInt(10 + looting);
        this.dropStack(new ItemStack(GileMod.PRIMOGEM, dropCount));
    }

    @Override
    public void tickMovement() {
        super.tickMovement();

        if (!this.getWorld().isClient && this.isAlive()) {
            // Check if moving fast (fleeing)
            if (this.getVelocity().horizontalLengthSquared() > 0.01) {
                PlayerEntity closest = this.getWorld().getClosestPlayer(this, 16.0);
                if (closest != null) {
                    if (this.dropCooldown <= 0) {
                        // REPLACE Items.GOLD_NUGGET WITH YOUR MORA ITEM
                        this.dropItem(GileMod.MORA);
                        // Random cooldown between 3 to 8 seconds
                        this.dropCooldown = 60 + this.random.nextInt(100);
                    }
                }
            }
            if (this.dropCooldown > 0) {
                this.dropCooldown--;
            }
        }
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (this.isAlive() && !this.hasCustomer() && !this.isBaby()) {
            if (!this.getWorld().isClient) {
                this.setCustomer(player);
                this.sendOffers(player, this.getDisplayName(), 1);
            }
            return ActionResult.success(this.getWorld().isClient);
        }
        return super.interactMob(player, hand);
    }

    @Override
    protected void fillRecipes() {
        TradeOfferList offers = new TradeOfferList();
        WeaselVariant variant = this.getVariant();

        // 1. Define Trade Limits based on Rarity
        int maxUses = variant == WeaselVariant.AMATEUR ? 5 : (variant == WeaselVariant.HOARDER ? 3 : 1);
        int xp = variant == WeaselVariant.AMATEUR ? 2 : (variant == WeaselVariant.HOARDER ? 5 : 10);

        // 2. Load Modded Items (Sigils & Currency)
        Item mora = getCustomItem("mora");
        Item pyro = getCustomItem("pyro_sigil");
        Item geo = getCustomItem("geo_sigil");
        Item dendro = getCustomItem("dendro_sigil");
        Item electro = getCustomItem("electro_sigil");
        Item hydro = getCustomItem("hydro_sigil");
        Item anemo = getCustomItem("anemo_sigil");
        Item cryo = getCustomItem("cryo_sigil");
        Item luna = getCustomItem("luna_sigil");

        // --- TRADE 1: MORA CONVERTER ---
        // Trades Mora for 1 random elemental Sigil. Cost depends on rarity variant.
        int moraCost = switch (variant) {
            case HOARDER -> 4; // Hoarder (Rare)
            case GOLDEN -> 2; // Golden (Epic)
            default -> 8; // Amateur (Common)
        };

        Item[] allSigils = {pyro, geo, dendro, electro, hydro, anemo, cryo, luna};
        Item randomSigil = allSigils[this.random.nextInt(allSigils.length)];

        offers.add(createTrade(mora, moraCost, randomSigil, 1, maxUses, xp));

        // Let's roll a random index (0, 1, or 2) for each of the 8 elements
        int rAir = this.random.nextInt(3);
        int rEarth = this.random.nextInt(3);
        int rElectro = this.random.nextInt(3);
        int rNature = this.random.nextInt(3);
        int rWater = this.random.nextInt(3);
        int rFire = this.random.nextInt(3);
        int rFrost = this.random.nextInt(3);
        int rMoon = this.random.nextInt(3);

        // --- TRADE 2: AIR ---
        switch (variant) {
            case AMATEUR -> offers.add(rAir == 0 ? createTrade(anemo, 2, Items.PHANTOM_MEMBRANE, 4, maxUses, xp) : rAir == 1 ? createTrade(anemo, 1, Items.EGG, 2, maxUses, xp) : createTrade(anemo, 4, createDuration3Rocket(8), maxUses, xp));
            case HOARDER -> offers.add(rAir == 0 ? createTrade(anemo, 6, Items.BREEZE_ROD, 4, maxUses, xp) : rAir == 1 ? createTrade(anemo, 15, Items.DRAGON_BREATH, 8, maxUses, xp) : createTrade(anemo, 7, Items.COBWEB, 12, maxUses, xp));
            case GOLDEN -> offers.add(rAir == 0 ? createTrade(anemo, 30, Items.HEAVY_CORE, 1, maxUses, xp) : rAir == 1 ? createTrade(anemo, 40, Items.ELYTRA, 1, maxUses, xp) : createTrade(anemo, 64, getCustomItem("daybreak_chronicles"), 1, maxUses, xp));
        }

        // --- TRADE 3: EARTH ---
        switch (variant) {
            case AMATEUR -> offers.add(rEarth == 0 ? createTrade(geo, 1, Items.SAND, 16, maxUses, xp) : rEarth == 1 ? createTrade(geo, 2, Items.GRASS_BLOCK, 4, maxUses, xp) : createTrade(geo, 4, Items.STONE, 32, maxUses, xp));
            case HOARDER -> offers.add(rEarth == 0 ? createTrade(geo, 8, Items.POINTED_DRIPSTONE, 4, maxUses, xp) : rEarth == 1 ? createTrade(geo, 4, Items.AMETHYST_CLUSTER, 8, maxUses, xp) : createTrade(geo, 6, getCustomItem("wish"), 1, maxUses, xp));
            case GOLDEN -> offers.add(rEarth == 0 ? createTrade(geo, 15, Items.DIAMOND_BLOCK, 1, maxUses, xp) : rEarth == 1 ? createTrade(geo, 30, Items.DEEPSLATE_EMERALD_ORE, 1, maxUses, xp) : createTrade(geo, 64, getCustomItem("vortex_vanquisher"), 1, maxUses, xp));
        }

        // --- TRADE 4: ELECTRO ---
        switch (variant) {
            case AMATEUR -> offers.add(rElectro == 0 ? createTrade(electro, 1, Items.REDSTONE, 32, maxUses, xp) : rElectro == 1 ? createTrade(electro, 3, Items.REPEATER, 18, maxUses, xp) : createTrade(electro, 5, Items.COMPARATOR, 12, maxUses, xp));
            case HOARDER -> offers.add(rElectro == 0 ? createTrade(electro, 4, Items.TNT, 8, maxUses, xp) : rElectro == 1 ? createTrade(electro, 6, Items.GLOWSTONE, 12, maxUses, xp) : createTrade(electro, 8, Items.OXIDIZED_COPPER, 4, maxUses, xp));
            case GOLDEN -> offers.add(rElectro == 0 ? createTrade(electro, 10, Items.REDSTONE_BLOCK, 8, maxUses, xp) : rElectro == 1 ? createTrade(electro, 32, createThunderTrident(), maxUses, xp) : createTrade(electro, 64, getCustomItem("engulfing_lightning"), 1, maxUses, xp));
        }

        // --- TRADE 5: NATURE ---
        switch (variant) {
            case AMATEUR -> offers.add(rNature == 0 ? createTrade(dendro, 1, Items.MOSS_BLOCK, 16, maxUses, xp) : rNature == 1 ? createTrade(dendro, 2, Items.LILY_PAD, 8, maxUses, xp) : createTrade(dendro, 3, Items.SPORE_BLOSSOM, 1, maxUses, xp));
            case HOARDER -> offers.add(rNature == 0 ? createTrade(dendro, 5, Items.SUGAR_CANE, 12, maxUses, xp) : rNature == 1 ? createTrade(dendro, 8, Items.BAMBOO, 4, maxUses, xp) : createTrade(dendro, 6, Items.COCOA_BEANS, 2, maxUses, xp));
            case GOLDEN -> offers.add(rNature == 0 ? createTrade(dendro, 15, Items.BEE_NEST, 1, maxUses, xp) : rNature == 1 ? createTrade(dendro, 20, Items.SNIFFER_EGG, 1, maxUses, xp) : createTrade(dendro, 64, getCustomItem("thousand_floating_dreams"), 1, maxUses, xp));
        }

        // --- TRADE 6: WATER ---
        switch (variant) {
            case AMATEUR -> offers.add(rWater == 0 ? createTrade(hydro, 2, Items.PRISMARINE_CRYSTALS, 16, maxUses, xp) : rWater == 1 ? createTrade(hydro, 1, Items.SEA_PICKLE, 8, maxUses, xp) : createTrade(hydro, 1, Items.DRIED_KELP_BLOCK, 4, maxUses, xp));
            case HOARDER -> offers.add(rWater == 0 ? createTrade(hydro, 6, Items.NAUTILUS_SHELL, 2, maxUses, xp) : rWater == 1 ? createTrade(hydro, 10, Items.AXOLOTL_BUCKET, 1, maxUses, xp) : createTrade(hydro, 8, Items.SPONGE, 4, maxUses, xp));
            case GOLDEN -> offers.add(rWater == 0 ? createTrade(hydro, 25, Items.HEART_OF_THE_SEA, 1, maxUses, xp) : rWater == 1 ? createTrade(hydro, 32, createRiptideTrident(), maxUses, xp) : createTrade(hydro, 64, getCustomItem("splendor_of_tranquil_waters"), 1, maxUses, xp));
        }

        // --- TRADE 7: FIRE ---
        switch (variant) {
            case AMATEUR -> offers.add(rFire == 0 ? createTrade(pyro, 1, Items.MAGMA_BLOCK, 16, maxUses, xp) : rFire == 1 ? createTrade(pyro, 3, Items.LAVA_BUCKET, 1, maxUses, xp) : createTrade(pyro, 2, Items.FIRE_CHARGE, 8, maxUses, xp));
            case HOARDER -> offers.add(rFire == 0 ? createTrade(pyro, 6, Items.OBSIDIAN, 1, maxUses, xp) : rFire == 1 ? createTrade(pyro, 2, Items.BLAZE_POWDER, 4, maxUses, xp) : createTrade(pyro, 4, Items.GHAST_TEAR, 2, maxUses, xp));
            case GOLDEN -> offers.add(rFire == 0 ? createTrade(pyro, 30, Items.WITHER_SKELETON_SKULL, 1, maxUses, xp) : rFire == 1 ? createTrade(pyro, 25, Items.NETHERITE_SCRAP, 1, maxUses, xp) : createTrade(pyro, 64, getCustomItem("thousand_blazing_suns"), 1, maxUses, xp));
        }

        // --- TRADE 8: FROST ---
        switch (variant) {
            case AMATEUR -> offers.add(rFrost == 0 ? createTrade(cryo, 2, Items.POWDER_SNOW_BUCKET, 1, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 1, Items.SNOW_BLOCK, 4, maxUses, xp) : createTrade(cryo, 1, Items.ICE, 16, maxUses, xp));
            case HOARDER -> offers.add(rFrost == 0 ? createTrade(cryo, 8, Items.PACKED_ICE, 32, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 10, createFrostWalkerBook(), maxUses, xp) : createTrade(cryo, 9, Items.SCULK_SENSOR, 16, maxUses, xp));
            case GOLDEN -> offers.add(rFrost == 0 ? createTrade(cryo, 20, Items.BLUE_ICE, 64, maxUses, xp) : rFrost == 1 ? createTrade(cryo, 36, createEpicPickaxe(), maxUses, xp) : createTrade(cryo, 64, getCustomItem("tsaritsas_scepter"), 1, maxUses, xp));
        }

        // --- TRADE 9: MOON ---
        switch (variant) {
            case AMATEUR -> offers.add(rMoon == 0 ? createTrade(luna, 1, getCustomItem("end_grass_block"), 2, maxUses, xp) : rMoon == 1 ? createTrade(luna, 1, Items.END_STONE, 16, maxUses, xp) : createTrade(luna, 2, getCustomItem("ghostly_sapling"), 1, maxUses, xp));
            case HOARDER -> offers.add(rMoon == 0 ? createTrade(luna, 6, Items.ENDER_PEARL, 8, maxUses, xp) : rMoon == 1 ? createTrade(luna, 8, Items.SHULKER_SHELL, 2, maxUses, xp) : createTrade(luna, 8, getCustomItem("heart_of_healing"), 1, maxUses, xp));
            case GOLDEN -> offers.add(rMoon == 0 ? createTrade(luna, 20, Items.END_CRYSTAL, 2, maxUses, xp) : rMoon == 1 ? createTrade(luna, 15, getCustomItem("shadow_clock"), 1, maxUses, xp) : createTrade(luna, 64, getCustomItem("nocturnes_curtain_call"), 1, maxUses, xp));
        }

        this.offers = offers;
    }

    // ==========================================
    // TRADE CREATION HELPERS
    // ==========================================

    private Item getCustomItem(String id) {
        return net.minecraft.registry.Registries.ITEM.get(net.minecraft.util.Identifier.of("gilemod", id));
    }

    private TradeOffer createTrade(Item cost, int costCount, Item reward, int rewardCount, int maxUses, int xp) {
        return new TradeOffer(new TradedItem(cost, costCount), new ItemStack(reward, rewardCount), maxUses, xp, 0.0f);
    }

    private TradeOffer createTrade(Item cost, int costCount, ItemStack rewardStack, int maxUses, int xp) {
        return new TradeOffer(new TradedItem(cost, costCount), rewardStack, maxUses, xp, 0.0f);
    }

    // 1.21.1 Component System for Fireworks
    private ItemStack createDuration3Rocket(int count) {
        ItemStack stack = new ItemStack(Items.FIREWORK_ROCKET, count);
        stack.set(net.minecraft.component.DataComponentTypes.FIREWORKS, new net.minecraft.component.type.FireworksComponent(3, java.util.List.of()));
        return stack;
    }

    // 1.21.1 Registry System for Enchanted Books
    private ItemStack createFrostWalkerBook() {
        var registryManager = this.getWorld().getRegistryManager();
        var enchantmentRegistry = registryManager.get(RegistryKeys.ENCHANTMENT);
        var frostWalkerEntry = enchantmentRegistry.getEntry(Enchantments.FROST_WALKER).orElseThrow();
        return EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(frostWalkerEntry, 2));
    }

    // 1.21.1 Registry System for Enchanted Pickaxe
    private ItemStack createEpicPickaxe() {
        ItemStack stack = new ItemStack(Items.DIAMOND_PICKAXE);
        var registryManager = this.getWorld().getRegistryManager();
        var enchantmentRegistry = registryManager.get(RegistryKeys.ENCHANTMENT);

        var silkTouchEntry = enchantmentRegistry.getEntry(Enchantments.SILK_TOUCH).orElseThrow();
        var efficiencyEntry = enchantmentRegistry.getEntry(Enchantments.EFFICIENCY).orElseThrow();

        stack.addEnchantment(silkTouchEntry, 1);
        stack.addEnchantment(efficiencyEntry, 3);
        return stack;
    }

    // 1.21.1 Registry System for Riptide Trident
    private ItemStack createRiptideTrident() {
        ItemStack stack = new ItemStack(Items.TRIDENT);
        var registryManager = this.getWorld().getRegistryManager();
        var enchantmentRegistry = registryManager.get(RegistryKeys.ENCHANTMENT);

        var riptideEntry = enchantmentRegistry.getEntry(Enchantments.RIPTIDE).orElseThrow();

        stack.addEnchantment(riptideEntry, 1);
        return stack;
    }

    // 1.21.1 Registry System for Thunder Trident
    private ItemStack createThunderTrident() {
        ItemStack stack = new ItemStack(Items.TRIDENT);
        var registryManager = this.getWorld().getRegistryManager();
        var enchantmentRegistry = registryManager.get(RegistryKeys.ENCHANTMENT);

        var channelingEntry = enchantmentRegistry.getEntry(Enchantments.CHANNELING).orElseThrow();
        var loyaltyEntry = enchantmentRegistry.getEntry(Enchantments.LOYALTY).orElseThrow();

        stack.addEnchantment(channelingEntry, 1);
        stack.addEnchantment(loyaltyEntry, 2);
        return stack;
    }

    @Nullable
    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
        // Roll for rarity: 10% Golden, 30% Hoarder, 60% Amateur
        int roll = this.random.nextInt(100);
        if (roll < 10) {
            this.setVariant(WeaselVariant.GOLDEN);
        } else if (roll < 40) {
            this.setVariant(WeaselVariant.HOARDER);
        } else {
            this.setVariant(WeaselVariant.AMATEUR);
        }
        return super.initialize(world, difficulty, spawnReason, entityData);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("WeaselVariant", this.getVariant().getId());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.setVariant(WeaselVariant.byId(nbt.getInt("WeaselVariant")));
    }

    @Override
    protected void afterUsing(TradeOffer offer) {
        // This is a mandatory method in 1.21.1. It triggers every time a trade is completed.
        // If you still want the Weasel to drop XP when traded with, you can add it here!

        if (!this.getWorld().isClient) {
            // Drops a small amount of XP when the player buys something
            int xp = 3 + this.random.nextInt(4);
            this.getWorld().spawnEntity(new net.minecraft.entity.ExperienceOrbEntity(this.getWorld(), this.getX(), this.getY() + 0.5D, this.getZ(), xp));
        }
    }

    @Nullable
    @Override
    public PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null; // They don't breed
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return GileMod.WEASEL_THIEF_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_FOX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_FOX_DEATH;
    }
}