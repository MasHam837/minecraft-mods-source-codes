package mh837.gile.entity;

import mh837.gile.GileMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.List;

public class JerboaEntity extends AnimalEntity {

    private static final TrackedData<Boolean> HIDING = DataTracker.registerData(JerboaEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private static final TrackedData<Boolean> DESERT_VARIANT = DataTracker.registerData(JerboaEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    public JerboaEntity(EntityType<? extends AnimalEntity> entityType, World world) {
        super(entityType, world);
    }

    @Override
    public float getPathfindingFavor(BlockPos pos, net.minecraft.world.WorldView world) {
        return 10.0F;
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new EscapeDangerGoal(this, 1.5));
        this.goalSelector.add(2, new FleeEntityGoal<>(this, HostileEntity.class, 8.0F, 1.2, 1.5));
        this.goalSelector.add(3, new FleeEntityGoal<>(this, PlayerEntity.class, 8.0F, 1.1, 1.4, player -> !isHoldingDryFlower((PlayerEntity) player)));
        this.goalSelector.add(4, new HideGoal(this));
        this.goalSelector.add(5, new AnimalMateGoal(this, 1.0));
        this.goalSelector.add(6, new TemptGoal(this, 1.1, Ingredient.ofItems(GileMod.DRY_FLOWER_ITEM), false));
        this.goalSelector.add(7, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));
        this.goalSelector.add(9, new LookAroundGoal(this));
    }

    public static DefaultAttributeContainer.Builder createJerboaAttributes() {
        return AnimalEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 6.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(HIDING, false);
        builder.add(DESERT_VARIANT, false); // Register the desert variant tracker
    }

    public boolean isHiding() {
        return this.dataTracker.get(HIDING);
    }

    public void setHiding(boolean hiding) {
        this.dataTracker.set(HIDING, hiding);
    }

    public boolean isDesertVariant() {
        return this.dataTracker.get(DESERT_VARIANT);
    }

    public void setDesertVariant(boolean variant) {
        this.dataTracker.set(DESERT_VARIANT, variant);
    }

    // Save and load the variant so it persists when chunks unload
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("DesertVariant", this.isDesertVariant());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.setDesertVariant(nbt.getBoolean("DesertVariant"));
    }

    // Check the biome when the Jerboa naturally spawns
    @Nullable
    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
        if (world.getBiome(this.getBlockPos()).isIn(BiomeTags.IS_OVERWORLD)) {
            this.setDesertVariant(true);
        }
        return super.initialize(world, difficulty, spawnReason, entityData);
    }

    // Complete Invincibility while hiding
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (this.isHiding()) {
            return false; // Cancels all damage, knockback, and hurt animations
        }
        return super.damage(source, amount);
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return stack.isOf(GileMod.DRY_FLOWER_ITEM);
    }

    @Override
    public void tick() {
        super.tick();

        if (this.getWorld().isClient || !this.isAlive()) {
            return;
        }

        boolean afraid = false;
        Box searchBox = this.getBoundingBox().expand(8.0);

        List<HostileEntity> hostiles = this.getWorld().getEntitiesByClass(HostileEntity.class, searchBox, entity -> true);
        if (!hostiles.isEmpty()) {
            afraid = true;
        }

        boolean playersNearby = this.getWorld().getPlayers().stream()
                .anyMatch(player -> player.squaredDistanceTo(this) < 100 && !isHoldingDryFlower(player));

        if (playersNearby) {
            afraid = true;
        }

        BlockState below = this.getWorld().getBlockState(this.getBlockPos().down());
        boolean canHide = below.isOf(GileMod.MOON_SAND) || below.isOf(Blocks.SAND) || below.isOf(Blocks.RED_SAND);

        boolean shouldHide = afraid && canHide;

        // Run 2x faster if scared and cannot hide
        if (afraid && !canHide) {
            this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED)
                    .setBaseValue(0.64); // 2x normal speed
        } else {
            this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED)
                    .setBaseValue(0.32); // normal speed
        }

        if (shouldHide != this.isHiding()) {
            this.setHiding(shouldHide);
            this.getWorld().sendEntityStatus(this, (byte)(shouldHide ? 10 : 11));
        }

        if (this.isHiding()) {
            this.getNavigation().stop();
        }
    }

    private boolean isHoldingDryFlower(PlayerEntity player) {
        return player.getMainHandStack().isOf(GileMod.DRY_FLOWER_ITEM) || player.getOffHandStack().isOf(GileMod.DRY_FLOWER_ITEM);
    }

    @Override
    public void handleStatus(byte status) {
        if (status == 10 || status == 11) {
            BlockState state = this.getWorld().getBlockState(this.getBlockPos().down());
            for (int i = 0; i < 12; ++i) {
                double offsetX = (this.random.nextDouble() - 0.5) * this.getWidth() * 1.5;
                double offsetZ = (this.random.nextDouble() - 0.5) * this.getWidth() * 1.5;
                this.getWorld().addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, state),
                        this.getX() + offsetX, this.getY() + 0.1, this.getZ() + offsetZ, 0.0, 0.15, 0.0);
            }
        } else {
            super.handleStatus(status);
        }
    }

    @Override
    public void travel(Vec3d movementInput) {
        if (this.isHiding()) {
            super.travel(Vec3d.ZERO);
        } else {
            super.travel(movementInput);
        }
    }

    @Override
    public boolean isPushable() {
        return !this.isHiding();
    }

    @Override
    protected void pushAway(Entity entity) {
        if (!this.isHiding()) {
            super.pushAway(entity);
        }
    }

    @Override
    protected void dropLoot(DamageSource source, boolean causedByPlayer) {
        super.dropLoot(source, causedByPlayer);
        int looting = 0;
        if (source.getAttacker() instanceof LivingEntity attacker) {
            RegistryEntry<Enchantment> lootingEnchant = attacker.getWorld()
                    .getRegistryManager()
                    .get(RegistryKeys.ENCHANTMENT)
                    .getEntry(Enchantments.LOOTING)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = EnchantmentHelper.getEquipmentLevel(lootingEnchant, attacker);
            }
        }
        float[] chances = {0.25f, 0.33f, 0.40f, 0.50f};
        // Prevent crashes if modded looting goes above 3
        int index = Math.min(looting, chances.length - 1);
        if (this.random.nextFloat() < chances[index]) {
            this.dropStack(new ItemStack(GileMod.JERBOAS_TAIL, 1));
        }
    }

    @Nullable
    @Override
    public JerboaEntity createChild(ServerWorld world, PassiveEntity entity) {
        JerboaEntity baby = GileMod.JERBOA.create(world);
        if (baby != null && entity instanceof JerboaEntity parent) {
            // Baby inherits variant from parents
            baby.setDesertVariant(this.random.nextBoolean() ? this.isDesertVariant() : parent.isDesertVariant());
        }
        return baby;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return this.isHiding() ? null : SoundEvents.ENTITY_RABBIT_AMBIENT;
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_RABBIT_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_RABBIT_DEATH;
    }

    static class HideGoal extends Goal {
        private final JerboaEntity jerboa;

        public HideGoal(JerboaEntity jerboa) {
            this.jerboa = jerboa;
            this.setControls(EnumSet.of(Control.MOVE, Control.LOOK, Control.JUMP));
        }

        @Override
        public boolean canStart() {
            return this.jerboa.isHiding();
        }

        @Override
        public void start() {
            this.jerboa.getNavigation().stop();
        }

        @Override
        public void tick() {
            this.jerboa.getNavigation().stop();
        }
    }
}