package mh837.gile.entity;

import mh837.gile.GileMod;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class FateArrowEntity extends PersistentProjectileEntity {
    public FateArrowEntity(EntityType<? extends PersistentProjectileEntity> entityType, World world) {
        super(entityType, world);
        this.pickupType = PickupPermission.ALLOWED;
    }

    public FateArrowEntity(World world, LivingEntity owner, ItemStack pickupStack) {
        super(GileMod.FATE_ARROW_TYPE, owner, world, pickupStack, null);
        this.setDamage(6.0);
        this.pickupType = PickupPermission.ALLOWED;
    }

    @Override
    protected ItemStack asItemStack() {
        return new ItemStack(GileMod.FATE_ARROW);
    }

    @Override
    protected ItemStack getDefaultItemStack() {
        return new ItemStack(GileMod.FATE_ARROW);
    }
    private int punch = 0;
    public void setPunch(int punch) {
        this.punch = punch;
    }

    @Override
    protected void onEntityHit(EntityHitResult entityHitResult) {
        // Correctly define the target from the hit result
        net.minecraft.entity.Entity target = entityHitResult.getEntity();
        // Handle the Knockback logic
        if (this.punch > 0 && target instanceof LivingEntity livingTarget) {
            Vec3d velocity = this.getVelocity().multiply(1, 0, 1).normalize().multiply(this.punch * 0.6);
            livingTarget.addVelocity(velocity.x, 0.1, velocity.z); }
        // Call super after custom knockback logic
        super.onEntityHit(entityHitResult);

        if (!this.getWorld().isClient) {
            if (target instanceof LivingEntity livingEntity) {
                // Apply levitation effect
                StatusEffectInstance levitationEffect = new StatusEffectInstance(
                        StatusEffects.LEVITATION,
                        100,
                        0,
                        true,
                        true);
                livingEntity.addStatusEffect(levitationEffect, this.getOwner());
                // Add particles
                if (this.getWorld() instanceof ServerWorld serverWorld) {
                    serverWorld.spawnParticles(
                            ParticleTypes.FIREWORK,
                            livingEntity.getX(),
                            livingEntity.getY() + livingEntity.getHeight() / 2,
                            livingEntity.getZ(),
                            40,
                            0.5, 0.5, 0.5,
                            0.1 );
                    // Play sound
                    serverWorld.playSound(
                            null,
                            livingEntity.getX(),
                            livingEntity.getY(),
                            livingEntity.getZ(),
                            SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK,
                            SoundCategory.PLAYERS,
                            1.0f,
                            1.0f );
                }
            }
        }
    }

    @Override
    protected void onBlockHit(BlockHitResult blockHitResult) {
        super.onBlockHit(blockHitResult);

        if (!this.getWorld().isClient) {
            // Only play sound on block hit, no particles
            this.playSound(net.minecraft.sound.SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.0F);
        }
    }

    @Override
    public void tick() {
        super.tick();

        // Trail particles while flying
        if (this.getWorld().isClient && !this.inGround) {
            // Spawn 5 particles with random offset
            for (int i = 0; i < 3; i++) {
                double offsetX = (this.random.nextDouble() - 0.5) * 0.5; // Increased from 0.2 to 0.5
                double offsetY = (this.random.nextDouble() - 0.5) * 0.5; // Increased from 0.2 to 0.5
                double offsetZ = (this.random.nextDouble() - 0.5) * 0.5; // Increased from 0.2 to 0.5

                this.getWorld().addParticle(ParticleTypes.EFFECT,
                        this.getX() + offsetX,
                        this.getY() + offsetY,
                        this.getZ() + offsetZ,
                        0.0, 0.0, 0.0);
            }
        }

        // Particles when stuck in ground
        if (this.getWorld().isClient && this.inGround && this.age % 10 == 0) {
            for (int i = 0; i < 2; i++) {
                double offsetX = (this.random.nextDouble() - 0.5) * 0.5; // Increased from 0.3 to 0.5
                double offsetZ = (this.random.nextDouble() - 0.5) * 0.5; // Increased from 0.3 to 0.5

                this.getWorld().addParticle(ParticleTypes.EFFECT,
                        this.getX() + offsetX,
                        this.getY() + 0.1,
                        this.getZ() + offsetZ,
                        0.0, 0.0, 0.0);
            }
        }
    }
    @Override
    protected float getDragInWater() {
        return 0.6F;
    }
}