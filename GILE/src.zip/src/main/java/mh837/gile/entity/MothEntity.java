package mh837.gile.entity;

import mh837.gile.GileMod;
import mh837.gile.advancement.NamedEntityCriterion;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.Flutterer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class MothEntity extends AnimalEntity implements Flutterer {
    private static final TrackedData<Byte> MOTH_FLAGS =
            DataTracker.registerData(MothEntity.class, TrackedDataHandlerRegistry.BYTE);

    public MothEntity(EntityType<? extends AnimalEntity> entityType, World world) {
        super(entityType, world);
        this.moveControl = new FlightMoveControl(this, 10, true);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new AnimalMateGoal(this, 1.0));
        this.goalSelector.add(2, new TemptGoal(this, 1.0, Ingredient.ofItems(GileMod.MOON_FLOWER_ITEM), false));
        this.goalSelector.add(3, new FollowParentGoal(this, 1.1));
        this.goalSelector.add(4, new WanderAroundFarGoal(this, 1.0));
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(MOTH_FLAGS, (byte)0);
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return stack.isOf(GileMod.MOON_FLOWER_ITEM);
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        BirdNavigation birdNavigation = new BirdNavigation(this, world);
        birdNavigation.setCanPathThroughDoors(false);
        birdNavigation.setCanSwim(true);
        birdNavigation.setCanEnterOpenDoors(true);
        return birdNavigation;
    }

    @Override
    public float getPathfindingFavor(BlockPos pos, WorldView world) {
        return world.getBlockState(pos.down()).isAir() ? 10.0F : 0.0F;
    }

    @Override
    public boolean isInAir() {
        return !this.isOnGround();
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack itemStack = player.getStackInHand(hand);

        if (this.isBreedingItem(itemStack)) {
            int age = this.getBreedingAge();

            if (!this.getWorld().isClient && age == 0 && this.canEat()) {
                this.eat(player, hand, itemStack);
                this.lovePlayer(player);
                return ActionResult.SUCCESS;
            }

            if (this.isBaby()) {
                this.eat(player, hand, itemStack);
                this.growUp(toGrowUpAge(-24000), true);
                return ActionResult.success(this.getWorld().isClient);
            }
        }

        return super.interactMob(player, hand);
    }

    @Override
    public void tickMovement() {
        super.tickMovement();

        // Try to fly higher when not on ground
        if (!this.isOnGround() && this.getVelocity().y < 0.0) {
            this.setVelocity(this.getVelocity().multiply(1.0, 0.6, 1.0));
        }

        if (this.getWorld().isClient) {
            // Wing scale particles while flying
            if (this.random.nextInt(10) == 0) {
                this.getWorld().addParticle(
                        ParticleTypes.END_ROD,
                        this.getParticleX(0.5),
                        this.getY() + 0.3,
                        this.getParticleZ(0.5),
                        0.0, 0.0, 0.0
                );
            }

            // Extra particles when in love mode
            if (this.isInLove() && this.random.nextInt(5) == 0) {
                this.getWorld().addParticle(
                        ParticleTypes.HEART,
                        this.getParticleX(0.5),
                        this.getY() + 0.5,
                        this.getParticleZ(0.5),
                        0.0, 0.0, 0.0
                );
            }
        }
    }

    @Override
    public void travel(Vec3d movementInput) {
        if (this.isLogicalSideForUpdatingMovement()) {
            if (this.isTouchingWater()) {
                this.updateVelocity(0.02F, movementInput);
                this.move(net.minecraft.entity.MovementType.SELF, this.getVelocity());
                this.setVelocity(this.getVelocity().multiply(0.8F));
            } else if (this.isInLava()) {
                this.updateVelocity(0.02F, movementInput);
                this.move(net.minecraft.entity.MovementType.SELF, this.getVelocity());
                this.setVelocity(this.getVelocity().multiply(0.5));
            } else {
                float f = 0.91F;
                if (this.isOnGround()) {
                    f = this.getWorld().getBlockState(this.getVelocityAffectingPos())
                            .getBlock().getSlipperiness() * 0.91F;
                }
                float g = 0.16277137F / (f * f * f);
                this.updateVelocity(this.isOnGround() ? 0.1F * g : 0.02F, movementInput);
                f = 0.91F;
                if (this.isOnGround()) {
                    f = this.getWorld().getBlockState(this.getVelocityAffectingPos())
                            .getBlock().getSlipperiness() * 0.91F;
                }
                this.move(net.minecraft.entity.MovementType.SELF, this.getVelocity());
                this.setVelocity(this.getVelocity().multiply(f));
            }
        }
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false; // No fall damage
    }

    @Override
    protected void dropLoot(DamageSource source, boolean causedByPlayer) {
        super.dropLoot(source, causedByPlayer);
        int looting = 0;
        if (source.getAttacker() instanceof LivingEntity attacker) {
            RegistryEntry<Enchantment> lootingEnchant = attacker.getWorld()
                    .getRegistryManager()
                    .get(RegistryKeys.ENCHANTMENT)
                    .getEntry(Enchantments.LOOTING)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = EnchantmentHelper.getEquipmentLevel(lootingEnchant, attacker);}}
        int dropCount = this.random.nextInt(2 + looting);
        this.dropStack(new ItemStack(GileMod.MOTH_WING, dropCount));
    }

    @Nullable
    @Override
    public MothEntity createChild(ServerWorld world, PassiveEntity entity) {
        return GileMod.MOTH.create(world);
    }

    public static DefaultAttributeContainer.Builder createMothAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 6.0)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.4) // Increased from 0.3
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.2)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 10.0);
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_BEE_LOOP;
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_BEE_HURT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_BEE_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.3F;
    }

    @Override
    public float getSoundPitch() {
        return 1.3F;
    }

    @Override
    public void setCustomName(@Nullable Text name) {
        super.setCustomName(name);
        if (name != null && !this.getWorld().isClient && this.getWorld() instanceof ServerWorld) {
            this.getWorld().getPlayers().forEach(player -> {
                if (player instanceof ServerPlayerEntity serverPlayer &&
                        player.squaredDistanceTo(this) < 100) { // Within 10 blocks
                    NamedEntityCriterion.CRITERION.trigger(serverPlayer, this, name.getString());
                }
            });
        }
    }
}