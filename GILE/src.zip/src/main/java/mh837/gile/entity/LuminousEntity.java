package mh837.gile.entity;

import mh837.gile.GileMod;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class LuminousEntity extends AnimalEntity {
    private static final TrackedData<Integer> VARIANT = DataTracker.registerData(LuminousEntity.class, TrackedDataHandlerRegistry.INTEGER);

    public LuminousEntity(EntityType<? extends AnimalEntity> entityType, World world) {
        super(entityType, world);
    }

    @Override
    public float getPathfindingFavor(BlockPos pos, net.minecraft.world.WorldView world) {
        // Returns a high favor so it gladly spawns in the dark on End blocks
        return 10.0F;
    }

    @Override
    public EntityDimensions getBaseDimensions(EntityPose pose) {
        EntityDimensions dimensions = super.getBaseDimensions(pose);
        if (this.isBaby()) {
            return dimensions.scaled(1.0f);
        }
        return dimensions;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return stack.isOf(GileMod.STAR_FRAGMENT);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new EscapeDangerGoal(this, 1.25));

        this.goalSelector.add(2, new AnimalMateGoal(this, 1.0));
        this.goalSelector.add(3, new TemptGoal(this, 1.15, stack -> stack.isOf(GileMod.STAR_FRAGMENT), false));

        this.goalSelector.add(4, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));
        this.goalSelector.add(6, new LookAroundGoal(this));
    }

    public static DefaultAttributeContainer.Builder createLuminousAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0)
                .add(EntityAttributes.GENERIC_JUMP_STRENGTH, 0.17)
                .add(EntityAttributes.GENERIC_GRAVITY, 0.01);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, 0); // Default: 0 = Yellow, 1 = Light Blue, 2 = Pink
    }

    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
        // Assign a random variant upon spawning naturally
        this.setVariant(this.random.nextInt(3));
        return super.initialize(world, difficulty, spawnReason, entityData);
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack itemStack = player.getStackInHand(hand);

        if (this.isBreedingItem(itemStack)) {
            int age = this.getBreedingAge();

            if (!this.getWorld().isClient && age == 0 && this.canEat()) {
                this.eat(player, hand, itemStack);
                this.lovePlayer(player);
                return ActionResult.SUCCESS;
            }

            if (this.isBaby()) {
                this.eat(player, hand, itemStack);

                int currentAge = this.getBreedingAge();
                int ageIncrease = (int)((float)(-currentAge / 20) * 0.1F);
                this.growUp(ageIncrease, true);
                return ActionResult.success(this.getWorld().isClient);
            }

        }

        return super.interactMob(player, hand);
    }

    public int getVariant() {
        return this.dataTracker.get(VARIANT);
    }

    public void setVariant(int variant) {
        this.dataTracker.set(VARIANT, variant);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Variant", this.getVariant());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.setVariant(nbt.getInt("Variant"));
    }

    @Override
    protected void dropLoot(DamageSource source, boolean causedByPlayer) {
        super.dropLoot(source, causedByPlayer);
        int looting = 0;
        if (source.getAttacker() instanceof LivingEntity attacker) {
            RegistryEntry<Enchantment> lootingEnchant = attacker.getWorld()
                    .getRegistryManager()
                    .get(RegistryKeys.ENCHANTMENT)
                    .getEntry(Enchantments.LOOTING)
                    .orElse(null);
            if (lootingEnchant != null) {
                looting = EnchantmentHelper.getEquipmentLevel(lootingEnchant, attacker);}}
        int dropCount = 1 + this.random.nextInt(2 + looting);
        this.dropStack(new ItemStack(GileMod.PHASMA, dropCount));
    }

    @Nullable
    @Override
    public LuminousEntity createChild(ServerWorld world, PassiveEntity entity) {
        LuminousEntity child = GileMod.LUMINOUS.create(world);
        if (child != null) {
            // Set variant - inherits from one of the parents
            child.setVariant(this.random.nextBoolean() ? this.getVariant() : ((LuminousEntity)entity).getVariant());

            // ADD THIS: Forces the child to spawn as a baby
            child.setBaby(true);
        }
        return child;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean damaged = super.damage(source, amount);

        if (damaged && !this.getWorld().isClient) {
            this.getWorld().playSound(
                    null,
                    this.getX(), this.getY(), this.getZ(),
                    GileMod.LUMINOUS_HURT, SoundCategory.HOSTILE,
                    0.8F,
                    2.0F
            );
        }

        return damaged;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return GileMod.LUMINOUS_AMBIENT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_CAT_DEATH;
    }

}