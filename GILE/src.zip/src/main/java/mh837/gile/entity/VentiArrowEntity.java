package mh837.gile.entity;

import mh837.gile.GileMod;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class VentiArrowEntity extends PersistentProjectileEntity {
    // Custom colored dust particles - greenish-cyan
    private static final ParticleEffect TRAIL_PARTICLE = new DustParticleEffect(
            new Vector3f(0.2f, 0.9f, 0.8f), // RGB: greenish-cyan
            1.5f // size
    );

    private static final ParticleEffect HIT_PARTICLE = new DustParticleEffect(
            new Vector3f(0.1f, 1.0f, 0.9f), // Brighter cyan for hits
            2.0f
    );

    private static final ParticleEffect BLOCK_HIT_PARTICLE = new DustParticleEffect(
            new Vector3f(0.3f, 0.8f, 0.7f), // Slightly different shade
            1.0f
    );

    private float pushStrength = 1.5f;

    public VentiArrowEntity(EntityType<? extends PersistentProjectileEntity> entityType, World world) {
        super(entityType, world);
        this.pickupType = PickupPermission.DISALLOWED;
    }

    public VentiArrowEntity(World world, LivingEntity owner) {
        super(GileMod.VENTI_ARROW_TYPE, owner, world, new ItemStack(Items.ARROW), null);
        this.setDamage(7.0);
        this.pickupType = PickupPermission.DISALLOWED;
    }

    @Override
    protected ItemStack asItemStack() {
        return new ItemStack(Items.ARROW);
    }

    @Override
    protected ItemStack getDefaultItemStack() {
        return new ItemStack(Items.ARROW);
    }

    private int punch = 0;
    public void setPunch(int punch) {
        this.punch = punch;
    }

    public void setPushStrength(float strength) {
        this.pushStrength = strength;
    }

    @Override
    protected void onEntityHit(EntityHitResult entityHitResult) {
        net.minecraft.entity.Entity target = entityHitResult.getEntity();

        if (target instanceof LivingEntity livingTarget) {
            Vec3d velocity = this.getVelocity().normalize().multiply(this.pushStrength);
            if (this.punch > 0) {
                velocity = velocity.multiply(1.0 + (this.punch * 0.5));
            }
            livingTarget.addVelocity(velocity.x, 0.2, velocity.z);
            livingTarget.velocityModified = true;
        }

        super.onEntityHit(entityHitResult);

        if (!this.getWorld().isClient) {
            if (target instanceof LivingEntity livingEntity) {

                if (this.getWorld() instanceof ServerWorld serverWorld) {
                    // Colored dust burst on hit
                    serverWorld.spawnParticles(
                            HIT_PARTICLE,
                            livingEntity.getX(),
                            livingEntity.getY() + livingEntity.getHeight() / 2,
                            livingEntity.getZ(),
                            40,
                            0.8, 1.0, 0.8,
                            0.1);

                    // White cloud overlay
                    serverWorld.spawnParticles(
                            ParticleTypes.CLOUD,
                            livingEntity.getX(),
                            livingEntity.getY() + livingEntity.getHeight() / 2,
                            livingEntity.getZ(),
                            15,
                            0.5, 0.5, 0.5,
                            0.05);

                    serverWorld.playSound(
                            null,
                            livingEntity.getX(),
                            livingEntity.getY(),
                            livingEntity.getZ(),
                            SoundEvents.ENTITY_BREEZE_SHOOT,
                            SoundCategory.PLAYERS,
                            1.0f,
                            1.0f);
                }
            }
        }
    }

    @Override
    protected void onBlockHit(BlockHitResult blockHitResult) {
        super.onBlockHit(blockHitResult);

        if (!this.getWorld().isClient) {
            this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.0F);

            // Rarer colored dust on block hit
            if (this.random.nextFloat() < 0.3f && this.getWorld() instanceof ServerWorld serverWorld) {
                serverWorld.spawnParticles(
                        BLOCK_HIT_PARTICLE,
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        10,
                        0.3, 0.3, 0.3,
                        0.03);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();

        // Trail particles while flying - colored dust
        if (this.getWorld().isClient && !this.inGround) {
            for (int i = 0; i < 3; i++) {
                double offsetX = (this.random.nextDouble() - 0.5) * 0.3;
                double offsetY = (this.random.nextDouble() - 0.5) * 0.3;
                double offsetZ = (this.random.nextDouble() - 0.5) * 0.3;

                this.getWorld().addParticle(TRAIL_PARTICLE,
                        this.getX() + offsetX,
                        this.getY() + offsetY,
                        this.getZ() + offsetZ,
                        0.0, 0.0, 0.0);
            }
        }

        // Rarer particles when stuck in ground
        if (this.getWorld().isClient && this.inGround && this.age % 40 == 0) {
            if (this.random.nextFloat() < 0.3f) {
                this.getWorld().addParticle(BLOCK_HIT_PARTICLE,
                        this.getX(),
                        this.getY() + 0.1,
                        this.getZ(),
                        0.0, 0.01, 0.0);
            }
        }

        // Auto-discard after being in ground too long
        if (!this.getWorld().isClient && this.inGround && this.age > 1200) {
            this.discard();
        }
    }

    @Override
    protected float getDragInWater() {
        return 0.6F;
    }

    @Override
    public void onPlayerCollision(PlayerEntity player) {
        // Do nothing - prevent pickup
    }
}