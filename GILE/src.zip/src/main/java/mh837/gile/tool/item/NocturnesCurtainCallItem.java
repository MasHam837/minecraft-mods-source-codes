package mh837.gile.tool.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class NocturnesCurtainCallItem extends SwordItem {

    // Store original gravity for reset
    private static final double MOON_GRAVITY = 0.029; // Lower gravity (vanilla is -0.08)
    private static final double MOON_JUMP_BOOST = 0.36; // Higher jump

    public NocturnesCurtainCallItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        return Text.translatable(this.getTranslationKey(stack)).styled(style ->
                style.withColor(net.minecraft.util.Formatting.YELLOW)
        );
    }

    // Pale moonlight (silver-white)
    private static final ParticleEffect HIT_PARTICLE = new DustParticleEffect(
            new Vector3f(0.85f, 0.85f, 0.95f),
            2.0f
    );

    private static final ParticleEffect FEET_PARTICLE = new DustParticleEffect(
            new Vector3f(0.75f, 0.75f, 0.85f),
            1.8f
    );

    private static final ParticleEffect MOON_GOLD_PARTICLE = new DustParticleEffect(
            new Vector3f(0.95f, 0.85f, 0.55f),
            2.0f
    );

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, world, entity, slot, selected);

        if (entity instanceof LivingEntity livingEntity) {
            boolean isHeld = selected || livingEntity.getOffHandStack() == stack;

            // Apply moon gravity when held in either hand
            if (isHeld) {
                applyMoonGravity(livingEntity, true);

                // Add slow falling effect for moon-like floating
                livingEntity.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.SLOW_FALLING,
                        20,  // 2 seconds
                        0,
                        false,
                        false,
                        true
                ));

                // Add strength effect when held
                livingEntity.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.STRENGTH,
                        20,
                        0,
                        false,
                        false,
                        true
                ));
            } else {
                // Reset gravity when not held
                applyMoonGravity(livingEntity, false);
            }

            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof ServerWorld serverWorld) {
                if (world.getTime() % 2 == 0) {
                    double x = livingEntity.getX();
                    double y = livingEntity.getY() + 0.1;
                    double z = livingEntity.getZ();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.random.nextDouble() - 0.5) * 0.6;
                        double offsetZ = (world.random.nextDouble() - 0.5) * 0.6;

                        serverWorld.spawnParticles(
                                ParticleTypes.ENCHANT,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                5,
                                0.1, 0.15, 0.1,
                                0.05
                        );

                        serverWorld.spawnParticles(
                                ParticleTypes.END_ROD,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0,
                                0.02
                        );
                    }

                    serverWorld.spawnParticles(
                            FEET_PARTICLE,
                            x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );
                }
            }
        }
    }

    private void applyMoonGravity(LivingEntity entity, boolean apply) {
        if (apply) {
            // Set lower gravity (moon-like)
            entity.getAttributeInstance(EntityAttributes.GENERIC_GRAVITY).setBaseValue(MOON_GRAVITY);

            // Increase jump strength
            entity.getAttributeInstance(EntityAttributes.GENERIC_JUMP_STRENGTH).setBaseValue(MOON_JUMP_BOOST);
        } else {
            // Reset to vanilla values
            if (entity.getAttributeInstance(EntityAttributes.GENERIC_GRAVITY).getBaseValue() == MOON_GRAVITY) {
                entity.getAttributeInstance(EntityAttributes.GENERIC_GRAVITY).setBaseValue(0.08);
            }
            if (entity.getAttributeInstance(EntityAttributes.GENERIC_JUMP_STRENGTH).getBaseValue() == MOON_JUMP_BOOST) {
                entity.getAttributeInstance(EntityAttributes.GENERIC_JUMP_STRENGTH).setBaseValue(0.42);
            }
        }
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);

        if (attacker.getWorld() instanceof ServerWorld serverWorld) {
            // Effects
            StatusEffectInstance levitationEffect = new StatusEffectInstance(
                    StatusEffects.LEVITATION,
                    40,
                    1,
                    true,
                    false);
            target.addStatusEffect(levitationEffect);

            serverWorld.spawnParticles(
                    HIT_PARTICLE,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    40,
                    0.5, 0.5, 0.5,
                    0.01
            );
            serverWorld.spawnParticles(
                    MOON_GOLD_PARTICLE,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    40,
                    0.5, 0.5, 0.5,
                    0.02
            );

            serverWorld.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE,
                    SoundCategory.PLAYERS,
                    1.0f,
                    1.0f
            );
        }
        return result;
    }
}