package mh837.gile.tool.item;

import mh837.gile.GileMod;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EnlargerItem extends Item {

    public EnlargerItem(Settings settings) {
        super(settings);
    }

    /**
     * Handles applying Enlarge OR countering an active Shrink effect.
     */
    private void processEnlargeTarget(LivingEntity target, World world, PlayerEntity user, ItemStack stack, boolean isSelf) {
        boolean isCountering = target.hasStatusEffect(GileMod.SHRINK_EFFECT);

        if (!world.isClient) {
            if (isCountering) {
                // COUNTER LOGIC: Subtract 5 mins (6000 ticks) from Shrink
                StatusEffectInstance currentEffect = target.getStatusEffect(GileMod.SHRINK_EFFECT);
                int remainingTicks = currentEffect != null ? currentEffect.getDuration() : 0;

                target.removeStatusEffect(GileMod.SHRINK_EFFECT);

                // If they had more than 5 minutes left, give back the remainder
                if (remainingTicks > 6000) {
                    target.addStatusEffect(new StatusEffectInstance(GileMod.SHRINK_EFFECT, remainingTicks - 6000, 3, true, true));
                }

                // Play cancel visuals
                if (world instanceof ServerWorld serverWorld) {
                    serverWorld.spawnParticles(ParticleTypes.CLOUD, target.getX(), target.getBodyY(0.5), target.getZ(), 20, 0.3, 0.5, 0.3, 0.1);
                }
            } else {
                // NORMAL APPLY LOGIC
                int finalDuration = 6000;
                if (target.hasStatusEffect(GileMod.ENLARGE_EFFECT)) {
                    StatusEffectInstance currentEffect = target.getStatusEffect(GileMod.ENLARGE_EFFECT);
                    if (currentEffect != null) {
                        finalDuration += currentEffect.getDuration();
                    }
                }

                target.addStatusEffect(new StatusEffectInstance(GileMod.ENLARGE_EFFECT, finalDuration, 3, true, true));

                if (world instanceof ServerWorld serverWorld) {
                    serverWorld.spawnParticles(ParticleTypes.HAPPY_VILLAGER, target.getX(), target.getBodyY(0.5), target.getZ(), 20, 0.3, 0.5, 0.3, 0.1);
                }

                // Trigger advancement
                if (user instanceof net.minecraft.server.network.ServerPlayerEntity serverPlayer) {
                    mh837.gile.advancement.UsedScepterCriterion.CRITERION.trigger(serverPlayer, stack);
                }
            }

            // Consume durability in both scenarios
            stack.damage(1, user, EquipmentSlot.MAINHAND);
        }

        // Handle Sound Effects (Runs on client and server for sync)
        if (isCountering) {
            SoundEvent cancelSound = isSelf ? SoundEvents.BLOCK_BEACON_DEACTIVATE : SoundEvents.BLOCK_DISPENSER_FAIL;
            world.playSound(null, target.getX(), target.getY(), target.getZ(), cancelSound, SoundCategory.PLAYERS, 1.0F, 1.0F);
        } else {
            world.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, SoundCategory.PLAYERS, 1.0F, 2.0F);
        }
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        // --- SELF-INTERACTION MODE (Shift + Right Click) ---
        if (user.isSneaking()) {
            // 1. SMART TOGGLE CANCEL
            if (user.getPitch() >= 80.0F && user.hasStatusEffect(GileMod.ENLARGE_EFFECT)) {
                if (!world.isClient) {
                    user.removeStatusEffect(GileMod.ENLARGE_EFFECT);
                    if (world instanceof ServerWorld serverWorld) {
                        serverWorld.spawnParticles(ParticleTypes.CLOUD, user.getX(), user.getBodyY(0.5), user.getZ(), 20, 0.3, 0.5, 0.3, 0.1);
                    }
                }
                world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 1.0F, 1.0F);
                user.getItemCooldownManager().set(this, 20);
                return TypedActionResult.success(stack, world.isClient());
            }

            // 2. APPLY OR COUNTER
            processEnlargeTarget(user, world, user, stack, true);
            user.getItemCooldownManager().set(this, 40);
            return TypedActionResult.success(stack, world.isClient());
        }

        // --- RAYCAST MODE ---
        double maxDistance = 20.0;
        Vec3d startPos = user.getEyePos();
        Vec3d lookDir = user.getRotationVec(1.0F);
        Vec3d endPos = startPos.add(lookDir.multiply(maxDistance));

        Box searchBox = user.getBoundingBox().stretch(lookDir.multiply(maxDistance)).expand(1.0, 1.0, 1.0);

        EntityHitResult hitResult = ProjectileUtil.raycast(
                user, startPos, endPos, searchBox,
                entity -> entity instanceof LivingEntity && !entity.isSpectator(),
                maxDistance * maxDistance
        );

        if (hitResult != null && hitResult.getEntity() instanceof LivingEntity target) {
            double distance = startPos.distanceTo(hitResult.getPos());

            // 1. Proximity Cancel Check
            if (distance <= 3.0 && target.hasStatusEffect(GileMod.ENLARGE_EFFECT)) {
                if (!world.isClient) {
                    target.removeStatusEffect(GileMod.ENLARGE_EFFECT);
                    if (world instanceof ServerWorld serverWorld) {
                        serverWorld.spawnParticles(ParticleTypes.CLOUD, target.getX(), target.getBodyY(0.5), target.getZ(), 20, 0.3, 0.5, 0.3, 0.1);
                    }
                }
                world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.BLOCK_DISPENSER_FAIL, SoundCategory.PLAYERS, 1.0F, 1.0F);
                user.getItemCooldownManager().set(this, 20);
                return TypedActionResult.success(stack, world.isClient());
            }
        }

        // 2. Draw Ray Particles
        Vec3d traceEnd = (hitResult != null) ? hitResult.getPos() : endPos;
        if (!world.isClient && world instanceof ServerWorld serverWorld) {
            double distance = startPos.distanceTo(traceEnd);
            int particleCount = (int) (distance * 2);

            for (int i = 0; i <= particleCount; i++) {
                double delta = (double) i / particleCount;
                Vec3d particlePos = startPos.lerp(traceEnd, delta);
                serverWorld.spawnParticles(
                        ParticleTypes.HAPPY_VILLAGER,
                        particlePos.x, particlePos.y - 0.2, particlePos.z,
                        1, 0.0, 0.0, 0.0, 0.0
                );
            }
        }

        // 3. Normal Enlarge Hit Logic
        if (hitResult != null && hitResult.getEntity() instanceof LivingEntity target) {
            processEnlargeTarget(target, world, user, stack, false);
            user.getItemCooldownManager().set(this, 40);
            return TypedActionResult.success(stack, world.isClient());
        }

        // 4. Missed Target
        world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.BLOCK_DISPENSER_FAIL, SoundCategory.PLAYERS, 1.0F, 1.5F);
        user.getItemCooldownManager().set(this, 40);
        return TypedActionResult.pass(stack);
    }
}