package mh837.gile.tool.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class ThousandFloatingDreamsItem extends SwordItem {
    public ThousandFloatingDreamsItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        return Text.translatable(this.getTranslationKey(stack)).styled(style ->
                style.withColor(net.minecraft.util.Formatting.YELLOW)
        );
    }

    private static final ParticleEffect HIT_PARTICLE = new DustParticleEffect(
            new Vector3f(0.2f, 0.7f, 0.2f),    // Vibrant green
            2.0f
    );

    private static final ParticleEffect FEET_PARTICLE = new DustParticleEffect(
            new Vector3f(0.15f, 0.55f, 0.15f),  // Deeper forest green
            1.8f
    );

    // Alternative: Magical nature (green-gold)
    private static final ParticleEffect PLANT_MAGIC_PARTICLE = new DustParticleEffect(
            new Vector3f(0.5f, 0.8f, 0.2f),    // Leafy green-yellow
            2.0f
    );

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, world, entity, slot, selected);

        if (entity instanceof LivingEntity livingEntity) {
            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof ServerWorld serverWorld) {
                if (world.getTime() % 2 == 0) { // Every other tick
                    double x = livingEntity.getX();
                    double y = livingEntity.getY() + 0.1; // Feet level
                    double z = livingEntity.getZ();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.random.nextDouble() - 0.5) * 0.6;
                        double offsetZ = (world.random.nextDouble() - 0.5) * 0.6;

                        serverWorld.spawnParticles(
                                ParticleTypes.COMPOSTER,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );

                        serverWorld.spawnParticles(
                                ParticleTypes.SPORE_BLOSSOM_AIR,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Spawn colored dust at feet
                    serverWorld.spawnParticles(
                            FEET_PARTICLE,
                            x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );
                }
            }
        }
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Call the parent method to apply damage
        boolean result = super.postHit(stack, target, attacker);
        // Add particles on hit
        if (attacker.getWorld() instanceof ServerWorld serverWorld) {
            // Effects
            StatusEffectInstance poisonEffect = new StatusEffectInstance(
                    StatusEffects.POISON,
                    60,
                    2,
                    true,
                    false);
            target.addStatusEffect(poisonEffect);
            // Spawn particles at the target's position
            serverWorld.spawnParticles(
                    HIT_PARTICLE,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    40,
                    0.5,  0.5, 0.5,
                    0.01 );
            // Play a sound effect
            serverWorld.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.BLOCK_GRASS_BREAK,
                    SoundCategory.PLAYERS,
                    1.0f,
                    1.0f);
        }
        return result;
    }
}