package mh837.gile.tool;

import net.minecraft.item.SmithingTemplateItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.List;

public class FateUpgradeSmithingTemplateItem extends SmithingTemplateItem {

    public FateUpgradeSmithingTemplateItem() {
        super(
                Text.empty(),
                Text.empty(),
                Text.translatable("trim_pattern.gilemod.fate_upgrade").formatted(Formatting.GRAY),
                Text.empty(),
                Text.empty(),
                List.of(),
                List.of()
        );
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("trim_pattern.gilemod.fate_upgrade").formatted(Formatting.GRAY));
        tooltip.add(Text.empty());
        tooltip.add(Text.translatable("item.minecraft.smithing_template.applies_to").formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("smithing_template.gilemod.fate_upgrade.applies_to").formatted(Formatting.BLUE));
        tooltip.add(Text.translatable("item.minecraft.smithing_template.ingredients").formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("smithing_template.gilemod.fate_upgrade.ingredients").formatted(Formatting.BLUE));
    }
}