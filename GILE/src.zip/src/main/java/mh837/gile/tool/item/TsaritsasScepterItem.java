package mh837.gile.tool.item;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class TsaritsasScepterItem extends SwordItem {
    public TsaritsasScepterItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        return Text.translatable(this.getTranslationKey(stack)).styled(style ->
                style.withColor(net.minecraft.util.Formatting.YELLOW)
        );
    }

    private static final ParticleEffect HIT_PARTICLE = new DustParticleEffect(
            new Vector3f(0.6f, 0.8f, 1.0f),
            2.0f
    );

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Call the parent method to apply damage
        boolean result = super.postHit(stack, target, attacker);
        // Add particles on hit
        if (attacker.getWorld() instanceof ServerWorld serverWorld) {
            // Spawn particles at the target's position
            serverWorld.spawnParticles(
                    HIT_PARTICLE,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    40,
                    0.5,  0.5, 0.5,
                    0.01 );
            // Play a sound effect
            serverWorld.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.BLOCK_GLASS_BREAK,
                    SoundCategory.PLAYERS,
                    1.0f,
                    1.0f);
        }
        return result;
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, world, entity, slot, selected);

        if (entity instanceof LivingEntity livingEntity) {
            // Apply effects constantly when held in main hand or offhand
            boolean isHeld = selected || livingEntity.getOffHandStack() == stack;

            if (isHeld) {
                // Constant Speed I effect (infinite duration, no particles)
                livingEntity.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.RESISTANCE,
                        1,
                        1,
                        false, // No ambient particles
                        false, // No icon particles
                        true   // Show icon
                ));}
            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof ServerWorld serverWorld) {
                if (world.getTime() % 2 == 0) { // Every other tick
                    double x = livingEntity.getX();
                    double y = livingEntity.getY() + 0.1; // Feet level
                    double z = livingEntity.getZ();

                    // Spawn frost particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.random.nextDouble() - 0.5) * 0.6;
                        double offsetZ = (world.random.nextDouble() - 0.5) * 0.6;

                        // Frost Walker-style ice particles
                        serverWorld.spawnParticles(
                                ParticleTypes.SNOWFLAKE, // Snowflake particles like Frost Walker
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Additional frost effects
                    // Blue-white dust particles for cold aura
                    serverWorld.spawnParticles(
                            new DustParticleEffect(
                                    new Vector3f(0.6f, 0.8f, 1.0f), // Ice blue color
                                    1.0f
                            ), x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );

                    // Ultra-sensitive Frost Walker - freezes all water in radius
                    if (world.getTime() % 2 == 0) { // Every other tick for maximum responsiveness
                        BlockPos playerPos = livingEntity.getBlockPos();
                        int radius = 2;
                        // Check multiple vertical levels
                        for (int yOffset = -1; yOffset <= 1; yOffset++) {
                            BlockPos checkCenter = playerPos.add(0, yOffset, 0);
                            for (BlockPos pos : BlockPos.iterateOutwards(checkCenter, radius, 0, radius)) {
                                // Use sphere shape for more natural freezing
                                double distance = Math.sqrt(pos.getSquaredDistance(playerPos.getX(), playerPos.getY(), playerPos.getZ()));
                                if (distance <= radius) {
                                    BlockState state = world.getBlockState(pos);
                                    // Freeze water
                                    if (state.isOf(Blocks.WATER)) {
                                        world.setBlockState(pos, Blocks.FROSTED_ICE.getDefaultState());
                                    }
                                    // Freeze adjacent water blocks too
                                    if (distance <= radius - 1) { // Inner radius gets extra freezing
                                        for (BlockPos neighborPos : BlockPos.iterateOutwards(pos, 1, 1, 1)) {
                                            if (world.getBlockState(neighborPos).isOf(Blocks.WATER)) {
                                                world.setBlockState(neighborPos, Blocks.FROSTED_ICE.getDefaultState());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // Play frost sound effect when freezing water
                        if (world.getTime() % 20 == 0) {
                            serverWorld.playSound(
                                    null,
                                    livingEntity.getX(), livingEntity.getY(), livingEntity.getZ(),
                                    SoundEvents.BLOCK_GLASS_PLACE,
                                    SoundCategory.PLAYERS,
                                    0.3f,
                                    1.5f
                            );
                        }
                    }
                }
            }
        }
    }
}