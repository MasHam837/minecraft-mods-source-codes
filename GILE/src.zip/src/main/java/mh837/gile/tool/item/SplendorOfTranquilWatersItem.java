package mh837.gile.tool.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.joml.Vector3f;

import java.util.Map;
import java.util.WeakHashMap;

public class SplendorOfTranquilWatersItem extends SwordItem {

    // A transient map to track the height at which an entity started falling
    private static final Map<Entity, Double> FALL_START_Y = new WeakHashMap<>();

    public SplendorOfTranquilWatersItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        return Text.translatable(this.getTranslationKey(stack)).styled(style ->
                style.withColor(net.minecraft.util.Formatting.YELLOW)
        );
    }

    private static final ParticleEffect HIT_PARTICLE = new DustParticleEffect(
            new Vector3f(0.1f, 0.1f, 0.85f),
            2.0f
    );

    private static final ParticleEffect FEET_PARTICLE = new DustParticleEffect(
            new Vector3f(0.3f, 0.3f, 0.85f),
            1.0f
    );

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, world, entity, slot, selected);

        if (entity instanceof LivingEntity livingEntity) {

            // If the item is not in the main hand, remove them from the fall tracker
            if (!selected) {
                FALL_START_Y.remove(livingEntity);
                return;
            }

            // --- CUSTOM FALL TRACKING FOR THE SPLASH ANIMATION ---
            if (!livingEntity.isOnGround() && livingEntity.getVelocity().y < -0.1) {
                // Record the exact Y height when they start falling
                FALL_START_Y.putIfAbsent(livingEntity, livingEntity.getY());
            } else if (livingEntity.isOnGround()) {
                // They just landed. Check how far they fell
                Double startY = FALL_START_Y.remove(livingEntity);

                if (startY != null && world instanceof ServerWorld serverWorld) {
                    double fallHeight = startY - livingEntity.getY();

                    // Trigger the dynamic splash if they fell 4 or more blocks
                    if (fallHeight >= 4.0) {
                        double x = livingEntity.getX();
                        double y = livingEntity.getY();
                        double z = livingEntity.getZ();

                        // --- DYNAMIC SCALING MATH ---
                        // Cap the fall height at 100 blocks to prevent server lag from too many particles
                        double effectiveFall = Math.min(fallHeight, 100.0);

                        // Count scales linearly with height (maxes out around 1500 particles total)
                        int splashCount = (int) (effectiveFall * 15);
                        int bubbleCount = (int) (effectiveFall * 4);
                        int dustCount   = (int) (effectiveFall * 8);

                        // Spread and Speed scale up to make huge falls explode outwards wider
                        double spread = 0.5 + (effectiveFall * 0.03);
                        double speed  = 0.1 + (effectiveFall * 0.005);

                        // Sound gets louder and deeper (lower pitch) the further you fall
                        float volume = (float) Math.min(4.0, 1.0 + (effectiveFall * 0.05));
                        float pitch  = (float) Math.max(0.6, 1.5 - (effectiveFall * 0.01));

                        // 1. Explosive outward water splash
                        serverWorld.spawnParticles(ParticleTypes.SPLASH, x, y, z, splashCount, spread, 0.5, spread, speed);
                        // 2. Popping bubbles for detail
                        serverWorld.spawnParticles(ParticleTypes.BUBBLE_POP, x, y, z, bubbleCount, spread * 0.7, 0.2, spread * 0.7, speed * 0.5);
                        // 3. A blast of your custom blue dust
                        serverWorld.spawnParticles(FEET_PARTICLE, x, y, z, dustCount, spread, 0.2, spread, speed * 0.8);

                        // 4. Play the vanilla high-speed dive splash sound
                        serverWorld.playSound(null, x, y, z, SoundEvents.ENTITY_PLAYER_SPLASH_HIGH_SPEED, SoundCategory.PLAYERS, volume, pitch);
                    }
                }
            }
            // -----------------------------------------------------

            // 1. Reset fall distance on BOTH client and server to prevent damage and camera jerking
            livingEntity.fallDistance = 0.0F;

            // 2. Handle server-side only logic (Effects and Particles)
            if (world instanceof ServerWorld serverWorld) {
                // Constant Reg I effect (infinite duration, no particles)
                livingEntity.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.REGENERATION,
                        3,
                        1,
                        false, // No ambient particles
                        false, // No icon particles
                        true   // Show icon
                ));
                livingEntity.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.WATER_BREATHING,
                        1,
                        0,
                        false,
                        false,
                        true
                ));

                if (world.getTime() % 2 == 0) { // Every other tick
                    double x = livingEntity.getX();
                    double y = livingEntity.getY() + 0.1; // Feet level
                    double z = livingEntity.getZ();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.random.nextDouble() - 0.5) * 0.6;
                        double offsetZ = (world.random.nextDouble() - 0.5) * 0.6;

                        serverWorld.spawnParticles(
                                ParticleTypes.SPLASH,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );

                        serverWorld.spawnParticles(
                                ParticleTypes.BUBBLE,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );

                        serverWorld.spawnParticles(
                                ParticleTypes.BUBBLE_COLUMN_UP,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Spawn colored dust at feet
                    serverWorld.spawnParticles(
                            FEET_PARTICLE,
                            x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );
                }
            }
        }
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Call the parent method to apply damage
        boolean result = super.postHit(stack, target, attacker);
        // Add particles on hit
        if (attacker.getWorld() instanceof ServerWorld serverWorld) {
            // Spawn particles at the target's position
            serverWorld.spawnParticles(
                    HIT_PARTICLE,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    40,
                    0.5,  0.5, 0.5,
                    0.01 );
            serverWorld.spawnParticles(
                    ParticleTypes.BUBBLE,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    40,
                    0.5,  0.5, 0.5,
                    0.01 );
            // Play a sound effect
            serverWorld.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.ENTITY_PLAYER_SPLASH,
                    SoundCategory.PLAYERS,
                    1.0f,
                    1.0f);
        }
        return result;
    }
}