package mh837.gile.tool.item;

import mh837.gile.GileMod;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

public class ShadowClockItem extends Item {

    public ShadowClockItem(Settings settings) {
        super(settings);
    }

    // =========================================================
    // 1. RIGHT CLICK SIGN = CREATE / REPLACE WARP
    // =========================================================

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {

        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        ItemStack stack = context.getStack();
        PlayerEntity player = context.getPlayer();

        if (player == null || world.isClient()) {
            return ActionResult.SUCCESS;
        }

        // =========================================================
        // SHIFT RIGHT CLICK = UNLINK
        // =========================================================

        if (player.isSneaking()) {

            if (stack.contains(DataComponentTypes.CUSTOM_DATA)) {

                stack.remove(DataComponentTypes.CUSTOM_DATA);

                world.playSound(
                        null,
                        player.getX(),
                        player.getY(),
                        player.getZ(),
                        SoundEvents.BLOCK_RESPAWN_ANCHOR_DEPLETE,
                        SoundCategory.PLAYERS,
                        0.7F,
                        1.3F
                );

                ((ServerWorld) world).spawnParticles(
                        ParticleTypes.SMOKE,
                        player.getX(),
                        player.getY() + 1.0,
                        player.getZ(),
                        15,
                        0.2,
                        0.2,
                        0.2,
                        0.03
                );

                player.sendMessage(
                        Text.translatable("message.gilemod.shadow_clock.unlinked")
                                .formatted(Formatting.GOLD),
                        true
                );

                return ActionResult.SUCCESS;
            }
        }

        BlockEntity blockEntity = world.getBlockEntity(pos);

        // Non-sign block -> use teleport behavior instead
        if (!(blockEntity instanceof SignBlockEntity sign)) {
            return this.use(world, player, context.getHand()).getResult();
        }

        // Read sign text
        Text rawText = sign.getFrontText().getMessage(0, false);

        String signText = rawText.getString().trim();
        String warpName = signText.isBlank() ? "Warp Point" : signText;

        // Safe teleport position ABOVE sign
        BlockPos warpPos = pos;

        // Save custom data
        NbtCompound nbt = new NbtCompound();

        nbt.putInt("X", warpPos.getX());
        nbt.putInt("Y", warpPos.getY());
        nbt.putInt("Z", warpPos.getZ());

        nbt.putString("Name", warpName);

        nbt.putString(
                "Dimension",
                world.getRegistryKey().getValue().toString()
        );

        // Save sign color if present
        Style style = rawText.getStyle();

        if (style.getColor() != null) {
            nbt.putString("Color", style.getColor().getName());
        }

        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));

        // Visuals
        world.playSound(
                null,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE,
                SoundCategory.PLAYERS,
                1.0F,
                1.0F
        );

        ((ServerWorld) world).spawnParticles(
                ParticleTypes.GLOW,
                warpPos.getX() + 0.5,
                warpPos.getY() + 0.5,
                warpPos.getZ() + 0.5,
                30,
                0.3,
                0.3,
                0.3,
                0.05
        );

        player.sendMessage(
                Text.literal("Warp linked to: ")
                        .formatted(Formatting.GRAY)
                        .append(Text.literal(warpName).formatted(Formatting.AQUA)),
                true
        );

        return ActionResult.SUCCESS;
    }

    // =========================================================
    // 2. RIGHT CLICK AIR = TELEPORT
    // =========================================================

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {

        ItemStack stack = user.getStackInHand(hand);

        if (world.isClient()) {
            return TypedActionResult.success(stack);
        }

        // No warp stored
        if (!stack.contains(DataComponentTypes.CUSTOM_DATA)) {

            user.sendMessage(
                    Text.translatable("message.gilemod.shadow_clock.click_sign")
                            .formatted(Formatting.GREEN),
                    true
            );

            return TypedActionResult.success(stack);
        }

        NbtCompound nbt = stack.get(DataComponentTypes.CUSTOM_DATA).copyNbt();

        if (!nbt.contains("X")) {

            user.sendMessage(
                    Text.translatable("message.gilemod.shadow_clock.click_sign")
                            .formatted(Formatting.GREEN),
                    true
            );

            return TypedActionResult.success(stack);
        }

        // Dimension validation
        String dimensionId = nbt.getString("Dimension");

        if (!world.getRegistryKey().getValue().toString().equals(dimensionId)) {

            user.sendMessage(
                    Text.translatable("message.gilemod.shadow_clock.wrong_dimension")
                            .formatted(Formatting.RED),
                    true
            );

            return TypedActionResult.fail(stack);
        }

        BlockPos targetPos = new BlockPos(
                nbt.getInt("X"),
                nbt.getInt("Y"),
                nbt.getInt("Z")
        );

        // Sign should still exist below warp position
        BlockPos signPos = targetPos;

        if (!(world.getBlockEntity(signPos) instanceof SignBlockEntity)) {

            user.sendMessage(
                    Text.translatable("message.gilemod.shadow_clock.missing_sign")
                            .formatted(Formatting.RED),
                    true
            );

            world.playSound(
                    null,
                    user.getX(),
                    user.getY(),
                    user.getZ(),
                    SoundEvents.ENTITY_WITHER_BREAK_BLOCK,
                    SoundCategory.PLAYERS,
                    0.5F,
                    1.5F
            );

            return TypedActionResult.fail(stack);
        }

        // =====================================================
// CHRONO GEAR CHECK
// =====================================================

        if (!user.isCreative()) {

            boolean hasChronoGear = false;

            for (int i = 0; i < user.getInventory().size(); i++) {

                ItemStack inventoryStack = user.getInventory().getStack(i);

                if (inventoryStack.isOf(GileMod.CHRONO_GEAR)) {

                    hasChronoGear = true;

                    inventoryStack.decrement(1);

                    break;
                }
            }

            if (!hasChronoGear) {

                user.sendMessage(
                        Text.translatable("message.gilemod.shadow_clock.no_chrono_gear")
                                .formatted(Formatting.RED),
                        true
                );

                return TypedActionResult.fail(stack);
            }
        }

        // =====================================================
        // TELEPORT
        // =====================================================

        if (user instanceof ServerPlayerEntity serverPlayer) {

            serverPlayer.teleport(
                    (ServerWorld) world,
                    targetPos.getX() + 0.5,
                    targetPos.getY(),
                    targetPos.getZ() + 0.5,
                    user.getYaw(),
                    user.getPitch()
            );

            world.playSound(
                    null,
                    targetPos.getX(),
                    targetPos.getY(),
                    targetPos.getZ(),
                    SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                    SoundCategory.PLAYERS,
                    1.0F,
                    1.0F
            );

            ((ServerWorld) world).spawnParticles(
                    ParticleTypes.PORTAL,
                    targetPos.getX() + 0.5,
                    targetPos.getY() + 0.5,
                    targetPos.getZ() + 0.5,
                    40,
                    0.5,
                    0.5,
                    0.5,
                    0.2
            );
        }

        return TypedActionResult.success(stack);
    }

    // =========================================================
    // 3. GLINT WHEN LINKED
    // =========================================================

    @Override
    public boolean hasGlint(ItemStack stack) {

        if (!stack.contains(DataComponentTypes.CUSTOM_DATA)) {
            return false;
        }

        NbtCompound nbt = stack.get(DataComponentTypes.CUSTOM_DATA).copyNbt();

        return nbt.contains("X");
    }

    // =========================================================
    // 4. TOOLTIP
    // =========================================================

    @Override
    public void appendTooltip(ItemStack stack,
                              TooltipContext context,
                              List<Text> tooltip,
                              TooltipType type) {

        if (!stack.contains(DataComponentTypes.CUSTOM_DATA)) {

            tooltip.add(
                    Text.translatable("tooltip.gilemod.shadow_clock.unlinked")
                            .formatted(Formatting.GRAY)
            );

            return;
        }

        NbtCompound nbt = stack.get(DataComponentTypes.CUSTOM_DATA).copyNbt();

        if (!nbt.contains("X")) {

            tooltip.add(
                    Text.translatable("tooltip.gilemod.shadow_clock.unlinked")
                            .formatted(Formatting.GRAY)
            );

            return;
        }

        int x = nbt.getInt("X");
        int y = nbt.getInt("Y");
        int z = nbt.getInt("Z");

        String name = nbt.getString("Name");

        // Coordinates
        tooltip.add(
                Text.translatable("tooltip.gilemod.shadow_clock.coordinates")
                        .formatted(Formatting.GRAY)
                        .append(
                                Text.literal(x + ", " + y + ", " + z)
                                        .formatted(Formatting.AQUA)
                        )
        );

        // Warp name
        if (!name.isBlank() && !name.equals("Warp Point")) {

            MutableText warpText = Text.literal(name);

            if (nbt.contains("Color")) {

                try {

                    Formatting formatting =
                            Formatting.valueOf(nbt.getString("Color").toUpperCase());

                    warpText.formatted(formatting);

                } catch (Exception ignored) {
                }
            }

            tooltip.add(
                    Text.translatable("tooltip.gilemod.shadow_clock.linked_warp")
                            .formatted(Formatting.GRAY)
                            .append(warpText)
            );
        }

        tooltip.add(
                Text.translatable("tooltip.gilemod.shadow_clock.consumes")
                        .formatted(Formatting.GRAY)
                        .append(
                                Text.translatable("item.gilemod.chrono_gear")
                                        .formatted(Formatting.LIGHT_PURPLE)
                        )
        );
    }
}