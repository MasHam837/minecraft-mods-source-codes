package mh837.gile.tool.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

public class FateSwordItem extends SwordItem {
    public FateSwordItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Call the parent method to apply damage
        boolean result = super.postHit(stack, target, attacker);
        // Add particles on hit
        if (attacker.getWorld() instanceof ServerWorld serverWorld) {
            // Spawn particles at the target's position
            serverWorld.spawnParticles(
                    ParticleTypes.FIREWORK,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    40,
                    0.5,  0.5, 0.5,
                    0.1 );
            // Play a sound effect
            serverWorld.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK,
                    SoundCategory.PLAYERS,
                    1.0f,
                    1.0f);
        }
        return result;
    }
}