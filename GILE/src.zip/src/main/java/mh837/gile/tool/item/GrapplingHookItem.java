package mh837.gile.tool.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import static net.minecraft.entity.EquipmentSlot.MAINHAND;
import static net.minecraft.entity.EquipmentSlot.OFFHAND;

public class GrapplingHookItem extends Item {

    private static class GrappleState {
        final Vec3d target;
        int ticksActive = 0;

        GrappleState(Vec3d target) {
            this.target = target;
        }
    }

    private final Map<UUID, GrappleState> activeHooks = new ConcurrentHashMap<>();

    public GrapplingHookItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        // --- UPDATED: Distance increased from 32.0 to 64.0 blocks ---
        double maxDistance = 64.0;
        Vec3d eyePos = user.getEyePos();
        Vec3d lookVec = user.getRotationVec(1.0F);
        Vec3d traceEnd = eyePos.add(lookVec.multiply(maxDistance));

        BlockHitResult hitResult = world.raycast(new RaycastContext(
                eyePos,
                traceEnd,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                user
        ));

        if (hitResult.getType() == HitResult.Type.BLOCK) {
            Vec3d hookPoint = hitResult.getPos();

            if (!world.isClient()) {
                activeHooks.put(user.getUuid(), new GrappleState(hookPoint));

                // 3 second cooldown remains active
                user.getItemCooldownManager().set(this, 60);

                world.playSound(null, user.getX(), user.getY(), user.getZ(),
                        SoundEvents.ENTITY_WIND_CHARGE_THROW, SoundCategory.PLAYERS, 1.0F, 1.5F);

                if (user instanceof ServerPlayerEntity serverPlayer) {
                    stack.damage(
                            1,
                            serverPlayer,
                            hand == Hand.MAIN_HAND ? MAINHAND : OFFHAND
                    );
                }
            }
            return TypedActionResult.success(stack);
        } else {
            if (!world.isClient()) {
                world.playSound(null, user.getX(), user.getY(), user.getZ(),
                        SoundEvents.BLOCK_CHAIN_BREAK, SoundCategory.PLAYERS, 0.5F, 0.8F);
            }
        }

        return TypedActionResult.pass(stack);
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (world.isClient() || !(entity instanceof ServerPlayerEntity player)) return;

        UUID uuid = player.getUuid();
        if (!activeHooks.containsKey(uuid)) return;

        boolean isHolding = player.getMainHandStack() == stack || player.getOffHandStack() == stack;
        if (!isHolding) {
            activeHooks.remove(uuid);
            return;
        }

        GrappleState state = activeHooks.get(uuid);
        state.ticksActive++;
        Vec3d currentPos = player.getPos();

        // --- UPDATED: Timeout filter increased from 80 to 120 ticks ---
        // This gives you up to 6 full seconds to cross the massive 64-block gap.
        if (state.ticksActive > 120) {
            activeHooks.remove(uuid);
            return;
        }

        if (currentPos.distanceTo(state.target) < 2.2) {
            activeHooks.remove(uuid);
            return;
        }

        if (state.ticksActive > 5 && player.isOnGround()) {
            activeHooks.remove(uuid);
            return;
        }

        spawnRopeParticles((ServerWorld) world, player.getEyePos(), state.target);

        Vec3d pullDirection = state.target.subtract(currentPos);
        double pullSpeed = 0.85;
        Vec3d velocityVector = pullDirection.normalize().multiply(pullSpeed);

        player.setVelocity(velocityVector.x, velocityVector.y + 0.1, velocityVector.z);
        player.velocityModified = true;
        player.fallDistance = 0.0F;
    }

    private void spawnRopeParticles(ServerWorld world, Vec3d start, Vec3d end) {
        double distance = start.distanceTo(end);
        int particleCount = (int) (distance * 2);

        for (int i = 0; i <= particleCount; i++) {
            double pct = (double) i / particleCount;
            double x = start.x + (end.x - start.x) * pct;
            double y = start.y + (end.y - start.y) * pct;
            double z = start.z + (end.z - start.z) * pct;

            world.spawnParticles(ParticleTypes.CRIT, x, y, z, 1, 0, 0, 0, 0);
        }
    }
}