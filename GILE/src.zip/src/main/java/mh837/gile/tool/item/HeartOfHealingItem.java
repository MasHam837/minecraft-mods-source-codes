package mh837.gile.tool.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class HeartOfHealingItem extends Item {

    public HeartOfHealingItem(Settings settings) {
        super(settings);}

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {

        if (entity instanceof PlayerEntity player && !world.isClient()) {

            if (player.getItemCooldownManager().isCoolingDown(this)) {
                return;}
            float lowHealthThreshold = player.getMaxHealth() * 0.2F;

            if (player.getHealth() < lowHealthThreshold) {
                executeEmergencyHeal(stack, (ServerWorld) world, player);
                player.getItemCooldownManager().set(this, 20);
            }
        }

        super.inventoryTick(stack, world, entity, slot, selected);
    }

    private void executeEmergencyHeal(ItemStack stack, ServerWorld world, PlayerEntity player) {

        player.addStatusEffect(new StatusEffectInstance(StatusEffects.INSTANT_HEALTH, 1, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 3));

        world.playSound(
                null,
                player.getX(), player.getY(), player.getZ(),
                SoundEvents.ITEM_TOTEM_USE,
                SoundCategory.PLAYERS,
                1.0F, 1.2F);

        world.spawnParticles(
                ParticleTypes.HEART,
                player.getX(), player.getY(), player.getZ(),
                15, 0.4, 0.4, 0.4, 0.1);

        // Consume only this stack
        stack.decrement(1);
    }
}