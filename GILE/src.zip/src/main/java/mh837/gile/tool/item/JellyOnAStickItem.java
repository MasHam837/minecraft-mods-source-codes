package mh837.gile.tool.item;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemSteerable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class JellyOnAStickItem extends Item {
    public JellyOnAStickItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack itemStack = user.getStackInHand(hand);

        // Check if the player is riding an entity capable of being steered
        if (user.hasVehicle() && user.getVehicle() instanceof ItemSteerable itemSteerable) {

            // consumeOnAStickItem checks if the ghost is saddled. If true, it activates the boost.
            if (itemSteerable.consumeOnAStickItem()) {

                // Only modify item stacks and check durability on the logical server side
                if (!world.isClient && !user.isCreative()) {
                    EquipmentSlot equipmentSlot = hand == Hand.MAIN_HAND ?
                            EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND;

                    itemStack.damage(1, user, equipmentSlot);

                    // If the item breaks, replace it cleanly with a regular fishing rod frame
                    if (itemStack.isEmpty()) {
                        ItemStack fishingRod = new ItemStack(Items.FISHING_ROD);

                        // Safely transfer 1.21.1 custom data components over to the broken frame
                        NbtComponent nbtComponent = itemStack.get(DataComponentTypes.CUSTOM_DATA);
                        if (nbtComponent != null) {
                            fishingRod.set(DataComponentTypes.CUSTOM_DATA, nbtComponent);
                        }
                        return TypedActionResult.success(fishingRod);
                    }
                }

                // Returns success on both client and server to synchronize animations and network packets
                return TypedActionResult.success(itemStack);
            }
        }

        // If the player isn't riding your ghost, pass the interaction to default behavior
        return TypedActionResult.pass(itemStack);
    }
}