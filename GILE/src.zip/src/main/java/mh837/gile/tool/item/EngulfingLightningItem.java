package mh837.gile.tool.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class EngulfingLightningItem extends SwordItem {
    public EngulfingLightningItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        return Text.translatable(this.getTranslationKey(stack)).styled(style ->
                style.withColor(net.minecraft.util.Formatting.YELLOW)
        );
    }

    private static final ParticleEffect HIT_PARTICLE = new DustParticleEffect(
            new Vector3f(0.5f, 0.1f, 0.9f),
            1.0f
    );

    private static final ParticleEffect FEET_PARTICLE = new DustParticleEffect(
            new Vector3f(0.5f, 0.3f, 0.9f),
            0.75f
    );

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, world, entity, slot, selected);

        if (entity instanceof LivingEntity livingEntity) {
            // Apply effects constantly when held in main hand or offhand
            boolean isHeld = selected || livingEntity.getOffHandStack() == stack;

            if (isHeld) {
                // Constant Speed I effect (infinite duration, no particles)
                livingEntity.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.FIRE_RESISTANCE,
                        1,
                        0,
                        false, // No ambient particles
                        false, // No icon particles
                        true   // Show icon
                ));
            }

            // Spawn particles at feet when selected in main hand
            if (selected && world instanceof ServerWorld serverWorld) {
                if (world.getTime() % 2 == 0) { // Every other tick
                    double x = livingEntity.getX();
                    double y = livingEntity.getY() + 0.1; // Feet level
                    double z = livingEntity.getZ();

                    // Spawn particles around the player's feet
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (world.random.nextDouble() - 0.5) * 0.6;
                        double offsetZ = (world.random.nextDouble() - 0.5) * 0.6;

                        serverWorld.spawnParticles(
                                ParticleTypes.ELECTRIC_SPARK,
                                x + offsetX,
                                y,
                                z + offsetZ,
                                1,
                                0.0, 0.05, 0.0, // Minimal spread
                                0.02 // Slow rising
                        );
                    }

                    // Spawn colored dust at feet
                    serverWorld.spawnParticles(
                            FEET_PARTICLE, x, y, z,
                            1,
                            0.3, 0.05, 0.3,
                            0.01
                    );

                    // Occasional smoke
                    if (world.getTime() % 6 == 0) {
                        serverWorld.spawnParticles(
                                ParticleTypes.END_ROD,
                                x,
                                y + 0.3,
                                z,
                                1,
                                0.2, 0.1, 0.2,
                                0.01
                        );
                    }
                }
            }
        }
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // Call the parent method to apply damage
        boolean result = super.postHit(stack, target, attacker);

        // Add lightning and particles on hit
        if (attacker.getWorld() instanceof ServerWorld serverWorld) {
            World world = attacker.getWorld();

            // SUMMON LIGHTNING BOLT at the target's position
            LightningEntity lightning = new LightningEntity(EntityType.LIGHTNING_BOLT, world);
            lightning.setPosition(target.getX(), target.getY(), target.getZ());
            world.spawnEntity(lightning);

            // Spawn electric particles
            serverWorld.spawnParticles(
                    HIT_PARTICLE,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    60,
                    0.8, 0.8, 0.8,
                    0.5
            );

            // Add spark particles
            serverWorld.spawnParticles(
                    net.minecraft.particle.ParticleTypes.ELECTRIC_SPARK,
                    target.getX(),
                    target.getY() + target.getHeight() / 2,
                    target.getZ(),
                    30,
                    0.5, 0.5, 0.5,
                    0.2
            );

            // Play thunder sound
            serverWorld.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                    SoundCategory.PLAYERS,
                    1.0f,
                    1.0f
            );

            // Electric crackle sound
            serverWorld.playSound(
                    null,
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    SoundEvents.BLOCK_BEACON_POWER_SELECT,
                    SoundCategory.PLAYERS,
                    1.0f,
                    0.5f
            );
        }

        return result;
    }
}